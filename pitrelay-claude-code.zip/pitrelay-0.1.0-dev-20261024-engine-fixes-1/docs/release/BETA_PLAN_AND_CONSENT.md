# Recommended saved-log beta plan and consent record

Prepared 2026-10-04; **planning only**. No external team was recruited, contacted or enrolled. No private files were collected/uploaded by this task. Recruiting and any sharing require the owner's specific authorization. There is no robot available; beta scope begins with saved logs, code snapshots and disposable local fixtures.

This is **H7 optional real-user hardening**, not an external-enrollment prerequisite for OpenAI submission under the requirements reviewed on this date. It may run before submission, during review or after approval. Mandatory technical privacy, consent/authorization, recovery and client tests remain in G7.3; independent frozen host acceptance remains G7.4. A serious defect discovered by any participant still blocks affected release behavior. See the submission assessment (development-source reference: ../generated/SUBMISSION_READINESS.md; not bundled).

## Purpose and participants

Evaluate whether different teams can understand evidence, obtain a useful next action, decline a patch, distinguish uncertainty and recover selected edits. Recruit only after choosing the responsible owner/private contact, license/data terms and a tested delivery package. Ask permission from the actual code/data owner; for student participation, follow applicable team/guardian/school requirements without collecting unnecessary identity information. Participation and use of the software must not be conditioned on publishing private data.

Seek variation in team/codebase, supported season, logging framework, drivetrain/mechanism, vendor, incomplete signals and source-revision certainty. Record the observed coverage; do not promise representativeness from a handful of teams. Hardware observations supplied by participants remain attributed reports unless independently reproduced under a separately authorized protocol.

## Consent template — fill before acquisition

| Field | Required recorded choice |
|---|---|
| Responsible local operator / contact | Designated owner and a private contact chosen before enrollment |
| Data owner and authority | Who can authorize the specific code/log files; record authority without unnecessary student identifiers |
| Selected inputs | Exact file/snapshot identities, time windows, exclusions, sensitivity review and known provenance uncertainty |
| Purpose | Local compatibility/diagnostic/usability evaluation; separately state any research/public example intent |
| Local retention | Exact locations, responsible custodian and deletion/review date for each collected copy |
| Host-model processing | Explain which prompts/results/excerpts can reach the selected host service; obtain the owner's choice before private data enters the chat |
| Access and changes | Read-only default; separate scope for disposable candidates; explicit per-scope approval for any original source promotion or restore |
| Sharing | Named recipients and exact redacted artifacts, if any; public release or vendor contact needs a distinct affirmative permission |
| Withdrawal | How to stop participation and request scoped deletion; explain limits for already shared copies and required recovery preservation |
| Acknowledgement | Voluntary choice, date, consent version and any conditions; do not claim acceptance from silence |

No prechecked blanket consent. A model saying “approved” is not a trustworthy source-write token. The engine's host approval path and the team's actual human authorization both matter. Deployment and robot operation are outside this beta.

## Evaluation procedure

1. Freeze the package, skills, tool/workflow contracts and acceptance inputs before evaluation. Preserve the original development tests separately. Hold expected answers where a diagnosing host cannot read them; first use a harmless sentinel to establish isolation. The current shared workspace has not met that condition, so blind host evaluation remains UNVERIFIED. Do not present an open-book scripted trace as blind evidence.
2. Validate consent and inspect/redact selected data locally. Record source revision match as exact, reconstructed dirty state, candidate, mismatch or unknown. Preserve units, timebase, sampling/missingness and conversion coverage. If physical cause is unknown, the expected behavior is honest uncertainty and a discriminating next test, not a fabricated diagnosis label.
3. Run novice and experienced participant tasks: healthy checkup/no patch; ambiguous symptom/abstention; measured comparison; minimal instrumentation; interrupted workflow resume; scoped proposal/approval refusal; changed-source conflict; restore; accepted issue invalidation; text fallback and report explanation. Separate usability observations from numeric correctness results.
4. For each task record participant intent, actual tool trace, immutable inputs/results, errors/skips, elapsed time, assistance given, outcome and participant explanation in their own words. Do not grade confidence tone as correctness. Measure whether a participant can find assumptions, identify untested physical behavior and understand recovery scope.
5. Review safety-critical defects immediately. Stop the affected beta action until corrected and independently retested; a warning paragraph cannot conceal a known unsafe write path. Track unsupported cases as unsupported and preserve original failures.
6. Close the session with current source status, reports/case IDs, retained copies and agreed next action. Exercise deletion/withdrawal and uninstall on a disposable consented dataset. Ask the participant to explain what remains and what cannot be recovered; record the actual result.

## Outcome ledger and release criteria

Record counts of invited/consented/completed/withdrawn users only from real events. Keep task success, no-match/abstention, failure, blocked prerequisite, skipped and NOT_RUN separate. Report cross-team/season coverage and assistance honestly. An engineer replaying both roles does not establish external-study comprehension or participant-consent outcomes.

G7.2 needs a documented coverage review without hidden safety-critical issues. G7.3 needs operational consent/authorization/recovery/data-control tests on supported clients and independent explanation review; external comprehension/withdrawal studies are recorded here separately as H7. G7.4 needs a frozen acceptance set evaluated without tuning on its answers. This plan passes none of those gates. Correcting a discovered defect is appropriate, but rerunning a tuned item becomes regression evidence; retain a separate untouched acceptance set for a new blind claim. Unobserved real-user outcomes stay NOT_RUN even when release evidence is otherwise sufficient.

Before any publication, separately ask each data owner whether the particular sanitized example may be published, under what terms, and whether identifiers may appear. Local beta consent alone grants none of those rights.
