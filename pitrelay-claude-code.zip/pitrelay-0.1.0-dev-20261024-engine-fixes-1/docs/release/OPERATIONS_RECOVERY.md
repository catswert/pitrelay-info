# Local operations, uninstall, recovery and incidents

Unreleased local development, 2026-10-04. The internal builder and operator console exist; final test/package receipts determine which bytes were verified. No native client installation or production hosted service is claimed.

## Configure and inspect

Select an existing Java 17 runtime and the tested product JAR. Keep the package and private state directory identified in a local installation receipt. New-source Standard Access uses `--state` and supplied artifacts without a team workspace path. Optional Workspace Access additionally uses `--experience workspace`, `--workspace`, explicit `--grants` and `--workspace-disclosure accepted-v1`. Explain authorized file reads, permitted development commands, checkpoints/temp files and separately approved edits before enabling it; build/replay/simulation does not prove physical safety or repair. The current source changes require a new validated package; frozen V4 retains its old syntax. `org.pitrelay.Main` remains the product entry class. MCP configuration uses an actual executable, argument array and `--mode mcp`; no build script runs during installation.

Verify engine/tool/workflow compatibility, capability availability and actual execution location before reading private project data. A missing fixture/converter capability is a prerequisite limitation. It is not a successful empty analysis. Preserve the original resource lock and package hashes; never self-update upstream or substitute the newest vendor dependency at startup.

The builder is `scripts/package_local.py`: `build` requires a new workspace development-package destination, a selected JAR and its exact SHA256; `verify` checks mandatory files, entry points and hashes; `config` creates a new literal-path TOML example without installing it. An existing package/archive/config is never overwritten. Source-package parsing, local CLI/MCP subprocess tests, native-client invocation and clean-machine installation are distinct checks. See [COMPATIBILITY](COMPATIBILITY.md).

The local Windows Java17 launcher may replace characters that its native code page cannot represent. Configuration refuses those paths before writing. Use representable paths for the Java executable, package, workspace and state; moving only the configuration file does not fix a classpath problem. Valid Unicode TOML is not a runtime compatibility test. No Windows regional/global setting is changed by the builder.

The package's resolved JAR path must not contain the platform classpath separator (`;` on Windows, `:` on POSIX). Java would treat it as multiple entries and could load a different file than the verified JAR. Configuration refuses this path before writing; the same restriction applies to manual `-cp` commands.

## Disconnect or stop

Persist the workflow ID, case ID, selected target and relevant artifact IDs. `workflow.status` and `workflow.report` are available even when a workflow budget is exhausted. Use `workflow.control` with the current revision to pause/cancel; cancellation only attempts cancellation of backend jobs recorded for that workflow and does not imply rollback. After reconnect, inspect current state before deciding to resume. A recorded unfinished operation may already have affected state; do not blindly retry a write. Acknowledge reconciliation only after inspecting the transaction/job/source outcome.

An idle disconnected host is not continuing autonomous model reasoning. Process disappearance does not prove a backend operation succeeded or was rolled back. Keep unknown outcomes explicit.

## Recover selected source

Stop further promotions when a transaction is interrupted or the engine returns `RECOVERY_REQUIRED`. Preserve the complete selected state, journal, checkpoint IDs and current source; leave external edits intact. First diagnose unavailable storage, permissions, missing bytes or locks using read-only inspection. Restore normal storage access before resuming recovery.

Use the runtime operation descriptions to inspect the current transaction and request supported recovery. Re-read current file hashes, verify checkpoint integrity, preview the selected paths and obtain applicable trusted-host approval for any source overwrite. Restore must refuse intervening changes rather than overwrite a programmer's newer work. Preserve a fresh recovery point before a deliberate overwrite. Never use `git reset --hard`, copy a checkpoint over the whole repository, edit a journal to say “complete”, or delete state to hide a failure.

The local console entry point is `org.pitrelay.Companion` in the bundled engine JAR. New source requires `--workspace`, `--workspace-disclosure accepted-v1`, `--state`, and the full `--patch patch-<sha256>`. Default action is preview. Explicit `--action promote|restore|recover` additionally requires `--actor` and an actual console; enter the exact action followed by the complete patch ID after reviewing every selected file. There is no `--yes` or piped approval option. Grants remain internal to that process and are not returned through MCP. Console presence is cooperative confirmation, not proof of human identity.

Use restore only for the fully promoted current patch. Explicit recover handles an eligible interrupted journal whose selected files still match their checkpoint or proposed states; it returns them to checkpoint originals, preserves unrelated work, and refuses changed content, metadata or Git staging. It does not resume promotion. The review binds the current journal digest as well as source state. If receipt persistence fails after a transaction, retain the returned actual outcome and reconcile before retrying. Source/code recovery is not physical validation.

The optional `org.pitrelay.LocalHttp` entry point requires `--state`, `--port` and `--token-file`, with the same Standard/Workspace selection rules; relative token names resolve inside scoped state. It binds only127.0.0.1 and requires the owner-only token on every request. It does not provide original-source apply/restore access, remote/public/OAuth or multi-user service. A restricted Windows token unable to set a private file DACL cannot start this adapter; do not relax token permissions to work around that restriction. An exchange timeout does not cancel domain computation, and JDK pre-header timeouts are not per-instance protection.

After recovery, inspect selected content/metadata and Git staging state within the promised scope. Record exact operations, target/checkpoint IDs, restored files, exclusions and tests. A successful restore does not validate the robot's physical behavior. If evidence is corrupt or the current source conflicts, preserve both versions and stop automatic writes for operator reconciliation.

The accepted Step 2 tests include actual abrupt child-process termination and controlled partial temporary-file writes failing with `FileSystemException`. Actual power loss and physical volume exhaustion were not performed. Cooperative locks do not prevent unrestricted native shell/editor changes. Recovery is scoped to captured selected data; it is not a whole-disk backup.

## Uninstall while preserving data

1. Read the exact local installation receipt. Identify the plugin package, generated client configuration, selected engine process, state roots and exported reports.
2. Stop owned workflows/jobs safely, reconcile any transaction, and close the connection. If another process owns an active transaction, do not remove its files.
3. Remove only the PitRelay client entry or package that was actually installed, using that client's supported management flow. Preview the specific entry first. A permission to uninstall PitRelay does not authorize deleting unrelated MCP configurations or modifying global defaults.
4. Remove the verified package-output directory only after confirming it contains package files rather than source or state. Retain the installation receipt and required recovery information until verification is complete.
5. Keep team source, state, logs and exports by default. If the operator also requests deletion, apply the separate [scoped deletion procedure](PRIVACY_RETENTION.md#manual-scoped-deletion). Uninstall never means “restore the original source” automatically.
6. Verify the client no longer starts PitRelay, no associated process remains and unrelated tools still work. Record the outcome. Clean-machine install/uninstall and actual-user recovery trials remain unverified until these actions are exercised and receipts retained.

## Incident response

| Event | Immediate containment | Recovery evidence / follow-up |
|---|---|---|
| Unexpected source change or stale approval accepted | Stop new writes and preserve current files, checkpoint, approval metadata without exposing the secret | Compare exact target/base/patch hashes; reproduce in scratch; block the affected release until reviewed |
| Corrupt or incomplete evidence | Stop claims depending on it; keep original bytes | Verify artifact hashes and dependency closure; reacquire only from a known authorized source; do not rewrite history as if intact |
| Suspected approval-key exposure | Close apply sessions, stop local engine and restrict access to state | Do not publish the key; owner-controlled credential/state recovery must preserve checkpoints and invalidate old approvals before apply resumes; no automated rotation UI is claimed |
| Private file included in shared report | Stop further sharing and preserve a minimal incident record | Identify every recipient/system/copy, request deletion through those systems, notify the owner accurately; local deletion cannot revoke downloaded copies |
| Storage/permission failure or abrupt termination | Stop further promotions; retain journal/state and current source | Recover storage first, then reconcile in a fresh session; do not promise that an error means source unchanged |
| Incorrect diagnosis or unsafe advice | Withdraw the affected conclusion and preserve contrary evidence | Reopen the issue, identify observation versus hypothesis, add a regression/acceptance case independent of the diagnosing host |

The public maintainer is catswert; the published contact for privacy questions and deletion requests is pitrelay@gmail.com. Optional report collection remains closed pending its operational controls. There is no uptime commitment or emergency response SLA; reports are reviewed periodically and this is not urgent match support. Record discovery time, affected build/hash/workspace scope, actual data exposure or source impact, containment, known uncertainty and next update. Avoid unnecessarily collecting student identifiers or full private projects.

## Support packet

Share only with a specifically authorized recipient: product version and JAR hash, OS/runtime version, operation/error code, sanitized command/arguments, observed versus expected behavior, test status/counts, and a minimal reproduction using synthetic data where possible. Include a consented redacted evidence bundle only when needed. Exclude approval keys/tokens, credentials, arbitrary environment dumps, raw private logs and entire state directories. Check the bundle's contents before transmission.

This repository is the current local development support record. The published privacy contact does not authorize unsolicited private attachments. Public reporting, remote access and uploading private files require the applicable designated channel, disclosures and explicit permission. The engine does not automatically submit report packages.
