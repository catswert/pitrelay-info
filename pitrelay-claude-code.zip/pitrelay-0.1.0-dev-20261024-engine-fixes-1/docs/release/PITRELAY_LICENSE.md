# PitRelay Private Use and Modification License

Version 1.0 — October 5, 2026 local (October 6 UTC). Identifier: `LicenseRef-PitRelay-Private-1.0`.

Adopted for the local candidate that includes this version and `PITRELAY_LICENSE_SCOPE.json`. Public distribution and platform approval are separate. The historical identifier `LicenseRef-PitRelay-Unreleased` is a release-scoped alias for this license in that candidate's identified source headers and license sidecar; it does not change any earlier package's terms.

## 1. Licensor and covered material

The licensor is the individual maintainer distributing PitRelay under the public name **catswert**, contact **pitrelay@gmail.com** ("Licensor").

"Covered Material" means the original PitRelay expression in the code, workflow instructions, templates and documentation expressly identified as covered in the accompanying `PITRELAY_LICENSE_SCOPE.json`, including modifications of that Covered Material, and only to the extent that Licensor holds rights permitting these terms. A file or compiled archive may contain both Covered Material and separately licensed material. Inclusion in PitRelay does not make an entire file or archive proprietary.

Covered Material excludes third-party and previously open-licensed material, user inputs, material in the public domain, and facts, ideas, rules, methods, algorithms, functional interfaces and other elements not protected by rights Licensor holds. No ownership of independently developed software or the general concept of FRC diagnostics is asserted. Section 5 preserves third-party rights.

## 2. Permitted private use and modification

Subject to these terms, Licensor grants you a nonexclusive, royalty-free license to install, run, inspect, copy for backup, and modify Covered Material for your own use or internal use within your own FRC team or organization. You may change behavior, configuration and workflow instructions. You need not publish modifications or provide them to Licensor.

For internal use, you may maintain private working copies and make the software available to students, mentors, employees and contractors acting for that same team or organization. Their access must be limited to that internal use and comply with these terms. Public repositories, public share links and provision to unrelated teams or customers are not internal use. A private repository does not by itself authorize provision to unrelated recipients.

You may use private development services, including AI assistants such as Codex or ChatGPT, to inspect or modify Covered Material solely for the permitted use. Necessary processing by those service providers is allowed for that purpose; this does not authorize public sharing or independent redistribution of Covered Material. Provider processing remains governed by applicable provider terms and settings. This license grants no additional permission to upload someone else's private information.

## 3. Redistribution and services for others

Except as permitted by sections 2, 4 and 5, by separate written permission from Licensor, or by applicable rights that cannot be restricted:

- You may not publish, distribute, sell, sublicense, upload to a public repository or plugin directory, or otherwise provide Covered Material to others, whether unchanged or modified.
- You may not distribute a modified PitRelay plugin, repackaged engine, copied workflow skill or another product incorporating Covered Material. Changes to name, formatting, verbosity, file format, implementation language or packaging do not themselves grant distribution rights to Covered Material that remains included.
- You may not make Covered Material available to unrelated users as a hosted tool or managed service in place of their obtaining an authorized distribution of PitRelay.

Privately changing PitRelay to produce shorter answers is permitted. Republishing that changed plugin with Covered Material still included is not licensed by these terms.

You may share links to an authorized PitRelay download or listing. Licensor may separately authorize distributors, including a plugin platform, to review, cache and distribute designated official builds under agreed terms. This paragraph does not grant platform distribution permission or authorize publication of the present local candidate.

These restrictions do not prohibit independent competing implementations, independently written add-ons, commentary about PitRelay or exercise of third-party rights. No restriction on an unprotected functional equivalent is created merely by calling it a derivative.

## 4. User projects, outputs and feedback

Your input files, robot projects, telemetry and observations do not become Covered Material when processed by PitRelay. These terms do not transfer their ownership to Licensor.

You may use, modify and distribute ordinary analysis outputs, diagnostic reports, proposed robot-code patches and instrumentation generated for your project, subject to rights belonging to you or third parties. You may publish your resulting robot project. Outputs are not restricted merely because PitRelay assisted in producing them. Extracting or repackaging the engine, workflow instructions or other Covered Material does not turn it into an unrestricted ordinary output.

You may privately send Licensor relevant modifications or excerpts for bug reports and proposed improvements. Public criticism, bug reports and quotations remain permitted to the extent otherwise allowed by law. Sending feedback does not assign copyright or grant an unrestricted right to incorporate your contribution; any contribution permission needed for a release must be agreed separately. Submission remains voluntary and subject to disclosed privacy terms.

## 5. Third-party and previously licensed material

The inherited `wpilog-mcp` source and its MIT-marked adaptations, BSD-licensed adapters/resources, dependencies and other third-party components retain their own licenses. Preserve required notices. This license does not withdraw, narrow or replace existing MIT, BSD, Apache or other permissions, including permission to modify and redistribute those components.

Where Covered Material and separately licensed material appear in one file or binary, these terms apply only to Covered Material. You may obtain upstream components independently and build your own tool under their licenses. The scope inventory does not establish redistribution rights in an unreviewed vendor resource or dataset.

The accompanying scope and third-party inventories identify these distinctions. A blanket description of the entire JAR as proprietary does not supersede them. If an inventory classification conflicts with an applicable third-party grant, that grant controls for its material. No restriction is imposed on separately licensed material merely because it was modified during PitRelay development.

## 6. Notices and retained rights

Keep applicable copyright, license and attribution notices in permitted copies. Identify private modifications sufficiently to distinguish them from an official build when reporting behavior. Do not falsely present a modified copy as official or imply endorsement by Licensor, FIRST, upstream developers or a vendor.

You may reproduce and share this license, its scope record and required third-party notices unchanged to communicate applicable terms, document compliance or exercise separately granted rights. This permission to share notices does not authorize redistribution of the Covered Material they describe.

No trademark license is granted beyond truthful identification and uses otherwise permitted by law. All rights in Covered Material not expressly granted are reserved to the extent Licensor holds them. Statutory exceptions and rights that cannot lawfully be waived remain unaffected. A label or inventory entry does not create copyright, establish human authorship or assert exclusive rights in a technical function.

## 7. Verification and warranty

PitRelay provides engineering assistance. Static analysis, builds, tests, replay and simulation do not establish that a physical robot is safe or repaired. Users must assess the evidence and perform appropriate validation before using changes on hardware.

To the extent permitted by applicable law, Covered Material is provided "as is" without warranties, including merchantability, fitness for a particular purpose or noninfringement. Nothing here excludes liability or rights that applicable law does not permit to be excluded. Third-party warranty provisions remain in their respective licenses.

## 8. Version and release scope

This version applies to Covered Material supplied with a candidate or release that expressly identifies version 1.0 and includes its scope record. Its recorded source hashes identify audited source snapshots; the package manifest identifies the delivered bytes. Permitted private modifications remain subject to these terms for any Covered Material they contain. Newly added files require an updated inventory before being asserted part of an official release's scope.

Publishing a later license does not silently replace the terms of an earlier obtained release. Neither this file nor an installation acknowledgment establishes ownership, contract enforceability, publisher verification or platform acceptance. Requests for other permissions may be directed to **pitrelay@gmail.com**.
