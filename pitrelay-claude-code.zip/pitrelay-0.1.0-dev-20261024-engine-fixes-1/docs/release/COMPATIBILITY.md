# Compatibility and evidence matrix

**LOCAL-FREEZE-1 local candidate:** the engine remains exactly the accepted MANUAL-LINKS-1 JAR. [Local setup](LOCAL_INSTALLATION.md) now prepares a complete compatibility-format Codex plugin with four skills and a scoped local MCP dependency, preserving Standard Access and separate new state. Final private-use terms and source/component scope are packaged. Actual candidate client outcomes are recorded in the local-freeze client report (development-source reference: ../generated/LOCAL_FREEZE_CLIENT_REPORT.md; not bundled); package presence is not a client pass. Historical evidence below retains its original versions. ChatGPT UI/model behavior, clean-machine and public local-MCP eligibility remain unverified unless separately recorded.


**Current candidate boundary (MANUAL-LINKS-1):** current report (development-source reference: ../generated/MANUAL_LINKS_REPORT.md; not bundled) binds the latest code/package/tests. `game.manual` adds a Standard/Workspace operation without original-file or execution grants. The catalog is offline link metadata; automatic reference search/reading uses the host's actually available browsing/PDF tools and is guidance, not an engine network capability. Missing host tools require an honest supplied-manual request. The new candidate is not installed in the current native Codex session; historical V6 evidence does not validate these new bytes. Actual ChatGPT and clean-machine/client support remain UNVERIFIED. The matrix below retains dated prior evidence.

Refreshed 2026-10-05 for V6 internal development preparation, engine `support-full-3`, SHA-256 `7dac99323100f980b73202e6abd5906c8a22b04cb2365d4f3655ca48b77b3649`. This matrix distinguishes tested implementation from distribution support. STATUS (development-source reference: ../STATUS.md; not bundled) and the current package report (development-source reference: ../generated/RELEASE_PREP_PACKAGE_REPORT.md; not bundled) control acceptance; subsequent source changes do not inherit earlier test receipts.

Submission reassessment: the current route/policy ledger (development-source reference: ../generated/SUBMISSION_READINESS.md; not bundled) identifies unverified local-execution eligibility and required public MCP operation exposure/annotations. Local Codex development remains primary, but public-directory policy requirements cannot be waived merely by choosing a narrow advertised matrix. Actual new-engine native clients, clean machines and any required desktop/mobile behavior remain unverified. External private-beta enrollment is optional; client compatibility and recovery tests remain mandatory.

## Runtime and transport

Standard Access is the default full product using supplied artifacts; Workspace Access is optional granular automation through the same engine. The retained support-full-3 engine has 2,547 full-suite Java passes plus 16 matching separate HTTP passes and 89 documented standard-suite skips. Current preparation reconciles retained receipts; it does not rerun the engine suite. Package/subprocess probes have separate receipts. Installed-client attachment handoff remains unverified; native ChatGPT supplied-file access and downloadable results require actual client evidence.

| Surface | Evidence | Limit / current claim |
|---|---|---|
| Windows 11 x64 local development | Accepted Step 2 on Windows `10.0.26200`, local Temurin `17.0.20.1+1`, Gradle `8.11`, Python `3.12.14` | Development-machine evidence; clean-machine installation NOT_RUN |
| Product CLI / stdio MCP | Accepted Step 2 external-process CLI/MCP probes, plus coordinator-owned later workflow runs when recorded | Does not establish installation or host reasoning quality |
| Preserved Step 0 native Codex server | Step 0 read-tool client probe passed | Different server snapshot; do not count as new product/package client verification |
| New foundation/workflow engine in native Codex | UNVERIFIED at this preparation snapshot | Requires actual current client load, compatibility and read operations with recorded package/JAR hashes |
| ChatGPT desktop/web connection | UNVERIFIED | No remote endpoint exposed; no administrative entitlement or supported local desktop transport assumed |
| macOS / Linux / ARM | NOT_RUN | Do not advertise supported installation or native conversion; Java portability is not proof |
| Hosted multi-user HTTP | NOT_IMPLEMENTED for PitRelay product | No authentication/authorization/tenant-isolation production service; inherited upstream listeners must not be exposed as a substitute |
| Internal localhost HTTP | Implemented;16 matching support-http-3 tests passed in a retained narrowly inspected runner with a normal Windows process token | Not rerun in this preparation; owner-only token ACL creation is denied under the development sandbox; no remote ChatGPT/HTTPS/OAuth support |
| Windows launcher paths | Spaces/native-codepage characters require actual launch evidence; unmappable paths refused before configuration | Emoji-path launch failed on pinned Java17 under ANSI1252; Unicode TOML alone does not establish runtime support |
| Optional visual UI | NOT_IMPLEMENTED / client-dependent | Structured results, text and downloadable evidence are the supported design path; native rendering still needs client evidence |
| Uninstall, state retention/deletion | Written procedure only | Mandatory clean-machine/client recovery/deletion trials NOT_RUN; external-user comprehension is separate recommended hardening |

## Version identities

| Identity | Current value / source | Interpretation |
|---|---|---|
| Local package | `pitrelay`, `0.1.0-dev` | Draft manifest, not a published version |
| Product engine handshake | `0.1.0-dev` | `client.compatibility` result; verify against actual packaged bytes |
| Tool result envelope | `1.0` | Shared Foundation result semantics remain unchanged |
| Tool exposure contract | `2.0` in support-full-3; V4 was `1.0` | 114 individually registered operations; actual exposed subset depends on grants |
| Workflow contract | `2` in support-full-3; V4 was `1` | Skills require exact handshake; wrong or missing workflow admission refuses |
| Implementation attribution | `pitrelay-foundation-1` | Algorithm/result metadata; pair with source/JAR hashes |
| Inherited Gradle artifact | group `org.triplehelix`, version `0.9.1`, `wpilog-mcp-0.9.1-all.jar` | Inherited build filename, not the product compatibility version; current default Main is PitRelay and has actual packaged launch evidence |
| Engine utility dependency | `wpiutil-java 2026.2.2` | From `engine/build.gradle`; distinct from robot fixture season |
| Inspected simulation/replay fixture | WPILib `2026.2.1`, AdvantageKit `26.0.2`, Java `17`, `windowsx86-64` | Exact fixture lock (development-source reference: ../../fixtures/physics-replay/fixture.lock.json; not bundled); no automatic upgrade or compatibility with all seasons |

Stale skill versions must fail admission before execution. Bundled/imported historical evidence retains its original identities; it does not become local verification by being imported. Moving a workspace changes its canonical path-derived workspace ID. Preserve the old receipt and state; a moved folder is not silently equivalent to the previous target.

The product MCP adapters explicitly advertise protocol2025-06-18. The preserved upstream server remains on its original default. Native clients must negotiate and validate the actual selected server; no universal newest-client claim is made. CLI/stdio JSON output is UTF-8 independently of the operator console encoding.

## Data and validation coverage

The accepted foundation report covers deterministic synthetic data, independent numeric oracles, inspected WPILib/AdvantageKit simulation/replay, controlled filesystem failures, selected native log formats and two public real-input sources. These are different evidence classes. The Team 4065 sample is publisher-reported trimmed real data with conflicting upstream documentation; the original complete archive was not obtained. The CTRE sample exercises native conversion and bounded indexing. Neither has an independently authenticated physical root-cause label here. Public logs are not bundled; redistribution rights remain unresolved.

Replay evaluates recorded inputs; it is not counterfactual physics. A model's fitted/simulated behavior applies only within its stated assumptions/range. Baseline replay must pass before modified replay claims. All physical robot validation remains `not_performed`. Three isolated Codex testers completed an initial frozen synthetic/software/model round with a separate judge; that limited evidence does not establish broad cross-team/season accuracy, safety certification, fresh holdout performance or normal ChatGPT behavior.

Step 2 performance evidence uses a Windows development machine, two input sizes and stated prospective resource alerts. The OS filesystem cache was uncontrolled and prewarmed. See the accepted Step 2 report (development-source reference: ../generated/STEP_2_REPORT.md; not bundled); these measurements are not minimum-system requirements or a universal latency SLA.

## Promotion requirements

For each newly advertised OS/client combination, use a fresh machine/profile with no inherited project caches, install the complete local delivery unit, probe actual stdio compatibility and evidence reads, exercise fallback and version refusal, recover an interrupted scoped change in a disposable fixture, uninstall and verify retained/deleted data choices. Record exact OS/client/runtime/package hashes and failures separately from missing prerequisites. A local script cannot grade the native UI or a user's comprehension by inference.
