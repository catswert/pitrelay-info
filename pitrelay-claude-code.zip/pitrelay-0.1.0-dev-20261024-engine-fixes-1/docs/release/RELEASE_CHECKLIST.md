# Release, publication and maintenance checklist

**MANUAL-LINKS-1 update:** bundled seasonal rules are removed; explicit seasons/current-calendar-year selection and official host lookup guidance replace them. Current exact-candidate tests (development-source reference: ../generated/MANUAL_LINKS_REPORT.md; not bundled) and updated submission assessment (development-source reference: ../generated/POST_MANUAL_LINKS_SUBMISSION.md; not bundled) supersede older resource and operation-count rows. An accepted local-MCP public route is still unconfirmed; final route-specific packaging, identity/license, actual-client acceptance and review materials remain. External private beta and closed optional report intake do not independently block submission.

Refreshed 2026-10-05 local / 2026-10-06 UTC for resource closure. This is a release-gate ledger, not owner approval to distribute, submit, expose an endpoint or spend money. STATUS (development-source reference: ../STATUS.md; not bundled), [validation](VALIDATION.md) and the current resource report (development-source reference: ../generated/RESOURCE_CLOSURE_REPORT.md; not bundled) distinguish retained tests, fresh packaging checks and unexecuted client/release gates.

**External private beta is recommended hardening, not a submission prerequisite** in the dated official-source assessment. Submission readiness (development-source reference: ../generated/SUBMISSION_READINESS.md; not bundled) is the policy/gap ledger. Required engineering/client gates remain. V1–V7 are historical immutable packages; the resource-closure candidate receives separate exact-byte evidence. Every receipt certifies only its captured bytes and scope. Installed native Codex remains V6; new subprocess tests do not automatically update that client.

The REV supplemental source gap is now closed with the official licensed implementation and retained notices. Sparse game facts/composition have been assessed and four demonstrated factual errors corrected. That historical FIRST source-access question remains uncertain; it is not a mandatory permission gate for the current link-only package. Selected own-material no-redistribution terms still require exact integration. These updates refine G7.1; they do not waive client, security, recovery or publication gates below. Older V6 rows retain their dated evidence rather than being relabeled as new-client passes.

## Gate ledger

| Gate | Present artifact / evidence | Still required |
|---|---|---|
| G6.1 install/uninstall | Actual allowlisted Java engine/skill/document package and ZIP; relocation probe passes on existing Windows Java17 | Clean-machine install/uninstall for every advertised OS; no OS support claim from this development host |
| G6.2 server/data boundary | Current support-full-3 retained engine suite and matching HTTP16; Standard artifact route and independent Workspace grants | Actual supported-client artifact/configuration test; no hosted product service supplied |
| G6.3 compatibility | Current workflow2/tool2.0, MCP2025-06-18 and strict literal configuration | Actual native-client stale-cache/version test; package integrity/config generation is not client installation |
| G6.4 capability surface | 115 source registrations, individual schemas/annotations, compact inventory and paged help; current static guidance checks | Actual native host discovery/refresh; inspected fixture execution is not general project execution |
| G6.5 report/UI | Structured/text/artifact reports and dependency-closed fallback survive restart | Real client rendering/download probe; UI only where supported |
| G7.1 operational/legal | Public policy/contact exists separately; exact JAR attribution and MessagePack notice refreshed; recovery/support documentation | Final own-material license integration, publisher verification, core retention/recovery and actual uninstall trials; optional report intake may stay closed |
| G7.2 coverage | Accepted foundation evidence and honest real/synthetic/model limits | Frozen-candidate coverage/known-defect review; unresolved critical issues block affected release; no external enrollment quota |
| G7.3 consent/recovery | Executable source recovery/approval tests and policy drafts | Actual supported-client/operator consent, refusal, recovery, retention/deletion and independently reviewed explanation tests |
| G7.4 frozen acceptance | Initial rounds and later support-continuity contexts independently evaluated; original failed/blocked facets preserved | Remaining milestone acceptance and independent exact-candidate coverage review; exposed regressions are not fresh holdouts |
| G8.1 route eligibility | Dated official-source assessment; local development candidates exist | Local execution/MCP support confirmation or authorized supported alternative; no Codex-only directory bypass assumed |
| G8.2 submission packet | Minimal identity and local checks only | Complete route-specific manifest/assets/identity/policies/review cases/demo; required scans and reviewer access |
| G8.3 frozen candidate | V6 local development preparation has its own exact archive/manifest and checks in the package report | Supported release candidate, rights/security/client/lifecycle gates and independent release signoff |
| G8.4 submit/publish | NOT_RUN | Exact destination/package owner authorization; actual review, approval and separately authorized publication |
| H7 optional user hardening | Saved-log beta plan | Recommended consenting-team/student trials; no enrollment dependency on G8, but discovered critical defects still block release |

## Freeze and reproduce

- Identify source commit, dirty-source manifest if applicable, build environment, resource lock, artifact schema, tool/workflow/skill versions and selected fixture locks. Do not silently advance first-use pins.
- Build only after inspecting scripts in a suitable restricted environment. Retain exact commands, exit codes, executed/failed/skipped counts, raw output and copied source. Distinguish unavailable prerequisites from test failures.
- Freeze package bytes. Hash every shipped file and archive with SHA-256; record the engine JAR separately from the package archive. Check that its launch command selects the intended product main class. Do not treat an inherited artifact filename as version verification.
- Compare contents against an allowlist: skills, engine, required metadata/licenses and documented launch/configuration material. Exclude raw/private logs, state, approval keys, recovery checkpoints, caches, unrelated source, hidden evaluation answers and credentials.
- Reconcile the full dependency/notice inventory and scan the frozen artifact for secrets and known dependency issues using inspected tools. Record database/tool versions and network/data handling. A planned scan is NOT_RUN; no vulnerability-free assertion follows from a header check.
- Independently inspect diff, result identities, permission refusals, recovery, host prompt-injection boundaries, target/version mismatches and case acceptance expiry/reopening. Keep counterexamples and original failures. Re-run only the affected tests plus required release suite after final changes.

## Client and public submission

Recheck the actual platform requirements immediately before submission. Current official docs describe portable package identity and optional publisher metadata; the submission surface may demand additional publisher/interface information. Do not fabricate a company, logo, app ID, privacy URL or support address. The owner must provide/approve the real identity, domains, accounts and public policy locations. [Official submission guide](https://developers.openai.com/plugins/deploy/submission)

Use G8.1–G8.4 and R0–R6 in the submission assessment. The official local-execution/MCP contact path is an unresolved eligibility prerequisite, not proof of rejection or approval. A complete skills-only variant needs its own eligibility/runtime/client evidence and cannot silently depend on our separately configured MCP server. The documented standard remote route needs production hosting and policy-required client coverage; a label saying Windows-only cannot waive it. No external beta cohort is required merely to prepare or submit.

Validate positive/negative client cases: successful version handshake/read/report, missing runtime, inaccessible selected workspace, wrong/stale skill contract, disabled capability, lost connection, rejected approval, stale source, bounded oversized input and recoverable interrupted transaction. Record the actual client version, administrative setup and package hash. Passing a JSON parser is not acceptance by Codex or ChatGPT.

If the chosen public surface requires HTTP, complete a separate production transport/security design and tests before deployment: supported Streamable HTTP, HTTPS, per-user authorization, workspace isolation, credential handling, rate/resource limits, safe request logging and lifecycle/retention. The current product has no such service. Never expose the inherited unauthenticated development transport or call a developer tunnel production-ready. No remote deployment is authorized by local package work. [Official MCP guide](https://developers.openai.com/plugins/build/mcp-server)

Prepare a consented/synthetic demo that shows uncertainty, scoped writes, recovery, accepted-issue invalidation and no physical-success claim. Supply accurate capabilities, data flows, known limitations, privacy/support links and review instructions. Run applicable platform validation/security review. Present the final frozen package, checklist gaps and proposed destination to the owner; explicit publication approval is the last step, not a substitute for preparation.

## Maintenance and rollback

Retain the previous verified package, source/lock manifests, checksums, contracts and compatibility matrix. Record changes in [CHANGELOG](CHANGELOG.md), including changed evidence semantics, permission behavior and migrations. Never automatically pull upstream or rewrite historical evidence to match a new implementation.

Before an upgrade, close active jobs and preserve a verified copy of the selected state and checkpoints. Inspect proposed migrations on a copy; no automatic migration/reinterpretation promise exists today. A binary downgrade must not read newer state as compatible without a tested contract. If incompatibility exists, use the old package with its preserved matching state copy, or export/import supported evidence while retaining original provenance and revalidation requirements.

Exercise rollback in a disposable workspace before release. Confirm the exact package restored, usable reports/evidence, source state and limitations. Do not use rollback as permission to discard newer source edits or acceptance history. Announce known regressions through the designated consented channel; contact/publishing authorization remains separate.

Schedule monitoring or release checks only after an explicit owner request. No background task, automatic update, service enrollment or recurring cloud expense is created by this checklist.
# Access and evaluation amendment

The candidate must provide useful default Standard Access from supplied code/logs/observations, with actual retrievable proposals and precise NOT_RUN local steps where execution is unavailable. Optional Workspace Access must disclose its actions before enablement and enforce independent read/propose/execute/apply/restore scope through the same engine. Test downgrade, checkpoint-before-mutation, interruption, out-of-scope/intervening edits and restore. A workflow failure in Standard Access is a product defect, not a reason to demand workspace permission.

Require the reusable evaluation's isolation preflight, at least three independent testers with software/hardware-like/ambiguous cases, separate deterministic checks and judge, preserved failures and reruns. Keep this evidence separate from actual installed Codex and ChatGPT client tests; unverified clients stay unverified. These additions do not waive any gate above or make optional external beta enrollment mandatory.
