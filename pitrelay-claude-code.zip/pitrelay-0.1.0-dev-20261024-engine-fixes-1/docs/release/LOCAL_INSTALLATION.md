# Local Codex installation

This local development candidate includes the Java engine and all four skills. It does not require another wpilog-mcp checkout. Public ChatGPT/Codex directory eligibility for a local MCP engine remains unconfirmed. The selected compatibility layout is documented for local Codex plugins and is tested separately from ChatGPT and public submission. No hosting is used.

## Prerequisites and license

Use an existing Java 17 or later runtime and Python 3.11 or later for one-time setup. Setup installs no software. The installed server uses Java only. Exact OS/client/runtime evidence belongs to the candidate's test report; a successful development-machine test is not a clean-machine or other-OS claim.

Read [the private-use license](PITRELAY_LICENSE.md), [coverage map](PITRELAY_LICENSE_SCOPE.json) and [preserved third-party notices](LICENSE_INVENTORY.md). Private/team-internal use and modification are permitted. Redistribution of protected original material, unchanged or modified, is restricted. Ordinary robot-project outputs and separately licensed components retain their stated permissions. Setup requires acknowledgment of the exact license hash; this records an operator choice, not a legal-enforceability certification.

## Prepare

1. Extract the retained candidate into a new local directory. Obtain the package-manifest SHA-256 and license SHA-256 from its independently retained release receipt. A hash read only from an untrusted download is not a publisher authenticity check. Inspect the setup scripts before executing them.
2. Choose an existing absolute Java executable path, a new local marketplace directory, and a separate new state directory. None may overlap the extracted package. Existing state/install paths are refused; an upgrade must use a new version and deliberate state migration, not silent reuse.
3. From the extracted package run the following, replacing every angle-bracket value with the selected path/hash and quoting paths for your shell:

```text
<python> -B setup/configure_local.py --package <extracted-package> --manifest-sha256 <trusted-manifest-sha256> --java <absolute-java-executable> --state <new-private-state> --output <new-local-marketplace> --accept-license <license-sha256>
```

4. Retain `prepared-installation.json`. It records exact source, license and derived installation bytes. The original package is untouched. The new `pitrelay/` contains `.codex-plugin/plugin.json`, `.mcp.json`, the engine, four skills and notices. Original metadata is retained under `provenance/`; it does not falsely certify the added configuration.
5. In a supported local Codex client, add the generated marketplace root as a local plugin source, then install `pitrelay@pitrelay-local`. CLI authoring supports `codex plugin marketplace add <new-local-marketplace>`; this is a client configuration action and is performed only when the operator chooses it. This setup script does not run it or edit global settings. For project-only discovery, use the generated root as a trusted project containing `.agents/plugins/marketplace.json`; enable/install through the supported client UI. Client versions vary, so inspect their actual available commands rather than assuming a universal interface.
6. Reload/restart the client as required and start a fresh conversation. Confirm all four skills and the `pitrelay_local` server. Call `pitrelay_client_compatibility` and `pitrelay_capability_list`. Check workflow contract 2, Standard Access and no workspace/execution/apply grants before supplying data. Cached tool schemas are not proof of a connected engine.

The prepared declaration binds explicit Java/state paths. Regenerate after relocating those paths. The client chooses its own installed-cache directory; runtime launch and removal must be tested there. Windows Java launcher paths must roundtrip through the native code page; setup refuses known unrepresentable selected paths without changing regional settings. No broad Unicode-path or cross-platform support is implied.

## Data and permissions

The default accepts explicitly supplied artifacts and can return useful analysis/proposals. It grants no arbitrary original-workspace read, build, apply or restore authority. Optional Workspace Access requires separately reviewed scoped configuration and the disclosure in the access documentation; installation does not enable it. Build, replay and simulation results never prove physical robot safety or repair.

Java home/temp and engine state are inside the separate chosen state directory. Its parent should be private to the intended OS account. The engine enforces its own path and permission checks; unrestricted client-native tools are outside its gateway. Connecting Codex can send tool inputs/results to its hosted model. Local-first does not mean the model runs offline. No automatic upload, telemetry, network listener, robot connection or model API purchase is created by preparation.

## Disable, remove, upgrade and rollback

Disable/remove this specific plugin through the client, then use a fresh conversation to verify its tools and skills are absent. Stop remaining related processes before moving/deleting its package. Do not delete unrelated entries or entire client profiles. Removal intentionally retains the separate state directory, which can contain artifacts, reports, checkpoints and approval state. Review and delete only that exact directory under the applicable retention procedure; never treat uninstall as implicit permission to delete recovery evidence.

Keep a previous immutable version and its own state for rollback. Prepare a new version into new directories, test compatibility and supplied-data behavior, then explicitly choose which client entry is enabled. This installer provides no automatic state migration and never silently shares writable state between versions.

The logo/icon is intentionally pending the maintainer's supplied artwork. Local preparation does not require an invented asset.

Official local packaging reference: https://developers.openai.com/plugins/build/plugins
