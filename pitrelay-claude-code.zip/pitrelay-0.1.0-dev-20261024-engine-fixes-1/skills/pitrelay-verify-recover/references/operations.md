# Verification and recovery requests

Substitute each `${...}` binding with an actual value of the required type before sending these templates. IDs and approvals must come from real records/the authorized host; placeholders are not valid arguments. Request the complete live schema with `help` when in doubt.

| Operation | Required arguments | Boundary |
|---|---|---|
| `snapshot.create` | `paths` array of selected relative files | Captures actual selected dirty/staged/untracked state; excludes sensitive/internal paths. |
| `snapshot.verify` | `checkpoint_id` | Rechecks persisted record and captured bytes. |
| `project.match_revision` | `recorded` object from actual build/source metadata | Exact, reconstructed dirty, candidate, mismatch and unknown remain distinct; inspect the matching schema rather than inventing a revision. |
| `patch.inspect`, `change.diff`, `patch.candidate` | `patch_id` | Inspect or create an isolated proposal; no original-source promotion. |
| `execution.plan` | None | Actual host-approved commands and prerequisites. |
| `execution.plan_candidate` | `patch_id` | Only the inspected reference adapter's supported source change. |
| `replay.inspect` | `artifact_id` | Required typed inputs for that adapter; not arbitrary-project determinism. |
| `job.start` | `plan_id`, `plan_digest`; optional `wait_ms` | Starts the host-registered plan, never a supplied shell command. |
| `job.status`, `job.results`, `job.cancel` | `job_id` | Persisted lifecycle, checked evidence or observed cancellation. |
| `case.bind_target` | `case_id`, `revision`, `target_artifact_id` | Exact captured target; selecting another target reopens investigation. |
| `case.update` | `case_id`, `revision`, `state`, `reason`; verification additionally uses `evidence`, `scope` | Fresh revision and matching typed local results. |
| `patch.apply`, `snapshot.restore`, `snapshot.recover` | `patch_id`, `approval` | Host-issued action-specific approval plus current-state checks. |

```json
{"operation":"job.start","workflow_id":"${session.id}","plan_id":"${plan.id}","plan_digest":"${plan.digest}","wait_ms":0}
```

```json
{"operation":"case.bind_target","workflow_id":"${session.id}","case_id":"${case.id}","revision":"${case.revision}","target_artifact_id":"${verification.target_artifact_id}"}
```

```json
{"operation":"case.update","workflow_id":"${session.id}","case_id":"${case.id}","revision":"${case.revision_after_binding}","state":"verified_with_scope","reason":"${supported_conclusion}","evidence":["${local_verification_artifact.id}"],"scope":"${verification.kind}"}
```

```json
{"operation":"snapshot.recover","workflow_id":"${session.id}","patch_id":"${interrupted_patch.id}","approval":"${host.restore_approval}"}
```

Verification rows should retain source integrity, build, regression, baseline replay, candidate replay and physics/model results separately when actually provided. A missing adapter, absent native library, unsupported OS or failed baseline is not a passing candidate check. A cancelled or failed job may still have useful captured output; do not infer success from its availability.

When reconnecting after an uncertain outcome, first call `workflow.status` and read the case/job/patch through the available inspection operations. Session policies may block ordinary budgeted calls until the unfinished outcome is explicitly reconciled; use authorized inspection outside that stopped execution policy only to determine state, never to continue the cancelled work or repeat writes. Resume uses `workflow.control` with current `revision`, `action: "resume"`, and `acknowledge_unfinished: true` only after inspection. `new_deadline_seconds` is an explicit policy change, not an automatic retry extension. If the host cannot establish safe state, report the blocker and preserve recovery artifacts.

For large workflow histories, use `workflow.report` with `delivery: "artifact"` only when its live help advertises that selector. Keep the compact state/revalidation/budget/unfinished/reconciliation fields and download the full structured evidence in small verified `artifact.download` chunks as needed. Its projection omits long history/prose explicitly; it does not prove a transaction succeeded or authorize recovery. The older inline summary can still contain the complete session/case and overflow a display. Avoid batching large case/status responses, and recover omitted evidence before relying on it.
