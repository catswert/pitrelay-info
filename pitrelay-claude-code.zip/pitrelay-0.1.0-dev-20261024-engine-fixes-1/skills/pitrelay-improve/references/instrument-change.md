# Instrumentation and source-change recipe

The currently supported instrumenter uses the project's recognized AdvantageKit26.0.2 logger and a selected Java primitive method parameter. Inspect exact source, overload/signature and shadowing before selecting it. Other languages, generated code, dynamic logger wrappers or unsupported versions require a clearly bounded proposal or collection plan, not an invented successful transform.

`instrumentation.plan` and `instrumentation.prepare` require all of:

| Argument | Supply from |
|---|---|
| `path`, `class_name`, `method`, `parameter_types`, `parameter` | The actual inspected Java declaration; the type array identifies the overload. |
| `framework`, `framework_version` | Actual declared/recognized logging dependency. |
| `unit`, `purpose` | Known parameter semantics and the question this observation will distinguish. |
| `every_n_calls`, `expected_calls_per_second` | Requested sampling interval and justified call-rate assumption. |
| `max_samples_per_second`, `max_bytes_per_second`, `expected_duration_seconds` | Explicit collection/storage budget; estimates do not measure CPU overhead. |

The plan is not permission to mutate original source. Preparation returns checkpoint/patch identities; inspect them with `snapshot.verify`, `patch.inspect` and `change.diff`. An isolated `patch.candidate` requires `patch_id`. A generic `patch.prepare` requires `checkpoint_id` plus `replacements`, whose keys are selected relative paths and values are complete UTF-8 replacement strings or explicit null deletions. Never supply an entire unrelated repository as patch scope.

For a supported prepared reference candidate, `execution.plan_candidate` requires `patch_id`. Read its returned plan ID/digest and exact source restrictions; the initial adapter only accepts its pinned one-literal gain change. Arbitrary robot source is not accepted merely because it is Java. Missing adapter/isolation is an unavailable prerequisite, not a passed build and not permission to execute an uninspected script through another tool.

Before promotion, show the real diff, new files, parameter changes, evidence and rollback scope. Respect existing authorization; otherwise obtain authorization for this specific action. `patch.apply` requires `patch_id` and a valid host-issued `approval` token bound to workspace/session/checkpoint/patch/path/action/expiry. The model must never invent or issue that token. Do not store it in a notebook, ordinary evidence attachment or workflow report.

Behavior-preservation checks should compare actual control outputs and state before/after instrumentation, plus the newly recorded signal. Preserve persistent PID/hardware objects, scheduler requirements, cleanup and team interfaces. Demonstrating that two software hypotheses become distinguishable in a fixture is valid software evidence; presenting those hypotheses as known physical causes is not.
