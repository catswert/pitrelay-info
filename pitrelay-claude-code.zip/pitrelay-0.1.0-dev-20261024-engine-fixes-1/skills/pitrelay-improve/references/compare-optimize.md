# Comparison and controls recipes

Read the live `help` schema before supplying nested objects. Request templates below use `${...}` for values from actual prior results or explicit user inputs; substitute their correct JSON types before sending. They contain no expected benchmark answers or invented physical parameters.

| Operation | Required arguments | Meaning and limits |
|---|---|---|
| `signal.compare` | `artifact_id`, `entry`, `start_us`, `end_us`, `other_artifact_id`, `other_entry`, `other_start_us`, `other_end_us` | Two explicit windows; compatible units required. Optional field/native-format selectors remain distinct for each side. |
| `signal.tracking` | First signal/window arguments plus `other_artifact_id`, `other_entry`, `interpolation`, `max_gap_us` | Tracking under explicit gap policy, optional angular `wrap_period`. Establish commanded/measured roles separately. |
| `clock.align` | `source_clock`, `target_clock`, `anchors`, `uncertainty_us`, `association_ambiguous`, `evidence_ids` | Actual integer timestamp anchors; ambiguous associations are not silently accepted. |
| `frc.compare_phases` | `first`, `second`, `phases`, `first_identity`, `second_identity`, `max_gap_us` | Explicit role/evidence bindings, real phase windows and captured source/configuration identities; retain unmatched/unsupported coverage. |
| `model.inspect` | `model` | Declared parameters only; no automatic calibration or physical safety certification. |
| `controls.characterize` | `training_artifact_id`, `heldout_artifact_id`, `gravity_voltage_v` | Separate captured explicit-unit/time datasets; held-out residuals are not training residuals. |
| `controls.sweep` | `gains_v_per_m`; optional `wait_ms` | Actual host-registered reference-model job, at most eight distinct supported gains; not arbitrary team controls tuning. |
| `job.status`, `job.results`, `job.cancel` | `job_id` | Actual lifecycle and validated result artifacts; polling timeout is not completion. |

```json
{"operation":"signal.compare","workflow_id":"${session.id}","artifact_id":"${first.id}","entry":"${first.entry}","start_us":"${first_window.start_us}","end_us":"${first_window.end_us}","other_artifact_id":"${second.id}","other_entry":"${second.entry}","other_start_us":"${second_window.start_us}","other_end_us":"${second_window.end_us}"}
```

```json
{"operation":"controls.characterize","workflow_id":"${session.id}","training_artifact_id":"${training.id}","heldout_artifact_id":"${heldout.id}","gravity_voltage_v":"${declared_model.gravity_voltage_v}"}
```

The `model` object for `model.inspect` requires `mass_kg`, `drum_radius_m`, `gearing`, `motor_count`, `motor_model`, `min_position_m`, `max_position_m`, `controller_period_s`, `plant_step_s`, `max_voltage_v`, `mass_unit`, `length_unit`, `time_unit`, and `voltage_unit`. Use identified measured/declared values and supported SI units, never a plausible generic robot. The current model supports its declared elevator reference only; missing mass/gearing/calibration does not authorize inventing them.

Characterization artifacts require schema version1.0, explicit `clock`, `sampling_policy`, `acceleration_derivation`, `velocity_unit`, `acceleration_unit`, `voltage_unit`, and numeric `samples` rows with `time_seconds`, `velocity_mps`, `acceleration_mps2`, `voltage_v`. An independently captured held-out identity is required. Register an actual prepared dataset through the approved artifact path; do not manufacture samples to satisfy the endpoint.

Inspect `execution.plan` and actual readiness before starting execution. A sweep result is a modeled prediction with observed constraints and uncertainty. Candidate replay holds recorded inputs fixed; model simulation changes state according to its declared equations. Keep those claims separate. Reject an optimization conclusion if the baseline cannot be reproduced or the comparison conditions do not support the objective.

Each phase object has `name`, `start_us`, `end_us`, `other_start_us`, `other_end_us`. Each identity object may carry `source_snapshot_artifact_id` and `configuration_artifact_id`; absent identities remain unknown. The `first`/`second` bindings require captured channel identity, explicit role, actor, assertion time and a captured assertion-evidence ID. Read their nested live schema; do not fabricate an assertion to meet the required fields.
