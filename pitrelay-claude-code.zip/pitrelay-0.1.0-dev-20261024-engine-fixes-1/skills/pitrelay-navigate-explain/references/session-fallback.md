# Sessions, issue continuity and fallback

These are templates. Replace `${...}` with actual values of the correct type before sending. Obtain IDs from real results, not filenames or example text.

## Versioned session policy

`client.compatibility` requires `workflow_contract: "2"`. A compatible response identifies engine, tool and workflow contracts; unsupported workflow versions return `WORKFLOW_VERSION`. The version handshake cannot prove that a native ChatGPT/Codex UI is connected or that optional executors are configured.

`workflow.start` requires `workflow_contract: "2"`, `kind` and `goal`; kinds are diagnose/checkup/compare/instrument/optimize/verify/explain. Optional `symptom`, `depth`, `presentation`, `deadline_seconds`, `max_calls`, `max_candidates` refine the policy. It opens a new case. Reconnect with the existing ID instead.

| Depth | Default deadline | Default ordinary calls | Default candidates |
|---|---:|---:|---:|
| pit | 300 seconds | 20 | 1 |
| standard | 1,800 seconds | 80 | 3 |
| deep | 7,200 seconds | 200 | 8 |

These are configurable execution policy, not scientific thresholds or a completion guarantee. Depth does not grant write/execute permission. Bounds are86,400 seconds/1,000 calls/32 candidates; the connected service owns enforcement. Model/native-shell calls are outside this cooperative gateway, not secretly covered by its counters.

Ordinary calls can carry `workflow_id`; start/status/control/report are session-management operations. The engine reserves before execution, serializes a workflow's active operation and retains outcomes/evidence and owned backend jobs. It cannot certify an outcome lost before durable recording. After an interruption, inspect source/case/job state before acknowledging reconciliation; never replay a write merely because its final report was lost. Keep authorization tokens out of user-visible notes/reports.

```json
{"operation":"workflow.status","workflow_id":"${session.id}"}
```

```json
{"operation":"workflow.control","workflow_id":"${session.id}","revision":"${session.revision}","action":"pause"}
```

```json
{"operation":"workflow.report","workflow_id":"${session.id}","presentation":"evidence"}
```

`workflow.control` also accepts action `cancel` or `resume`. Cancel stops new work and attempts cancellation only for recorded owned jobs; inspect reported failures or unavailable cancellation. Resume requires the current revision and, where applicable, `acknowledge_unfinished: true` after reconciliation. Spent calls/candidates remain spent. A new remaining duration uses explicit `new_deadline_seconds`; do not extend budgets without the user's authorized scope. Reports/status stay available when a budget is exhausted.

## Cases and accepted scope

```json
{"operation":"issues.scope","workflow_id":"${session.id}","paths":"${selected_source.paths}","artifact_ids":"${selected_artifacts.ids}","conditions":"${current_conditions.string_map}"}
```

```json
{"operation":"issues.accept","workflow_id":"${session.id}","case_id":"${case.id}","revision":"${case.revision}","scope_artifact_id":"${captured_scope.id}","reason":"${user.acceptance_reason}","reopen_when":"${user.reopening_conditions}","artifact_ids":"${current_artifacts.ids}","conditions":"${current_conditions.string_map}"}
```

```json
{"operation":"issues.evaluate","workflow_id":"${session.id}","case_id":"${case.id}","revision":"${case.revision}","artifact_ids":"${current_artifacts.ids}","conditions":"${current_conditions.string_map}"}
```

```json
{"operation":"issues.preview","workflow_id":"${session.id}","existing":"${current_notebook.text}","case_ids":["${case.id}"]}
```

Acceptance follows the user's decision. `issues.scope` captures hashes for the selected live source paths, selected artifact identities, an attributed condition string map of at most32 entries, and optional `expires_at`. Conditions are human/host assertions, not measured sensor truth. `issues.accept` requires a currently matching capture; it grants no edit permission. `issues.evaluate` rechecks live source, current artifact IDs, conditions and expiry. Only a current exact match returns `acceptance_assessment.suppression_allowed: true`; mismatch/expired/unavailable context appends an open state. Case/report reads without supplied current context require acceptance revalidation. Legacy `issues.reconcile`/caller `context_hash` history cannot certify suppression. Prose `reopen_when` describes human policy; do not execute it. Case writes require the latest revision. A notebook preview has `source_modified: false`; application remains a separate approved source transaction.

## Access and transport recovery

For a long saved workflow, inspect exact `help` for `workflow.report`. When its schema advertises `delivery`, use `delivery: "artifact"` to obtain a compact resume/safety view and full structured/text report artifacts. This remains available after the session stops. The compact view deliberately omits history and long prose; follow its field/count descriptions, download relevant full evidence with small `artifact.download` chunks, and verify returned byte counts and hashes. Check current state, revalidation, unfinished work and reconciliation before any explicit resume. Never infer that omitted calls passed or repeat a write from the summary alone. Earlier engines without this selector require their supported report/download path; do not invent the argument or claim a truncated display was complete. Case/status and mutation responses can still be large; avoid batching them.

- Standard Access is the default complete product. Analyze supplied artifacts and captured source through the same engine, guide collection of missing evidence and return retrievable proposed files and precise local steps. A missing execution capability does not justify requesting Workspace Access when supplied evidence can answer the question.
- Workspace Access optionally automates authorized collection and development operations. Discover its separate read, propose, execute, apply, restore and notebook grants; present the first-enable disclosure. A connection alone grants none of these. Missing capabilities return the affected step to supplied-artifact exchange or local instructions.
- If MCP transport is unavailable, an already installed authorized CLI or exported evidence can preserve the work. The Java entrypoint is `org.pitrelay.Main`; Standard CLI takes private `--state`, `--mode cli`, `--operation` and optional JSON `--arguments`. Workspace additionally needs `--experience workspace`, selected `--workspace`, explicit `--grants` and `--workspace-disclosure accepted-v1`. Old `--access` is rejected. Operation `help` returns the actual registry. Inspect installed launcher/runtime paths instead of inventing them. Preserve the same units, clocks, source identities and verification limits; do not imply any local command ran merely because instructions were supplied.

`bundle.preview` and `bundle.export` require `artifact_ids`, with optional `include_dependencies`. Preview payloads, closure and content first. `artifact.redact_preview`/`artifact.redact` require `artifact_id` and explicit `json_pointers`; they create a separately identified view, not a sanitized replacement for its dependencies. Export only the approved selection; dependency expansion must be explicit. `bundle.import` requires a captured bundle's `artifact_id`, verifies payloads and keeps imported origin untrusted. A hash proves byte identity, not authentic source revision or physical truth.

If client access is absent, mark it unverified. If execution is unavailable, preserve analysis and the exact prerequisite. If an immutable source is missing, request that specific authorized artifact rather than inventing evidence. Public-log root causes remain unknown when observations cannot establish them.
