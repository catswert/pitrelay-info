# Optional report package

Use the term **report package**: a standardized local ZIP of selected evidence that the user may review and optionally submit to help improve PitRelay. This is available in Standard Access; do not request Workspace Access just to prepare it. Selected source snapshots and artifact bytes feed the same engine in both experiences. No tool here reads arbitrary original files, runs code, applies a patch, or uploads.

## Explain and select

Describe the observed PitRelay mistake, its impact, what you currently believe caused it, and what remains uncertain. Ask for the smallest missing relevant source/log/observation set. Preserve full relevant logs where the supported sanitizer permits it. Do not invent missing data or replace a full log with a sampled analysis index.

Capture an attributed record of the user's report, expected and actual behavior, explanations/justification already shown to the user, the proposed fix, exact checks/results and missing validation. Visible conversation excerpts must be explicitly supplied/selected: do not claim complete authenticated chat history. Never request or export hidden chain-of-thought, private scratch work, benchmark answers or peer conversations. A proposed fix is evidence of the attempt, not proof that it worked.

Use `source.import_files` or `source.import_zip` for selected source snapshots. Use the existing supplied-artifact upload operations for full logs and textual diagnostics. Capture proposed source as an additional snapshot if useful; do not overwrite the observed copy. Request actual schemas through `help`; upload kind must be one of its advertised values. The report request itself is supplied JSON, not executable instructions.

The request artifact contains an object with `schema_version` equal to `pitrelay-report-request-1`. Required fields are category, user_report, expected_behavior, observed_behavior, explanation_shared_with_user, proposed_fix, visible_messages, source_snapshot_ids and log_artifact_ids. The five prose fields are strings; use an honest unavailable statement where appropriate. Category is one of incorrect_information, deterministic_tool_bug, confusing_workflow or other. Each visible_messages item has only role (user or assistant) and content. Source/log selections are arrays of actual returned artifact IDs, never invented names. Optional attachment_artifact_ids contains selected text diagnostic records.

Optional identity_terms contains identifying strings to remove. Optional secret_values contains objects with value and service; service is github, openai, google, aws, slack, discord or unknown. Do not echo secret hints into summaries. Optional symbol_aliases contains symbol, replacement and evidence strings. This evidence is the caller's attributed assertion, not an engine-verified physical role. Prefer neutral aliases unless version-matched code supports a functional name; a motor name alone proves nothing. Optional sensitive_log_channels declares exact original channel names whose contents may identify the team; such logs block export rather than silently losing channels. Numeric identifiers cannot reliably be inferred, and unrelated numeric measurements must not be replaced.

Optional omit_artifact_ids explicitly identifies selected inputs to omit; allow_partial must also be true. Missing or omitted code/logs remain disclosed as partial coverage. Never quietly enable partial export just to make an error go away. Native DS/vendor, opaque/custom WPILOG payloads, malformed input and invalid encoding may be unsupported: explain the blocker and let the user choose another supported artifact or explicit omission.

Use the returned limits as authoritative. The initial implementation permits a 1 MiB request, 64 visible messages, 4 source snapshots, 16 logs, 16 attachments and 128 entries in each hint list. Prose fields are limited to 32 KiB; selected input/output to 32 MiB; individual logs to 16 MiB; text artifacts and WPILOG records to 2 MiB. Limits also cover 500,000 WPILOG records, 250,000 matching escapes per text field and 8,192 archive members. Expansion can exceed a budget even when the original fits. Explain the refusal and narrow the selected scope with the user; never truncate secretly.

## Preview, review and export

```json
{"operation":"report_package.preview","request_artifact_id":"${report_request_artifact_id}"}
```

Read the actual preview inventory, coverage, transformations, blockers and limitations. Preserve its exact preview_id and review_digest. Inspect with `report_package.inspect` after reconnect; do not regenerate or substitute inputs silently. Read the sanitized files where available and explain the transformed evidence's limitations. The original source/logs stay unchanged. Renaming or redaction can affect reproduction and compilation; neither an archive checksum nor an acknowledgement proves a build, replay, physical repair or human privacy review.

To inspect actual sanitized files before export, pass preview_id to `artifact.inspect`, then use `artifact.download` with that returned descriptor. The preview JSON's members array maps safe package paths to sanitized member artifact IDs, byte sizes and hashes. Download those selected members through the same bounded operation; manifest.json holds the full inventory when the summary is truncated. This is a local draft mapping, not material to add to the public ZIP. Never substitute original source/log artifacts for these sanitized members.

Before local export, explain: “This package attempts to remove identifying details and secrets. Automated checks and AI-assisted review can miss information. Inspect every file before deciding whether to submit; submission is optional.” Obtain the user's acknowledgement of these limits. An earlier explicit request to create the package may authorize local work, but does not itself certify they reviewed every file or authorize any upload.

```json
{"operation":"report_package.export","preview_id":"${preview_id}","review_digest":"${review_digest}","acknowledge_privacy_limits":true}
```

Use returned artifact information and `artifact.download` to hand over actual ZIP bytes with a useful filename. Do not treat the artifact ID alone as a completed file handoff. Explain selected coverage and omissions. If the user edits a ZIP copy, its original manifest no longer verifies it; prepare a new validated package. Retain build/replay/simulation statuses as actually performed or NOT_RUN. Physical validation remains not performed.

## Optional submission

Call `report_package.submission_info`. If unavailable, say submission is not configured and provide the local package for the user's own review. Do not invent a URL, use a search result as the destination, or route through a generic evidence exporter.

Only if owner-verified destination and policy exist, show the returned link and state the recipient's declared improvement-only, non-public use policy, access, retention/deletion contact and Google's handling/sign-in requirements. Explain any additional declared AI processing, including OpenAI when Codex investigates packages; sole human review does not mean no provider receives content. Distinguish improving code/instructions/tests from training model weights and from the provider's separate data controls. Do not invent account settings or deletion guarantees. The software cannot enforce what a recipient does. Do not call a signed-in upload anonymous. Explain the category, optional feedback and ZIP fields. Review locally before selecting the file in Google Forms; file selection may itself transfer data. The user can decline without losing diagnostic service. Never submit or upload on their behalf without separate explicit authorization. Actual form acceptance and installed-client behavior require their own evidence.
