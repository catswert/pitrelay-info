"""Build/verify an internal local package; no install, network, publication or source mutation.

Java17 is an explicit host prerequisite. This builder never redistributes a runtime,
vendor binary, fixture cache, private state or log. Public delivery remains unapproved.
"""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import tomllib
import uuid
import zipfile

ROOT = Path(__file__).resolve().parents[1]
MAX_MANIFEST_BYTES = 1024 * 1024
MAX_RELEASE_DOCUMENT_BYTES = 8 * 1024 * 1024
ENGINE_CLASSES = {"org/pitrelay/" + name + ".class" for name in ("Main", "Companion", "LocalHttp")}
# These are reviewed release inputs, not extension-based inclusion rules. Adding a
# file to these trees requires an intentional packaging review before it can ship.
REVIEWED_TREES = {
    "engine/LICENSES": ("engine/LICENSES", ("LicenseRef-PitRelay-Unreleased.txt",)),
    "plugin/skills": ("skills", (
        "pitrelay-improve/SKILL.md", "pitrelay-improve/references/compare-optimize.md",
        "pitrelay-improve/references/instrument-change.md", "pitrelay-investigate/SKILL.md",
        "pitrelay-investigate/references/operations.md", "pitrelay-investigate/references/access.md", "pitrelay-investigate/references/game-manuals.md", "pitrelay-navigate-explain/SKILL.md",
        "pitrelay-navigate-explain/references/session-fallback.md", "pitrelay-navigate-explain/references/report-package.md", "pitrelay-verify-recover/SKILL.md",
        "pitrelay-verify-recover/references/operations.md")),
    "docs/release": ("docs/release", (
        "BETA_PLAN_AND_CONSENT.md", "CHANGELOG.md", "COMPATIBILITY.md", "DEPENDENCY_LICENSE_EVIDENCE.json",
        "LICENSE_INVENTORY.md", "OPERATIONS_RECOVERY.md", "PRIVACY_RETENTION.md", "RELEASE_CHECKLIST.md", "REPORT_SUBMISSION_SETUP.md",
        "STATIC_CHECKS.json", "VALIDATION.md", "LOCAL_INSTALLATION.md", "PITRELAY_LICENSE.md", "PITRELAY_LICENSE_SCOPE.json", "notices/WPILOG_MCP_LICENSE.txt",
        "notices/MESSAGEPACK_LICENCE_SBT_EXTRAS.txt")),
}
# Reviewed source-only documents may coexist with shipped release inputs. These
# exact names are optional, must still be regular nonlinked files, and are never
# accepted by package verification or read/copied into an archive.
NONSHIPPING_SOURCE_DOCUMENTS = {
    "docs/release": ("OWNER_TO_PUBLICATION_PLAN.md", "REPORT_FORM_COPY.md",
                     "RIGHTS_FOLLOWUP.md", "DELIVERY_ELIGIBILITY_PACKET.md",
                     "SUBMISSION_MATERIALS_DRAFT.md", "LOCAL_MCP_SUPPORT_INQUIRY.md",
                     "PITRELAY_LICENSE_DRAFT.md", "LICENSE_DRAFT_REVIEW.md"),
}
REVIEWED_FILES = {"engine/LICENSE": "engine/LICENSE", "plugin/plugin.json": "plugin.json",
                  "scripts/package_local.py": "setup/package_local.py", "scripts/configure_local.py": "setup/configure_local.py"}
MANIFEST_METADATA = {
    "schema_version": "1.0", "package_kind": "internal_local_development", "version": "0.1.0-dev",
    "workflow_contract": "2", "tool_contract": "2.0", "entry_point": "org.pitrelay.Main",
    "java_prerequisite": "17+; exact tested runtime recorded separately",
    "distribution": "NOT_AUTHORIZED; local candidate with scoped private-use terms; public local-MCP route and release gates unresolved",
    "client_installation": "Requires explicit local preparation; see exact candidate client receipt", "physical_validation": "not_performed",
    "license": "LicenseRef-PitRelay-Private-1.0 for identified original material; preserved third-party grants",
}


def required_package_files():
    files = {"README.md", "engine/pitrelay.jar", *REVIEWED_FILES.values()}
    for target, names in REVIEWED_TREES.values():
        files.update(target + "/" + name for name in names)
    return files


def digest(path):
    require_file(path)
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def no_links(path):
    path = path.absolute()
    for node in (path, *path.parents):
        if node.is_symlink() or (hasattr(node, "is_junction") and node.is_junction()):
            raise ValueError("Links/junctions are outside package scope")
        # Python3.11 has no Path.is_junction. Windows exposes the reparse bit
        # through lstat on both supported versions; reject all reparse types.
        try:
            attributes = getattr(node.lstat(), "st_file_attributes", 0)
        except (FileNotFoundError, NotADirectoryError):
            continue
        if attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            raise ValueError("Links/junctions/reparse points are outside package scope")


def require_file(path):
    no_links(path)
    if not path.is_file() or not stat.S_ISREG(path.stat(follow_symlinks=False).st_mode):
        raise ValueError("Required regular package file missing: " + str(path))


def tree_entries(folder):
    """Inspect every node without entering links or reading any file contents."""
    no_links(folder)
    if not folder.is_dir():
        raise ValueError("Required package input directory missing: " + str(folder))
    files, directories, pending = {}, set(), [folder]
    while pending:
        current = pending.pop()
        no_links(current)
        with os.scandir(current) as entries:
            children = sorted(entries, key=lambda entry: entry.name)
        for entry in children:
            path = current / entry.name
            no_links(path)
            relative = path.relative_to(folder).as_posix()
            mode = path.stat(follow_symlinks=False).st_mode
            if stat.S_ISDIR(mode):
                directories.add(relative)
                pending.append(path)
            elif stat.S_ISREG(mode):
                files[relative] = path
            else:
                raise ValueError("Non-regular package input is unsupported: " + relative)
    return files, directories


def checked_tree(folder, expected, excluded=()):
    files, directories = tree_entries(folder)
    expected = set(expected)
    excluded = set(excluded)
    if expected & excluded:
        raise ValueError("Shipped and nonshipping source inventories must be disjoint")
    expected_directories = {"/".join(name.split("/")[:index]) for name in expected for index in range(1, len(name.split("/")))}
    if not expected <= files.keys() or files.keys() - expected - excluded or directories != expected_directories:
        raise ValueError("Package tree differs from reviewed inventory: " + str(folder)
                         + "; missing=" + repr(sorted(expected - files.keys()))
                         + "; unexpected=" + repr(sorted(files.keys() - expected - excluded))
                         + "; unexpected_directories=" + repr(sorted(directories - expected_directories)))
    return {name: path for name, path in files.items() if name in expected}


def inventory(folder):
    result = []
    files, _ = tree_entries(folder)
    for relative, path in sorted(files.items()):
        if relative != "package-manifest.json":
            result.append({"path": relative, "byte_size": path.stat().st_size, "sha256": digest(path)})
    return result


def copy_file(source, target):
    require_file(source)
    no_links(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    no_links(target)
    with source.open("rb") as original, target.open("xb") as output:
        shutil.copyfileobj(original, output)


def copy_tree(source, target, expected=None, excluded=()):
    if expected is None:
        raise ValueError("Copying a tree requires an explicit reviewed inventory")
    for relative, path in sorted(checked_tree(source, expected, excluded).items()):
        copy_file(path, target / relative)


def write_json(path, value):
    no_links(path)
    with path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate manifest field: " + key)
        result[key] = value
    return result


def valid_hash(value):
    return type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def validate_manifest(manifest):
    if type(manifest) is not dict or set(manifest) != {*MANIFEST_METADATA, "engine_sha256", "files"}:
        raise ValueError("Package manifest requires every supported field and no unknown fields")
    if any(type(manifest[key]) is not str or manifest[key] != expected for key, expected in MANIFEST_METADATA.items()):
        raise ValueError("Unsupported or malformed package metadata")
    if not valid_hash(manifest["engine_sha256"]):
        raise ValueError("Package requires a non-null engine SHA256")
    rows = manifest["files"]
    if type(rows) is not list or not rows or len(rows) != len(required_package_files()):
        raise ValueError("Package requires the complete reviewed file inventory")
    paths = []
    for row in rows:
        if type(row) is not dict or set(row) != {"path", "byte_size", "sha256"}:
            raise ValueError("Malformed package file record")
        path = row["path"]
        if type(path) is not str or not re.fullmatch(r"[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)*", path) or any(part in {".", ".."} for part in path.split("/")):
            raise ValueError("Package file path must be a canonical relative reviewed path")
        if type(row["byte_size"]) is not int or row["byte_size"] < 0 or not valid_hash(row["sha256"]):
            raise ValueError("Package file size/hash is malformed")
        paths.append(path)
    if paths != sorted(required_package_files()):
        raise ValueError("Package file paths must be the exact sorted reviewed inventory without duplicates")
    engine = next(row for row in rows if row["path"] == "engine/pitrelay.jar")
    if engine["byte_size"] == 0 or engine["sha256"] != manifest["engine_sha256"]:
        raise ValueError("Engine identity differs from manifest")


def verify_engine(jar):
    require_file(jar)
    with zipfile.ZipFile(jar) as archive:
        if not ENGINE_CLASSES.issubset(archive.namelist()):
            raise ValueError("Engine lacks the entry points documented by this package; rebuild the current source")
        if any(name.startswith("games/") and not name.endswith("/") for name in archive.namelist()):
            raise ValueError("Seasonal game resources must not be bundled; use the official manual link catalog")
        if archive.namelist().count("META-INF/MANIFEST.MF") != 1 or archive.getinfo("META-INF/MANIFEST.MF").file_size > 65536:
            raise ValueError("Engine requires one bounded product manifest")
        main_section = archive.read("META-INF/MANIFEST.MF").decode("utf-8", errors="strict").replace("\r\n", "\n").split("\n\n", 1)[0].replace("\n ", "")
        attributes = {}
        for line in main_section.splitlines():
            if ": " not in line:
                raise ValueError("Malformed engine manifest")
            name, value = line.split(": ", 1)
            name = name.lower()
            if name in attributes:
                raise ValueError("Duplicate engine manifest attribute")
            attributes[name] = value
        if attributes.get("main-class") != "org.pitrelay.Main" or "class-path" in attributes:
            raise ValueError("Engine manifest must select org.pitrelay.Main without an external Class-Path")


def verify(folder):
    folder = folder.absolute()
    no_links(folder)
    manifest_path = folder / "package-manifest.json"
    require_file(manifest_path)
    with manifest_path.open("rb") as stream:
        contents = stream.read(MAX_MANIFEST_BYTES + 1)
    if len(contents) > MAX_MANIFEST_BYTES:
        raise ValueError("Package manifest exceeds 1 MiB")
    manifest = json.loads(contents.decode("utf-8"), object_pairs_hook=unique_object)
    validate_manifest(manifest)
    checked_tree(folder, required_package_files() | {"package-manifest.json"})
    actual = inventory(folder)
    if actual != manifest["files"]:
        raise ValueError("Package bytes or file inventory differ; do not run this package")
    verify_engine(folder / "engine/pitrelay.jar")
    return {"result": "PASS", "files_verified": len(actual), "engine_sha256": manifest["engine_sha256"],
            "manifest_sha256": digest(manifest_path), "scope": "local byte integrity; not publisher signature, clean-machine validation or distribution approval"}


def rewrite_document_links(document, destination):
    """Rewrite prose links while retaining UTF-8 bytes and standalone fenced blocks.

    Fences use Markdown's zero-to-three-space indentation, matching backtick or
    tilde markers, and a closing run at least as long as the opening run. An
    unclosed fence stays opaque through EOF. This is not a general Markdown parser.
    """
    require_file(document)
    with document.open("rb") as stream:
        contents = stream.read(MAX_RELEASE_DOCUMENT_BYTES + 1)
    if len(contents) > MAX_RELEASE_DOCUMENT_BYTES:
        raise ValueError("Release Markdown exceeds the 8 MiB rewrite budget")
    text = contents.decode("utf-8", errors="strict")

    def link(match):
        label, target = match.groups()
        if "://" in target or target.startswith("#"):
            return match.group(0)
        resolved = (document.parent / target.split("#", 1)[0]).resolve()
        if resolved.is_relative_to(destination.resolve()) and resolved.exists():
            return match.group(0)
        return label + " (development-source reference: " + target + "; not bundled)"

    output, prose, fence = [], [], None
    def flush_prose():
        output.append(re.sub(r"\[([^\]]+)\]\(([^)]+)\)", link, "".join(prose)))
        prose.clear()

    # Recognize only CR/LF line endings and keep their original byte spelling.
    for match in re.finditer(r"[^\r\n]*(?:\r\n|\r|\n|$)", text):
        line = match.group(0)
        marker = re.fullmatch(r" {0,3}(`{3,}|~{3,})([^\r\n]*)", line.rstrip("\r\n"))
        if fence is not None:
            output.append(line)
            if marker and marker[1][0] == fence[0] and len(marker[1]) >= fence[1] and not marker[2].strip(" \t"):
                fence = None
        elif marker and (marker[1][0] == "~" or "`" not in marker[2]):
            flush_prose()
            output.append(line)
            fence = (marker[1][0], len(marker[1]))
        else:
            prose.append(line)
    flush_prose()
    rewritten = "".join(output).encode("utf-8")
    if rewritten != contents:
        document.write_bytes(rewritten)


def rename_noreplace(source, destination):
    """Publish one complete artifact, refusing an existing name in the OS call.

    Checking exists() then using a replacing rename would lose a competing
    writer's output. Unsupported exclusive-rename APIs/filesystems fail closed.
    This is not a two-artifact transaction or a power-loss durability guarantee.
    """
    source, destination = source.absolute(), destination.absolute()
    no_links(source)
    no_links(destination)
    if sys.platform == "win32":
        # Windows os.rename always refuses an existing destination.
        os.rename(source, destination)
        return
    if sys.platform not in ("linux", "darwin"):
        raise ValueError("PACKAGE_PUBLICATION_UNSUPPORTED: exclusive rename is unavailable on this platform")
    library = ctypes.CDLL(None, use_errno=True)
    try:
        if sys.platform == "linux":
            rename = library.renameat2
            rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
            arguments = [0, os.fsencode(source), 0, os.fsencode(destination), 1]  # Absolute paths; RENAME_NOREPLACE.
        else:
            rename = library.renamex_np
            rename.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_uint]
            arguments = [os.fsencode(source), os.fsencode(destination), 4]  # RENAME_EXCL.
    except AttributeError as error:
        raise ValueError("PACKAGE_PUBLICATION_UNSUPPORTED: native exclusive rename API is unavailable") from error
    rename.restype = ctypes.c_int
    if rename(*arguments) != 0:
        number = ctypes.get_errno()
        raise OSError(number, os.strerror(number), str(source), None, str(destination))


def verify_archive(archive, folder):
    """Compare every archived member with the verified staged package bytes."""
    verify(folder)
    require_file(archive)
    files = checked_tree(folder, required_package_files() | {"package-manifest.json"})
    with zipfile.ZipFile(archive) as contents:
        names = contents.namelist()
        if len(names) != len(files) or set(names) != set(files):
            raise ValueError("Package archive differs from the exact verified file inventory")
        for name, path in sorted(files.items()):
            expected_size = path.stat().st_size
            if contents.getinfo(name).file_size != expected_size:
                raise ValueError("Package archive file size differs: " + name)
            size, value = 0, hashlib.sha256()
            with contents.open(name) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    size += len(block)
                    if size > expected_size:
                        raise ValueError("Package archive exceeds expected file size: " + name)
                    value.update(block)
            if size != expected_size or value.hexdigest() != digest(path):
                raise ValueError("Package archive bytes differ: " + name)
    return digest(archive)


def build(destination, jar, expected_sha256):
    no_links(destination.absolute())
    destination = destination.resolve()
    allowed = (ROOT / ".pitrelay-dev" / "packages").absolute()
    no_links(destination)
    if not destination.is_relative_to(allowed) or destination == allowed:
        raise ValueError("Build destination must be a new child of workspace .pitrelay-dev/packages")
    if destination.exists():
        raise ValueError("Destination already exists; packages are never overwritten")
    archive = destination.parent / (destination.name + ".zip")
    no_links(archive)
    if archive.exists():
        raise ValueError("Archive already exists; retained package is not overwritten")
    if not valid_hash(expected_sha256):
        raise ValueError("An explicit expected engine SHA256 is required")
    require_file(jar)
    if not jar.resolve().is_relative_to(ROOT.resolve()) or digest(jar) != expected_sha256:
        raise ValueError("Engine must be a verified workspace artifact with the expected hash")
    verify_engine(jar)
    # Inspect the complete input inventory before making any package output. No
    # wildcard copy may quietly omit missing notices or include a private log.
    for source in REVIEWED_FILES:
        require_file(ROOT / source)
    for source, (_, names) in REVIEWED_TREES.items():
        checked_tree(ROOT / source, names, NONSHIPPING_SOURCE_DOCUMENTS.get(source, ()))
    destination.parent.mkdir(parents=True, exist_ok=True)
    no_links(destination.parent)
    stage = destination.parent / ("." + destination.name + ".stage-" + uuid.uuid4().hex)
    # Windows 0700 mkdir installs a new DACL that can exclude a restricted
    # development token. Inherit the approved workspace ACL there; POSIX uses
    # owner-only mode. Neither branch grants access outside this workspace.
    stage.mkdir(mode=0o777 if sys.platform == "win32" else 0o700)
    staged_package, staged_archive = stage / "package", stage / "package.zip"
    published = []
    try:
        write_json(stage / "build-request.json", {"schema_version": "1.0", "package": str(destination),
                   "archive": str(archive), "engine_sha256": expected_sha256, "two_path_atomicity": False})
        result = assemble_package(staged_package, jar, expected_sha256)
        with zipfile.ZipFile(staged_archive, "x", compression=zipfile.ZIP_DEFLATED) as output:
            for relative, path in sorted(checked_tree(staged_package, required_package_files() | {"package-manifest.json"}).items()):
                require_file(path)
                output.write(path, relative)
        archive_hash = verify_archive(staged_archive, staged_package)
        write_json(stage / "verified.json", {**result, "archive_sha256": archive_hash})
        rename_noreplace(staged_package, destination)
        published.append(str(destination))
        write_json(stage / "package-published.json", {"package": str(destination), "manifest_sha256": result["manifest_sha256"]})
        rename_noreplace(staged_archive, archive)
        published.append(str(archive))
        write_json(stage / "archive-published.json", {"archive": str(archive), "archive_sha256": archive_hash})
        result.update({"package": str(destination), "archive": str(archive), "archive_sha256": archive_hash,
                       "build_receipts": str(stage), "two_path_atomicity": False})
        return result
    except BaseException as error:
        # Retain failed staging and any completed publication; never delete or
        # replace a final path that another process could already be using.
        receipt = stage / "failure.json"
        try:
            write_json(receipt, {"result": "FAIL", "error_type": type(error).__name__, "error": str(error),
                       "package": str(destination), "archive": str(archive), "published": published,
                       "two_path_atomicity": False, "recovery": "Inspect retained staging and verified identities; existing final names are never overwritten"})
        except (OSError, ValueError) as receipt_error:
            error.add_note("Could not write failure receipt: " + str(receipt_error))
        error.add_note("Package build evidence retained at " + str(stage))
        error.package_build_stage = str(stage)
        raise


def assemble_package(destination, jar, expected_sha256):
    """Populate only a private, caller-owned staging directory."""
    destination.mkdir()
    copy_file(jar, destination / "engine" / "pitrelay.jar")
    for source, target in REVIEWED_FILES.items():
        copy_file(ROOT / source, destination / target)
    for source, (target, names) in REVIEWED_TREES.items():
        copy_tree(ROOT / source, destination / target, names, NONSHIPPING_SOURCE_DOCUMENTS.get(source, ()))
    # Broken source-tree links are identified explicitly instead of masquerading as installed files.
    for name in REVIEWED_TREES["docs/release"][1]:
        if not name.endswith(".md"):
            continue
        document = destination / "docs/release" / name
        rewrite_document_links(document, destination)
    readme = """# PitRelay internal local package

Local code-freeze candidate; public distribution is not authorized. Read
docs/release/PITRELAY_LICENSE.md and PITRELAY_LICENSE_SCOPE.json for private-use
terms and exact scope. Inherited MIT/BSD/Apache rights and ordinary robot outputs
are preserved. This is not a blanket proprietary license for the entire JAR.
Java17 or later is a host prerequisite; no system software is installed and no
second wpilog-mcp checkout is needed. This package contains the engine itself.

Verify package-manifest.json against the original retained SHA256 before use.
The manifest detects changed bytes but is not a publisher signature. The complete
local Codex preparation path is docs/release/LOCAL_INSTALLATION.md. It uses the
included setup/configure_local.py once (Python3.11+ standard library), an existing
Java17+, explicit new state and output paths, and the exact license hash. It
produces all four skills plus their MCP dependency, without global config edits.
Python is not needed by the running plugin. No runtime installer is bundled.

Standard Access starts with private state and explicitly supplied artifacts:

    <java> -Xmx384m -cp <package>/engine/pitrelay.jar org.pitrelay.Main --state <private-state> --mode cli --operation capability.list

Optional Workspace Access additionally requires --experience workspace,
--workspace <authorized-project>, explicit --grants and --workspace-disclosure
accepted-v1. Read the disclosed file/command/checkpoint/source-write permissions
before enabling it. A build/replay/simulation does not prove physical safety or repair.

Use --mode mcp for stdio, or --operation and --arguments for the non-UI CLI.
Paths and JSON must be quoted for the shell in use. Project-specific Codex TOML
can be generated by scripts/package_local.py config in the development checkout;
it writes only a requested file, never user/global configuration. Regenerate
literal paths after moving the package. Actual client verification is specific
to the candidate and client version recorded in the release evidence.

Windows configuration preflight reads the native ANSI code page (GetACP) and
refuses launch paths that cannot be represented exactly. Java17's launcher can
replace unmappable characters before the engine starts. Use paths representable
in the current code page or a separately validated runtime/environment. This
tool never changes Windows regional settings. Unicode-correct TOML and runtime
eligibility are separate checks; broad Java Unicode-path support is UNVERIFIED.
See Oracle Java17.0.17 launcher note JDK-8337506:
https://www.oracle.com/java/technologies/javase/17-0-17-relnotes.html

The optional org.pitrelay.Companion entry point previews a patch by default.
Promote/restore/recover require an actual console and exact scoped confirmation; no token
issuer is exposed through MCP. Use the companion's documented named arguments.
The optional org.pitrelay.LocalHttp entry point is a localhost-only development
adapter. It requires explicit state/port/token configuration and defaults to
Standard Access. Optional Workspace Access requires its workspace, grants and
disclosure; apply, restore and notebook-write grants are rejected. It is not a
public endpoint, OAuth service or hosted multiuser mode.

Runtime skills live in skills/. Their presence is not proof they were installed
or activated by a client. Always require workflow contract2 compatibility.

All source, logs, state, approval keys, jobs and reports stay in the configured
local directories. Connecting a host model can send selected tool results to that
host; local-first does not mean the model runs offline. No automatic uploads,
updates, network listener, robot connection or model API call starts with the CLI.

Uninstall by stopping related processes, removing their explicit client entries,
and removing only this package directory after preserving needed versions. State
and source are separate; never delete recovery checkpoints as an uninstall side
effect. See docs/release/ for privacy, recovery, compatibility and release limits.
"""
    (destination / "README.md").write_text(readme, encoding="utf-8")
    manifest = {**MANIFEST_METADATA, "engine_sha256": expected_sha256, "files": inventory(destination)}
    write_json(destination / "package-manifest.json", manifest)
    return verify(destination)


def native_windows_code_page():
    """Read native launcher encoding; never infer it from Python/console locale."""
    if os.name != "nt":
        return None
    try:
        get_code_page = ctypes.WinDLL("kernel32", use_last_error=True).GetACP
        get_code_page.argtypes = []
        get_code_page.restype = ctypes.c_uint
        code_page = get_code_page()
        if not code_page:
            raise ValueError("GetACP returned no code page")
        return code_page
    except (AttributeError, OSError, ValueError) as error:
        raise ValueError("WINDOWS_LAUNCHER_ENCODING_UNAVAILABLE: cannot establish the native Windows launcher code page; use a separately validated runtime/environment") from error


def require_launcher_encoding(paths, code_page):
    """Pure conservative eligibility check; successful encoding is not a launch test."""
    if type(code_page) is not int or not 1 <= code_page <= 65535:
        raise ValueError("WINDOWS_LAUNCHER_ENCODING_UNAVAILABLE: invalid native code page")
    encoding = "cp" + str(code_page)
    try:
        for role, value in paths.items():
            if type(value) is not str or value.encode(encoding, errors="strict").decode(encoding, errors="strict") != value:
                raise ValueError("WINDOWS_JAVA_PATH_ENCODING: " + role + " cannot roundtrip exactly through native code page " + str(code_page))
    except UnicodeError as error:
        raise ValueError("WINDOWS_JAVA_PATH_ENCODING: " + role + " contains characters unsupported by native code page " + str(code_page)
                         + "; use a representable path or a separately validated runtime/environment. No code-page/global-setting change is performed.") from error
    except LookupError as error:
        raise ValueError("WINDOWS_LAUNCHER_ENCODING_UNAVAILABLE: native code page " + str(code_page) + " cannot be checked; use a separately validated runtime/environment") from error


def launcher_preflight(java, args, working_directory):
    for index, argument in enumerate(args):
        if argument in ("-cp", "-classpath", "--class-path"):
            if index + 1 >= len(args) or os.pathsep in args[index + 1]:
                raise ValueError("JAVA_CLASSPATH_SEPARATOR: selected package must be one literal classpath entry; relocate it outside a path containing " + repr(os.pathsep))
    code_page = native_windows_code_page()
    if code_page is not None:
        values = {"java executable": str(java), "working directory": str(working_directory)}
        values.update({"launcher argument " + str(index): value for index, value in enumerate(args)})
        require_launcher_encoding(values, code_page)
    return {"native_windows_code_page": code_page,
            "encoding_check": "representable_in_native_code_page" if code_page is not None else "not_applicable_non_windows",
            "runtime_launch": "NOT_RUN", "broad_unicode_runtime_support": "UNVERIFIED"}


def configuration_toml(java, args, workspace):
    """Serialize literal paths without making a claim about runtime eligibility."""
    # Preserve Unicode scalar values: JSON's ASCII-only surrogate pairs are not
    # valid TOML escapes. Parse and check literal arguments before creating output.
    text = "# Generated literal-path example; not installed. Regenerate after relocation.\n[mcp_servers.pitrelay]\n"
    text += "command = " + json.dumps(str(java), ensure_ascii=False) + "\nargs = " + json.dumps(args, ensure_ascii=False) + "\ncwd = " + json.dumps(str(workspace), ensure_ascii=False) + "\nstartup_timeout_sec = 30\ntool_timeout_sec = 120\n"
    text += "\n[mcp_servers.pitrelay.env]\nJAVA_TOOL_OPTIONS = ''\nJDK_JAVA_OPTIONS = ''\n_JAVA_OPTIONS = ''\n"
    text.encode("utf-8", errors="strict")
    parsed = tomllib.loads(text)["mcp_servers"]["pitrelay"]
    if parsed["command"] != str(java) or parsed["args"] != args or parsed["cwd"] != str(workspace):
        raise ValueError("Generated TOML does not preserve the exact selected paths")
    return text


WORKSPACE_DISCLOSURE = (
    "Workspace Access lets PitRelay read the project files you authorize. With the corresponding permissions, "
    "it can run development commands and create checkpoints and temporary files. Modifying source requires "
    "separate authorization for the proposed scope. Builds, replay and simulation do not prove that a physical "
    "robot is safe or fixed."
)


def configuration(package, java, workspace, state, output, *, experience="standard", grants=None, workspace_disclosure=None):
    checked = verify(package)
    if experience not in ("standard", "workspace"):
        raise ValueError("Choose Standard Access or Workspace Access")
    if experience == "standard" and (workspace is not None or grants is not None or workspace_disclosure is not None):
        raise ValueError("Standard Access uses supplied artifacts; workspace/grant options require explicit Workspace Access")
    if experience == "workspace" and (workspace is None or workspace_disclosure != "accepted-v1"):
        raise ValueError("Workspace Access requires a selected workspace and --workspace-disclosure accepted-v1. " + WORKSPACE_DISCLOSURE)
    granted = set((grants or "project_read").split(",")) if experience == "workspace" else set()
    if not granted <= {"project_read", "propose", "apply", "execute", "restore", "persist_notebook"}:
        raise ValueError("Unknown Workspace Access grant")
    for path in (java, package, state, output, *([workspace] if workspace is not None else [])):
        no_links(path.absolute())
    java, package, state, output = [path.resolve() for path in (java, package, state, output)]
    workspace = workspace.resolve() if workspace is not None else None
    if not java.is_file() or (workspace is not None and (not workspace.is_dir() or state == workspace or workspace.is_relative_to(state))):
        raise ValueError("Java/workspace/state selection is missing or unsafe")
    if not output.is_relative_to(ROOT.absolute()) or output.exists():
        raise ValueError("Generate a new workspace-local config file; never overwrite existing settings")
    if (output.is_relative_to(package) or state.is_relative_to(package) or package.is_relative_to(state)
            or output.is_relative_to(state) or state.is_relative_to(output)):
        raise ValueError("Package, state and config output must not overlap")
    # A missing leaf is allowed, but every existing ancestor must support a
    # directory. Do not create a config that makes state itself into a file.
    for directory in (state, output.parent):
        for node in (directory, *directory.parents):
            if node.exists() and not node.is_dir():
                raise ValueError("State and config parents must be directories: " + str(node))
    args = ["-Xmx384m", "-cp", str(package / "engine" / "pitrelay.jar"), "org.pitrelay.Main",
            "--state", str(state), "--mode", "mcp"]
    if experience == "workspace":
        args += ["--experience", "workspace", "--workspace", str(workspace), "--grants", ",".join(sorted(granted)),
                 "--workspace-disclosure", "accepted-v1"]
    cwd = workspace if workspace is not None else package
    preflight = launcher_preflight(java, args, cwd)
    text = configuration_toml(java, args, cwd)
    if experience == "workspace":
        text = "# " + WORKSPACE_DISCLOSURE + "\n" + text
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        stream.write(text)
    return {"result": "PASS", "config": str(output), "installed": False, "command": [str(java), *args],
            "engine_sha256": checked["engine_sha256"], "launcher_preflight": preflight,
            "experience": experience, "grants": sorted(granted),
            "workspace_disclosure": WORKSPACE_DISCLOSURE if experience == "workspace" else None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    create = sub.add_parser("build")
    create.add_argument("--destination", type=Path, required=True)
    create.add_argument("--jar", type=Path, required=True)
    create.add_argument("--jar-sha256", required=True)
    check = sub.add_parser("verify")
    check.add_argument("package", type=Path)
    config = sub.add_parser("config")
    for name in ("package", "java", "state", "output"):
        config.add_argument("--" + name, type=Path, required=True)
    config.add_argument("--workspace", type=Path)
    config.add_argument("--experience", choices=("standard", "workspace"), default="standard")
    config.add_argument("--grants")
    config.add_argument("--workspace-disclosure", choices=("accepted-v1",), help=WORKSPACE_DISCLOSURE)
    args = parser.parse_args()
    try:
        if args.command == "build":
            result = build(args.destination, args.jar, args.jar_sha256)
        elif args.command == "verify":
            result = verify(args.package)
        else:
            result = configuration(args.package, args.java, args.workspace, args.state, args.output,
                                   experience=args.experience, grants=args.grants, workspace_disclosure=args.workspace_disclosure)
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as error:
        result = {"result": "FAIL", "error": str(error)}
        if hasattr(error, "package_build_stage"):
            result["build_receipts"] = error.package_build_stage
        print(json.dumps(result))
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
