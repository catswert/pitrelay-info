"""Prepare a new local Codex marketplace. Never edit a client profile or install Java.

Python 3.11+ is needed only for setup/verification; the installed server runs Java.
Read the packaged license and supply its exact SHA-256 to acknowledge its terms.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid

sys.dont_write_bytecode = True
import package_local as packaging

SERVER = "pitrelay_local"
MARKETPLACE = "pitrelay-local"
LICENSE = "docs/release/PITRELAY_LICENSE.md"
INJECTION_VARIABLES = ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "CLASSPATH")


def disjoint(paths):
    for index, left in enumerate(paths):
        for right in paths[index + 1:]:
            if left == right or left.is_relative_to(right) or right.is_relative_to(left):
                raise ValueError("Package, output and state must be separate non-overlapping paths")


def java_version(java, cwd):
    environment = {key: value for key, value in os.environ.items() if key.upper() not in INJECTION_VARIABLES}
    completed = subprocess.run([str(java), "-version"], cwd=cwd, env=environment,
                               shell=False, capture_output=True, timeout=20)
    output = (completed.stdout + completed.stderr).decode("utf-8", errors="replace")
    match = re.search(r'(?:openjdk|java) version "(\d+)(?:[.\-"]|$)', output)
    if completed.returncode != 0 or not match or int(match[1]) < 17:
        raise ValueError("An existing Java 17+ runtime is required; version probe failed: " + output[:2048])
    return {"major": int(match[1]), "exit_code": completed.returncode, "version_output": output[:2048]}


def prepare(package, manifest_sha256, java, state, output, accept_license):
    # Never trust an inventory supplied beside its files as an authenticity anchor.
    for path in (package, java, state, output):
        packaging.no_links(path.absolute())
    package, java, state, output = (path.resolve() for path in (package, java, state, output))
    disjoint([package, state, output])
    manifest_path = package / "package-manifest.json"
    packaging.require_file(manifest_path)
    with manifest_path.open("rb") as stream:
        manifest_bytes = stream.read(packaging.MAX_MANIFEST_BYTES + 1)
    if (len(manifest_bytes) > packaging.MAX_MANIFEST_BYTES or not packaging.valid_hash(manifest_sha256)
            or hashlib.sha256(manifest_bytes).hexdigest() != manifest_sha256):
        raise ValueError("Original manifest SHA256 differs from the independently retained release receipt")
    original = json.loads(manifest_bytes.decode("utf-8"), object_pairs_hook=packaging.unique_object)
    packaging.validate_manifest(original)
    checked = packaging.verify(package)
    if checked["engine_sha256"] != original["engine_sha256"]:
        raise ValueError("Source engine identity changed during verification")
    if not packaging.valid_hash(accept_license) or packaging.digest(package / LICENSE) != accept_license:
        raise ValueError("Read the packaged license and acknowledge its exact SHA256 with --accept-license")
    packaging.require_file(java)
    if output.exists() or state.exists():
        raise ValueError("Output and state must be new paths; existing installs/state are never overwritten or reused")
    for directory in (output.parent, state.parent):
        for node in (directory, *directory.parents):
            if node.exists() and not node.is_dir():
                raise ValueError("Output/state parents must be directories")
    if java.is_relative_to(output) or java.is_relative_to(state) or java.is_relative_to(package):
        raise ValueError("Select an independently installed Java runtime outside package/output/state")
    jvm_home, temporary = state / "jvm-home", state / "tmp"
    args = ["-Xmx384m", "-Duser.home=" + str(jvm_home), "-Djava.io.tmpdir=" + str(temporary),
            "-cp", "engine/pitrelay.jar", "org.pitrelay.Main", "--state", str(state / "engine"), "--mode", "mcp"]
    packaging.launcher_preflight(java, args, output / "pitrelay")
    # The installed cache is selected by the client, so also reject launcher path
    # limitations at preparation; relocation still requires a real client probe.
    runtime = java_version(java, package)
    packaging.no_links(output.parent)
    output.parent.mkdir(parents=True, exist_ok=True)
    packaging.no_links(output.parent)
    stage = output.parent / ("." + output.name + ".prepare-" + uuid.uuid4().hex)
    stage.mkdir()
    plugin = stage / "pitrelay"
    plugin.mkdir()
    try:
        for entry in original["files"]:
            relative = entry["path"]
            target = "provenance/original-plugin.json" if relative == "plugin.json" else relative
            packaging.copy_file(package / relative, plugin / target)
        with (plugin / "provenance/original-package-manifest.json").open("xb") as stream:
            stream.write(manifest_bytes)
        manifest = {
            "name": "pitrelay", "version": "0.1.0-dev",
            "description": "Local FRC code and telemetry investigation using explicitly supplied artifacts.",
            "author": {"name": "catswert", "email": "pitrelay@gmail.com"},
            "license": "SEE LICENSE IN docs/release/PITRELAY_LICENSE.md AND docs/release/LICENSE_INVENTORY.md",
            "skills": "./skills/", "mcpServers": "./.mcp.json",
            "interface": {"displayName": "PitRelay", "shortDescription": "FRC code and telemetry investigation", "category": "Developer Tools"},
        }
        (plugin / ".codex-plugin").mkdir()
        packaging.write_json(plugin / ".codex-plugin/plugin.json", manifest)
        packaging.write_json(plugin / ".mcp.json", {"mcpServers": {SERVER: {
            "command": str(java), "args": args, "cwd": ".",
            "env": {key: "" for key in INJECTION_VARIABLES}, "startup_timeout_sec": 30, "tool_timeout_sec": 120,
        }}})
        marketplace = stage / ".agents/plugins"
        marketplace.mkdir(parents=True)
        packaging.write_json(marketplace / "marketplace.json", {
            "name": MARKETPLACE, "interface": {"displayName": "PitRelay local"},
            "plugins": [{"name": "pitrelay", "source": {"source": "local", "path": "./pitrelay"},
                         "policy": {"installation": "AVAILABLE", "authentication": "ON_INSTALL"},
                         "category": "Developer Tools"}],
        })
        receipt = {"schema_version": "1.0", "kind": "prepared_local_codex_plugin", "installed": False,
                   "source_manifest_sha256": manifest_sha256, "engine_sha256": checked["engine_sha256"],
                   "license_acknowledged_sha256": accept_license, "license_version": "1.0",
                   "experience": "standard", "workspace_grants": [], "runtime": runtime,
                   "java_executable_sha256": packaging.digest(java),
                   "state": str(state), "output": str(output), "server": SERVER,
                   "relocation": "Regenerate for another Java/state path; installed-cache behavior must be tested",
                   "files": packaging.inventory(stage)}
        packaging.write_json(stage / "prepared-installation.json", receipt)
        # Recheck copied payloads against source before exposing a usable marketplace.
        for entry in original["files"]:
            target = "provenance/original-plugin.json" if entry["path"] == "plugin.json" else entry["path"]
            if packaging.digest(plugin / target) != entry["sha256"]:
                raise ValueError("Copied payload identity changed during preparation")
        if packaging.digest(package / "package-manifest.json") != manifest_sha256:
            raise ValueError("Source manifest changed during preparation")
        # State is separate and intentionally retained even if final publication fails.
        packaging.no_links(state)
        state.mkdir(parents=True, exist_ok=False)
        packaging.no_links(state)
        jvm_home.mkdir()
        temporary.mkdir()
        packaging.no_links(output)
        packaging.no_links(stage)
        packaging.rename_noreplace(stage, output)
        return {"result": "PASS", "installed": False, "plugin": str(output / "pitrelay"),
                "marketplace_root": str(output), "state": str(state), "runtime": runtime,
                "engine_sha256": checked["engine_sha256"], "receipt": str(output / "prepared-installation.json")}
    except BaseException as error:
        error.add_note("Retained preparation at " + str(stage) + "; separate state, if created, retained at " + str(state))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for field in ("package", "java", "state", "output"):
        parser.add_argument("--" + field, type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--accept-license", required=True)
    args = parser.parse_args()
    try:
        result = prepare(args.package, args.manifest_sha256, args.java, args.state, args.output, args.accept_license)
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print(json.dumps({"result": "FAIL", "error": str(error), "notes": getattr(error, "__notes__", [])}))
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
