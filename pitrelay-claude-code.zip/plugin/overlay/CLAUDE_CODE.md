# PitRelay for Claude Code (locally prepared)

This folder is a Claude Code plugin prepared on this computer by `configure_claude.py` from a verified PitRelay package. The PitRelay files are byte-for-byte the packaged ones; their original metadata is kept under `provenance/`. Only the following were added for Claude Code:

| Added file | Purpose |
|---|---|
| `.claude-plugin/plugin.json` | Plugin metadata for Claude Code. |
| `.mcp.json` | Starts the host (`host/gateway.py`) as a local stdio MCP server named `pr`, with the Python chosen at setup. |
| `host/` | The host. It runs the bundled engine (unmodified) with the Java, state folder and access level chosen at setup (`host/launch.json`), relays the engine's answers unchanged and adds labelled host notes for known v11 engine problems. Unless the plugin was prepared `--without-collector`, it also runs PitRelay Collector (`host/pitrelay_collector/`, with `host/collector.py` as its command line). |
| `skills/pitrelay-claude-host/` | Claude Code specifics: tool names, the host, evidence intake, and the boundary between PitRelay's gateway and Claude Code's own tools. |
| `skills/pitrelay-collect/` | Collecting robot and Driver Station logs with the built-in collector (not in a `--without-collector` preparation). |
| `skills/pitrelay-collector-intake/` | Using PitRelay Collector packages. |
| `commands/` | `/pitrelay:start`, `/pitrelay:diagnose`, `/pitrelay:checkup`, `/pitrelay:import-collection`, and `/pitrelay:collect` with the collector. |
| `CLAUDE_CODE.md` | This file. |

The four PitRelay skills appear as `/pitrelay:pitrelay-investigate`, `/pitrelay:pitrelay-improve`, `/pitrelay:pitrelay-verify-recover` and `/pitrelay:pitrelay-navigate-explain`. Claude also uses them on its own when they apply. Engine tools appear as `mcp__plugin_pitrelay_pr__pitrelay_<operation>`. Host and collector tools appear as `mcp__plugin_pitrelay_pr__host_status` and `mcp__plugin_pitrelay_pr__collector_<action>`.

**License.** Read `docs/release/PITRELAY_LICENSE.md` before preparing the plugin. Private and team-internal use and modification are permitted. Redistribution of protected original material, unchanged or modified, is restricted.

This folder contains the engine. So does the copy Claude Code makes when you install it, in `~/.claude/plugins/cache/pitrelay-local/`. Do not share, sync, publish or commit either. Within your team, share the generator project instead (`configure_claude.py` with its `overlay/`, `host/` and `collector/` folders, or the whole repository). Each person then prepares their own copy from a package they are entitled to use.

**State.** Two folders outside this plugin hold data, and `claude plugin uninstall` deletes neither:
* the state folder named in `prepared-installation.json` (`state`): PitRelay's state (artifacts, cases, reports, checkpoints), the host's Python environment and the host's logs;
* with the collector, the collector store (`collector.store` in `prepared-installation.json`; `host_status` shows it): the collected logs, the sources and trusted robot keys, and the exported packages (private, not anonymized). By default it is the standalone PitRelay Collector's per-user folder, shared with that collector.

Review each and delete it deliberately when you no longer need it; deleting the state folder does not delete the collected logs.

**Collection.** The collector reads only the sources the person confirmed and never changes anything on a robot or Driver Station. It collects while a Claude Code session with this plugin is open. For collection while Claude Code is closed, ask Claude to turn on background collection (`collector_background`), which starts the bundled collector now and at every login; turn it off the same way (or on the collector page) before deleting this folder.

**Removing.** After `claude plugin uninstall` and `claude plugin marketplace remove`, also delete `~/.claude/plugins/cache/pitrelay-local/`, then this marketplace folder.

**Moving.** Claude Code starts the host from this folder (its path is recorded in `.mcp.json`), not from its cached copy, and background collection runs from here too. If you move this folder, the state folder, Java or Python, prepare a new copy instead. `--reuse-state` keeps the state folder's files, but the engine reaches its earlier cases and artifacts only with the same state path, access level and workspace. A moved marketplace fails to start.
