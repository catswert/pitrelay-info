---
description: Report-first PitRelay checkup of supplied robot code and logs, with no reported failure
argument-hint: "[scope, e.g. 'drivetrain logs from Saturday' or 'the whole project']"
---

Use the `pitrelay-claude-host` and `pitrelay-investigate` skills to run a report-first checkup (workflow kind `checkup`) of: $ARGUMENTS

Group results as:
* observed problems;
* credible latent risks;
* insufficient observability;
* maintainability suggestions;
* accepted behavior within scope.

Keep a coverage ledger of what was examined and what was skipped. Do not create instrumentation, patches or files unless the user asks after seeing the report.
