---
description: Collect robot and Driver Station logs with the built-in PitRelay Collector, export a verified package and analyze it with PitRelay
argument-hint: "[what to collect or look at, e.g. 'the robot over USB' or 'the last match']"
allowed-tools: mcp__plugin_pitrelay_pr__host_status, mcp__plugin_pitrelay_pr__collector_status, mcp__plugin_pitrelay_pr__collector_configure_source, mcp__plugin_pitrelay_pr__collector_trust_host_key, mcp__plugin_pitrelay_pr__collector_collect_now, mcp__plugin_pitrelay_pr__collector_list_captures, mcp__plugin_pitrelay_pr__collector_export, mcp__plugin_pitrelay_pr__collector_job_status, mcp__plugin_pitrelay_pr__collector_supply_to_engine, mcp__plugin_pitrelay_pr__collector_open_page, mcp__plugin_pitrelay_pr__collector_background, mcp__plugin_pitrelay_pr__pitrelay_log_inspect, mcp__plugin_pitrelay_pr__pitrelay_log_entries, mcp__plugin_pitrelay_pr__pitrelay_log_messages, mcp__plugin_pitrelay_pr__pitrelay_log_message_groups, mcp__plugin_pitrelay_pr__pitrelay_signal_read, mcp__plugin_pitrelay_pr__pitrelay_signal_statistics, mcp__plugin_pitrelay_pr__pitrelay_signal_time_statistics, mcp__plugin_pitrelay_pr__pitrelay_signal_transitions, mcp__plugin_pitrelay_pr__pitrelay_signal_peaks, mcp__plugin_pitrelay_pr__pitrelay_frc_timeline, mcp__plugin_pitrelay_pr__pitrelay_frc_power
---

Use the `pitrelay-collect` skill (and `pitrelay-claude-host` for the engine) for: $ARGUMENTS

The tools above are pre-approved for this command. Adding or widening a source, trusting a robot's key, collecting in the background, including robot source code in a package and reading a package from outside the collector's store each still ask the person in a dialog.

1. Call `mcp__plugin_pitrelay_pr__collector_status`. Report in a few lines:
   * which sources exist and their state;
   * whether collection runs (in this session, in the background, or not at all);
   * any alert.

   If the collector is not available, report `host_status` and stop.
2. If no source fits the request, propose one with `collector_configure_source`, using `suggested_sources`. Ask only what you cannot know:
   * **Robot:** its address (USB `172.22.11.2`; Ethernet or radio `10.TE.AM.2` from the team number; `roborio-TEAM-frc.local`).
     * A roboRIO uses user `lvuser` and `auth: blank_password`.
     * Systemcore uses user `systemcore` and `auth: systemcore_default`.

     Nothing is contacted before the person allows the source. Then, if the robot answers, a second dialog shows its SSH host key to trust.
   * **Driver Station laptop:** its log folder on this computer.
3. Call `collector_collect_now` (sync now). It works even while automatic collection is off.
   * If a robot is waiting for host-key trust, call `collector_trust_host_key`.
   * If a robot needs a password the team set, call `collector_open_page`; never ask for it in the conversation.
4. Once, ask whether the person wants logs collected automatically, even while Claude Code is closed (matches happen when nobody is at the laptop). If yes, call `collector_background` with `on`; they confirm in the dialog.
5. Find what to analyze with `collector_list_captures`:
   * The most recent match is usually the newest robot `.wpilog` together with the Driver Station `.dslog`/`.dsevents` from the same time (collector clock).
   * WPILib names robot logs `FRC_<date>_<time>_<event>_<match>.wpilog` once FMS is connected.

   Confirm the choice with the person.
6. Call `collector_export` with those capture ids. Add observations the person states, attributed to them. If the person wants the robot code included, pass its project folder as `source_project_dir`; they confirm it in a dialog. The store keeps the five newest packages, plus every package with observations or source code.
7. Call `collector_supply_to_engine` with package `latest`, then analyze with PitRelay's own skills (`pitrelay-investigate`). State each recording's acquisition status, gaps and clock domain alongside any result.

Say up front what cannot be analyzed here, using each recording's `not_supplied` reason or limitations:
* files over 64 MiB;
* CTRE `.hoot` without a configured Owlet;
* NI Driver Station v3 logs;
* REVLOG v2 with the v11 engine (it decodes REVLOG v1 only; a newer engine build may decode it, so go by the engine's answer).

Nothing is ever changed or deleted on the robot or the Driver Station. Nothing is uploaded anywhere. Collection works without internet; the analysis in Claude Code needs it.
