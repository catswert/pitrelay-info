---
description: Verify a PitRelay Collector package and bring its recordings into a PitRelay investigation
argument-hint: "<path to pitrelay-collection-*.zip or an extracted package folder>"
---

Use the `pitrelay-claude-host` and `pitrelay-collector-intake` skills for this collector package: $ARGUMENTS

1. For a `.zip`, if the collector tools are available, call `collector_supply_to_engine` with its absolute path (or `latest` for the newest package the built-in collector exported). It verifies the package and supplies its recordings directly; for a ZIP from outside the collector store the person confirms it in a dialog, which needs an interactive session. For an extracted package folder, or without the collector tools, follow `pitrelay-collector-intake`: verify the package with the collector's `verify` command, check the access level, and propose how to bring the recordings in; wait for the user's agreement before extracting or uploading.
2. List the recordings with their acquisition status, format, size and PitRelay result or planned operation. Include the ones that cannot be supplied, and why.
3. Ask which recordings and time window matter before analyzing further.

State gaps, unobserved intervals and clock domains alongside any result.
