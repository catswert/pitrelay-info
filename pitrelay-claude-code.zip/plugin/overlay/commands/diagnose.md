---
description: Diagnose an FRC robot symptom from supplied code and telemetry with PitRelay evidence
argument-hint: "<what happened, when, and what you have (logs, code, observations)>"
---

Use the `pitrelay-claude-host` and `pitrelay-investigate` skills, and diagnose this reported symptom:

$ARGUMENTS

Start the session as those skills describe. Ask only for evidence that distinguishes between plausible causes. Keep observed facts, derived results, attributed reports and hypotheses separate. If the evidence cannot decide between causes, say so and name the observation that would. Never change the team's project or anything on a robot as part of diagnosing.
