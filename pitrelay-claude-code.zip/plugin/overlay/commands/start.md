---
description: Connect to the local PitRelay engine and collector and report compatibility, access level and readiness
allowed-tools: mcp__plugin_pitrelay_pr__host_status, mcp__plugin_pitrelay_pr__pitrelay_client_compatibility, mcp__plugin_pitrelay_pr__pitrelay_capability_list, mcp__plugin_pitrelay_pr__pitrelay_workspace_inspect, mcp__plugin_pitrelay_pr__collector_status
---

Use the `pitrelay-claude-host` skill.

1. Call `mcp__plugin_pitrelay_pr__host_status`.
2. Call `mcp__plugin_pitrelay_pr__pitrelay_client_compatibility` with `{"workflow_contract": "2"}`.
3. Call `mcp__plugin_pitrelay_pr__pitrelay_capability_list`.
4. Call `mcp__plugin_pitrelay_pr__pitrelay_workspace_inspect`.
5. If `host_status` shows the collector is included, call `mcp__plugin_pitrelay_pr__collector_status`.

If the tools are missing or fail, report the exact error (from `host_status` when it answers). Point to `/mcp`, and do not invent results.

Report briefly:
* engine and workflow compatibility, and whether the host's notes for the v11 engine are active;
* access level (Standard, or Workspace with its root and granted capabilities);
* which kinds of evidence can be analyzed now;
* what the engine lists as unsupported or conditional;
* the collector, if included: whether collection is on, its sources and their state, and any alert.

Then ask what the user wants to do: collect logs (with the collector), look at a symptom, run a checkup, or bring in a collector package. Mention `/pitrelay:diagnose`, `/pitrelay:checkup`, `/pitrelay:import-collection`, and `/pitrelay:collect` when the collector is included.
