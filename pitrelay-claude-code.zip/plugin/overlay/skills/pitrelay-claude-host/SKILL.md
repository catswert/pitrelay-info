---
name: pitrelay-claude-host
description: How PitRelay runs inside Claude Code - its tool names (mcp__plugin_pitrelay_pr__pitrelay_*), the local host in front of the engine (host_status, labelled host notes), how logs and code reach the engine here, how to read this installation's access level, and the boundary between PitRelay's permission gateway and Claude Code's own file and shell tools. Use before the first PitRelay tool call in a conversation, and whenever a PitRelay skill mentions tool names, attachments, client limitations or Workspace Access.
---

# PitRelay in Claude Code

The other PitRelay skills (`pitrelay-investigate`, `pitrelay-improve`, `pitrelay-verify-recover`, `pitrelay-navigate-explain`) are the method. This skill only explains what is specific to running them in Claude Code. Where they conflict, the PitRelay skills and the engine's own responses win.

## Tool names

PitRelay skills name operations like `capability.list` and MCP tools like `pitrelay_capability_list`. In Claude Code the same tool is exposed as:

`mcp__plugin_pitrelay_pr__pitrelay_capability_list`

To map any operation, replace dots with underscores, add `pitrelay_`, then add the prefix `mcp__plugin_pitrelay_pr__`. Each tool is one operation, so never add an `operation` argument, and use the live schema (`pitrelay_help` with `operation_name`). Never type tool names into a shell.

If no `mcp__plugin_pitrelay_pr__` tools are available, the server is not connected. Say so and suggest `/mcp` or `claude mcp list` to see the error (a common cause is that the Java or Python recorded at setup moved). Never imitate engine results.

## The host in front of the engine

The server `pr` is a small local host that runs PitRelay's unmodified engine and relays its answers unchanged. It adds `host_status` and, when this installation includes the collector, the `collector_*` tools (see `pitrelay-collect`).

* **Engine errors.** When an engine tool returns `ENGINE_UNAVAILABLE`, call `host_status` and report its `engine.problem`:
  * The engine stopped. The host restarts it on the next call. Upload transfers that were open are kept by the engine: continue one with the same `transfer_id` from the next offset, or abort it, rather than starting over.
  * `engine/pitrelay.jar` is not the engine recorded at setup. Nothing is started; the person prepares the plugin again.

  Several Claude Code sessions may use the installation at the same time. Each runs its own engine on the same state, and the engine coordinates them; an `upload_begin` that answers `blocked` `TRANSFER_BUSY` was already retried by the host.
* **Host notes.** The engine's result is never changed. Where a v11 answer is known to mislead, the host adds a second text item that starts `Host note (PitRelay for Claude Code, not the PitRelay engine; <rule>, engine issue <n>)`. Report a note as the host's explanation, never as an engine measurement. The rules are:
  * `revlog_v2`: the v11 engine decodes REVLOG v1 only, so on a REVLOG v2 file nothing was decoded and its "Unknown REV native record ID" issues come from that. Other issues it lists may still be real damage. Do not retry; the person can convert the file to WPILOG with REV's own tools and supply that.
  * `ds_format`: the file's records have the other Driver Station format's structure; the note names the format to call again with.
  * `upload_transfer_id`: `upload_begin` returns the transfer id as `result.id`; pass it as `transfer_id`.

  `host_status` lists the active rules (`compatibility`).
* A CSV `time_unit` other than `us`, `ms` or `s` is answered `unsupported` (`CSV_TIME_UNIT`) by the engine. The valid units are `us`, `ms` and `s`; the person confirms every CSV mapping.
* The engine reads a WPILOG entry's `unit` metadata key (not `units`).

## Start of a session

1. Call `pitrelay_client_compatibility` with `workflow_contract: "2"`. Stop the PitRelay recipes if it is not compatible.
2. Call `pitrelay_capability_list`, then `pitrelay_workspace_inspect`.
3. Tell the user the access level in one line:
   * **Standard Access**: no workspace attached. Supplied artifacts can be analyzed, and proposals made about them (`PROPOSE`).
   * **Workspace Access**: report `root` and `granted_capabilities`. Without `PROPOSE`, four tools are absent: `patch.candidate`, `patch.prepare`, `instrumentation.prepare` and `execution.plan_candidate`. `instrumentation.plan`, `patch.inspect` and `patch.export` remain. Say which are missing instead of looking for them.

   Installation chose this level, not the conversation. Never claim a grant the engine did not report, and never put grants in a tool argument.

## Getting evidence into the engine

* **Collector packages, at any access level.** For logs the built-in collector gathered, or a collector ZIP someone gave the person, use `collector_supply_to_engine`. It verifies the package, streams the recordings to the engine without passing bytes through the conversation, and inspects each one. Prefer this to uploading by hand.
* **Workspace Access with PROJECT_READ.** Capture files inside the authorized `root` with `pitrelay_artifact_register`, passing a path *relative to that root*. The engine refuses absolute paths, `..` and anything outside the root (`PATH_SCOPE`); that refusal is intended, so do not work around it. Placing a file inside the authorized folder (copying or extracting it there) changes the user's files, so ask first.
* **Standard Access.** Send bytes with `pitrelay_artifact_upload_begin`, then `pitrelay_artifact_upload_chunk`, then `pitrelay_artifact_upload_finish`:
  * at most 49152 decoded bytes per chunk, base64-encoded;
  * exact offsets, plus the file's exact byte length and SHA-256;
  * at most 64 MiB per artifact.

  You can compute the size, hash and chunks with a local command the user approves. Every chunk still passes through the conversation, so this suits small files. Before a large upload, tell the user the approximate number of chunks. Offer the alternatives:
  * narrow the evidence;
  * have the user prepare a new installation with Workspace Access to a folder holding the logs.

  If they choose a new installation, tell them two things:
  * it needs `--grants project_read,propose` to keep the proposal tools that Standard Access has;
  * the engine scopes cases and artifacts to the access level and workspace, so the Workspace installation cannot reach this installation's cases or artifact IDs, even with `--reuse-state`. The evidence is supplied or registered again there; the old cases stay reachable from a Standard installation on the same state folder.
* Never upload, or read in order to upload, credentials: `.env`, tokens in `gradle.properties`, SSH keys, keystores, passwords in deploy JSON.

## Claude Code's own tools are outside PitRelay's gateway

PitRelay's checkpoints, scoped approvals and grants govern what *PitRelay* does. The engine itself reports "Unrestricted native host tools remain outside this gateway". Claude Code's Read, Edit, Write and Bash tools are such native tools. Therefore:

* Do not use Edit, Write or Bash to apply a PitRelay proposal, restore a checkpoint, or run builds, replays or simulations **as a substitute for a PitRelay permission that is missing**. The PitRelay skills require: never bypass missing permissions through unrelated native tools. Return the proposal and the exact local verification steps instead, as Standard Access intends.
* The user may still explicitly ask Claude Code itself to edit their project, for example "apply that exported patch with Claude". That is then an ordinary Claude Code edit made at the user's request, under Claude Code's own permission prompts. It must still follow the safeguards in the export's own instructions (`patch.export` returns them):
  1. Before writing, compute each current file's SHA-256 and compare it with the export's `before_sha256`. On any mismatch, stop: the file changed since the proposal was made, and writing would discard newer work.
  2. Back up the selected files and the Git staging state, as the instructions say.
  3. Write only the listed replacement files. Handle any listed deletion separately, with the user's explicit confirmation.
  4. Show which files changed.
  5. Keep PitRelay's result labelled `NOT_APPLIED` by PitRelay, and never describe the edit as verified by PitRelay. Verification is a separate step.

  If any of these cannot be done, give the user the export and its instructions to apply themselves.
* Measurements come from PitRelay operations. You may read a file with Read to understand it, but never present your own decoding of a log as a PitRelay measurement.
* No deployment to a robot and no actuation, through PitRelay or any other tool. The only robot connection is the built-in collector's read-only log collection from sources the person confirmed. Builds, replay and simulation never prove a physical robot is safe or fixed. Physical validation stays "not performed".

## Size, paging and data handling

* Engine results can be large. Use the skills' paging and narrow windows (`offset`, `limit`, explicit time windows). If Claude Code truncates a result, retrieve the rest before relying on it.
* PitRelay runs and stores its state locally. Tool inputs and results, however, become part of this conversation and are processed by the model provider. Local-first does not mean offline.
* Nothing is uploaded anywhere else. Never send packages, logs or reports to a third party unless the user explicitly asks you to in this conversation.

## Plugin facts

* Claude Code starts `python ... host/gateway.py`, a local stdio server named `pr` (short, to keep full tool names within the 64-character limit). The host starts the engine as `java ... org.pitrelay.Main --mode mcp` with the Java recorded at setup.
* PitRelay's state and the host's Python environment live in a separate folder chosen at setup; host and engine logs are in its `host/` folder. The collector's store (collected logs, sources, trusted keys, exported packages) is another folder: by default the standalone PitRelay Collector's per-user folder; `host_status` shows it as `collector.store`. Both are outside Claude Code's plugin data, so uninstalling the plugin keeps them; each is reviewed and deleted separately.
* `prepared-installation.json`, next to the plugin folder, records the engine SHA-256, the access level, the Java and Python, the collector's packages and every file hash. `python3 configure_claude.py verify --output <marketplace>` re-checks it.
