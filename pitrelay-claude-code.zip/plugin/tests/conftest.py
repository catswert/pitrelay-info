"""Shared fixtures for the host and generator tests."""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT, ROOT / "host", ROOT / "collector" / "src", ROOT / "collector" / "tests", Path(__file__).resolve().parent):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))


@pytest.fixture
def robot(tmp_path):
    """A fake roboRIO: a local read-only SFTP server (no real robot or network beyond 127.0.0.1)."""
    from sftp_server import FakeRobotSFTP
    root = tmp_path / "robotfs"
    (root / "home" / "lvuser" / "logs").mkdir(parents=True)
    srv = FakeRobotSFTP(root).start()
    srv.root = root
    srv.logs = root / "home" / "lvuser" / "logs"
    yield srv
    srv.stop()
