"""Drive a prepared plugin's MCP server exactly as Claude Code launches it, and check the results.

    python3 tests/mcp_e2e.py <prepared-marketplace> [--posix-locale] [--home <dir>]
        [--upload <file> | --register <path-relative-to-workspace>] [--entry <name> --expect-mean <v> --expect-min <v>]
        [--collector-flow <folder with logs> --entry ... --expect-mean ... --expect-min ...]

Launch rules observed for Claude Code 2.1.309:
* the server is started from .mcp.json (command, args, env) and inherits Claude Code's environment, overlaid with
  the "env" block; "cwd" is ignored, so it runs in whatever folder Claude Code was started in;
* Claude Code sends server/discover first, then initialize (protocol 2025-11-25, capabilities roots + elicitation).

Checks:
* MCP handshake as Claude Code does it, tools/list, and every full tool name (mcp__plugin_<plugin>_<server>__<tool>)
  within 64 characters of API-legal characters;
* host_status: engine ready, the host's own files unchanged, the collector available when included;
* the workflow-contract handshake, capability.list and workspace.inspect against the receipt's access level;
* optionally an upload (Standard Access) or register (Workspace Access) of a file, then log.inspect and
  signal.statistics;
* optionally the collector route: a local-folder source (the dialog answered yes, as a person would), sync now,
  export, supply_to_engine, then signal.statistics on the supplied voltage recording.

Prints a JSON report. Exits 0 only if every check passed.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


class Server:
    def __init__(self, spec: dict, cwd: Path, posix_locale: bool = False, home: Path | None = None):
        cmd = [spec["command"], *spec.get("args", [])]
        env = dict(os.environ)
        if posix_locale:
            # Claude Code started under the POSIX locale (common over ssh and in containers). Python's own
            # C-locale coercion may have put LC_CTYPE=C.UTF-8 into os.environ; Claude Code would not.
            for k in [k for k in env if k == "LANG" or k.startswith("LC_")]:
                del env[k]
            env["LC_ALL"] = "C"
        if home is not None:
            env["HOME"] = str(home)  # login items and the credential store stay in a private test home
            env.pop("XDG_CONFIG_HOME", None)
            env.pop("XDG_DATA_HOME", None)
        env.update(spec.get("env") or {})
        self.stderr = tempfile.TemporaryFile()
        self.p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr, cwd=cwd, env=env)
        self.n = 0
        self.lines: list[dict] = []
        self.dialogs: list[dict] = []
        self.cv = threading.Condition()
        self.wlock = threading.Lock()
        threading.Thread(target=self._read, daemon=True).start()

    def _send(self, msg: dict) -> None:
        with self.wlock:
            self.p.stdin.write((json.dumps(msg) + "\n").encode())
            self.p.stdin.flush()

    def _read(self):
        for raw in self.p.stdout:
            try:
                msg = json.loads(raw)
            except ValueError:
                msg = {"_non_json_stdout": raw[:200].decode("utf-8", "replace")}
            if msg.get("method") == "elicitation/create":
                # Stands in for the person: answer yes to every dialog (only synthetic sources are offered).
                self.dialogs.append(msg["params"])
                props = msg["params"]["requestedSchema"]["properties"]
                content = {k: (True if v.get("type") == "boolean" else v.get("default")) for k, v in props.items()}
                self._send({"jsonrpc": "2.0", "id": msg["id"], "result": {"action": "accept", "content": content}})
                continue
            with self.cv:
                self.lines.append(msg)
                self.cv.notify_all()

    def rpc(self, method, params=None, timeout=180, rid=None):
        if rid is None:
            self.n += 1
            rid = self.n
        self._send({"jsonrpc": "2.0", "id": rid, "method": method, **({"params": params} if params is not None else {})})
        with self.cv:
            ok = self.cv.wait_for(lambda: any(m.get("id") == rid for m in self.lines) or self.p.poll() is not None, timeout)
            found = [m for m in self.lines if m.get("id") == rid]
        if not found:
            raise RuntimeError(f"no response to {method} (server exited={self.p.poll()}, waited={ok})")
        return found[0]

    def notify(self, method):
        self._send({"jsonrpc": "2.0", "method": method})

    def call(self, tool, arguments, timeout=180):
        r = self.rpc("tools/call", {"name": tool, "arguments": arguments}, timeout)
        if "error" in r:
            return {"_rpc_error": r["error"]}
        texts = [c.get("text", "") for c in r["result"].get("content", []) if c.get("type") == "text"]
        try:
            content = json.loads(texts[0]) if texts else {}
        except ValueError:
            content = {"_text": texts[0][:2000]}
        if isinstance(content, dict) and len(texts) > 1:
            content["_host_notes"] = texts[1:]
        return content

    def close(self):
        try:
            self.p.stdin.close()
            self.p.wait(timeout=30)
        except Exception:
            self.p.kill()


def stats_of(st: dict) -> dict:
    sr = st.get("result") or {}
    stats = sr.get("statistics") or sr
    out = {k: stats.get(k) for k in ("count", "mean", "min", "max")}
    out["unit"] = stats.get("unit", (stats.get("source") or {}).get("unit"))  # the engine reports it under source
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("marketplace", type=Path)
    ap.add_argument("--register", help="Workspace Access: register this path (relative to the workspace)")
    ap.add_argument("--upload", type=Path, help="Standard Access: upload this local file in 48 KiB chunks")
    ap.add_argument("--collector-flow", type=Path, help="a folder of logs: add it as a source, sync, export and supply")
    ap.add_argument("--entry")
    ap.add_argument("--expect-mean", type=float)
    ap.add_argument("--expect-min", type=float)
    ap.add_argument("--posix-locale", action="store_true", help="launch as a Claude Code running under LC_ALL=C would")
    ap.add_argument("--home", type=Path, help="HOME for the server (keeps login items and keyrings out of the real one)")
    a = ap.parse_args(argv)
    receipt = json.loads((a.marketplace / "prepared-installation.json").read_text(encoding="utf-8"))
    plugin = a.marketplace / receipt["plugin"]
    servers = json.loads((plugin / ".mcp.json").read_text(encoding="utf-8"))["mcpServers"]
    (key, spec), = servers.items()
    prefix = f"mcp__plugin_{receipt['plugin']}_{key}__"
    report: dict = {"checks": {}, "prefix": prefix}
    checks = report["checks"]
    with tempfile.TemporaryDirectory() as unrelated_cwd:
        srv = Server(spec, Path(unrelated_cwd), posix_locale=a.posix_locale, home=a.home)
        try:
            discover = srv.rpc("server/discover", {}, rid="server-discover-probe-1")
            checks["server_discover_answered"] = discover.get("error", {}).get("code") == -32601
            init = srv.rpc("initialize", {"protocolVersion": "2025-11-25", "capabilities": {
                "roots": {"listChanged": True}, "elicitation": {}}, "clientInfo": {"name": "pitrelay-claude-plugin-e2e",
                                                                                   "version": "1"}})
            report["server_info"] = init.get("result", {}).get("serverInfo")
            checks["initialize"] = init.get("result", {}).get("protocolVersion") == "2025-06-18"
            srv.notify("notifications/initialized")
            tools = srv.rpc("tools/list", {})["result"]["tools"]
            full = [prefix + t["name"] for t in tools]
            too_long = sorted((len(n), n) for n in full if not NAME_RE.match(n))
            report["tools"] = len(tools)
            report["engine_tools"] = sum(1 for t in tools if t["name"].startswith("pitrelay_"))
            report["longest_full_tool_name"] = max(full, key=len)
            report["longest_full_tool_name_length"] = len(report["longest_full_tool_name"])
            checks["tool_names_within_64_chars"] = not too_long
            if too_long:
                report["invalid_tool_names"] = too_long
            hs = srv.call("host_status", {})
            report["host_status"] = {"engine": hs.get("engine", {}).get("status"), "self_check": hs.get("host", {}).get(
                "self_check"), "notes_active": hs.get("compatibility", {}).get("notes_active"), "collector": hs.get("collector")}
            checks["engine_ready"] = hs.get("engine", {}).get("status") == "ready"
            checks["host_files_unchanged"] = (hs.get("host", {}).get("self_check") or {}).get("status") == "ok"
            included = receipt["collector"]["included"]
            checks["collector_matches_receipt"] = bool((hs.get("collector") or {}).get("available")) == included
            compat = srv.call("pitrelay_client_compatibility", {"workflow_contract": "2"})
            report["compatibility_status"] = compat.get("status")
            checks["compatibility"] = compat.get("status") == "ok"
            caps = srv.call("pitrelay_capability_list", {})
            checks["capability_list"] = caps.get("status") == "ok"
            ws = srv.call("pitrelay_workspace_inspect", {})
            wr = ws.get("result", {})
            report["workspace"] = {"attached": wr.get("workspace_attached"), "root": wr.get("root"),
                                   "granted": (wr.get("access") or {}).get("granted_capabilities")}
            expected_attached = receipt["experience"] == "workspace"
            checks["access_matches_receipt"] = bool(wr.get("workspace_attached")) == expected_attached and (
                not expected_attached or sorted(g.lower() for g in wr["access"]["granted_capabilities"])
                == sorted(receipt["workspace_grants"]))
            rr = None
            if a.upload:
                data = a.upload.read_bytes()
                begin = srv.call("pitrelay_artifact_upload_begin", {"kind": "log", "filename": a.upload.name,
                                                                    "byte_size": len(data),
                                                                    "sha256": hashlib.sha256(data).hexdigest()})
                transfer = (begin.get("result") or {}).get("id")
                ok = begin.get("status") == "ok" and transfer
                for off in range(0, len(data), 49152) if ok else []:
                    ch = srv.call("pitrelay_artifact_upload_chunk", {"transfer_id": transfer, "offset": off,
                                                                     "data_base64": base64.b64encode(data[off:off + 49152]).decode()})
                    ok = ok and ch.get("status") == "ok"
                fin = srv.call("pitrelay_artifact_upload_finish", {"transfer_id": transfer}) if ok else {}
                rr = fin.get("result") or {}
                report["upload"] = {"status": fin.get("status"), "id": rr.get("id"), "sha256": rr.get("sha256"),
                                    "chunks": -(-len(data) // 49152), "host_note": (begin.get("_host_notes") or [None])[0]}
                checks["upload"] = fin.get("status") == "ok" and rr.get("sha256") == hashlib.sha256(data).hexdigest()
            if a.register:
                reg = srv.call("pitrelay_artifact_register", {"path": a.register, "kind": "log"})
                rr = reg.get("result") or {}
                report["register"] = {"status": reg.get("status"), "id": rr.get("id"), "sha256": rr.get("sha256")}
                checks["register"] = reg.get("status") == "ok"
                outside = srv.call("pitrelay_artifact_register", {"path": "../outside.wpilog", "kind": "log"})
                report["register_outside_workspace"] = outside.get("status"), (outside.get("error") or {}).get("code")
                checks["outside_workspace_refused"] = outside.get("status") != "ok"
            if rr and rr.get("id"):
                ins = srv.call("pitrelay_log_inspect", {"artifact_id": rr["id"]})
                checks["log_inspect"] = ins.get("status") == "ok"
                if a.entry:
                    st = srv.call("pitrelay_signal_statistics", {"artifact_id": rr["id"], "entry": a.entry,
                                                                 "start_us": 0, "end_us": 5_000_000})
                    report["statistics"] = stats_of(st)
            if a.collector_flow:
                # A unique alias, and an export of this source only, so a store reused from earlier runs does not matter.
                src = srv.call("collector_configure_source", {"alias": "e2e-" + os.urandom(3).hex(), "kind": "local",
                                                              "role": "driver_station",
                                                              "directories": [str(a.collector_flow.resolve())]})
                checks["collector_source_saved_after_dialog"] = src.get("saved") is True and len(srv.dialogs) == 1
                src_id = (src.get("source") or {}).get("id")
                sync = srv.call("collector_collect_now", {"wait_s": 90}, timeout=200)
                report["collector_sync"] = {"poll_completed": sync.get("poll_completed"),
                                            "new_captures": sync.get("new_captures_since_request")}
                checks["collector_sync"] = bool(sync.get("poll_completed")) and (sync.get("new_captures_since_request") or 0) > 0
                exp = srv.call("collector_export", {"label": "SYNTHETIC e2e", "source_ids": [src_id], "wait_s": 90},
                               timeout=200)
                checks["collector_export"] = exp.get("ok") is True
                sup = srv.call("collector_supply_to_engine", {"package": "latest", "wait_s": 110}, timeout=240)
                rows = sup.get("supplied") or []
                report["collector_supply"] = [{"file": r["file"].rsplit("/", 1)[-1],
                                               "inspect": ((r.get("original") or {}).get("inspect") or {}).get("status"),
                                               "matches": (r.get("original") or {}).get("sha256_matches_manifest"),
                                               "notes": len((r.get("original") or {}).get("host_notes") or [])} for r in rows]
                checks["collector_supply"] = sup.get("state") == "succeeded" and all(
                    (r.get("original") or {}).get("sha256_matches_manifest") for r in rows if r.get("original"))
                volt = next((r for r in rows if "voltage" in r["file"]), None)
                if volt and a.entry:
                    st = srv.call("pitrelay_signal_statistics", {"artifact_id": volt["original"]["artifact_id"],
                                                                 "entry": a.entry, "start_us": 0, "end_us": 5_000_000})
                    report["statistics"] = stats_of(st)
                removed = srv.call("collector_remove_source", {"source_id": src_id})
                checks["collector_source_removed"] = removed.get("removed") == src_id
            if report.get("statistics"):
                if a.expect_mean is not None:
                    checks["mean"] = abs(float(report["statistics"]["mean"]) - a.expect_mean) < 1e-9
                if a.expect_min is not None:
                    checks["min"] = abs(float(report["statistics"]["min"]) - a.expect_min) < 1e-9
            checks["stdout_only_json"] = not any("_non_json_stdout" in m for m in srv.lines)
        except (RuntimeError, OSError, KeyError, ValueError, TypeError, StopIteration) as e:
            checks["server_answered"] = False
            report["error"] = f"{e.__class__.__name__}: {e}"
        finally:
            srv.close()
            srv.stderr.seek(0)
            err = srv.stderr.read().decode("utf-8", "replace")
            report["stderr_lines"] = [ln for ln in err.splitlines() if ln and not ln.startswith(("Picked up", "NOTE: Picked up"))][:10]
    report["result"] = "PASS" if all(checks.values()) else "FAIL"
    print(json.dumps(report, indent=2))
    return 0 if report["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
