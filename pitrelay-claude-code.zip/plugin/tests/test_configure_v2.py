"""configure_claude.py 2.x: the host, the collector's environment and store, reuse of a state, and verify."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

from test_configure_claude import fake_java, fake_python_env, make_package, run, sha  # noqa: F401  (fixtures below)
import configure_claude as cc


@pytest.fixture
def setup(tmp_path):
    pkg, msha, lsha = make_package(tmp_path)
    return {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
            "state": tmp_path / "state", "output": tmp_path / "out", "python_env_factory": fake_python_env,
            "collector_store": tmp_path / "collector-store"}


def receipt_of(s):
    return json.loads((s["output"] / "prepared-installation.json").read_text())


def rewrite_receipt(out: Path, **changes):
    r = json.loads((out / "prepared-installation.json").read_text())
    r.update(changes)
    files, _ = cc.tree_files(out)
    files.pop("prepared-installation.json")
    r["files"] = [{"path": rel, "byte_size": p.stat().st_size, "sha256": sha(p.read_bytes())} for rel, p in sorted(files.items())]
    (out / "prepared-installation.json").write_text(json.dumps(r))


# --- variants ---------------------------------------------------------------------------------


def test_engine_only_variant_runs_the_host_on_the_selected_python_without_an_environment(setup):
    res = run(setup, collector=False, collector_store=None)
    r = receipt_of(setup)
    spec = json.loads((setup["output"] / "pitrelay/.mcp.json").read_text())["mcpServers"]["pr"]
    assert spec["command"] == r["python"]["executable"] == res["python"]
    launch = json.loads((setup["output"] / "pitrelay/host/launch.json").read_text())
    assert launch["collector"] is False and launch["collector_store"] is None
    assert not list(setup["state"].glob("python*")) and r["collector"]["installed"] == {}
    assert cc.verify_output(setup["output"])["result"] == "PASS"


def test_collector_options_are_refused_without_the_collector(setup, tmp_path):
    (tmp_path / "wheels").mkdir()
    with pytest.raises(cc.SetupError, match="not with --without-collector"):
        run(setup, collector=False, wheelhouse=tmp_path / "wheels", collector_store=None)


def test_host_notes_switch_is_recorded_in_the_launch_file_and_checked(setup):
    run(setup, host_notes=False)
    launch = json.loads((setup["output"] / "pitrelay/host/launch.json").read_text())
    assert launch["host_notes"] is False and receipt_of(setup)["host_notes"] is False
    assert cc.verify_output(setup["output"])["result"] == "PASS"
    launch["host_notes"] = True
    (setup["output"] / "pitrelay/host/launch.json").write_text(json.dumps(launch))
    rewrite_receipt(setup["output"])
    assert any("launch.json does not start exactly" in p for p in cc.verify_output(setup["output"])["problems"])


# --- reusing a state -------------------------------------------------------------------------------


def test_reuse_state_keeps_engine_state_and_makes_a_new_python_environment(setup, tmp_path):
    first = run(setup)
    st = setup["state"]
    (st / "engine").mkdir(exist_ok=True)
    (st / "engine" / "case-1.json").write_text("precious case")
    old_env = st / f"python-{receipt_of(setup)['install_id']}"
    s2 = dict(setup, output=tmp_path / "out2")
    second = run(s2, reuse_state=True)
    r2 = receipt_of(s2)
    assert second["state_reused"] == "2.x" and r2["state_reused"] == "2.x"
    assert (st / "engine" / "case-1.json").read_text() == "precious case"
    assert r2["install_id"] != receipt_of(setup)["install_id"] and second["plugin_version"] != first["plugin_version"]
    # Listed with the caveat (gen-12): the still-installed plugin and its login item start it until the switch.
    assert old_env.is_dir() and second["older_python_environments"] == [str(old_env)]
    assert "only after you have switched" in second["older_python_environments_note"]
    assert json.loads((st / "pitrelay-state.json").read_text())["install_id"] == r2["install_id"]
    assert cc.verify_output(s2["output"])["result"] == "PASS"


def test_a_1x_state_can_be_reused(setup):
    st = setup["state"]
    for sub in ("engine", "jvm-home", "tmp"):
        (st / sub).mkdir(parents=True)
    (st / "engine" / "artifact").write_text("from 1.2.0")
    res = run(setup, reuse_state=True)
    assert res["state_reused"] == "1.x" and (st / "engine" / "artifact").read_text() == "from 1.2.0"
    assert cc.verify_output(setup["output"])["result"] == "PASS"


def test_reuse_needs_the_flag_and_a_failed_reuse_leaves_the_state_as_it_was(setup, tmp_path, monkeypatch):
    run(setup)
    st = setup["state"]
    marker = (st / "pitrelay-state.json").read_bytes()
    before = sorted(p.name for p in st.iterdir())
    with pytest.raises(cc.SetupError, match="add --reuse-state"):
        run(dict(setup, output=tmp_path / "o2"))

    def boom(src, dst):
        raise OSError(28, "No space left on device")
    monkeypatch.setattr(cc, "rename_noreplace", boom)
    with pytest.raises(cc.SetupError, match="removed"):
        run(dict(setup, output=tmp_path / "o3"), reuse_state=True)
    assert sorted(p.name for p in st.iterdir()) == before  # the new Python environment was removed again
    assert (st / "pitrelay-state.json").read_bytes() == marker
    with pytest.raises(cc.SetupError, match="does not exist"):
        run(dict(setup, state=tmp_path / "nope", output=tmp_path / "o4"), reuse_state=True)


# --- the collector store ------------------------------------------------------------------------------


def make_store(path: Path, schema: str | None = None):
    """A real collector store (made by the collector itself), optionally claiming another schema version."""
    sys.path.insert(0, str(cc.COLLECTOR_PACKAGE.parent))
    from pitrelay_collector.store import Store
    Store.create(path)
    if schema is not None:
        c = sqlite3.connect(Store(path).db_path)
        c.execute("UPDATE meta SET value=? WHERE key='schema_version'", (schema,))
        c.commit()
        c.close()


def test_an_existing_collector_store_is_adopted_and_an_incompatible_one_refused(setup, tmp_path):
    good = tmp_path / "good-store"
    make_store(good)
    assert (good / cc.collector_store_catalog()).is_file()
    res = run(setup, collector_store=good)
    assert receipt_of(setup)["collector"]["store_was"] == "existing" and res["collector_store"] == str(good)
    bad = tmp_path / "bad-store"
    make_store(bad, "999")
    with pytest.raises(cc.SetupError, match="another collector version"):
        run(dict(setup, output=tmp_path / "o2", state=tmp_path / "s2"), collector_store=bad)
    other = tmp_path / "other"
    other.mkdir()
    (other / "notes.txt").write_text("mine")
    with pytest.raises(cc.SetupError, match="contains other files"):
        run(dict(setup, output=tmp_path / "o3", state=tmp_path / "s3"), collector_store=other)


@pytest.mark.parametrize("where", ["output", "package"])
def test_the_collector_store_may_not_overlap_the_plugin_or_package(setup, where):
    store = (setup["output"] if where == "output" else setup["package"]) / "store"
    with pytest.raises(cc.SetupError, match=f"collector store and the {where} folder must not overlap"):
        run(setup, collector_store=store)


def test_default_store_is_the_standalone_collectors(monkeypatch, tmp_path):
    sys.path.insert(0, str(cc.COLLECTOR_PACKAGE.parent))
    from pitrelay_collector.autostart import default_store_path
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "xdg"))
    assert cc.default_collector_store() == default_store_path() == tmp_path / "xdg" / "pitrelay-collector"


def test_collector_requirements_match_the_collector_project():
    text = (cc.HERE / "collector" / "pyproject.toml").read_text()
    deps = re.search(r"dependencies = \[(.*?)\]", text, re.S)[1]
    assert sorted(re.findall(r'"([^"]+)"', deps)) == sorted(cc.COLLECTOR_REQUIREMENTS)
    assert all("==" in v for v in cc.COLLECTOR_TESTED_VERSIONS)


# --- Python -------------------------------------------------------------------------------------


def fake_python(tmp_path: Path, version=(3, 12, 1), implementation="cpython", gil_disabled=False, name="python3") -> Path:
    py = tmp_path / "fakepy" / name
    py.parent.mkdir(parents=True, exist_ok=True)
    info = {"executable": str(py), "version": list(version), "implementation": implementation, "prefix": "/x",
            "base_prefix": "/x", "base_executable": str(py), "gil_disabled": gil_disabled}
    py.write_text(f"#!/bin/sh\necho '{json.dumps(info)}'\n")
    py.chmod(0o755)
    return py


@pytest.mark.parametrize("kw, message", [({"version": (3, 9, 18)}, "3.10 or later"),
                                         ({"implementation": "pypy"}, "standard CPython"),
                                         ({"gil_disabled": True}, "standard CPython")])
def test_unsuitable_pythons_are_refused(setup, tmp_path, kw, message):
    with pytest.raises(cc.SetupError, match=message):
        run(setup, python=fake_python(tmp_path, **kw))


def test_microsoft_store_python_is_refused(tmp_path):
    py = fake_python(tmp_path / "AppData/Local/Microsoft/WindowsApps")
    with pytest.raises(cc.SetupError, match="Microsoft Store"):
        cc.select_python(py, tmp_path)


def test_a_virtual_environment_is_resolved_to_its_base_and_the_selected_path_is_kept(tmp_path):
    venv = tmp_path / "v"
    subprocess.run([sys.executable, "-m", "venv", "--without-pip", str(venv)], check=True)
    base = cc.select_python(cc.venv_python(venv), tmp_path)["executable"]
    info = json.loads(subprocess.run([str(cc.venv_python(venv)), "-c", "import sys, json; print(json.dumps(sys._base_executable))"],
                                     capture_output=True, text=True).stdout)
    if cc.lies_in(Path(info), venv):  # Python 3.10 reports the environment's own interpreter: never pinned
        assert not cc.lies_in(base, venv) and os.path.samefile(base, cc.venv_python(venv))
    else:
        assert base == Path(os.path.abspath(info))
    link = tmp_path / "python3-link"
    link.symlink_to(base)
    assert cc.select_python(link, tmp_path)["executable"] == link  # the selected (stable) name, not the resolved one


def test_verify_tolerates_a_patch_update_of_python_but_not_a_new_minor_version(setup, tmp_path):
    run(setup)
    out = setup["output"]
    r = receipt_of(setup)
    assert r["python"]["sys_version"] == sys.version  # the full build string of the interpreter, recorded at setup
    # A patch update or a distribution's rebuild: other bytes, another build (gen2-2).
    rewrite_receipt(out, python={**r["python"], "executable_sha256": "0" * 64,
                                 "sys_version": "3.0.0 (main, Jan  1 2026, 00:00:00) [an earlier build]"})
    # The Python is run to read its version only when the receipt is anchored (gen-3): the kept hash of this receipt.
    v = cc.verify_output(out, receipt_sha256=sha((out / "prepared-installation.json").read_bytes()))
    assert v["result"] == "PASS" and "updated since setup" in v["note"]
    rewrite_receipt(out, python={**r["python"], "executable_sha256": "0" * 64})  # other bytes, the very same build
    v = cc.verify_output(out, receipt_sha256=sha((out / "prepared-installation.json").read_bytes()))
    assert any("changed without becoming another build" in p for p in v["problems"])
    rewrite_receipt(out, python={**r["python"], "version": "3.9.1"})
    v = cc.verify_output(out, receipt_sha256=sha((out / "prepared-installation.json").read_bytes()))
    assert any("changed from 3.9.1" in p for p in v["problems"])


# --- the collector's Python environment, checked from outside -----------------------------------------------


def make_env_with_dist(tmp_path: Path) -> tuple[Path, Path]:
    env = tmp_path / "env"
    base = cc.select_python(Path(sys.executable), tmp_path)["executable"]
    subprocess.run([str(base), "-I", "-m", "venv", "--without-pip", str(env)], check=True)  # as setup makes it
    sp = cc.site_packages(env, PY_VERSION)
    (sp / "demo").mkdir()
    code = b"VALUE = 1\n"
    (sp / "demo" / "__init__.py").write_bytes(code)
    dist = sp / "demo-1.0.dist-info"
    dist.mkdir()
    (dist / "METADATA").write_text("Metadata-Version: 2.1\nName: demo\nVersion: 1.0\n\n")
    h = base64.urlsafe_b64encode(hashlib.sha256(code).digest()).rstrip(b"=").decode()
    meta_h = base64.urlsafe_b64encode(hashlib.sha256((dist / "METADATA").read_bytes()).digest()).rstrip(b"=").decode()
    (dist / "RECORD").write_text(f"demo/__init__.py,sha256={h},10\ndemo-1.0.dist-info/METADATA,sha256={meta_h},0\n"
                                 "demo-1.0.dist-info/RECORD,,\n")
    return env, base


PY_VERSION = "{}.{}.{}".format(*sys.version_info[:3])


def check_env(env: Path, base: Path, installed: dict, records: dict | None = None, unhashed: dict | None = None) -> list[str]:
    """check_python_env with the identity setup records (install records, launcher, hashes of the files no record
    hashes) taken from the env as it is now, unless given."""
    return cc.check_python_env(env, base, PY_VERSION, installed,
                               cc.install_records(env, PY_VERSION) if records is None else records, cc.env_launchers(env),
                               cc.unhashed_files(env, PY_VERSION) if unhashed is None else unhashed)


def test_environment_check_catches_changed_planted_and_unrecorded_files(tmp_path):
    env, base = make_env_with_dist(tmp_path)
    sp = cc.site_packages(env, PY_VERSION)
    records = cc.install_records(env, PY_VERSION)
    assert check_env(env, base, {"demo": "1.0"}) == []
    assert any("differ from those recorded" in p for p in check_env(env, base, {}))
    (sp / "demo" / "__init__.py").write_bytes(b"VALUE = 2\n")
    assert any("differs from its install record: demo/__init__.py" in p for p in check_env(env, base, {"demo": "1.0"}))
    (sp / "demo" / "__init__.py").write_bytes(b"VALUE = 1\n")
    (sp / "evil.pth").write_text("import os\n")
    (sp / "demo" / "__pycache__").mkdir()
    (sp / "demo" / "__pycache__" / "__init__.cpython-312.pyc").write_bytes(b"x")
    problems = check_env(env, base, {"demo": "1.0"}, records)
    assert any("no install record claims: evil.pth" in p for p in problems)
    assert any("__init__.cpython-312.pyc" in p for p in problems)


def test_environment_check_catches_a_foreign_base_and_system_packages(tmp_path):
    env, base = make_env_with_dist(tmp_path)
    cfg = (env / "pyvenv.cfg").read_text()
    (env / "pyvenv.cfg").write_text(re.sub(r"(?m)^home = .*$", "home = /somewhere/else", cfg)
                                    .replace("include-system-site-packages = false", "include-system-site-packages = true"))
    problems = check_env(env, base, {"demo": "1.0"})
    assert any("not made from the recorded Python" in p for p in problems)
    assert any("includes the system's packages" in p for p in problems)


# --- verify ------------------------------------------------------------------------------------------


def test_verify_names_the_generator_of_another_major_version_instead_of_listing_mismatches(setup):
    run(setup)
    rewrite_receipt(setup["output"], schema_version="1.1", generator={"name": "pitrelay-claude-plugin", "version": "1.2.0"})
    v = cc.verify_output(setup["output"])
    assert v["result"] == "FAIL" and v["problem_count"] == 1 and "verify it with that version" in v["problems"][0]


@pytest.mark.parametrize("edit", ["plugin_root", "host_files", "collector_store", "version"])
def test_verify_catches_a_changed_launch_or_version(setup, tmp_path, edit):
    run(setup)
    out = setup["output"]
    if edit == "version":
        pj = out / "pitrelay/.claude-plugin/plugin.json"
        data = json.loads(pj.read_text())
        data["version"] = "0.1.0-dev"
        pj.write_text(json.dumps(data))
        expected = "plugin.json differs from what setup writes"
    else:
        lj = out / "pitrelay/host/launch.json"
        launch = json.loads(lj.read_text())
        launch[edit] = {"plugin_root": str(tmp_path / "elsewhere"), "collector_store": str(tmp_path / "x"),
                        "host_files": {}}[edit]
        lj.write_text(json.dumps(launch))
        expected = "launch.json does not start exactly"
    rewrite_receipt(out)
    assert any(expected in p for p in cc.verify_output(out)["problems"])


def test_a_mcp_json_pointing_at_the_claude_code_cache_is_caught(setup):
    run(setup)
    out = setup["output"]
    p = out / "pitrelay/.mcp.json"
    spec = json.loads(p.read_text())
    spec["mcpServers"]["pr"]["args"][-1] = "${CLAUDE_PLUGIN_ROOT}/host/gateway.py"
    p.write_text(json.dumps(spec))
    rewrite_receipt(out)
    assert any(".mcp.json does not start exactly" in x for x in cc.verify_output(out)["problems"])


# --- warnings ---------------------------------------------------------------------------------------


def test_location_warnings():
    w = cc.location_warnings({"state": Path("/home/a/OneDrive/pitrelay"), "output": Path("/mnt/c/Users/a/out"),
                              "collector store": Path("/home/a/fine")})
    assert any("synced cloud folder" in x for x in w) and any("Windows drive seen from WSL" in x for x in w)
    assert len(w) == 2


def test_an_earlier_login_item_is_reported(setup, monkeypatch):
    monkeypatch.setattr(cc, "existing_login_item", lambda: {"enabled": True, "location": "/home/a/.config/autostart/x"})
    res = run(setup)
    assert any("starts at login" in w for w in res["warnings"]) and res["warnings"] == receipt_of(setup)["warnings"]


def test_wheelhouse_refuses_a_folder_that_is_not_empty(tmp_path):
    d = tmp_path / "w"
    d.mkdir()
    (d / "x").write_text("x")
    with pytest.raises(cc.SetupError, match="not empty"):
        cc.make_wheelhouse(d)


def test_verify_names_a_generator_with_another_reviewed_overlay_instead_of_listing_mismatches(setup):
    run(setup)
    r = json.loads((setup["output"] / "prepared-installation.json").read_text())
    rewrite_receipt(setup["output"], generator={**r["generator"], "overlay_sha256": "0" * 64})
    problems = cc.verify_output(setup["output"])["problems"]
    assert any("with a different reviewed overlay" in x for x in problems)
    assert not any("overlay file differs" in x for x in problems)


def test_verify_never_accepts_an_injected_environment_even_from_a_rewritten_receipt(setup):
    run(setup)
    out = setup["output"]
    spec_path = out / "pitrelay/.mcp.json"
    spec = json.loads(spec_path.read_text())
    spec["mcpServers"]["pr"]["env"]["JAVA_TOOL_OPTIONS"] = "-javaagent:/tmp/agent.jar"
    spec_path.write_text(json.dumps(spec))
    r = json.loads((out / "prepared-installation.json").read_text())
    rewrite_receipt(out, server_env_extra={**(r.get("server_env_extra") or {}), "JAVA_TOOL_OPTIONS": "-javaagent:/tmp/agent.jar"})
    assert any(".mcp.json does not start exactly" in x for x in cc.verify_output(out)["problems"])


def test_environment_check_catches_changed_bytecode_and_a_repeated_home(tmp_path):
    env, base = make_env_with_dist(tmp_path)
    sp = cc.site_packages(env, PY_VERSION)
    cached = sp / "demo" / "__pycache__" / "x.cpython-313.pyc"
    cached.parent.mkdir(parents=True, exist_ok=True)
    cached.write_bytes(b"original bytecode")
    record = next(sp.glob("*.dist-info/RECORD"))
    record.write_text(record.read_text() + "demo/__pycache__/x.cpython-313.pyc,,\n")
    records, unhashed = cc.install_records(env, PY_VERSION), cc.unhashed_files(env, PY_VERSION)
    assert cached.relative_to(env).as_posix() in unhashed and "pyvenv.cfg" in unhashed
    assert check_env(env, base, {"demo": "1.0"}, records, unhashed) == []
    cached.write_bytes(b"planted bytecode")  # listed without a hash in its record, so only the receipt's hash shows it
    assert any("differs from the one installed at setup" in x for x in check_env(env, base, {"demo": "1.0"}, records, unhashed))
    cached.write_bytes(b"original bytecode")
    cfg = env / "pyvenv.cfg"
    cfg.write_text(f"home = {tmp_path / 'elsewhere'}\n" + cfg.read_text())
    problems = check_env(env, base, {"demo": "1.0"}, records, unhashed)
    assert any("repeated setting" in x for x in problems) and any("changed since setup: pyvenv.cfg" in x for x in problems)
