"""Host notes against damaged files: a note never calls a damaged file intact, nor points at the other format."""
from __future__ import annotations

import base64
import json
import struct

import host_harness  # noqa: F401  (puts the host and the collector on the import path)

from pitrelay_collector import synthetic
from pitrelay_host.compat import V11_ENGINE_SHA256, Compat


class _Engine:
    jar_sha256 = V11_ENGINE_SHA256

    def __init__(self, data: bytes):
        self.data = data

    def call_tool(self, name, args):
        assert name == "pitrelay_artifact_download" and "workflow_id" not in args
        return {"status": "ok", "result": {"data_base64": base64.b64encode(self.data[:args["length"]]).decode()}}


class _Server:
    def __init__(self, data: bytes):
        self.launch = {"host_notes": True}
        self.engine = _Engine(data)


def _result(status: str) -> dict:
    return {"content": [{"type": "text", "text": json.dumps({"status": status, "result": {}})}]}


def _notes(data: bytes, fmt: str, status: str = "partial") -> list[str]:
    compat = Compat(_Server(data))
    args = {"artifact_id": "artifact-1", "format": fmt}
    assert compat.wants_notes("pitrelay_log_inspect", args, _result(status))
    return [n["text"] for n in compat.notes("pitrelay_log_inspect", args, _result(status))]


def test_a_zero_filled_ds_file_gets_no_format_note():
    damaged = struct.pack(">iq", 4, 3_843_000_000) + b"\0" * 8 + b"\0" * (64 * 14)
    assert _notes(damaged, "dsevents_v4") == []
    assert _notes(damaged, "dslog_v4") == []


def test_the_wrong_ds_adapter_still_gets_its_note():
    log = synthetic.dslog_v4(1_760_000_000, 40, pd_type=25)
    texts = _notes(log, "dsevents_v4")
    assert len(texts) == 1 and "ds_format" in texts[0] and '"dslog_v4"' in texts[0]


def test_the_revlog_v2_note_never_calls_the_file_intact():
    texts = _notes(synthetic.revlog_v2(), "rev_native")
    assert len(texts) == 1 and "revlog_v2" in texts[0]
    assert "not damaged" not in texts[0] and "file is damaged" not in texts[0]
    assert "may still describe real damage" in texts[0]
