"""configure_claude.py 2.x, third review round: the collector environment's integrity, what verify may run, wheelhouses
for another computer, reusing a state after a failure, Python shims and names, the store path, front matter, and the
engine-only variant."""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

from test_configure_claude import fake_java, fake_python_env, launch_of, make_package, run, sha  # noqa: F401
from test_configure_v2 import make_store, receipt_of, rewrite_receipt
import configure_claude as cc

pytestmark = pytest.mark.skipif(os.name != "posix", reason="fake Java and shims are POSIX shell scripts")

BASE = cc.select_python(Path(sys.executable), Path.home())["executable"]  # the real base interpreter running the tests
BASE_VERSION = "{}.{}".format(*sys.version_info[:2])


@pytest.fixture
def setup(tmp_path):
    pkg, msha, lsha = make_package(tmp_path)
    return {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
            "state": tmp_path / "state", "output": tmp_path / "out", "python_env_factory": fake_env_with_dist,
            "collector_store": tmp_path / "collector-store"}


def record_hash(data: bytes) -> str:
    return base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()


def fake_env_with_dist(base, target, wheelhouse, cwd):
    """A real venv from the selected Python (no pip, nothing downloaded) holding one installed distribution with an
    install record, as pip would leave it, including a console script outside site-packages."""
    subprocess.run([str(base), "-I", "-m", "venv", "--without-pip", str(target)], check=True, capture_output=True)
    sp = next(target.glob("lib/python3*/site-packages"))
    (sp / "demo").mkdir()
    (sp / "demo" / "__init__.py").write_bytes(b"VALUE = 1\n")
    (target / "bin" / "demo-tool").write_bytes(b"#!/bin/sh\n")
    dist = sp / "demo-1.0.dist-info"
    dist.mkdir()
    (dist / "METADATA").write_bytes(b"Metadata-Version: 2.1\nName: demo\nVersion: 1.0\n\n")
    rows = [f"{rel},sha256={record_hash(p.read_bytes())},{p.stat().st_size}" for rel, p in
            (("demo/__init__.py", sp / "demo/__init__.py"), ("demo-1.0.dist-info/METADATA", dist / "METADATA"),
             ("../../../bin/demo-tool", target / "bin/demo-tool"))]
    (dist / "RECORD").write_text("\n".join(rows + ["demo-1.0.dist-info/RECORD,,"]) + "\n")
    return {"python": str(cc.venv_python(target)), "installed": {"demo": "1.0"}}


def sp_of(env: Path) -> Path:
    return env / "lib" / f"python{BASE_VERSION}" / "site-packages"


def kept(s) -> str:
    return sha((s["output"] / "prepared-installation.json").read_bytes())


def env_of(s) -> Path:
    return s["state"] / f"python-{receipt_of(s)['install_id']}"


# --- gen-1 / gen-2: the collector's environment, anchored by the receipt -----------------------------------------


def test_the_receipt_records_the_environments_launcher_and_install_records(setup):
    run(setup)
    rec = receipt_of(setup)["collector"]
    env = env_of(setup)
    assert rec["launcher"] == {"bin/python": {"link_to": os.path.realpath(BASE)}}
    sp = cc.site_packages(env, BASE_VERSION)
    assert rec["install_records"] == {"demo-1.0.dist-info/RECORD": sha((sp / "demo-1.0.dist-info/RECORD").read_bytes())}
    assert rec["installed"] == {"demo": "1.0"}
    assert cc.verify_output(setup["output"], receipt_sha256=kept(setup))["result"] == "PASS"


def test_a_wrapper_script_as_the_environments_launcher_fails_verify(setup, tmp_path):
    run(setup)
    py = cc.venv_python(env_of(setup))
    ran = tmp_path / "ran"
    py.unlink()
    py.write_text(f"#!/bin/sh\necho ran >> {ran}\nexec {BASE} \"$@\"\n")  # .mcp.json starts this
    py.chmod(0o755)
    v = cc.verify_output(setup["output"], receipt_sha256=kept(setup))
    assert v["result"] == "FAIL" and not ran.exists()
    assert any("bin/python, which is a file instead of venv's link" in p for p in v["problems"])


def test_a_link_to_another_interpreter_fails_verify(setup, tmp_path):
    run(setup)
    py = cc.venv_python(env_of(setup))
    other = tmp_path / "other-python"
    other.write_text(f"#!/bin/sh\nexec {BASE} \"$@\"\n")
    other.chmod(0o755)
    py.unlink()
    py.symlink_to(other)
    problems = cc.verify_output(setup["output"], receipt_sha256=kept(setup))["problems"]
    assert any("runs a different interpreter" in p for p in problems)
    assert any("link in the collector's Python environment: bin/python" in p for p in problems)


@pytest.mark.parametrize("where", ["lib/python{v}/dist-packages", "lib/python3/dist-packages",
                                   "local/lib/python{v}/dist-packages"])
def test_a_pth_file_in_a_folder_debians_site_py_reads_fails_verify(setup, where):
    run(setup)
    folder = env_of(setup) / where.format(v=BASE_VERSION)
    folder.mkdir(parents=True)
    (folder / "zz.pth").write_text("import os\n")
    problems = cc.verify_output(setup["output"], receipt_sha256=kept(setup))["problems"]
    assert any("Python would load packages from" in p and "dist-packages" in p or p.endswith(": local") for p in problems)
    assert any("no install record claims" in p and p.endswith(f"{where.format(v=BASE_VERSION)}/zz.pth") for p in problems)


def test_a_real_lib64_folder_and_a_planted_link_fail_verify(setup, tmp_path):
    run(setup)
    env = env_of(setup)
    if (env / "lib64").is_symlink():
        (env / "lib64").unlink()
    (env / "lib64").mkdir()
    sp = sp_of(env)
    (tmp_path / "elsewhere.py").write_text("x = 1\n")
    (sp / "sitecustomize.py").symlink_to(tmp_path / "elsewhere.py")
    problems = cc.verify_output(setup["output"], receipt_sha256=kept(setup))["problems"]
    assert any(p.endswith("which setup never makes: lib64") for p in problems)
    assert any(p.endswith(f"link in the collector's Python environment: lib/python{BASE_VERSION}/site-packages/"
                          "sitecustomize.py") for p in problems)


def test_a_file_added_to_an_install_record_fails_verify(setup):
    run(setup)
    sp = sp_of(env_of(setup))
    (sp / "zz_evil.pth").write_text("import os\n")
    data = (sp / "zz_evil.pth").read_bytes()
    with open(sp / "demo-1.0.dist-info/RECORD", "a") as f:  # the RECORD now claims it, with the right hash
        f.write(f"zz_evil.pth,sha256={record_hash(data)},{len(data)}\n")
    problems = cc.verify_output(setup["output"], receipt_sha256=kept(setup))["problems"]
    # One line for the changed record (what it lists is not trusted), not one per file it lists.
    assert problems == ["install record changed since setup, in the collector's Python environment: "
                        "demo-1.0.dist-info/RECORD (the 5 files it lists are not trusted)"]
    (sp / "zz_other.pth").write_text("import os\n")  # listed by no record at all
    problems = cc.verify_output(setup["output"], receipt_sha256=kept(setup))["problems"]
    assert any(p.endswith("no install record claims: zz_other.pth (in site-packages)") for p in problems)


def test_a_new_dist_info_and_a_decoy_site_packages_are_not_trusted(setup):
    run(setup)
    env = env_of(setup)
    sp = sp_of(env)
    fake = sp / "zz-1.0.dist-info"
    fake.mkdir()
    (fake / "METADATA").write_text("Name: zz\nVersion: 1.0\n\n")
    (fake / "RECORD").write_text("zz-1.0.dist-info/METADATA,,\nzz-1.0.dist-info/RECORD,,\n")
    decoy = env / "lib" / "python3.0" / "site-packages"  # sorts before python3.1x: a glob would pick it
    decoy.mkdir(parents=True)
    problems = cc.verify_output(setup["output"], receipt_sha256=kept(setup))["problems"]
    assert any("install record that setup did not make" in p and "zz-1.0.dist-info/RECORD" in p for p in problems)
    assert any("differ from those recorded at setup" in p for p in problems)  # zz is not a recorded package
    assert cc.site_packages(env, f"{BASE_VERSION}.9") == sp and cc.installed_distributions(env, BASE_VERSION) == \
        {"demo": "1.0", "zz": "1.0"}


def test_a_receipt_without_the_environments_identity_fails_verify(setup):
    run(setup)
    r = receipt_of(setup)
    rewrite_receipt(setup["output"], collector={**r["collector"], "install_records": None, "launcher": None})
    problems = cc.verify_output(setup["output"], receipt_sha256=kept(setup))["problems"]
    assert any("records no install records" in p for p in problems)
    assert any("records no launcher" in p for p in problems)


def test_setup_refuses_an_environment_that_verify_would_refuse(setup):
    def planting_factory(base, target, wheelhouse, cwd):
        made = fake_env_with_dist(base, target, wheelhouse, cwd)
        (sp_of(target) / "planted.pth").write_text("import os\n")
        return made
    with pytest.raises(cc.SetupError, match="does not pass the check verify makes.*planted.pth"):
        run(setup, python_env_factory=planting_factory)
    assert not setup["state"].exists() and not setup["output"].exists()


# --- gen-3: verify never runs a program named only by an unverified receipt -------------------------------------


def evil_programs(folder: Path, ran: Path) -> tuple[Path, Path]:
    folder.mkdir(parents=True, exist_ok=True)
    out = []
    for name in ("evil-java", "evil-python"):
        p = folder / name
        p.write_text(f"#!/bin/sh\necho \"{name} $*\" >> {ran}\nexit 1\n")
        p.chmod(0o755)
        out.append(p)
    return out[0], out[1]


def name_programs(s, java: Path, python: Path):
    r = receipt_of(s)
    rewrite_receipt(s["output"], java_executable=str(java), java_executable_sha256=sha(java.read_bytes()),
                    python={**r["python"], "executable": str(python), "executable_sha256": sha(python.read_bytes())})


def test_a_receipt_that_differs_from_the_kept_hash_stops_verify_before_anything_runs(setup, tmp_path):
    run(setup, collector=False, collector_store=None)
    original = kept(setup)
    ran = tmp_path / "ran.txt"
    name_programs(setup, *evil_programs(setup["output"], ran))
    v = cc.verify_output(setup["output"], receipt_sha256=original)
    assert v["result"] == "FAIL" and v["problem_count"] == 1 and "receipt SHA-256 you kept" in v["problems"][0]
    assert not ran.exists()


def test_without_the_receipt_anchor_the_named_programs_are_only_named(setup, tmp_path):
    run(setup, collector=False, collector_store=None)
    ran = tmp_path / "ran.txt"
    java, python = evil_programs(tmp_path / "elsewhere", ran)
    name_programs(setup, java, python)
    for v in (cc.verify_output(setup["output"]), cc.verify_output(setup["output"], setup["manifest_sha256"])):
        assert not ran.exists()
        assert f"Java {java}" in v["note"] and f"Python {python}" in v["note"] and "were not run" in v["anchored_by"]
        assert any("launch.json does not start exactly" in p for p in v["problems"])


def test_a_program_inside_the_marketplace_or_state_is_never_run_even_when_anchored(setup, tmp_path):
    run(setup, collector=False, collector_store=None)
    ran = tmp_path / "ran.txt"
    java, _ = evil_programs(setup["output"], ran)
    _, python = evil_programs(setup["state"] / "x", ran)
    name_programs(setup, java, python)
    v = cc.verify_output(setup["output"], receipt_sha256=kept(setup))  # the person anchored the changed receipt
    assert not ran.exists()
    assert any(f"Java {java} lies inside the marketplace folder" in p for p in v["problems"])
    assert any(f"Python {python} lies inside the state folder" in p for p in v["problems"])


def test_an_unanchored_verify_reports_a_changed_python_without_running_it(setup):
    run(setup, collector=False, collector_store=None)
    r = receipt_of(setup)
    rewrite_receipt(setup["output"], python={**r["python"], "executable_sha256": "0" * 64})
    v = cc.verify_output(setup["output"])
    assert any("changed since setup; it was not run" in p for p in v["problems"])


# --- gen-9: an in-place Java update -----------------------------------------------------------------------------


def test_an_in_place_java_update_is_a_note_but_a_new_major_or_a_wrapper_fails(setup, tmp_path, monkeypatch):
    run(setup, collector=False, collector_store=None)
    java, out = setup["java"], setup["output"]
    receipt_sha = kept(setup)
    # The fake Java here is a script; a real launcher is a compiled program, which is what an update must leave.
    monkeypatch.setattr(cc, "native_executable", lambda path: True)
    java.write_text(java.read_text() + "# other bytes, same version\n")
    v = cc.verify_output(out, receipt_sha256=receipt_sha)
    assert any("changed without becoming another Java version" in p for p in v["problems"])
    java.write_text(java.read_text().replace("21.0.4", "21.0.5"))  # same path, same runtime, new patch version
    v = cc.verify_output(out, receipt_sha256=receipt_sha)
    assert v["result"] == "PASS" and "updated in place since setup (21.0.4 -> 21.0.5)" in v["note"]
    monkeypatch.setattr(cc, "native_executable", lambda path: False)  # a script now stands at the launcher's path
    v = cc.verify_output(out, receipt_sha256=receipt_sha)
    assert any("changed and is not a native program; it was not run" in p for p in v["problems"])
    monkeypatch.setattr(cc, "native_executable", lambda path: True)
    java.write_text(java.read_text().replace("21.0.5", "22.0.1"))
    v = cc.verify_output(out, receipt_sha256=receipt_sha)
    assert any("changed from Java 21 to Java 22" in p for p in v["problems"])
    other = fake_java(tmp_path / "other")
    java.write_text(f"#!/bin/sh\nexec {other} \"$@\"\n")  # the recorded path is now a wrapper around another runtime
    v = cc.verify_output(out, receipt_sha256=receipt_sha)
    assert any("not a Java runtime's own launcher" in p for p in v["problems"])


# --- gen-4: wheelhouses for another computer --------------------------------------------------------------------


@pytest.mark.parametrize("marker, env, expected", [
    ('sys_platform == "win32"', {"sys_platform": "win32"}, True),
    ('sys_platform == "linux"', {"sys_platform": "win32"}, False),
    ('python_version < "3.12"', {"python_version": "3.11"}, True),
    ('python_version < "3.12"', {"python_version": "3.12"}, False),
    ('python_version >= "3.8" and (os_name == "nt" or extra == "socks")', {"python_version": "3.9", "os_name": "posix",
                                                                           "extra": "SOCKS"}, True),
    ('"3.10" <= python_version', {"python_version": "3.9"}, False),
    ('python_full_version >= "3.11.4"', {"python_full_version": "3.11.10"}, True),
    ('platform_machine == "x86_64" and sys_platform == "linux"', {"platform_machine": None, "sys_platform": "win32"}, False),
    ('platform_machine == "x86_64" or sys_platform == "linux"', {"platform_machine": None, "sys_platform": "win32"}, None),
    ("platform_python_implementation != 'PyPy'", {"platform_python_implementation": "CPython"}, True),
    ('implementation_name not in "pypy graalpy"', {"implementation_name": "cpython"}, True),
    ('extra == "gssapi"', {"extra": ""}, False),
    ('sys.platform == "darwin"', {"sys_platform": "darwin"}, True),
])
def test_environment_markers_are_evaluated_for_the_given_environment(marker, env, expected):
    assert cc.evaluate_marker(marker, env) is expected


@pytest.mark.parametrize("marker", ['sys_platform = "win32"', 'nonsense == "x"', 'python_version < "3" and', "(os_name == 'nt'"])
def test_unreadable_markers_are_refused(marker):
    with pytest.raises(cc.SetupError):
        cc.evaluate_marker(marker, {"os_name": "nt", "sys_platform": "win32", "python_version": "3.12"})


@pytest.mark.parametrize("spec, version, expected", [
    (">=3.4", "5.1.0", True), ("<3.12", "3.12", False), ("<3.12", "3.11.9", True), ("~=2.2", "2.9", True),
    ("~=2.2.1", "2.3", False), ("==3.12.*", "3.12.4", True), ("!=3.12.*", "3.12.4", False), (">=1,!=1.5", "1.5.0", False),
    ("<1.0", "1.0rc1", False), (">1.0", "1.0.post1", False), (">=1.0.dev0", "1.0a1", True), ("==1.0", "1.0.0", True),
    ("", "anything", None), ("", "2.0", True),
])
def test_version_specifiers(spec, version, expected):
    assert cc.specifier_allows(spec, version) is expected


def test_target_environments_from_platform_tags():
    win = cc.target_environment("win_amd64", "3.11", "3.13.1")
    assert (win["sys_platform"], win["os_name"], win["platform_system"], win["platform_machine"], win["python_version"],
            win["python_full_version"]) == ("win32", "nt", "Windows", "AMD64", "3.11", "3.11.0")
    mac = cc.target_environment("macosx_11_0_arm64", None, "3.12.4")
    assert (mac["sys_platform"], mac["platform_machine"], mac["python_full_version"]) == ("darwin", "arm64", "3.12.4")
    assert cc.target_environment("macosx_10_9_universal2", None, "3.12.4")["platform_machine"] is None
    linux = cc.target_environment("manylinux_2_17_aarch64", "3.10", "3.13.1")
    assert (linux["sys_platform"], linux["platform_machine"]) == ("linux", "aarch64")
    with pytest.raises(cc.SetupError, match="Unknown --platform"):
        cc.target_environment("solaris_sparc", None, "3.12.0")
    with pytest.raises(cc.SetupError, match="--python-version"):
        cc.target_environment(None, "three", "3.12.0")


# A tiny package index for the fake pip below: name -> (version, Requires-Dist lines), shaped like keyring's.
INDEX = {
    "paramiko": ("5.1.0", ["bcrypt>=3.2", "invoke>=2.0", 'gssapi>=1.4.1; extra == "gssapi"']),
    "bcrypt": ("5.0.0", []), "invoke": ("3.0.3", []), "gssapi": ("1.9.0", []),
    "keyring": ("25.7.0", ['pywin32-ctypes>=0.2.0; sys_platform == "win32"', 'SecretStorage>=3.2; sys_platform == "linux"',
                           'jeepney>=0.4.2; sys_platform == "linux"', 'importlib_metadata>=4.11.4; python_version < "3.12"',
                           "jaraco.classes"]),
    "pywin32-ctypes": ("0.2.3", []), "secretstorage": ("3.5.0", ["jeepney>=0.6"]), "jeepney": ("0.9.0", []),
    "importlib-metadata": ("8.7.0", ['zipp>=3.20', 'typing-extensions>=3.6.4; python_version < "3.8"']),
    "zipp": ("3.23.0", []), "typing-extensions": ("4.15.0", []), "jaraco.classes": ("3.4.0", ["more-itertools"]),
    "more-itertools": ("11.2.1", []),
}
HOST = {"os_name": "posix", "sys_platform": "linux", "platform_system": "Linux", "platform_machine": "x86_64",
        "python_version": "3.13", "python_full_version": "3.13.1", "implementation_name": "cpython",
        "platform_python_implementation": "CPython", "extra": ""}


CANONICAL_INDEX = {re.sub(r"[-_.]+", "-", k).lower(): v for k, v in INDEX.items()}


def fake_wheel(dest: Path, name: str):
    version, requires = CANONICAL_INDEX[name]
    dist = name.replace("-", "_").replace(".", "_")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(f"{dist}-{version}.dist-info/METADATA", "Metadata-Version: 2.1\nName: " + name + "\nVersion: " + version
                   + "\n" + "".join(f"Requires-Dist: {r}\n" for r in requires) + "\n")
    (dest / f"{dist}-{version}-py3-none-any.whl").write_bytes(buf.getvalue())


def fake_pip(calls: list, unavailable=()):
    """pip download as it behaves: it resolves the requested names and their dependencies, evaluating markers for the
    Python running it (HOST), never for the target given with --platform and --python-version."""
    def runner(cmd):
        calls.append(cmd)
        dest = Path(cmd[cmd.index("--dest") + 1])
        pending = list(cmd[max(i for i, a in enumerate(cmd) if a.startswith("-")) + 2:])  # after the last option's value
        while pending:
            name, _, _, marker = cc.parse_requirement(pending.pop())
            if marker and not cc.evaluate_marker(marker, HOST):
                continue
            if cc.canonical_name(name) in unavailable:
                return 1, f"ERROR: No matching distribution found for {name}"
            fake_wheel(dest, cc.canonical_name(name))
            pending += CANONICAL_INDEX[cc.canonical_name(name)][1]
        return 0, "Saved"
    return runner


def test_a_wheelhouse_for_windows_and_python_3_11_gets_the_dependencies_that_apply_there(tmp_path):
    calls = []
    res = cc.make_wheelhouse(tmp_path / "wh", platform="win_amd64", python_version="3.11", runner=fake_pip(calls))
    assert res["result"] == "PASS" and res["tested_versions"] is True
    added = res["added_for_target"]
    assert [w.split("-")[0] for w in added] == ["importlib_metadata", "pywin32_ctypes", "zipp"]
    assert set(added) <= set(res["wheels"]) and not any(w.startswith("gssapi") for w in res["wheels"])
    assert all("--platform" in c and "win_amd64" in c and "3.11" in c for c in calls)
    assert any(c[-1] == "pywin32-ctypes>=0.2.0" and "-c" in c for c in calls)  # tested pins kept where they apply
    assert cc.missing_for_target(tmp_path / "wh", cc.target_environment("win_amd64", "3.11", "3.13.1")) == []


def test_a_wheelhouse_for_this_computer_needs_nothing_more(tmp_path):
    calls = []
    res = cc.make_wheelhouse(tmp_path / "wh", python_version=HOST["python_version"], platform="manylinux2014_x86_64",
                             runner=fake_pip(calls))  # the target is the fake pip's own Python and platform
    assert res["result"] == "PASS" and res["added_for_target"] == [] and len(calls) == 1


def test_a_wheelhouse_that_cannot_be_completed_for_the_target_fails(tmp_path):
    with pytest.raises(cc.SetupError, match="cannot be completed for win_amd64.*pywin32-ctypes>=0.2.0, needed there by "
                                            "keyring 25.7.0 \\(sys_platform == \"win32\"\\)"):
        cc.make_wheelhouse(tmp_path / "wh", platform="win_amd64", python_version="3.12",
                           runner=fake_pip([], unavailable=("pywin32-ctypes",)))


# --- gen-5: a failed --reuse-state preparation of a 1.x state --------------------------------------------------


def test_a_failed_preparation_of_a_1x_state_leaves_it_recognizable(setup):
    st = setup["state"]
    for sub in ("engine", "jvm-home", "tmp"):
        (st / sub).mkdir(parents=True)
    (st / "engine" / "case.json").write_text("1.x case")

    def offline(base, target, wheelhouse, cwd):
        raise cc.SetupError("pip failed (offline)")
    with pytest.raises(cc.SetupError, match="offline"):
        run(setup, reuse_state=True, python_env_factory=offline)
    assert sorted(p.name for p in st.iterdir()) == ["engine", "jvm-home", "tmp"]
    assert run(setup, reuse_state=True)["state_reused"] == "1.x"
    assert (st / "engine" / "case.json").read_text() == "1.x case"


def test_a_1x_state_with_a_host_folder_and_os_metadata_is_recognized(setup):
    st = setup["state"]
    for sub in ("engine", "jvm-home", "tmp", "host"):
        (st / sub).mkdir(parents=True)
    for junk in (".DS_Store", "._engine", "Thumbs.db", "desktop.ini"):
        (st / junk).write_bytes(b"\x00")
    assert run(setup, reuse_state=True)["state_reused"] == "1.x"


# --- gen-6 / gen-8: shims and unversioned names -------------------------------------------------------------------


def make_shim(tmp_path: Path) -> Path:
    shim = tmp_path / "shims" / "python3"  # like pyenv: a script that picks an interpreter by folder
    shim.parent.mkdir()
    shim.write_text(f"#!/bin/sh\nexec {BASE} \"$@\"\n")
    shim.chmod(0o755)
    return shim


def test_a_shim_is_resolved_to_the_interpreter_it_runs(setup, tmp_path):
    shim = make_shim(tmp_path)
    res = run(setup, python=shim)
    r = receipt_of(setup)
    assert r["python"]["executable"] == str(BASE) and r["python"]["selected"] == str(shim)
    assert f"{shim} is a shim that started another interpreter; that interpreter, {BASE}, is pinned" == res["python_pinned"]
    assert cc.verify_output(setup["output"], receipt_sha256=kept(setup))["result"] == "PASS"


def test_an_engine_only_installation_never_starts_the_shim(setup, tmp_path):
    shim = make_shim(tmp_path)
    run(setup, python=shim, collector=False, collector_store=None)
    spec = json.loads((setup["output"] / "pitrelay/.mcp.json").read_text())["mcpServers"]["pr"]
    assert spec["command"] == str(BASE) != str(shim)


def test_an_unversioned_name_is_pinned_by_its_versioned_sibling(tmp_path):
    folder = tmp_path / "brew" / "bin"
    folder.mkdir(parents=True)
    (folder / "python3").symlink_to(BASE)
    (folder / f"python{BASE_VERSION}").symlink_to(BASE)
    chosen = cc.select_python(folder / "python3", tmp_path)
    assert chosen["executable"] == folder / f"python{BASE_VERSION}"
    assert chosen["pinned"] == f"{folder / 'python3'} is an unversioned name; its versioned name " \
                               f"{folder / ('python' + BASE_VERSION)}, the same file, is pinned"


def test_an_unversioned_name_without_a_versioned_sibling_is_kept_with_a_warning(setup, tmp_path):
    folder = tmp_path / "only" / "bin"
    folder.mkdir(parents=True)
    (folder / "python3").symlink_to(BASE)
    (folder / f"python{BASE_VERSION}").symlink_to("/nonexistent/python")  # a sibling that is not the same file
    res = run(setup, python=folder / "python3")
    assert res["python"].endswith("/bin/python") and receipt_of(setup)["python"]["executable"] == str(folder / "python3")
    assert any("unversioned name" in w for w in res["warnings"])


def test_a_versioned_name_is_kept_unchanged():
    chosen = cc.select_python(BASE, Path.home())
    assert chosen["executable"] == BASE and chosen["pinned"] is None


# --- gen-7: store paths with URI characters -----------------------------------------------------------------------


@pytest.mark.parametrize("folder", ["FRC #1234", "logs?2026", "100% robot"])
def test_a_store_path_with_uri_characters_is_read_and_nothing_is_created_beside_it(tmp_path, folder):
    store = tmp_path / folder / "store"
    make_store(store)
    before = sorted(p.name for p in tmp_path.iterdir())
    assert cc.check_collector_store(store) == "existing"
    assert sorted(p.name for p in tmp_path.iterdir()) == before


# --- gen-10: front matter Claude Code would read differently --------------------------------------------------------


@pytest.mark.parametrize("front", [
    '{name: x, description: y, allowed-tools: "Bash(*)"}\n',
    "? allowed-tools\n: Bash(*)\n",
    "  name: x\n  allowed-tools: Bash(*)\n",
    '"allowed\\x2dtools": Bash(*)\n',
    "'model': opus\n",
    "&a name: x\n",
    "*a : x\n",
    "!!str allowed-tools: Bash(*)\n",
    "<<: {allowed-tools: Bash(*)}\n",
    "allowed-tools : Bash(*)\n",
    "name: x\n---a: 1\nallowed-tools: Bash(*)\n",
    "name: x\n...\n",
    "- allowed-tools\n",
])
def test_front_matter_in_other_yaml_forms_is_refused(front):
    with pytest.raises(cc.SetupError, match="would change what it may do"):
        cc.check_skill_front_matter("skills/x/SKILL.md", f"---\n{front}---\nbody\n".encode())


@pytest.mark.parametrize("text", ["--- {allowed-tools: Bash(*)}\n---\n", "---\nname: x\n"])
def test_an_unusual_opening_or_a_missing_closing_line_is_refused(text):
    with pytest.raises(cc.SetupError, match="would change what it may do"):
        cc.check_skill_front_matter("skills/x/SKILL.md", text.encode())


def test_plain_front_matter_with_continued_values_is_accepted():
    cc.check_skill_front_matter("skills/x/SKILL.md", (
        "---\nname: pitrelay-x\n# a comment\ndescription: >\n  Diagnose an FRC symptom: one,\n  two.\n"
        "metadata:\n  allowed-tools: nested, not top-level\nversion: 1.0\n---\n# Body\n").encode())
    cc.check_skill_front_matter("skills/x/SKILL.md", b"# No front matter\nallowed-tools: in the body\n")


# --- gen-11: the store and the state ------------------------------------------------------------------------------


@pytest.mark.parametrize("where", ["same", "inside", "around"])
def test_the_collector_store_may_not_overlap_the_state(setup, tmp_path, where):
    store = {"same": setup["state"], "inside": setup["state"] / "engine" / "store", "around": tmp_path / "logs"}[where]
    state = tmp_path / "logs" / "state" if where == "around" else setup["state"]
    with pytest.raises(cc.SetupError, match="collector store and the state folder must not overlap"):
        run(setup, collector_store=store, state=state)
    assert not state.exists()


# --- gen-12: older Python environments ------------------------------------------------------------------------------


def two_preparations(setup, tmp_path, monkeypatch, login_item):
    run(setup)
    old_env = env_of(setup)
    monkeypatch.setattr(cc, "existing_login_item", lambda: login_item(old_env) if login_item else None)
    second = run(dict(setup, output=tmp_path / "out2"), reuse_state=True)
    return old_env, second


def test_an_environment_the_login_item_still_starts_is_not_offered_for_deletion(setup, tmp_path, monkeypatch):
    item = lambda env: {"enabled": True, "location": "HKCU\\...\\PitRelayClaudeCollector",  # noqa: E731
                        "command": [str(cc.venv_python(env)), "-I", "-B", "collector.py", "run"]}
    old_env, second = two_preparations(setup, tmp_path, monkeypatch, item)
    assert "older_python_environments" not in second
    assert f"Not listed, because the background collector registered at login may still start it: {old_env}" in \
        second["older_python_environments_note"]


def test_an_xdg_login_item_is_read_from_its_desktop_file(setup, tmp_path, monkeypatch):
    desktop = tmp_path / "pitrelay-claude-collector.desktop"

    def item(env):
        desktop.write_text(f'[Desktop Entry]\nExec="{cc.venv_python(env)}" "-I" "run"\n')
        return {"enabled": True, "location": str(desktop), "command": None}
    old_env, second = two_preparations(setup, tmp_path, monkeypatch, item)
    assert "older_python_environments" not in second and str(old_env) in second["older_python_environments_note"]


def test_an_unreadable_login_item_withholds_every_older_environment(setup, tmp_path, monkeypatch):
    item = lambda env: {"enabled": True, "location": str(tmp_path / "gone.desktop"), "command": None}  # noqa: E731
    old_env, second = two_preparations(setup, tmp_path, monkeypatch, item)
    assert "older_python_environments" not in second and str(old_env) in second["older_python_environments_note"]


def test_a_login_item_of_another_environment_leaves_the_old_one_listed_with_the_caveat(setup, tmp_path, monkeypatch):
    item = lambda env: {"enabled": True, "location": "x",  # noqa: E731
                        "command": [str(cc.venv_python(Path(str(env) + "0"))), "run"]}  # python-gXXXXXXXX0: not a prefix
    old_env, second = two_preparations(setup, tmp_path, monkeypatch, item)
    assert second["older_python_environments"] == [str(old_env)]
    assert "turned it on again here" in second["older_python_environments_note"]


# --- notes-7: the engine-only variant leaves out the collector's skill and command --------------------------------


def test_the_engine_only_variant_has_no_collector_skill_or_command(setup):
    run(setup, collector=False, collector_store=None)
    plugin, r = setup["output"] / "pitrelay", receipt_of(setup)
    for rel in ("skills/pitrelay-collect/SKILL.md", "commands/collect.md"):
        assert not (plugin / rel).exists() and rel not in r["overlay_files"]
    assert (plugin / "skills/pitrelay-collector-intake/SKILL.md").is_file() and (plugin / "commands/start.md").is_file()
    assert set(r["overlay_files"]) == set(cc.overlay_inventory(False))
    assert cc.verify_output(setup["output"], receipt_sha256=kept(setup))["result"] == "PASS"
    (plugin / "commands/collect.md").write_bytes(cc.overlay_files()["commands/collect.md"])  # put back by someone
    rewrite_receipt(setup["output"])
    problems = cc.verify_output(setup["output"], receipt_sha256=kept(setup))["problems"]
    assert "file not produced by setup: pitrelay/commands/collect.md" in problems


def test_the_collector_variant_keeps_them(setup):
    run(setup)
    plugin, r = setup["output"] / "pitrelay", receipt_of(setup)
    assert (plugin / "commands/collect.md").is_file() and "skills/pitrelay-collect/SKILL.md" in r["overlay_files"]
    (plugin / "commands/collect.md").unlink()
    rewrite_receipt(setup["output"])
    assert "overlay file differs from the reviewed inventory: commands/collect.md" in \
        cc.verify_output(setup["output"], receipt_sha256=kept(setup))["problems"]



def test_native_executables_are_told_from_scripts(tmp_path):
    for head, native in ((b"\x7fELF\x02\x01", True), (b"MZ\x90\x00", True), (b"\xcf\xfa\xed\xfe", True),
                         (b"#!/bin/sh\nexec java", False), (b"", False)):
        f = tmp_path / f"p{len(head)}{native}"
        f.write_bytes(head)
        assert cc.native_executable(f) is native
    assert cc.native_executable(Path(sys.executable)) is True


@pytest.mark.parametrize("state", ["/home/u/100% team/state", "/home/u/a$b/state", '/home/u/say "hi"/state'])
def test_a_desktop_entry_naming_an_environment_is_recognised_however_it_is_escaped(state):
    sys.path.insert(0, str(Path(cc.__file__).parent / "collector" / "src"))
    from pitrelay_collector.autostart import _desktop_quote
    env = f"{state}/python-g1234abcd"
    exec_line = " ".join(_desktop_quote(a) for a in (f"{env}/bin/python", "-I", "/out/pitrelay/host/collector.py", "run"))
    assert cc.command_uses(f"Exec={exec_line}", env)
    assert not cc.command_uses(f"Exec={exec_line}", f"{state}/python-gffffffff")


# --- round two -------------------------------------------------------------------------------------------------
# gen2-1: the receipt's keys of the files no install record hashes, where paths compare case-insensitively (Windows)


def test_cached_bytecode_keys_keep_their_spelling_where_paths_compare_case_insensitively(tmp_path, monkeypatch):
    env = tmp_path / "env"
    fake_env_with_dist(BASE, env, None, tmp_path)
    sp = sp_of(env)
    cached = sp / "Demo" / "__pycache__" / "x.cpython-313.pyc"  # pip's bytecode, listed without a hash
    cached.parent.mkdir(parents=True)
    cached.write_bytes(b"original bytecode")
    record = sp / "demo-1.0.dist-info" / "RECORD"
    record.write_text(record.read_text() + "Demo/__pycache__/x.cpython-313.pyc,,\n")
    records, launchers, unhashed = (cc.install_records(env, BASE_VERSION), cc.env_launchers(env),
                                    cc.unhashed_files(env, BASE_VERSION))
    key = f"lib/python{BASE_VERSION}/site-packages/Demo/__pycache__/x.cpython-313.pyc"
    assert key in unhashed
    # Windows' rule (ntpath.normcase lowercases): paths are case-folded to compare them, never in the receipt's keys.
    monkeypatch.setattr(cc.os.path, "normcase", lambda p: os.fspath(p).lower())

    def check():
        return cc.check_python_env(env, BASE, BASE_VERSION, {"demo": "1.0"}, records, launchers, unhashed)
    assert check() == []
    cached.write_bytes(b"planted bytecode")
    assert check() == [f"collector dependency file differs from the one installed at setup: {key}"]


# gen2-2 / docs-3: the recorded base Python, changed


def test_a_wrapper_script_in_place_of_the_recorded_python_fails_anchored_verify(setup, tmp_path):
    bash = shutil.which("bash")
    if bash is None:
        pytest.skip("needs bash for exec -a")
    folder = tmp_path / "pybase" / "bin"
    folder.mkdir(parents=True)
    py = folder / f"python{BASE_VERSION}"
    py.symlink_to(BASE)
    run(setup, python=py, collector=False, collector_store=None)
    assert receipt_of(setup)["python"]["executable"] == str(py)
    receipt_sha = kept(setup)
    assert cc.verify_output(setup["output"], receipt_sha256=receipt_sha)["result"] == "PASS"
    py.unlink()  # a wrapper that keeps sys.executable (so it still looks like the recorded base) and runs a payload
    py.write_text(f"#!{bash}\necho ran >> {tmp_path / 'wrapper-ran'}\nexec -a \"$0\" {BASE} \"$@\"\n")
    py.chmod(0o755)
    v = cc.verify_output(setup["output"], receipt_sha256=receipt_sha)
    assert v["result"] == "FAIL" and any("changed and is not a native interpreter" in p for p in v["problems"])


# gen2-3: Java pinned by a stable link


def test_a_java_link_survives_an_update_that_installs_the_runtime_in_a_new_folder(setup, tmp_path, monkeypatch):
    cellar = tmp_path / "Cellar" / "openjdk@21"
    launcher = fake_java(cellar / "21.0.4")
    (tmp_path / "opt").mkdir()
    (tmp_path / "opt" / "openjdk@21").symlink_to(cellar / "21.0.4")  # as Homebrew links a keg
    selected = tmp_path / "opt" / "openjdk@21" / "jdk" / "bin" / "java"
    res = run(setup, java=selected, collector=False, collector_store=None)
    assert res["java"] == str(selected) == launch_of(setup)["java"]
    assert receipt_of(setup)["java_launcher"] == os.path.realpath(launcher)
    assert not any("removes this folder" in w for w in res["warnings"])
    receipt_sha = kept(setup)
    # brew upgrade: 21.0.5 in a new folder, the old folder removed, the link repointed.
    (cellar / "21.0.4").rename(cellar / "21.0.5")
    moved = cellar / "21.0.5" / "jdk" / "bin" / "java"
    moved.write_text(moved.read_text().replace("21.0.4", "21.0.5"))
    (tmp_path / "opt" / "openjdk@21").unlink()
    (tmp_path / "opt" / "openjdk@21").symlink_to(cellar / "21.0.5")
    monkeypatch.setattr(cc, "native_executable", lambda path: True)  # the fake launcher is a script
    v = cc.verify_output(setup["output"], receipt_sha256=receipt_sha)
    assert v["result"] == "PASS" and f"now leads to another runtime's launcher, {os.path.realpath(moved)}" in v["note"]


def test_an_alternatives_link_is_not_pinned_so_switching_it_never_changes_the_engines_java(setup, tmp_path):
    jdk21, jdk17 = fake_java(tmp_path / "jvm21"), fake_java(tmp_path / "jvm17", version="17.0.12")
    alternative = tmp_path / "etc-alternatives-java"
    alternative.symlink_to(jdk21)
    usr_bin_java = tmp_path / "usr-bin-java"
    usr_bin_java.symlink_to(alternative)
    res = run(setup, java=usr_bin_java, collector=False, collector_store=None)
    assert res["java"] == os.path.realpath(jdk21)
    receipt_sha = kept(setup)
    alternative.unlink()
    alternative.symlink_to(jdk17)  # update-alternatives --set java .../jvm17: the engine keeps its Java 21
    assert cc.verify_output(setup["output"], receipt_sha256=receipt_sha)["result"] == "PASS"


def test_a_version_named_link_redirected_to_the_same_version_fails(setup, tmp_path, monkeypatch):
    cellar = tmp_path / "Cellar" / "openjdk@21"
    fake_java(cellar / "21.0.4")
    (tmp_path / "opt").mkdir()
    (tmp_path / "opt" / "openjdk@21").symlink_to(cellar / "21.0.4")
    run(setup, java=tmp_path / "opt" / "openjdk@21" / "jdk" / "bin" / "java", collector=False, collector_store=None)
    receipt_sha = kept(setup)
    copy = fake_java(tmp_path / "doctored" / "21.0.4")  # another runtime reporting the very same version
    (tmp_path / "opt" / "openjdk@21").unlink()
    (tmp_path / "opt" / "openjdk@21").symlink_to(copy.parent.parent.parent)
    monkeypatch.setattr(cc, "native_executable", lambda path: True)
    v = cc.verify_output(setup["output"], receipt_sha256=receipt_sha)
    assert any("without becoming another Java version" in p for p in v["problems"])


def test_a_java_link_through_the_workspace_is_never_pinned(setup, tmp_path):
    ws = tmp_path / "ws"
    ws.mkdir()
    cellar = tmp_path / "Cellar" / "openjdk@21"
    launcher = fake_java(cellar / "21.0.4")
    (ws / "jlink").symlink_to(launcher)  # whoever controls the workspace could repoint this
    selected = tmp_path / "bin" / "java"
    selected.parent.mkdir()
    selected.symlink_to(ws / "jlink")
    res = run(setup, java=selected, collector=False, collector_store=None, workspace=ws,
              workspace_disclosure=cc.DISCLOSURE_ACK)
    assert res["java"] == os.path.realpath(launcher)


def test_verify_never_runs_a_changed_java_or_python_that_is_not_a_native_program(setup, tmp_path):
    run(setup, collector=False, collector_store=None)
    receipt_sha = kept(setup)
    ran = tmp_path / "ran"
    java = Path(launch_of(setup)["java"])
    java.write_text(f"#!/bin/sh\necho ran > {ran}\n")  # the fake launcher is replaced by another script
    v = cc.verify_output(setup["output"], receipt_sha256=receipt_sha)
    assert any("changed and is not a native program; it was not run" in p for p in v["problems"]) and not ran.exists()


def test_setup_refuses_a_script_as_the_base_python(setup, tmp_path):
    wrapper = tmp_path / "wrap" / "python3.13"
    wrapper.parent.mkdir()
    # The script makes the interpreter report the script's own path. Some builds (relocatable Python 3.10) then look
    # for their library next to the script and cannot start; any working CPython 3.10+ serves here.
    for real in dict.fromkeys(os.path.realpath(p) for p in (sys.executable, shutil.which("python3") or sys.executable)):
        wrapper.write_text(f"#!/bin/bash\nexec -a \"$0\" {real} \"$@\"\n")
        wrapper.chmod(0o755)
        probe = subprocess.run([str(wrapper), "-I", "-c", "import sys; assert sys.version_info >= (3, 10)"],
                               capture_output=True)
        if probe.returncode == 0:
            break
    else:
        pytest.skip("no Python here starts under another program name")
    with pytest.raises(cc.SetupError, match="is a script, not an interpreter"):
        run(setup, python=wrapper, collector=False, collector_store=None)


def test_a_virtual_environment_made_from_another_is_pinned_by_the_base_interpreter(tmp_path):
    outer, inner = tmp_path / "outer", tmp_path / "inner"
    subprocess.run([sys.executable, "-m", "venv", "--without-pip", str(outer)], check=True)
    subprocess.run([str(cc.venv_python(outer)), "-m", "venv", "--without-pip", str(inner)], check=True)
    # Python 3.10 writes the outer environment's folder as the inner one's 'home': pinning a name there would start
    # the outer environment, not a base interpreter.
    (inner / "pyvenv.cfg").write_text(f"home = {cc.venv_python(outer).parent}\ninclude-system-site-packages = false\n"
                                      f"version = {sys.version_info[0]}.{sys.version_info[1]}.{sys.version_info[2]}\n")
    base = cc.select_python(cc.venv_python(inner), tmp_path)["executable"]
    assert not cc.lies_in(base, outer) and not cc.lies_in(base, inner)
    assert os.path.samefile(base, os.path.realpath(sys.executable))


def test_a_python_reached_through_the_workspace_is_refused(setup, tmp_path):
    ws = tmp_path / "ws"
    ws.mkdir()
    (ws / "py").symlink_to(os.path.realpath(sys.executable))
    selected = tmp_path / "pybin" / f"python{sys.version_info[0]}.{sys.version_info[1]}"
    selected.parent.mkdir()
    selected.symlink_to(ws / "py")
    with pytest.raises(cc.SetupError, match="reached through it"):
        run(setup, python=selected, collector=False, collector_store=None, workspace=ws,
            workspace_disclosure=cc.DISCLOSURE_ACK)


def test_a_shim_into_a_version_named_folder_is_pinned_there_with_a_warning(setup, tmp_path):
    jdk = fake_java(tmp_path / "installs" / "temurin-21.0.4+7")
    shim = tmp_path / "shims" / "java"  # like asdf: a script that picks the JDK
    shim.parent.mkdir()
    shim.write_text(f"#!/bin/sh\nexec {jdk} \"$@\"\n")
    shim.chmod(0o755)
    res = run(setup, java=shim, collector=False, collector_store=None)
    assert res["java"] == str(jdk) and "java_pinned" not in res
    assert any(f"pinned by {jdk}, a folder named for version 21.0.4: a JDK update that removes this folder will "
               "require preparing again" in w for w in res["warnings"])


def test_a_java_link_inside_the_workspace_is_not_pinned(setup, tmp_path):
    ws = tmp_path / "inbox"
    ws.mkdir()
    (ws / "java").symlink_to(setup["java"])  # the workspace could switch it later
    res = run(setup, java=ws / "java", workspace=ws, workspace_disclosure="accepted-v1", collector=False,
              collector_store=None)
    assert res["java"] == str(setup["java"]) and "java_pinned" not in res


@pytest.mark.parametrize("path, version, named", [
    ("/usr/lib/jvm/java-21-openjdk-21.0.4.0.7-1.fc40.x86_64/bin/java", "21.0.4", True),
    ("/opt/homebrew/Cellar/openjdk@21/21.0.4/bin/java", "21.0.4", True),
    ("/opt/homebrew/opt/openjdk@21/bin/java", "21.0.4", False),
    ("/usr/lib/jvm/jdk-17.0.12/bin/java", "17.0.1", False),
    ("/usr/lib/jvm/java-21/bin/java", "21", False),
])
def test_version_named_folders(path, version, named):
    assert cc.names_version(Path(path), version) is named


# gen2-4: a virtual environment as --python


def test_a_virtual_environment_pins_its_base_by_the_name_it_was_made_from(setup, tmp_path):
    stable = tmp_path / "brewpy" / "bin" / f"python{BASE_VERSION}"  # like /opt/homebrew/bin/python3.x, a link
    stable.parent.mkdir(parents=True)
    stable.symlink_to(BASE)
    venv = tmp_path / "myvenv"
    subprocess.run([str(stable), "-I", "-m", "venv", "--without-pip", str(venv)], check=True, capture_output=True)
    chosen = cc.select_python(cc.venv_python(venv), tmp_path)
    assert chosen["executable"] == stable and chosen["warning"] is None
    res = run(setup, python=cc.venv_python(venv))  # the collector's environment is made from that name, and passes
    assert receipt_of(setup)["python"]["executable"] == str(stable) and not any("resolved path" in w for w in res["warnings"])
    assert cc.verify_output(setup["output"], receipt_sha256=kept(setup))["result"] == "PASS"


def test_a_virtual_environment_without_a_stable_name_for_its_base_warns(setup, tmp_path):
    def script(path: Path, info: dict) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"#!/bin/sh\necho '{json.dumps(info)}'\n")
        path.chmod(0o755)
        return path
    common = {"version": [3, 12, 1], "implementation": "cpython", "gil_disabled": False, "sys_version": "3.12.1 (x)"}
    base = tmp_path / "Cellar" / "3.12.1" / "bin" / "python3.12"  # reported fully resolved, as Python 3.11+ does
    script(base, {**common, "executable": str(base), "prefix": "/nonexistent", "base_prefix": "/nonexistent",
                  "base_executable": str(base)})
    venv = tmp_path / "v"
    script(venv / "bin" / "python", {**common, "executable": str(venv / "bin" / "python"), "prefix": str(venv),
                                     "base_prefix": "/nonexistent", "base_executable": str(base)})
    (venv / "pyvenv.cfg").write_text(f"home = {tmp_path / 'gone'}\n")
    chosen = cc.select_python(venv / "bin" / "python", tmp_path)
    assert chosen["executable"] == base and "names no other path to its base interpreter" in chosen["warning"]
    import configure_claude as cc_mod
    native, cc_mod.native_executable = cc_mod.native_executable, lambda path: True  # the fake interpreters are scripts
    try:
        res = run(setup, python=venv / "bin" / "python", collector=False, collector_store=None)
    finally:
        cc_mod.native_executable = native
    assert any("names no other path to its base interpreter" in w for w in res["warnings"])


# gen2-5: hashes the person types or pastes


def test_verify_takes_a_kept_hash_in_uppercase_or_with_spaces_and_refuses_a_malformed_one(setup, capsys):
    run(setup, collector=False, collector_store=None)
    out, receipt_sha = setup["output"], kept(setup)
    for given in (receipt_sha.upper(), f"  {receipt_sha}\n"):  # as Get-FileHash prints it, or pasted
        assert cc.verify_output(out, receipt_sha256=given)["result"] == "PASS"
    assert cc.verify_output(out, manifest_sha256=setup["manifest_sha256"].upper())["result"] == "PASS"
    for bad in ("e842e0ca", receipt_sha + "0", "g" * 64):
        with pytest.raises(cc.SetupError, match="--receipt-sha256 must be a SHA-256: 64 hex characters"):
            cc.verify_output(out, receipt_sha256=bad)
    assert cc.main(["verify", "--output", str(out), "--manifest-sha256", "E842"]) == 1
    problems = json.loads(capsys.readouterr().out)["problems"]
    assert problems == ["--manifest-sha256 must be a SHA-256: 64 hex characters (got 'E842')"]


# docs-6 / docs-1: what a reused state says about its previous preparation


def test_a_reused_state_keeps_the_collector_store_its_previous_preparation_used(setup, tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "xdg"))
    custom = tmp_path / "frc-logs"
    run(setup, collector_store=custom)
    s2 = dict(setup, output=tmp_path / "out2", collector_store=None)
    second = run(s2, reuse_state=True)
    assert second["collector_store"] == str(custom) == receipt_of(s2)["collector"]["store"]
    assert "previous preparation" in second["collector_store_note"]
    assert not any("collector store" in w for w in second["warnings"])
    third = run(dict(setup, output=tmp_path / "out3", collector_store=tmp_path / "other-logs"), reuse_state=True)
    assert any(f"The earlier preparation of this state used the collector store {custom}" in w for w in third["warnings"])
    (tmp_path / "out3" / "prepared-installation.json").write_text("not a receipt")  # only a readable receipt counts
    fourth = run(dict(setup, output=tmp_path / "out4", collector_store=None), reuse_state=True)
    assert fourth["collector_store"] == str(cc.default_collector_store()) and "collector_store_note" not in fourth


def test_a_reused_state_prepared_for_another_access_or_place_warns_that_earlier_cases_are_out_of_reach(setup, tmp_path):
    engine_only = {"collector": False, "collector_store": None}
    run(setup, **engine_only)
    marker = json.loads((setup["state"] / "pitrelay-state.json").read_text())
    assert (marker["experience"], marker["workspace"], marker["state"]) == ("standard", None, str(setup["state"]))
    assert "no longer reaches the earlier cases and artifacts" in receipt_of(setup)["relocation"]
    ws = tmp_path / "inbox"
    ws.mkdir()
    workspace = {"workspace": ws, "workspace_disclosure": "accepted-v1"}
    second = run(dict(setup, output=tmp_path / "o2"), reuse_state=True, **engine_only, **workspace)
    assert any(f"were made with Standard Access; this preparation uses Workspace Access on {ws}" in w
               for w in second["warnings"])
    third = run(dict(setup, output=tmp_path / "o3"), reuse_state=True, grants="project_read,propose", **engine_only,
                **workspace)  # only the grants changed: the engine still reaches them
    assert not any("cannot reach" in w for w in third["warnings"])
    marker = json.loads((setup["state"] / "pitrelay-state.json").read_text())
    (setup["state"] / "pitrelay-state.json").write_text(json.dumps(  # an older marker: the receipt says it instead
        {k: marker[k] for k in ("kind", "generator", "generator_version", "install_id", "marketplace")}))
    moved = tmp_path / "moved-state"
    setup["state"].rename(moved)
    fourth = run(dict(setup, output=tmp_path / "o4", state=moved), reuse_state=True, **engine_only)
    assert any(f"were made with Workspace Access on {ws}; this preparation uses Standard Access" in w
               for w in fourth["warnings"])
    assert any(f"This state folder was prepared at {setup['state']}. Moved, it keeps its files" in w
               for w in fourth["warnings"])

