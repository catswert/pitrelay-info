"""Run the host in-process over pipes, as Claude Code would talk to it, with a fake or the real engine."""
from __future__ import annotations

import json
import os
import shutil
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT / "host", ROOT / "collector" / "src", ROOT / "collector" / "tests"):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from pitrelay_host.relay import HostServer  # noqa: E402

FAKE_ENGINE = Path(__file__).resolve().parent / "fake_engine.py"
PREFIX = "mcp__plugin_pitrelay_pr__"


def real_engine_jar() -> Path | None:
    jar = os.environ.get("PITRELAY_ENGINE_JAR")
    return Path(jar) if jar and Path(jar).is_file() and shutil.which("java") else None


def fake_java(folder: Path) -> Path:
    java = folder / "fake-java"
    java.write_text(f"#!/bin/sh\nexec '{sys.executable}' -I -B '{FAKE_ENGINE}' \"$@\"\n")
    java.chmod(0o755)
    return java


def flaky_java(folder: Path, failures: int) -> Path:
    """A fake `java` whose first `failures` starts exit with code 1; every start is counted in java-starts.txt."""
    java = folder / "flaky-java"
    count = folder / "java-starts.txt"
    java.write_text(f"#!/bin/sh\necho x >> '{count}'\n"
                    f"[ \"$(wc -l < '{count}')\" -le {int(failures)} ] && exit 1\n"
                    f"exec '{sys.executable}' -I -B '{FAKE_ENGINE}' \"$@\"\n")
    java.chmod(0o755)
    return java


class Harness:
    """A host on pipes. Elicitations are answered by `answer(params) -> result` (default: decline)."""

    def __init__(self, tmp: Path, *, real_jar: Path | None = None, collector: bool = False, config: dict | None = None,
                 host_notes: bool = True, java: str | None = None, workspace: Path | None = None,
                 capabilities: dict | None = None, protocol: str = "2025-11-25", initialize: bool = True,
                 install_collector=None, state: Path | None = None, collector_store: Path | None = None,
                 engine_sha256: str | None = None):
        self.tmp = Path(tmp)
        self.plugin = self.tmp / "plugin"
        (self.plugin / "engine").mkdir(parents=True, exist_ok=True)
        (self.plugin / "host").mkdir(exist_ok=True)
        jar = self.plugin / "engine" / "pitrelay.jar"
        if not jar.exists():
            if real_jar is not None:
                shutil.copyfile(real_jar, jar)
            else:
                jar.write_bytes(b"not a real engine")
        self.state = Path(state) if state is not None else self.tmp / "state"
        for sub in ("jvm-home", "tmp", "host"):
            (self.state / sub).mkdir(parents=True, exist_ok=True)
        if config is not None:
            (self.state / "fake-engine.json").write_text(json.dumps(config))
        self.launch = {"schema_version": "1.0",
                       "java": java or (shutil.which("java") if real_jar is not None else str(fake_java(self.tmp))),
                       "state": str(self.state), "workspace": str(workspace) if workspace else None,
                       "workspace_grants": ["project_read"] if workspace else [], "lc_all": "C.UTF-8",
                       "collector": collector,
                       "collector_store": str(collector_store or self.state / "collector") if collector else None,
                       "host_notes": host_notes, "tool_name_prefix": PREFIX, "engine_sha256": engine_sha256}
        r_in, w_in = os.pipe()
        r_out, w_out = os.pipe()
        self._to_host = os.fdopen(w_in, "wb")
        self._from_host = os.fdopen(r_out, "rb")
        self.server = HostServer(self.launch, self.plugin, os.fdopen(r_in, "rb"), os.fdopen(w_out, "wb"))
        if collector:
            from pitrelay_host.collector_tools import install
            self.collector = (install_collector or install)(self.server)
        self.messages: list[dict] = []
        self.elicitations: list[dict] = []
        self.answer = lambda params: {"action": "decline"}
        self.cv = threading.Condition()
        self._n = 0
        self._wlock = threading.Lock()
        self.thread = threading.Thread(target=self.server.serve, daemon=True)
        self.thread.start()
        threading.Thread(target=self._read, daemon=True).start()
        if initialize:
            self.init = self.request("initialize", {"protocolVersion": protocol, "capabilities": capabilities if
                                                    capabilities is not None else {"elicitation": {}, "roots": {}},
                                                    "clientInfo": {"name": "harness", "version": "1"}})
            self.notify("notifications/initialized")

    def _read(self):
        for line in self._from_host:
            msg = json.loads(line)  # every line must be one JSON object
            if msg.get("method") == "elicitation/create":
                self.elicitations.append(msg)
                result = self.answer(msg["params"])
                if result is not None:
                    self.send({"jsonrpc": "2.0", "id": msg["id"], **(result if "error" in result else {"result": result})})
                continue
            with self.cv:
                self.messages.append(msg)
                self.cv.notify_all()

    def send(self, msg: dict) -> None:
        with self._wlock:
            self._to_host.write((json.dumps(msg) + "\n").encode())
            self._to_host.flush()

    def send_raw(self, data: bytes) -> None:
        with self._wlock:
            self._to_host.write(data)
            self._to_host.flush()

    def next_id(self):
        self._n += 1
        return self._n

    def start(self, method: str, params: dict | None = None, rid=None):
        rid = rid if rid is not None else self.next_id()
        self.send({"jsonrpc": "2.0", "id": rid, "method": method, **({"params": params} if params is not None else {})})
        return rid

    def wait(self, rid, timeout: float = 60.0) -> dict:
        with self.cv:
            ok = self.cv.wait_for(lambda: any(m.get("id") == rid and "method" not in m for m in self.messages), timeout)
            if not ok:
                raise TimeoutError(f"no answer to {rid!r}")
            return next(m for m in self.messages if m.get("id") == rid and "method" not in m)

    def answered(self, rid) -> bool:
        with self.cv:
            return any(m.get("id") == rid and "method" not in m for m in self.messages)

    def request(self, method: str, params: dict | None = None, timeout: float = 60.0) -> dict:
        return self.wait(self.start(method, params), timeout)

    def notify(self, method: str, params: dict | None = None) -> None:
        self.send({"jsonrpc": "2.0", "method": method, **({"params": params} if params is not None else {})})

    def call_result(self, name: str, arguments: dict | None = None, timeout: float = 120.0, meta: dict | None = None) -> dict:
        params = {"name": name, "arguments": arguments or {}}
        if meta:
            params["_meta"] = meta
        resp = self.request("tools/call", params, timeout)
        assert "result" in resp, resp
        return resp["result"]

    def call(self, name: str, arguments: dict | None = None, timeout: float = 120.0) -> tuple[dict, bool]:
        r = self.call_result(name, arguments, timeout)
        return json.loads(r["content"][0]["text"]), bool(r.get("isError"))

    def notifications(self, method: str) -> list[dict]:
        with self.cv:
            return [m for m in self.messages if m.get("method") == method]

    def engine_received(self) -> list[dict]:
        path = self.state / "fake-engine-received.jsonl"
        if not path.exists():
            return []
        out = []
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                out.append(json.loads(line))
            except ValueError:
                out.append({"_raw_len": len(line)})
        return out

    def close(self, timeout: float = 10.0) -> None:
        try:
            self._to_host.close()
        except OSError:
            pass
        self.thread.join(timeout)
        proc = self.server.engine._proc
        if proc is not None and proc.proc is not None:
            try:
                proc.proc.wait(timeout=timeout)
            except Exception:
                proc.proc.kill()


def wait_until(predicate, timeout: float = 30.0, step: float = 0.05) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(step)
    return predicate()
