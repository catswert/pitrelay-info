"""configure_claude.py against synthetic PitRelay-shaped packages (no real engine needed)."""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import stat
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "host"))
import configure_claude as cc  # noqa: E402
from pitrelay_host.engine import engine_argv  # noqa: E402

LICENSE_TEXT = b"SYNTHETIC TEST LICENSE - not the PitRelay license\n"


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def fake_jar(main_class="org.pitrelay.Main", extra_manifest="", classes=("org/pitrelay/Main.class",)) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("META-INF/MANIFEST.MF", f"Manifest-Version: 1.0\r\nMain-Class: {main_class}\r\n{extra_manifest}\r\n")
        for c in classes:
            z.writestr(c, b"\xca\xfe\xba\xbe")
    return buf.getvalue()


def make_package(base: Path, files: dict[str, bytes] | None = None, version="0.1.0-dev") -> tuple[Path, str, str]:
    pkg = base / "pkg"
    content = {
        "README.md": b"# synthetic package\n",
        "plugin.json": json.dumps({"name": "pitrelay", "version": version, "author": {"name": "Test Author"}}).encode(),
        "engine/pitrelay.jar": fake_jar(),
        "engine/LICENSE": b"engine license\n",
        cc.LICENSE: LICENSE_TEXT,
        "docs/release/LICENSE_INVENTORY.md": b"inventory\n",
        "skills/pitrelay-investigate/SKILL.md": b"---\nname: pitrelay-investigate\ndescription: test skill\n---\nbody\n",
        "skills/pitrelay-investigate/references/access.md": b"ref\n",
        "setup/configure_local.py": b"# not executed\nraise SystemExit('must never run')\n",
        "setup/package_local.py": (b"raise SystemExit('must never run')\n"
                                   b"WORKSPACE_DISCLOSURE = (\n    'SYNTHETIC DISCLOSURE: Workspace Access lets the engine read '\n"
                                   b"    'the folder you authorize.'\n)\n"),
    }
    if files:
        content.update(files)
    for rel, data in content.items():
        p = pkg / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    rows = [{"path": rel, "byte_size": len(data), "sha256": sha(data)} for rel, data in sorted(content.items())]
    manifest = {"schema_version": "1.0", "package_kind": "internal_local_development", "version": version,
                "workflow_contract": "2", "tool_contract": "2.0", "entry_point": "org.pitrelay.Main",
                "engine_sha256": sha(content["engine/pitrelay.jar"]), "files": rows}
    raw = json.dumps(manifest, indent=2).encode()
    (pkg / "package-manifest.json").write_bytes(raw)
    return pkg, sha(raw), sha(LICENSE_TEXT)


def fake_java(base: Path, version='21.0.4') -> Path:
    """A stand-in for `java -XshowSettings:properties -version` (file-name encoding follows LC_ALL, like Linux)."""
    home = base / "jdk"
    d = home / "bin"
    d.mkdir(parents=True)
    j = d / "java"
    j.write_text("#!/bin/sh\n"
                 "case \"$LC_ALL\" in *UTF-8|*utf8) enc=UTF-8;; *) enc=ANSI_X3.4-1968;; esac\n"
                 "echo 'Property settings:' >&2\n"
                 f"echo '    java.home = {home}' >&2\n"
                 f"echo '    java.version = {version}' >&2\n"
                 "echo \"    sun.jnu.encoding = $enc\" >&2\n"
                 f"echo 'openjdk version \"{version}\" 2026-07-15' >&2\nexit 0\n")
    j.chmod(0o755)
    return j


def fake_python_env(base, target, wheelhouse, cwd):
    """Stands in for creating the collector's environment: a real venv from the selected Python, without pip and
    without downloading anything (the real installation is exercised by tests/mcp_e2e.py and docs/TESTING.md)."""
    subprocess.run([str(base), "-I", "-m", "venv", "--without-pip", str(target)], check=True, capture_output=True)
    return {"python": str(cc.venv_python(target)), "installed": {}}


@pytest.fixture
def setup(tmp_path):
    pkg, msha, lsha = make_package(tmp_path)
    java = fake_java(tmp_path)
    return {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": java,
            "state": tmp_path / "state", "output": tmp_path / "out", "python_env_factory": fake_python_env,
            "collector_store": tmp_path / "collector-store"}


def run(s, **kw):
    args = dict(s)
    args.update(kw)
    return cc.prepare(args.pop("package"), args.pop("manifest_sha256"), args.pop("java"), args.pop("state"),
                      args.pop("output"), args.pop("accept_license"), **args)


def nothing_created(s):
    leftovers = [p for p in s["output"].parent.iterdir() if p.name.startswith(".out.prepare-")]
    return not s["output"].exists() and not s["state"].exists() and not leftovers


pytestmark = pytest.mark.skipif(os.name != "posix", reason="fake Java is a POSIX shell script")


# --- success path ---------------------------------------------------------------------------------


def test_standard_access_marketplace_is_complete_and_byte_identical(setup):
    res = run(setup)
    assert res["result"] == "PASS" and res["experience"] == "standard" and res["installed"] is False
    out, plugin = setup["output"], setup["output"] / "pitrelay"
    manifest = json.loads((setup["package"] / "package-manifest.json").read_text())
    for row in manifest["files"]:
        target = "provenance/original-plugin.json" if row["path"] == "plugin.json" else row["path"]
        assert sha((plugin / target).read_bytes()) == row["sha256"]
    assert (plugin / "provenance/original-package-manifest.json").read_bytes() == \
        (setup["package"] / "package-manifest.json").read_bytes()
    r = json.loads((out / "prepared-installation.json").read_text())
    pj = json.loads((plugin / ".claude-plugin/plugin.json").read_text())
    # A version unique to this preparation, so Claude Code never serves a cached copy of an earlier one.
    assert pj["name"] == "pitrelay" and pj["version"] == f"0.1.0-dev.claude.{r['install_id']}" == res["plugin_version"]
    assert pj["author"] == {"name": "Test Author"}
    mk = json.loads((out / ".claude-plugin/marketplace.json").read_text())
    assert mk["name"] == "pitrelay-local" and mk["plugins"][0]["source"] == "./pitrelay"
    assert mk["plugins"][0]["version"] == pj["version"]
    mcp = json.loads((plugin / ".mcp.json").read_text())["mcpServers"]
    assert list(mcp) == ["pr"]
    spec = mcp["pr"]
    st = setup["state"]
    # Claude Code starts the host with the collector's Python environment; the host starts Java from launch.json.
    # Both name the verified marketplace folder itself, never Claude Code's cached copy.
    env = st / f"python-{r['install_id']}"
    assert spec["command"] == str(cc.venv_python(env))
    assert spec["args"] == ["-I", "-B", "-X", "utf8", str(plugin / "host" / "gateway.py")]
    assert "${" not in json.dumps(spec)
    assert {k: v for k, v in spec["env"].items() if k != "LC_ALL"} == {k: "" for k in cc.INJECTION_VARIABLES}
    assert "cwd" not in spec  # ignored by Claude Code; every path is absolute instead
    launch = launch_of(setup)
    assert launch["java"] == str(setup["java"].resolve()) and launch["state"] == str(st)
    assert launch["plugin_root"] == str(plugin)
    assert launch["collector"] is True and launch["collector_store"] == str(setup["collector_store"])
    assert launch["workspace"] is None and launch["workspace_grants"] == []
    assert launch["host_files"] == {k: v for k, v in cc.OVERLAY_INVENTORY.items() if k.startswith("host/")}
    for rel, h in launch["host_files"].items():
        assert sha((plugin / rel).read_bytes()) == h
    argv = engine_argv(launch, plugin)
    assert argv[argv.index("-cp") + 1] == str(plugin / "engine/pitrelay.jar")
    assert argv[argv.index("--state") + 1] == str(st / "engine")
    assert "--experience" not in argv and "--grants" not in argv
    for f in ("skills/pitrelay-claude-host/SKILL.md", "skills/pitrelay-collector-intake/SKILL.md",
              "commands/start.md", "commands/collect.md", "CLAUDE_CODE.md", "host/gateway.py", "host/collector.py",
              "host/pitrelay_host/relay.py", "host/pitrelay_collector/store.py", "host/pitrelay_collector/static/app.js"):
        assert (plugin / f).is_file()
    assert not list(plugin.rglob("__pycache__"))
    assert (st / "jvm-home").is_dir() and (st / "tmp").is_dir() and stat.S_IMODE(st.stat().st_mode) == 0o700
    assert cc.venv_python(env).is_file()
    assert json.loads((st / "pitrelay-state.json").read_text())["install_id"] == r["install_id"]
    assert not setup["collector_store"].exists()  # created by the collector on first use, never by setup
    assert r["kind"] == "prepared_local_claude_code_plugin" and r["workspace_grants"] == [] and r["schema_version"] == "2.0"
    assert r["collector"]["store"] == str(setup["collector_store"]) and r["collector"]["store_was"] == "new"
    assert r["tool_name_prefix"] == "mcp__plugin_pitrelay_pr__" and r["state"] == str(st)
    assert cc.verify_output(out)["result"] == "PASS"


def test_state_is_never_claude_plugin_data(setup):
    run(setup)
    text = (setup["output"] / "pitrelay/.mcp.json").read_text()
    assert "CLAUDE_PLUGIN_DATA" not in text  # Claude Code deletes that folder on uninstall


def test_workspace_access_requires_the_disclosure_and_records_grants(setup, tmp_path):
    ws = tmp_path / "inbox"
    ws.mkdir()
    with pytest.raises(cc.SetupError, match="accepted-v1 after reading PitRelay's disclosure: SYNTHETIC DISCLOSURE"):
        run(setup, workspace=ws)  # the disclosure shown is the package's own text
    assert nothing_created(setup)
    res = run(setup, workspace=ws, workspace_disclosure="accepted-v1")
    assert res["workspace_grants"] == ["project_read"]
    args = engine_argv(launch_of(setup), setup["output"] / "pitrelay")
    assert args[-8:] == ["--experience", "workspace", "--workspace", str(ws), "--grants", "project_read",
                         "--workspace-disclosure", "accepted-v1"]
    r = json.loads((setup["output"] / "prepared-installation.json").read_text())
    assert r["workspace_disclosure"] == ("SYNTHETIC DISCLOSURE: Workspace Access lets the engine read the folder "
                                         "you authorize.") and r["experience"] == "workspace"


def test_grants_are_validated(setup, tmp_path):
    ws = tmp_path / "inbox"
    ws.mkdir()
    with pytest.raises(cc.SetupError, match="Unknown Workspace Access grant"):
        run(setup, workspace=ws, workspace_disclosure="accepted-v1", grants="project_read,root")
    with pytest.raises(cc.SetupError, match="only together with --workspace"):
        run(setup, grants="project_read")
    res = run(setup, workspace=ws, workspace_disclosure="accepted-v1", grants="propose,project_read,propose")
    assert res["workspace_grants"] == ["project_read", "propose"]


# --- integrity refusals: nothing is created --------------------------------------------------------


def test_wrong_manifest_hash(setup):
    with pytest.raises(cc.SetupError, match="does not match"):
        run(setup, manifest_sha256="0" * 64)
    assert nothing_created(setup)


def test_tampered_file_extra_file_and_link(setup):
    skill = setup["package"] / "skills/pitrelay-investigate/SKILL.md"
    original = skill.read_bytes()
    skill.write_bytes(original.replace(b"body", b"BODY"))
    with pytest.raises(cc.SetupError, match="bytes differ"):
        run(setup)
    skill.write_bytes(original)
    (setup["package"] / "skills/extra.md").write_text("unlisted")
    with pytest.raises(cc.SetupError, match="unexpected"):
        run(setup)
    (setup["package"] / "skills/extra.md").unlink()
    (setup["package"] / "docs/link").symlink_to("/etc")
    with pytest.raises(cc.SetupError, match="link"):
        run(setup)
    assert nothing_created(setup)


def test_license_must_be_acknowledged_exactly(setup):
    with pytest.raises(cc.SetupError, match="--accept-license"):
        run(setup, accept_license=sha(b"something else"))
    assert nothing_created(setup)


@pytest.mark.parametrize("mutate,match", [
    (lambda m: m.update(workflow_contract="3"), "workflow_contract"),
    (lambda m: m.update(entry_point="evil.Main"), "entry_point"),
    (lambda m: m["files"].append({"path": "../escape", "byte_size": 1, "sha256": "0" * 64}), "canonical"),
    (lambda m: m["files"].reverse(), "sorted"),
    (lambda m: m.update(engine_sha256="1" * 64), "Engine identity"),
    (lambda m: m.update(version="1.0 beta"), "version"),
    (lambda m: m.update(files=[r for r in m["files"] if r["path"] != cc.LICENSE]), "missing required"),
])
def test_malformed_manifests_are_refused(setup, mutate, match):
    p = setup["package"] / "package-manifest.json"
    m = json.loads(p.read_text())
    mutate(m)
    raw = json.dumps(m).encode()
    p.write_bytes(raw)
    with pytest.raises(cc.SetupError, match=match):
        run(setup, manifest_sha256=sha(raw))
    assert nothing_created(setup)


def test_duplicate_manifest_keys_are_refused(setup):
    p = setup["package"] / "package-manifest.json"
    raw = p.read_bytes().replace(b'"version":', b'"version": "x", "version":', 1)
    p.write_bytes(raw)
    with pytest.raises(cc.SetupError, match="Duplicate"):
        run(setup, manifest_sha256=sha(raw))


@pytest.mark.parametrize("jar,match", [
    (fake_jar(main_class="other.Main"), "org.pitrelay.Main"),
    (fake_jar(extra_manifest="Class-Path: http://example.invalid/x.jar\r\n"), "Class-Path"),
    (fake_jar(classes=()), "entry point"),
    (b"not a zip", "not a valid archive"),
])
def test_engine_jar_checks(tmp_path, jar, match):
    pkg, msha, lsha = make_package(tmp_path, {"engine/pitrelay.jar": jar})
    s = {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
         "state": tmp_path / "state", "output": tmp_path / "out"}
    with pytest.raises(cc.SetupError, match=match):
        run(s)


# --- paths and runtime ----------------------------------------------------------------------------------


def test_existing_destinations_are_never_reused(setup):
    setup["state"].mkdir()
    (setup["state"] / "precious").write_text("checkpoint")
    with pytest.raises(cc.SetupError, match="--state must be a new path, or add --reuse-state"):
        run(setup)
    with pytest.raises(cc.SetupError, match="is not a PitRelay for Claude Code state folder"):
        run(setup, reuse_state=True)  # an unknown folder is never adopted
    assert (setup["state"] / "precious").read_text() == "checkpoint"
    setup["state"] = setup["state"].with_name("state2")
    setup["output"].mkdir()
    with pytest.raises(cc.SetupError, match="--output must be a new path"):
        run(setup)
    assert list(setup["output"].iterdir()) == []


@pytest.mark.parametrize("which", ["state_in_package", "output_in_state", "workspace_is_state_parent"])
def test_overlapping_folders_are_refused(setup, tmp_path, which):
    kw = {}
    if which == "state_in_package":
        kw["state"] = setup["package"] / "state"
    elif which == "output_in_state":
        kw["output"] = setup["state"] / "out"
    else:
        kw.update(workspace=tmp_path, workspace_disclosure="accepted-v1")
    with pytest.raises(cc.SetupError, match="non-overlapping"):
        run(setup, **kw)


def test_relative_paths_are_refused(setup):
    with pytest.raises(cc.SetupError, match="absolute"):
        run(setup, state=Path("relative/state"))


def test_linked_state_path_is_refused(setup, tmp_path):
    real = tmp_path / "real"
    real.mkdir()
    (tmp_path / "linked").symlink_to(real)
    with pytest.raises(cc.SetupError, match="link"):
        run(setup, state=tmp_path / "linked" / "state")


def test_java_must_be_17_or_later_and_outside_the_package(setup, tmp_path):
    old = fake_java(tmp_path / "old", version="11.0.2")
    with pytest.raises(cc.SetupError, match="Java 17"):
        run(setup, java=old)
    with pytest.raises(cc.SetupError, match="not found"):
        run(setup, java=tmp_path / "nojava")
    inside = setup["package"] / "README.md"
    with pytest.raises(cc.SetupError, match="independently installed Java"):
        run(setup, java=inside)
    assert nothing_created(setup)


def test_a_link_to_a_runtime_not_named_for_its_version_pins_the_launcher(setup, tmp_path):
    link = tmp_path / "usr-bin-java"
    link.symlink_to(setup["java"])
    res = run(setup, java=link)
    r = json.loads(Path(res["receipt"]).read_text())
    # Like Debian's /usr/bin/java (alternatives): the link could later lead to another installed Java, while the
    # runtime's own folder survives its updates. Only a version-named folder is pinned by a link (gen2-3).
    assert launch_of(setup)["java"] == str(setup["java"].resolve()) == res["java"] and r["java_selected"] == str(link)
    assert r["java_launcher"] == str(setup["java"].resolve())


def test_classpath_separator_in_output_path_is_refused(setup, tmp_path):
    with pytest.raises(cc.SetupError, match="split"):
        run(setup, output=tmp_path / f"a{os.pathsep}b")


def test_overlay_cannot_replace_package_files(tmp_path):
    pkg, msha, lsha = make_package(tmp_path, {"skills/pitrelay-claude-host/SKILL.md": b"---\nname: x\n---\n"})
    s = {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
         "state": tmp_path / "state", "output": tmp_path / "out"}
    with pytest.raises(cc.SetupError, match="Overlay files would replace"):
        run(s)


def test_package_scripts_are_never_executed(setup, tmp_path):
    marker = tmp_path / "ran"
    (setup["package"] / "setup/configure_local.py").write_text(f"open({str(marker)!r}, 'w')\n")
    m = json.loads((setup["package"] / "package-manifest.json").read_text())
    for row in m["files"]:
        if row["path"] == "setup/configure_local.py":
            data = (setup["package"] / row["path"]).read_bytes()
            row.update(byte_size=len(data), sha256=sha(data))
    raw = json.dumps(m).encode()
    (setup["package"] / "package-manifest.json").write_bytes(raw)
    run(setup, manifest_sha256=sha(raw))
    assert not marker.exists()


def test_publication_never_replaces_an_existing_folder(tmp_path):
    src, dst = tmp_path / "src", tmp_path / "dst"
    src.mkdir()
    dst.mkdir()
    (dst / "keep").write_text("x")
    with pytest.raises(OSError):
        cc.rename_noreplace(src, dst)
    assert (dst / "keep").read_text() == "x" and src.is_dir()


# --- verify ------------------------------------------------------------------------------------------------


def test_verify_detects_changed_added_and_missing_files(setup):
    run(setup)
    out = setup["output"]
    target = out / "pitrelay/skills/pitrelay-investigate/SKILL.md"
    target.write_bytes(target.read_bytes() + b"\ninjected instruction\n")
    (out / "pitrelay/commands/extra.md").write_text("---\ndescription: x\n---\n")
    (out / "pitrelay/CLAUDE_CODE.md").unlink()
    r = cc.verify_output(out)
    assert r["result"] == "FAIL"
    assert {"changed file pitrelay/skills/pitrelay-investigate/SKILL.md", "unexpected file pitrelay/commands/extra.md",
            "missing file pitrelay/CLAUDE_CODE.md"} <= set(r["problems"])
    assert "PitRelay file differs from its package manifest: skills/pitrelay-investigate/SKILL.md" in r["problems"]


def test_cli_reports_failures_as_json(setup, capsys):
    rc = cc.main(["--package", str(setup["package"]), "--manifest-sha256", "0" * 64, "--accept-license",
                  setup["accept_license"], "--java", str(setup["java"]), "--state", str(setup["state"]),
                  "--output", str(setup["output"])])
    out = json.loads(capsys.readouterr().out)
    assert rc == 1 and out["result"] == "FAIL" and "does not match" in out["error"]


# --- the real Claude Code validator (skipped when the CLI is not installed) -----------------------------------


@pytest.mark.skipif(shutil.which("claude") is None, reason="Claude Code CLI not installed")
def test_generated_marketplace_passes_claude_plugin_validate_strict(setup, tmp_path):
    run(setup)
    env = dict(os.environ, HOME=str(tmp_path / "home"), CLAUDE_CONFIG_DIR=str(tmp_path / "cfg"))
    for target in (setup["output"], setup["output"] / "pitrelay"):
        done = subprocess.run(["claude", "plugin", "validate", str(target), "--strict"], capture_output=True, text=True,
                              env=env, timeout=120, cwd=tmp_path)
        assert done.returncode == 0, done.stdout + done.stderr


def test_paths_that_claude_code_would_expand_are_refused(setup, tmp_path):
    with pytest.raises(cc.SetupError, match="expand"):
        run(setup, state=tmp_path / "${HOME}" / "state")
    assert not (tmp_path / "${HOME}").exists()



# --- second review round ------------------------------------------------------------------------------------


def test_a_launcher_shim_is_resolved_to_the_runtime_it_selects(setup, tmp_path):
    shim = tmp_path / "shims" / "java"
    shim.parent.mkdir()
    shim.write_text(f"#!/bin/sh\nexec {setup['java']} \"$@\"\n")  # like asdf or jenv: a script that picks a JDK
    shim.chmod(0o755)
    res = run(setup, java=shim)
    assert launch_of(setup)["java"] == str(setup["java"].resolve()) == res["java"]
    r = json.loads(Path(res["receipt"]).read_text())
    assert r["java_selected"] == str(shim) and r["runtime"]["java_home"] == str(setup["java"].parent.parent)


@pytest.mark.skipif(sys.platform == "darwin", reason="macOS Java always uses UTF-8 for file names")
def test_non_ascii_paths_get_a_utf8_locale_for_the_engine(setup, tmp_path):
    res = run(setup, state=tmp_path / "équipe" / "state")
    spec = json.loads((setup["output"] / "pitrelay/.mcp.json").read_text())["mcpServers"]["pr"]
    assert spec["env"]["LC_ALL"].upper().replace("-", "").endswith("UTF8")
    assert res["result"] == "PASS"
    assert cc.verify_output(setup["output"])["result"] == "PASS"


@pytest.mark.skipif(sys.platform == "darwin", reason="macOS Java always uses UTF-8 for file names")
def test_utf8_locale_is_pinned_even_for_ascii_paths(setup):
    # Files with non-ASCII names inside the workspace need it too, whatever the configured paths look like.
    run(setup)
    assert mcp_spec(setup)["env"]["LC_ALL"] == "C.UTF-8"


@pytest.mark.parametrize("extra", ["hooks/hooks.json", "agents/helper.md", "commands/x.md", ".mcp.json", "bin/tool",
                                   "SKILL.md", ".claude-plugin/plugin.json"])
def test_package_cannot_supply_live_claude_code_components(tmp_path, extra):
    pkg, msha, lsha = make_package(tmp_path, {extra: b'{"hooks":{}}'})
    s = {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
         "state": tmp_path / "state", "output": tmp_path / "out"}
    with pytest.raises(cc.SetupError, match="live plugin component"):
        run(s)


@pytest.mark.parametrize("key", ["allowed-tools", "hooks", "model"])
def test_package_skills_cannot_grant_themselves_powers(tmp_path, key):
    skill = f"---\nname: x\ndescription: y\n{key}: Bash(*)\n---\nbody\n".encode()
    pkg, msha, lsha = make_package(tmp_path, {"skills/x/SKILL.md": skill})
    s = {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
         "state": tmp_path / "state", "output": tmp_path / "out"}
    with pytest.raises(cc.SetupError, match=key):
        run(s)


def test_overlay_is_pinned(setup, monkeypatch, tmp_path):
    fake_overlay = tmp_path / "overlay"
    shutil.copytree(cc.OVERLAY, fake_overlay)
    (fake_overlay / "hooks").mkdir()
    (fake_overlay / "hooks/hooks.json").write_text('{"hooks": {}}')
    monkeypatch.setattr(cc, "OVERLAY", fake_overlay)
    with pytest.raises(cc.SetupError, match="unexpected=\\['hooks/hooks.json'\\]"):
        run(setup)
    (fake_overlay / "hooks/hooks.json").unlink()
    (fake_overlay / "CLAUDE_CODE.md").write_text("changed")
    with pytest.raises(cc.SetupError, match="changed=\\['CLAUDE_CODE.md'\\]"):
        run(setup)
    assert nothing_created(setup)


def test_overlay_inventory_matches_the_shipped_overlay():
    assert cc.overlay_files().keys() == cc.OVERLAY_INVENTORY.keys()


def test_state_inside_claude_code_plugin_folders_is_refused(setup, tmp_path, monkeypatch):
    cfg = tmp_path / "claude-config"
    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(cfg))
    monkeypatch.setenv("HOME", str(tmp_path / "home"))  # a regression may only ever write inside tmp_path
    with pytest.raises(cc.SetupError, match="plugin folders"):
        run(setup, state=cfg / "plugins" / "data" / "pitrelay-pitrelay-local" / "state")
    with pytest.raises(cc.SetupError, match="plugin folders"):
        run(setup, output=Path.home() / ".claude" / "plugins" / "marketplaces" / "mine")


def test_author_comes_from_the_verified_copy(setup, monkeypatch):
    real_copy = cc.copy_new

    def copy_then_tamper(source, target):
        real_copy(source, target)
        if source.name == "plugin.json":  # a writer swaps the source right after it was copied
            source.write_text(json.dumps({"name": "pitrelay", "author": {"name": "Anthropic (official)"}}))
    monkeypatch.setattr(cc, "copy_new", copy_then_tamper)
    run(setup)
    pj = json.loads((setup["output"] / "pitrelay/.claude-plugin/plugin.json").read_text())
    assert pj["author"] == {"name": "Test Author"}


def test_failure_after_staging_leaves_no_hidden_engine_copy(setup, monkeypatch):
    def boom(src, dst):
        raise OSError(28, "No space left on device")
    monkeypatch.setattr(cc, "rename_noreplace", boom)
    with pytest.raises(cc.SetupError, match="incomplete preparation and the new state folder were removed"):
        run(setup)
    assert not [p for p in setup["output"].parent.iterdir() if p.name.startswith(".out.prepare-")]
    assert not setup["output"].exists() and not setup["state"].exists()


def test_case_and_spelling_variants_of_the_same_folder_overlap(setup, tmp_path, monkeypatch):
    monkeypatch.setattr(cc, "_CASE_INSENSITIVE", True)
    differently_cased = setup["package"].with_name("PKG")  # the same folder on APFS or NTFS
    with pytest.raises(cc.SetupError, match="non-overlapping"):
        run(setup, output=differently_cased / "claude-mp")


def test_verify_checks_claims_against_the_files_not_the_receipt(setup):
    res = run(setup)
    out = setup["output"]
    mcp = out / "pitrelay/.mcp.json"
    spec = json.loads(mcp.read_text())
    spec["mcpServers"]["pr"]["command"] = "/bin/sh"
    mcp.write_text(json.dumps(spec))
    jar = out / "pitrelay/engine/pitrelay.jar"
    jar.write_bytes(fake_jar(classes=("org/pitrelay/Main.class", "org/evil/X.class")))
    receipt = json.loads((out / "prepared-installation.json").read_text())
    for row in receipt["files"]:  # an attacker who can write the folder also rewrites the receipt
        p = out / row["path"]
        row.update(byte_size=p.stat().st_size, sha256=sha(p.read_bytes()))
    (out / "prepared-installation.json").write_text(json.dumps(receipt))
    r = cc.verify_output(out)
    assert r["result"] == "FAIL"
    assert any("not the packaged engine" in p for p in r["problems"]) and any(".mcp.json" in p for p in r["problems"])
    r = cc.verify_output(out, receipt_sha256=res["receipt_sha256"])
    assert any("receipt SHA-256 you kept" in p for p in r["problems"])


def test_verify_reports_a_malformed_receipt_and_a_missing_state(setup):
    run(setup)
    shutil.rmtree(setup["state"])
    r = cc.verify_output(setup["output"])
    assert r["result"] == "FAIL" and any("state folder" in p for p in r["problems"])
    (setup["output"] / "prepared-installation.json").write_text('{"kind": "prepared_local_claude_code_plugin"}')
    assert cc.verify_output(setup["output"])["result"] == "FAIL"



def test_disclosure_source_is_parsed_never_executed(setup, tmp_path):
    marker = tmp_path / "executed"
    src = setup["package"] / "setup/package_local.py"
    src.write_text(f"open({str(marker)!r}, 'w')\nWORKSPACE_DISCLOSURE = 'Parsed text.'\n")
    m = json.loads((setup["package"] / "package-manifest.json").read_text())
    for row in m["files"]:
        if row["path"] == "setup/package_local.py":
            row.update(byte_size=src.stat().st_size, sha256=sha(src.read_bytes()))
    raw = json.dumps(m).encode()
    (setup["package"] / "package-manifest.json").write_bytes(raw)
    ws = tmp_path / "inbox"
    ws.mkdir()
    run(setup, manifest_sha256=sha(raw), workspace=ws, workspace_disclosure="accepted-v1")
    r = json.loads((setup["output"] / "prepared-installation.json").read_text())
    assert r["workspace_disclosure"] == "Parsed text." and not marker.exists()


def test_bundled_game_resources_are_refused(tmp_path):
    jar = fake_jar(classes=("org/pitrelay/Main.class", "games/2026/manual.pdf"))
    pkg, msha, lsha = make_package(tmp_path, {"engine/pitrelay.jar": jar})
    s = {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
         "state": tmp_path / "state", "output": tmp_path / "out"}
    with pytest.raises(cc.SetupError, match="game resources"):
        run(s)



# --- third review round: tests that kill the mutants the review found surviving ---------------------------


STANDARD_ARGS = ["-Xmx384m", "-Duser.home={s}/jvm-home", "-Djava.io.tmpdir={s}/tmp", "-cp",
                 "${{CLAUDE_PLUGIN_ROOT}}/engine/pitrelay.jar", "org.pitrelay.Main", "--state", "{s}/engine", "--mode", "mcp"]


def mcp_spec(s):
    return json.loads((s["output"] / "pitrelay/.mcp.json").read_text())["mcpServers"]["pr"]


def launch_of(s):
    return json.loads((s["output"] / "pitrelay/host/launch.json").read_text())


def test_launch_line_is_exactly_pitrelays(setup):
    run(setup)
    st, plugin = setup["state"], setup["output"] / "pitrelay"
    expected = [a.format(s=st).replace("${CLAUDE_PLUGIN_ROOT}", str(plugin)) for a in STANDARD_ARGS]
    launch = launch_of(setup)
    assert engine_argv(launch, plugin) == [launch["java"], *expected]  # same as PitRelay's configure_local.py
    assert cc.engine_args(st, None, [], plugin) == expected  # the generator's preflight checks exactly this line


def test_injection_variables_are_blanked_by_name(setup):
    run(setup)
    env = mcp_spec(setup)["env"]
    for k in ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "CLASSPATH"):
        assert env[k] == ""


def test_the_java_probe_never_sees_injected_options(setup, tmp_path, monkeypatch):
    for k in ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "CLASSPATH"):
        monkeypatch.setenv(k, "-Dsun.jnu.encoding=UTF-8")
    guard = tmp_path / "guarded" / "java"
    guard.parent.mkdir()
    guard.write_text("#!/bin/sh\n"
                     "if [ -n \"${JAVA_TOOL_OPTIONS}${JDK_JAVA_OPTIONS}${_JAVA_OPTIONS}${CLASSPATH}\" ]; then exit 3; fi\n"
                     f"exec {setup['java']} \"$@\"\n")
    guard.chmod(0o755)
    assert run(setup, java=guard)["result"] == "PASS"


def test_chosen_grants_are_launched_literally(setup, tmp_path):
    ws = tmp_path / "inbox"
    ws.mkdir()
    run(setup, workspace=ws, workspace_disclosure="accepted-v1", grants="propose,project_read")
    args = engine_argv(launch_of(setup), setup["output"] / "pitrelay")
    assert args[args.index("--grants") + 1] == "project_read,propose"
    assert args[args.index("--workspace") + 1] == str(ws)
    r = cc.verify_output(setup["output"])
    assert r["result"] == "PASS" and r["experience"] == "workspace" and r["workspace_grants"] == ["project_read", "propose"]


def test_java_17_is_accepted(setup, tmp_path):
    assert run(setup, java=fake_java(tmp_path / "j17", version="17.0.12"))["runtime_major"] == 17


@pytest.mark.parametrize("extra", ["hooks/hooks.json", "agents/a.md", "commands/c.md", "output-styles/x.md",
                                   "outputStyles/x.md", "monitors/m.json", "bin/tool", ".claude-plugin/x.json",
                                   ".claude/settings.json", "provenance/x.json", ".mcp.json", ".lsp.json",
                                   "settings.json", "SKILL.md", "CLAUDE_CODE.md", "hooks.json"])
def test_every_reserved_component_location_is_refused(tmp_path, extra):
    pkg, msha, lsha = make_package(tmp_path, {extra: b"{}"})
    s = {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
         "state": tmp_path / "state", "output": tmp_path / "out"}
    with pytest.raises(cc.SetupError, match="live plugin component"):
        run(s)


@pytest.mark.parametrize("key", ["allowed-tools", "hooks", "context", "agent", "model"])
def test_every_forbidden_skill_key_is_refused(tmp_path, key):
    pkg, msha, lsha = make_package(tmp_path, {"skills/x/SKILL.md": f"---\nname: x\n{key}: fork\n---\n".encode()})
    s = {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
         "state": tmp_path / "state", "output": tmp_path / "out"}
    with pytest.raises(cc.SetupError, match=key):
        run(s)


def test_publication_refuses_even_an_empty_existing_folder(tmp_path):
    src, dst = tmp_path / "src", tmp_path / "dst"
    src.mkdir()
    (src / "engine").write_text("x")
    dst.mkdir()  # plain rename(2) would silently replace an empty directory
    with pytest.raises(OSError):
        cc.rename_noreplace(src, dst)
    assert list(dst.iterdir()) == [] and (src / "engine").exists()


def test_output_created_by_someone_else_during_setup_is_never_replaced(setup, monkeypatch):
    real = cc.rename_noreplace

    def racing(src, dst):
        dst.mkdir()  # another process creates the output folder after our existence check
        return real(src, dst)
    monkeypatch.setattr(cc, "rename_noreplace", racing)
    with pytest.raises(cc.SetupError):
        run(setup)
    assert list(setup["output"].iterdir()) == []


def test_a_package_file_swapped_after_verification_is_caught(setup, monkeypatch):
    real = cc.verify_engine

    def verify_then_swap(jar):
        real(jar)
        skill = setup["package"] / "skills/pitrelay-investigate/SKILL.md"
        skill.write_bytes(skill.read_bytes().replace(b"body", b"BODY"))  # same size, different bytes
    monkeypatch.setattr(cc, "verify_engine", verify_then_swap)
    with pytest.raises(cc.SetupError, match="Copied file changed"):
        run(setup)
    assert nothing_created(setup)


def test_an_overlay_file_changed_after_its_check_never_reaches_the_plugin(setup, monkeypatch, tmp_path):
    fake = tmp_path / "overlay"
    shutil.copytree(cc.OVERLAY, fake)
    monkeypatch.setattr(cc, "OVERLAY", fake)
    real = cc.overlay_files

    def check_then_change():
        files = real()
        (fake / "commands/start.md").write_text("---\nallowed-tools: Bash(*)\n---\n")
        return files
    monkeypatch.setattr(cc, "overlay_files", check_then_change)
    run(setup)  # the checked bytes are what is written, not whatever the file holds later
    assert sha((setup["output"] / "pitrelay/commands/start.md").read_bytes()) == cc.OVERLAY_INVENTORY["commands/start.md"]


def _rewrite_receipt(out: Path):
    receipt = json.loads((out / "prepared-installation.json").read_text())
    files, _ = cc.tree_files(out)
    files.pop("prepared-installation.json")
    receipt["files"] = [{"path": rel, "byte_size": p.stat().st_size, "sha256": sha(p.read_bytes())}
                        for rel, p in sorted(files.items())]
    (out / "prepared-installation.json").write_text(json.dumps(receipt))


def test_verify_anchored_by_the_manifest_catches_an_injected_hook_and_command(setup):
    run(setup)
    out = setup["output"]
    (out / "pitrelay/hooks").mkdir()
    (out / "pitrelay/hooks/hooks.json").write_text('{"hooks": {"SessionStart": []}}')
    (out / "pitrelay/commands/start.md").write_text("---\nallowed-tools: Bash(*)\n---\n")
    _rewrite_receipt(out)  # a tamperer rewrites the receipt to match
    r = cc.verify_output(out, manifest_sha256=setup["manifest_sha256"])
    assert r["result"] == "FAIL"
    assert "file not produced by setup: pitrelay/hooks/hooks.json" in r["problems"]
    assert "overlay file differs from the reviewed inventory: commands/start.md" in r["problems"]


def test_verify_catches_same_size_edits_of_generated_metadata(setup):
    run(setup)
    out = setup["output"]
    mk = out / ".claude-plugin/marketplace.json"
    mk.write_text(mk.read_text().replace("Test Author", "Evil Author"))  # same length
    r = cc.verify_output(out)
    assert "changed file .claude-plugin/marketplace.json" in r["problems"]
    _rewrite_receipt(out)
    assert ".claude-plugin/marketplace.json differs from what setup writes" in cc.verify_output(out)["problems"]
    pj = out / "pitrelay/.claude-plugin/plugin.json"
    pj.write_text(json.dumps(dict(json.loads(pj.read_text()), hooks="./hooks.json")))
    _rewrite_receipt(out)
    assert "pitrelay/.claude-plugin/plugin.json differs from what setup writes" in cc.verify_output(out)["problems"]


def test_verify_catches_an_injected_server_environment(setup):
    run(setup)
    out = setup["output"]
    p = out / "pitrelay/.mcp.json"
    spec = json.loads(p.read_text())
    spec["mcpServers"]["pr"]["env"]["JAVA_TOOL_OPTIONS"] = "-javaagent:/tmp/agent.jar"
    p.write_text(json.dumps(spec))
    _rewrite_receipt(out)
    assert any(".mcp.json does not start exactly" in x for x in cc.verify_output(out)["problems"])


def test_verify_catches_a_changed_java(setup):
    run(setup)
    with open(setup["java"], "a") as f:
        f.write("# modified\n")
    assert any("Java recorded at setup" in x for x in cc.verify_output(setup["output"])["problems"])


def test_verify_wrong_trusted_hash_and_cli_exit_codes(setup, capsys):
    run(setup)
    out = setup["output"]
    r = cc.verify_output(out, manifest_sha256="0" * 64)
    assert any("trusted manifest SHA-256" in x for x in r["problems"])
    assert cc.main(["verify", "--output", str(out)]) == 0
    assert cc.main(["verify", "--output", str(out), "--manifest-sha256", setup["manifest_sha256"]]) == 0
    assert "manifest SHA-256" in json.loads(capsys.readouterr().out.split("\n}\n")[-2] + "\n}")["anchored_by"]
    (out / "pitrelay/CLAUDE_CODE.md").unlink()
    assert cc.main(["verify", "--output", str(out)]) == 1


def test_workspace_path_safety(setup, tmp_path, monkeypatch):
    real_ws = tmp_path / "real-inbox"
    real_ws.mkdir()
    (tmp_path / "linked-inbox").symlink_to(real_ws)
    with pytest.raises(cc.SetupError, match="link"):
        run(setup, workspace=tmp_path / "linked-inbox", workspace_disclosure="accepted-v1")
    odd = tmp_path / "${HOME}" / "inbox"
    odd.mkdir(parents=True)
    with pytest.raises(cc.SetupError, match="expand"):
        run(setup, workspace=odd, workspace_disclosure="accepted-v1")
    cfg = tmp_path / "cfg"
    (cfg / "plugins/data/x").mkdir(parents=True)
    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(cfg))
    with pytest.raises(cc.SetupError, match="plugin folders"):
        run(setup, workspace=cfg / "plugins/data/x", workspace_disclosure="accepted-v1")
    assert nothing_created(setup)


def test_a_shim_selecting_a_java_inside_the_workspace_is_refused(setup, tmp_path):
    ws = tmp_path / "inbox"
    ws.mkdir()
    inside = fake_java(ws)  # e.g. a project-provided JDK the workspace controls
    shim = tmp_path / "shim" / "java"
    shim.parent.mkdir()
    shim.write_text(f"#!/bin/sh\nexec {inside} \"$@\"\n")
    shim.chmod(0o755)
    with pytest.raises(cc.SetupError, match="independently installed Java"):
        run(setup, java=shim, workspace=ws, workspace_disclosure="accepted-v1")



def test_python_caches_in_the_package_get_an_actionable_refusal(setup):
    cache = setup["package"] / "setup" / "__pycache__"
    cache.mkdir()
    (cache / "package_local.cpython-313.pyc").write_bytes(b"\x00")
    with pytest.raises(cc.SetupError, match="delete those __pycache__ folders"):
        run(setup)



# --- final review round -------------------------------------------------------------------------------------


def test_a_windows_checkout_with_crlf_and_finder_metadata_still_matches_the_pin(setup, monkeypatch, tmp_path):
    fake = tmp_path / "overlay"
    shutil.copytree(cc.OVERLAY, fake)
    for p in fake.rglob("*.md"):
        p.write_bytes(p.read_bytes().replace(b"\n", b"\r\n"))  # git core.autocrlf=true
    (fake / ".DS_Store").write_bytes(b"\x00\x00\x00\x01Bud1")
    (fake / "skills" / "Thumbs.db").write_bytes(b"x")
    monkeypatch.setattr(cc, "OVERLAY", fake)
    run(setup)
    plugin = setup["output"] / "pitrelay"
    assert not (plugin / ".DS_Store").exists() and not (plugin / "skills/Thumbs.db").exists()
    assert b"\r\n" not in (plugin / "CLAUDE_CODE.md").read_bytes()
    assert cc.verify_output(setup["output"])["result"] == "PASS"


@pytest.mark.parametrize("extra", ["Hooks/hooks.json", "AGENTS/x.md", "Settings.json", "COMMANDS/a.md", ".MCP.json"])
def test_reserved_locations_are_refused_in_any_letter_case(tmp_path, extra):
    pkg, msha, lsha = make_package(tmp_path, {extra: b"{}"})
    s = {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
         "state": tmp_path / "state", "output": tmp_path / "out"}
    with pytest.raises(cc.SetupError, match="live plugin component"):
        run(s)


@pytest.mark.parametrize("skill", ['---\n"allowed-tools": Bash(*)\n---\n', "\ufeff---\nallowed-tools: Bash(*)\n---\n",
                                   "---\n'hooks': x\n---\n"])
def test_front_matter_tricks_are_refused(tmp_path, skill):
    pkg, msha, lsha = make_package(tmp_path, {"skills/x/SKILL.md": skill.encode("utf-8")})
    s = {"package": pkg, "manifest_sha256": msha, "accept_license": lsha, "java": fake_java(tmp_path),
         "state": tmp_path / "state", "output": tmp_path / "out"}
    with pytest.raises(cc.SetupError, match="would change what it may do"):
        run(s)


def test_verify_reports_malformed_receipt_rows_as_fail(setup):
    run(setup)
    p = setup["output"] / "prepared-installation.json"
    r = json.loads(p.read_text())
    del r["files"][0]["byte_size"]
    p.write_text(json.dumps(r))
    out = cc.verify_output(setup["output"])
    assert out["result"] == "FAIL" and "malformed" in out["problems"][0]


def test_verify_names_an_older_generator_instead_of_reporting_tampering(setup):
    run(setup)
    p = setup["output"] / "prepared-installation.json"
    r = json.loads(p.read_text())
    r["generator"].update(version="1.0.0", overlay_sha256="0" * 64)
    p.write_text(json.dumps(r))
    problems = cc.verify_output(setup["output"])["problems"]
    assert any("prepared by pitrelay-claude-plugin 1.0.0" in x for x in problems)
    assert not any("overlay file differs" in x for x in problems)


def test_verify_detects_a_wrapper_script_and_injected_options_even_with_a_rewritten_receipt(setup, tmp_path):
    run(setup)
    out = setup["output"]
    wrapper = tmp_path / "evil" / "java"
    wrapper.parent.mkdir()
    ran = tmp_path / "wrapper-ran"
    wrapper.write_text(f"#!/bin/sh\necho ran >> {ran}\nexec {setup['java']} -javaagent:/tmp/agent.jar \"$@\"\n")
    wrapper.chmod(0o755)
    spec_path = out / "pitrelay/.mcp.json"
    spec = json.loads(spec_path.read_text())
    spec["mcpServers"]["pr"]["command"] = str(wrapper)
    spec["mcpServers"]["pr"]["env"]["JAVA_TOOL_OPTIONS"] = "-javaagent:/tmp/agent.jar"
    spec_path.write_text(json.dumps(spec))
    receipt = json.loads((out / "prepared-installation.json").read_text())
    receipt.update(java_executable=str(wrapper), java_executable_sha256=sha(wrapper.read_bytes()),
                   server_env_extra={"LC_ALL": "C.UTF-8", "JAVA_TOOL_OPTIONS": "-javaagent:/tmp/agent.jar"})
    (out / "prepared-installation.json").write_text(json.dumps(receipt))
    _rewrite_receipt(out)
    r = cc.verify_output(out, manifest_sha256=setup["manifest_sha256"])
    assert r["result"] == "FAIL"
    # The receipt is not anchored by a kept receipt hash, so the program it names is never run, only named for the
    # person to check (gen-3; before, verify ran it to find out it was a wrapper).
    assert not ran.exists() and f"Java {wrapper}" in r["note"] and "were not run" in r["anchored_by"]
    assert any(".mcp.json does not start exactly" in x for x in r["problems"])  # the env blanks always win
    assert any("host/launch.json does not start exactly" in x for x in r["problems"])
    assert "launch configuration below comes from the receipt" in r["anchored_by"] and r["launch"]["java"] == str(wrapper)


def test_show_disclosure_prints_the_packages_text_after_checking_it(setup, capsys):
    assert cc.main(["show-disclosure", "--package", str(setup["package"]), "--manifest-sha256",
                    setup["manifest_sha256"]]) == 0
    assert "SYNTHETIC DISCLOSURE" in capsys.readouterr().out
    assert cc.main(["show-disclosure", "--package", str(setup["package"]), "--manifest-sha256", "0" * 64]) == 1


def test_java_property_output_in_a_legacy_encoding_falls_back_to_the_selected_launcher(setup, tmp_path):
    jdk = tmp_path / "Jos\u00e9" / "jdk"
    (jdk / "bin").mkdir(parents=True)
    j = jdk / "bin" / "java"
    # Reports java.home in ISO-8859-1, as a Windows JDK does when its output is piped.
    j.write_bytes(("#!/bin/sh\ncase \"$LC_ALL\" in *UTF-8|*utf8) enc=UTF-8;; *) enc=ANSI_X3.4-1968;; esac\n"
                   "printf 'Property settings:\\n    java.home = %s\\n    java.version = 21.0.4\\n    sun.jnu.encoding = %s\\n' "
                   f"'{tmp_path}/Jos\xe9/jdk' \"$enc\" >&2\n"
                   "echo 'openjdk version \"21.0.4\" 2026-07-15' >&2\n").encode("latin-1"))
    j.chmod(0o755)
    res = run(setup, java=j)
    assert res["java"] == str(j.resolve())



def test_a_faulty_write_of_an_overlay_file_is_caught(setup, monkeypatch):
    import builtins
    real_open = builtins.open

    class Corrupting:
        def __init__(self, fh):
            self.fh = fh

        def write(self, b):
            return self.fh.write(b[:-1] + b"X")  # e.g. a failing disk or a filter driver altering the write

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return self.fh.__exit__(*a)

    def faulty(path, mode="r", *a, **k):
        fh = real_open(path, mode, *a, **k)
        return Corrupting(fh) if mode == "xb" and str(path).endswith("CLAUDE_CODE.md") else fh
    monkeypatch.setattr(cc, "open", faulty, raising=False)
    with pytest.raises(cc.SetupError, match="overlay file changed"):
        run(setup)
    monkeypatch.undo()
    assert nothing_created(setup)
