"""The host relay (host/pitrelay_host): protocol, engine queue, notes, shutdown. Fake engine unless marked."""
from __future__ import annotations

import base64
import calendar
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path

import pytest

from host_harness import PREFIX, ROOT, Harness, fake_java, flaky_java, real_engine_jar, wait_until

from pitrelay_host import compat as host_compat  # noqa: E402
from pitrelay_host import relay  # noqa: E402
from pitrelay_host.engine import encode  # noqa: E402
from pitrelay_collector import formats, synthetic  # noqa: E402

needs_engine = pytest.mark.skipif(real_engine_jar() is None, reason="set PITRELAY_ENGINE_JAR to the v11 engine jar")


@pytest.fixture
def host(tmp_path):
    made = []

    def make(**kw):
        h = Harness(tmp_path / f"h{len(made)}", **kw)
        made.append(h)
        return h
    yield make
    for h in made:
        h.close()


def text_of(result: dict) -> dict:
    return json.loads(result["content"][0]["text"])


# --- protocol -------------------------------------------------------------------------------


def test_initialize_negotiates_2025_06_18_and_advertises_only_tools(host):
    h = host()
    r = h.init["result"]
    assert r["protocolVersion"] == "2025-06-18"  # Claude Code asks for 2025-11-25 and accepts 2025-06-18
    assert r["capabilities"] == {"tools": {"listChanged": True}}
    assert r["serverInfo"]["name"] == "pitrelay-claude-host"
    assert r["instructions"].startswith("FAKE ENGINE INSTRUCTIONS") and "Host note" in r["instructions"]
    assert len(r["instructions"]) <= 3000  # Claude Code cuts server instructions at 4096 characters
    old = host(protocol="2025-03-26")
    assert old.init["result"]["protocolVersion"] == "2025-03-26"


def test_server_discover_ping_and_unknown_methods_are_answered_at_once_even_while_the_engine_is_busy(host):
    h = host()
    slow = h.start("tools/call", {"name": "pitrelay_slow", "arguments": {"seconds": 3}})
    t = time.monotonic()
    assert h.request("server/discover", {}, timeout=5)["error"]["code"] == -32601
    assert h.request("ping", timeout=5)["result"] == {}
    assert h.request("resources/list", {}, timeout=5)["error"]["code"] == -32601
    assert time.monotonic() - t < 2.0 and not h.answered(slow)
    assert h.wait(slow)["result"]["content"]


def test_string_and_integer_ids_are_kept_exactly(host):
    h = host()
    for rid in ("server-discover-probe-1", 7, "7"):
        assert h.wait(h.start("ping", rid=rid))["id"] == rid


def test_tools_list_has_engine_tools_unchanged_plus_host_status(host):
    h = host()
    tools = h.request("tools/list", {})["result"]["tools"]
    names = [t["name"] for t in tools]
    assert names[:7] == ["pitrelay_echo", "pitrelay_slow", "pitrelay_crash", "pitrelay_nan", "pitrelay_unicode",
                         "pitrelay_ask_client", "pitrelay_notify"]
    assert "host_status" in names and not any(n.startswith("collector_") for n in names)
    echo = next(t for t in tools if t["name"] == "pitrelay_echo")
    assert echo == {"name": "pitrelay_echo", "description": "fake pitrelay_echo", "inputSchema": {"type": "object"},
                    "_meta": {"pitrelay/operation": "echo"}}
    status = next(t for t in tools if t["name"] == "host_status")
    assert status["annotations"]["readOnlyHint"] is True and "outputSchema" not in status


def test_engine_results_pass_through_byte_for_byte(host):
    h = host()
    r = h.call_result("pitrelay_echo", {"x": "é 😀  ", "n": 1.5e-05})
    # The fake engine writes json.dumps(envelope); the text must arrive exactly as written (no re-serialization).
    engine_text = json.dumps({"status": "ok", "operation": "pitrelay_echo", "request_id": text_of(r)["request_id"],
                              "result": {"echo": {"x": "é 😀  ", "n": 1.5e-05}}})
    assert r["content"] == [{"type": "text", "text": engine_text}] and "isError" not in r
    err = h.call_result("pitrelay_echo", {"status": "error"})
    assert err["isError"] is True and text_of(err)["status"] == "error"
    partial = h.call_result("pitrelay_echo", {"status": "partial"})
    assert "isError" not in partial


def test_lone_surrogates_and_nan_never_break_the_protocol_line(host):
    h = host()
    u = h.call_result("pitrelay_unicode")
    assert json.loads(u["content"][0]["text"])["text"] == "é \ud800‮ x"
    n = h.call_result("pitrelay_nan")
    assert n["_meta"]["value"] is None  # NaN is not JSON; it becomes null instead of an unreadable line


def test_requests_over_the_engines_1_mib_limit_are_refused_with_the_callers_id(host):
    h = host()
    rid = h.start("tools/call", {"name": "pitrelay_echo", "arguments": {"blob": "x" * (1024 * 1024)}})
    r = h.wait(rid)["result"]
    assert r["isError"] is True and text_of(r)["error"]["code"] == "REQUEST_TOO_LARGE"
    assert not any(m.get("_raw_len", 0) > 1024 * 1024 for m in h.engine_received())
    assert not any("blob" in json.dumps(m) for m in h.engine_received())


def test_parse_errors_and_batches_are_answered_without_the_engine(host):
    h = host()
    h.send_raw(b"{not json\n")
    h.send_raw(b'[{"jsonrpc":"2.0","id":5,"method":"ping"}]\n')
    assert wait_until(lambda: sum(1 for m in h.messages if m.get("id") is None and "error" in m) == 2, 5)
    codes = sorted(m["error"]["code"] for m in h.messages if m.get("id") is None and "error" in m)
    assert codes == [-32700, -32600]


def test_long_engine_tool_names_get_a_short_alias_that_routes_to_the_engine_name(host):
    long_name = "pitrelay_" + "x" * 45  # 25-character prefix + 54 = 79 > 64
    h = host(config={"extra_tools": [long_name]})
    tools = h.request("tools/list", {})["result"]["tools"]
    alias = next(t for t in tools if t["name"].startswith("pitrelay_xxx"))
    assert len(PREFIX + alias["name"]) == 64 and long_name in alias["description"]
    assert all(len(PREFIX + t["name"]) <= 64 for t in tools)
    h.call_result(alias["name"], {"a": 1})
    calls = [m for m in h.engine_received() if m.get("method") == "tools/call"]
    assert calls[-1]["params"]["name"] == long_name


def test_engine_requests_are_refused_and_engine_notifications_are_not_relayed(host):
    h = host()
    h.call_result("pitrelay_ask_client")
    h.call_result("pitrelay_notify")
    assert wait_until(lambda: any(m.get("id") == "engine-req-1" and "error" in m for m in h.engine_received()), 5)
    assert not h.notifications("notifications/message") and not h.notifications("roots/list")


def test_non_json_engine_output_is_ignored(host):
    h = host(config={"print_junk": True})
    assert h.call_result("pitrelay_echo", {})["content"]


# --- queue, cancellation, failures -------------------------------------------------------


def test_one_request_at_a_time_and_claude_codes_calls_go_before_background_work(host):
    h = host()
    h.server.engine.known.wait(30)
    blocker = h.start("tools/call", {"name": "pitrelay_slow", "arguments": {"seconds": 1.5}})
    time.sleep(0.3)
    import threading
    done = []
    for i in range(5):  # host background calls, queued behind the slow one
        threading.Thread(target=lambda i=i: done.append(h.server.engine.call_tool("pitrelay_echo", {"bg": i})),
                         daemon=True).start()
    time.sleep(0.2)
    client = h.start("tools/call", {"name": "pitrelay_echo", "arguments": {"client": True}})
    h.wait(blocker)
    h.wait(client)
    assert wait_until(lambda: len(done) == 5, 10)
    calls = [m["params"]["arguments"] for m in h.engine_received() if m.get("method") == "tools/call"]
    order = [("client" if a.get("client") else "bg") for a in calls if "client" in a or "bg" in a]
    assert order[0] == "client", order  # it overtook every queued background call


def test_cancelled_queued_call_is_never_sent_and_running_call_answer_is_dropped(host):
    h = host()
    running = h.start("tools/call", {"name": "pitrelay_slow", "arguments": {"seconds": 1.0}})
    time.sleep(0.3)
    queued = h.start("tools/call", {"name": "pitrelay_echo", "arguments": {"queued": True}})
    h.notify("notifications/cancelled", {"requestId": queued, "reason": "Esc"})
    h.notify("notifications/cancelled", {"requestId": running, "reason": "Esc"})
    after = h.request("tools/call", {"name": "pitrelay_echo", "arguments": {"after": True}})
    assert after["result"]["content"]
    time.sleep(0.3)
    assert not h.answered(running) and not h.answered(queued)  # no answer after a cancellation
    received = h.engine_received()
    assert not any((m.get("params") or {}).get("arguments", {}).get("queued") for m in received)
    assert not any(m.get("method") == "notifications/cancelled" for m in received)  # the engine ignores them anyway


def test_engine_crash_answers_with_a_clear_error_and_the_next_call_restarts_it(host, monkeypatch):
    monkeypatch.setattr(relay, "RESTART_BACKOFF_S", 0.0)
    h = host()
    r = h.call_result("pitrelay_crash")
    assert r["isError"] is True
    err = text_of(r)["error"]
    assert err["code"] == "ENGINE_UNAVAILABLE" and "exit code 3" in err["message"] and "restarted" in err["message"]
    # The engine keeps open transfers across its restart: the model is told to continue them, not that they are lost.
    assert "keeps open upload transfers" in err["message"] and "same transfer_id" in err["message"]
    assert "lost" not in err["message"]
    again = h.call_result("pitrelay_echo", {"ok": 1})
    assert text_of(again)["status"] == "ok" and h.server.engine.restarts == 1
    status, _ = h.call("host_status")
    assert status["engine"]["status"] == "ready"


def test_an_engine_that_cannot_start_still_connects_and_explains(host, tmp_path):
    h = host(java=str(tmp_path / "no-such-java"))
    assert "result" in h.init
    tools = [t["name"] for t in h.request("tools/list", {})["result"]["tools"]]
    assert tools == ["host_status"]
    status, err = h.call("host_status")
    assert status["engine"]["status"] == "failed" and "Could not start the PitRelay engine" in status["engine"]["problem"]
    r = h.call_result("pitrelay_echo")
    assert r["isError"] is True and text_of(r)["error"]["code"] == "ENGINE_UNAVAILABLE"


def test_cached_tool_list_answers_at_once_and_list_changed_follows_a_different_live_list(host, tmp_path):
    first = host(config={"extra_tools": ["pitrelay_old"]})
    first.request("tools/list", {})
    first.close()
    cache = json.loads((first.state / "host" / "engine-cache.json").read_text())
    assert "pitrelay_old" in [t["name"] for t in cache["tools"]]
    (first.state / "fake-engine.json").write_text(json.dumps({"start_delay_s": 2.0, "extra_tools": ["pitrelay_new"]}))
    second = Harness(first.tmp, initialize=False, state=first.state, config={"start_delay_s": 2.0,
                                                                            "extra_tools": ["pitrelay_new"]})
    try:
        t = time.monotonic()
        second.request("initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "x"}})
        second.notify("notifications/initialized")
        names = [x["name"] for x in second.request("tools/list", {})["result"]["tools"]]
        assert time.monotonic() - t < 1.5 and "pitrelay_old" in names  # from the cache, before Java answered
        assert wait_until(lambda: second.notifications("notifications/tools/list_changed"), 15)
        names = [x["name"] for x in second.request("tools/list", {})["result"]["tools"]]
        assert "pitrelay_new" in names and "pitrelay_old" not in names
    finally:
        second.close()


def test_two_sessions_each_run_their_own_engine_on_one_state(host, tmp_path):
    a = host()
    b = Harness(tmp_path / "b", state=a.state)
    try:
        assert text_of(a.call_result("pitrelay_echo", {"s": "a"}))["status"] == "ok"
        assert text_of(b.call_result("pitrelay_echo", {"s": "b"}))["status"] == "ok"
        assert a.server.engine._proc.proc.pid != b.server.engine._proc.proc.pid
    finally:
        b.close()


def test_engine_environment_drops_java_injection_and_pins_the_locale(tmp_path, monkeypatch):
    from pitrelay_host.engine import engine_env
    monkeypatch.setenv("JAVA_TOOL_OPTIONS", "-javaagent:/tmp/x.jar")
    monkeypatch.setenv("_JAVA_OPTIONS", "-Xbad")
    monkeypatch.setenv("LC_ALL", "C")
    env = engine_env({"lc_all": "C.UTF-8"})
    assert "JAVA_TOOL_OPTIONS" not in env and "_JAVA_OPTIONS" not in env and env["LC_ALL"] == "C.UTF-8"


# --- engine identity and start-up retries --------------------------------------------------------------


def test_a_jar_that_differs_from_setup_is_refused_for_good_and_never_started(host, monkeypatch):
    monkeypatch.setattr(relay, "RESTART_BACKOFF_S", 0.0)
    h = host(engine_sha256="f" * 64)
    assert [t["name"] for t in h.request("tools/list", {})["result"]["tools"]] == ["host_status"]
    for _ in range(2):  # not only until the restart backoff has passed
        r = h.call_result("pitrelay_echo")
        assert r["isError"] is True and text_of(r)["error"]["code"] == "ENGINE_UNAVAILABLE"
        assert "not the engine recorded at setup" in text_of(r)["error"]["message"]
    engine = h.server.engine  # the path collector_supply_to_engine takes
    with pytest.raises(relay.EngineUnavailable, match="not the engine recorded"):
        engine.ensure()
    t = time.monotonic()
    with pytest.raises(relay.EngineUnavailable, match="not the engine recorded"):
        engine.call_tool("pitrelay_echo", {}, timeout=30)
    assert time.monotonic() - t < 1.0
    status, _ = h.call("host_status")
    assert status["engine"]["status"] == "failed" and "not the engine recorded" in status["engine"]["problem"]
    time.sleep(0.3)
    assert not h.engine_received() and not h.notifications("notifications/tools/list_changed")


def test_the_jar_is_checked_again_before_every_restart(host, monkeypatch):
    monkeypatch.setattr(relay, "RESTART_BACKOFF_S", 0.0)
    h = host(engine_sha256=hashlib.sha256(b"not a real engine").hexdigest())  # the harness's stand-in jar
    assert text_of(h.call_result("pitrelay_echo", {}))["status"] == "ok"
    assert "pitrelay_echo" in [t["name"] for t in h.request("tools/list", {})["result"]["tools"]]
    (h.plugin / "engine" / "pitrelay.jar").write_bytes(b"a changed engine")
    h.call_result("pitrelay_crash")
    for _ in range(2):
        r = h.call_result("pitrelay_echo", {})
        assert "not the engine recorded at setup" in text_of(r)["error"]["message"]
    assert sum(1 for m in h.engine_received() if m.get("method") == "initialize") == 1  # never started again
    assert wait_until(lambda: h.notifications("notifications/tools/list_changed"), 5)
    assert [t["name"] for t in h.request("tools/list", {})["result"]["tools"]] == ["host_status"]
    status, _ = h.call("host_status")
    assert "not the engine recorded at setup" in status["engine"]["problem"]
    assert status["engine"]["jar_sha256"] == hashlib.sha256(b"a changed engine").hexdigest()


def test_an_unreadable_jar_is_refused_when_setup_recorded_its_hash(host, tmp_path, monkeypatch):
    monkeypatch.setattr(relay, "RESTART_BACKOFF_S", 0.0)
    (tmp_path / "h0" / "plugin" / "engine" / "pitrelay.jar").mkdir(parents=True)  # a folder cannot be read as the jar
    h = host(engine_sha256="0" * 64)
    r = h.call_result("pitrelay_echo")
    assert text_of(r)["error"]["code"] == "ENGINE_UNAVAILABLE" and "cannot be read" in text_of(r)["error"]["message"]
    with pytest.raises(relay.EngineUnavailable, match="cannot be read"):
        h.server.engine.ensure()
    assert h.call("host_status")[0]["engine"]["problem"].startswith("The engine jar cannot be read")
    assert not h.engine_received()


def test_a_failed_first_start_is_retried_without_any_engine_call(host, tmp_path, monkeypatch):
    monkeypatch.setattr(relay, "RESTART_BACKOFF_S", 1.0)
    h = host(java=str(flaky_java(tmp_path, 1)))  # no engine-cache.json: no engine tool is listed after the failure
    assert [t["name"] for t in h.request("tools/list", {})["result"]["tools"]] == ["host_status"]
    assert wait_until(lambda: h.notifications("notifications/tools/list_changed"), 15)
    assert "pitrelay_echo" in [t["name"] for t in h.request("tools/list", {})["result"]["tools"]]
    assert h.server.engine.status == "ready" and (tmp_path / "java-starts.txt").read_text().count("x") == 2


def test_host_status_starts_an_engine_whose_tools_are_unknown(host, tmp_path, monkeypatch):
    monkeypatch.setattr(relay, "RESTART_BACKOFF_S", 0.2)
    monkeypatch.setattr(relay, "AUTO_START_RETRIES", 0)  # only host_status may start it here
    h = host(java=str(flaky_java(tmp_path, 1)))
    assert [t["name"] for t in h.request("tools/list", {})["result"]["tools"]] == ["host_status"]
    time.sleep(0.5)
    assert h.server.engine.status == "failed"
    status, _ = h.call("host_status")
    assert status["engine"]["status"] == "ready" and status["engine"]["tools"] > 0 and status["engine"]["problem"] is None
    assert wait_until(lambda: h.notifications("notifications/tools/list_changed"), 5)


def test_starts_on_the_hosts_own_are_bounded(host, tmp_path, monkeypatch):
    monkeypatch.setattr(relay, "RESTART_BACKOFF_S", 0.05)
    monkeypatch.setattr(relay, "AUTO_START_RETRIES", 3)
    h = host(java=str(flaky_java(tmp_path, 100)))
    starts = tmp_path / "java-starts.txt"
    assert wait_until(lambda: starts.exists() and starts.read_text().count("x") == 4, 10)  # the first start, 3 retries
    time.sleep(1.0)
    assert starts.read_text().count("x") == 4 and h.server.engine.status == "failed"


def test_backoffs_are_pauses_after_a_start_that_hangs_and_host_status_reports_the_running_start(host, monkeypatch):
    """A start whose engine never answers fails after START_TIMEOUT_S; the next start waits its backoff after that. While
    a start runs, host_status reports "starting" and waits for it instead of queueing another."""
    monkeypatch.setattr(relay, "START_TIMEOUT_S", 1.5)
    monkeypatch.setattr(relay, "RESTART_BACKOFF_S", 0.75)
    monkeypatch.setattr(relay, "AUTO_START_RETRIES", 2)
    monkeypatch.setattr(relay, "TOOLS_WAIT_S", 0.3)
    h = host(config={"never_answer": True})
    engine, log = h.server.engine, h.state / "fake-engine-starts.txt"

    def stamps(event):
        return [float(t) for e, t in (line.split() for line in log.read_text().splitlines()) if e == event] \
            if log.exists() else []
    assert wait_until(lambda: engine.status == "failed", 10) and len(stamps("start")) == 1
    t = time.monotonic()
    r = h.call_result("pitrelay_echo")  # just after the failed start, within its backoff: not started again
    assert text_of(r)["error"]["message"] == "The engine did not answer in time" and time.monotonic() - t < 1.0
    assert wait_until(lambda: len(stamps("start")) == 2, 10)  # the first retry on the host's own runs
    status, _ = h.call("host_status")
    assert status["engine"]["status"] == "starting"
    assert status["engine"]["problem"] == "Starting the engine again; the last problem: The engine did not answer in time"
    with pytest.raises(relay.EngineUnavailable, match="; it is still being started$"):
        engine.call_tool("pitrelay_echo", {}, timeout=0.2)
    monkeypatch.setattr(relay, "TOOLS_WAIT_S", 5.0)
    t = time.monotonic()
    status, _ = h.call("host_status")  # waits for the running start
    assert status["engine"]["status"] == "failed" and time.monotonic() - t < 2.0
    assert wait_until(lambda: len(stamps("end")) == 3 and engine.status == "failed", 10)
    starts, ends = stamps("start"), stamps("end")
    assert len(starts) == 3 and engine._auto_starts == 2  # host_status queued no start of its own
    pauses = [b - a for a, b in zip(ends, starts[1:])]
    assert all(pause >= 0.75 * 2 ** i for i, pause in enumerate(pauses)), pauses


# --- malformed client messages --------------------------------------------------------------------------


def test_malformed_client_messages_never_end_the_server(host):
    h = host()
    for name in ({"x": 1}, ["pitrelay_echo"], None, 5):
        assert h.request("tools/call", {"name": name, "arguments": {}}, timeout=5)["error"]["code"] == -32602
    deep = b"[" * 100000 + b"]" * 100000  # deeper than Python's JSON parser goes
    h.send_raw(b'{"jsonrpc":"2.0","id":99,"method":"tools/call","params":{"name":"pitrelay_echo","arguments":' + deep
               + b"}}\n")
    assert wait_until(lambda: any(m.get("id") is None and (m.get("error") or {}).get("code") == -32700
                                  for m in h.messages), 10)
    assert h.request("ping", timeout=5)["result"] == {}
    assert text_of(h.call_result("pitrelay_echo", {}))["status"] == "ok"


def test_a_message_the_host_fails_on_is_logged_and_answered(host):
    h = host()
    h.request("ping")  # messages are handled in order: the harness's notifications/initialized is done

    def boom(*args):
        raise RuntimeError("boom")
    h.server._tools_call = boom
    h.server._client_notification = boom
    assert h.request("tools/call", {"name": "pitrelay_echo"}, timeout=5)["error"]["code"] == -32603
    h.notify("notifications/cancelled", {"requestId": 1})  # a notification is never answered
    assert h.request("ping", timeout=5)["result"] == {}
    assert not any(m.get("id") is None for m in h.messages)
    assert (h.state / "host" / "host-errors.log").read_text().count("RuntimeError: boom") == 2


# --- the transfer journal ---------------------------------------------------------------------------


def _engine_reply(status: str, code: str | None = None, **result) -> dict:
    env = {"status": status, "result": {**({"code": code} if code else {}), **result}}
    return {"jsonrpc": "2.0", "id": 1, "result": {"content": [{"type": "text", "text": json.dumps(env)}]}}


def _dead_pid() -> int:
    p = subprocess.Popen([sys.executable, "-c", "pass"])
    p.wait()
    return p.pid


class _StubEngine:
    """Answers upload_abort for TransferJournal.abort_orphans: `answers` maps a transfer id to an envelope or an error."""

    def __init__(self, answers: dict | None = None, launch: dict | None = None):
        self.answers, self.launch, self.calls = answers or {}, launch, []

    def call_tool(self, name, arguments, timeout=None):
        self.calls.append(arguments["transfer_id"])
        answer = self.answers.get(arguments["transfer_id"], {"status": "ok", "result": {"state": "aborted"}})
        if isinstance(answer, Exception):
            raise answer
        return answer


def test_the_journal_keeps_a_transfer_until_the_engine_has_closed_it(tmp_path):
    j = relay.TransferJournal(tmp_path / "state" / "host")
    record = tmp_path / "state" / "engine" / "ws-1" / "transfers" / "t1.json"
    record.parent.mkdir(parents=True)
    record.write_text("{}")  # the engine still holds t1; it has no record of t2
    fin, abort = "pitrelay_artifact_upload_finish", "pitrelay_artifact_upload_abort"

    def journaled():
        return json.loads(j.path.read_text())["transfers"] if j.path.exists() else []
    for tid in ("t1", "t2", "t3", "t4", "t5"):
        j.observe({"name": "pitrelay_artifact_upload_begin", "arguments": {}}, _engine_reply("ok", id=tid))
    keep = [(fin, _engine_reply("blocked", "TRANSFER_INCOMPLETE")), (fin, _engine_reply("error", "TRANSFER_INTEGRITY")),
            (abort, _engine_reply("blocked", "TRANSFER_BUSY")), (fin, _engine_reply("error", "IO_FAILURE")),
            (fin, {"jsonrpc": "2.0", "id": 1, "error": {"code": -32602, "message": "bad"}}),
            (abort, {"jsonrpc": "2.0", "error": {"code": -32603, "message": "stopped"}, "_unavailable": True})]
    for name, reply in keep:
        j.observe({"name": name, "arguments": {"transfer_id": "t1"}}, reply)
    assert journaled() == ["t1", "t2", "t3", "t4", "t5"]
    closed = [("t1", fin, _engine_reply("ok", id="artifact-1")), ("t2", fin, _engine_reply("error", "IO_FAILURE")),
              ("t3", abort, _engine_reply("ok", state="aborted")), ("t4", abort, _engine_reply("blocked", "TRANSFER_FINISHED")),
              ("t5", abort, _engine_reply("error", "TRANSFER_ID"))]
    for tid, name, reply in closed:
        j.observe({"name": name, "arguments": {"transfer_id": tid}}, reply)
        assert tid not in journaled()
    assert not j.path.exists()


def test_orphan_cleanup_keeps_the_transfers_whose_abort_was_refused(tmp_path):
    folder = tmp_path / "state" / "host"
    folder.mkdir(parents=True)
    dead = _dead_pid()
    f = folder / f"open-transfers-{dead}-0123456789ab.json"
    f.write_text(json.dumps({"pid": dead, "started": 7, "transfers": ["t-busy", "t-ok", "t-later"]}))
    busy = {"status": "blocked", "result": {"code": "TRANSFER_BUSY"}}
    j = relay.TransferJournal(folder)
    assert j.abort_orphans(_StubEngine({"t-busy": busy, "t-later": relay.EngineUnavailable("stopped")})) == 1
    assert json.loads(f.read_text()) == {"pid": dead, "started": 7, "transfers": ["t-busy", "t-later"]}
    assert j.abort_orphans(_StubEngine()) == 2 and not f.exists()


def test_damaged_journals_never_stop_the_cleanup_of_others(tmp_path):
    folder = tmp_path / "state" / "host"
    folder.mkdir(parents=True)
    dead = _dead_pid()
    bad = {"open-transfers-1.json": "null", "open-transfers-2.json": "[]", "open-transfers-3.json": "{not json",
           "open-transfers-4.json": json.dumps({"pid": 10 ** 30, "transfers": ["t-huge"]}),
           "open-transfers-5.json": json.dumps({"pid": "abc", "transfers": ["t-abc"]}),
           "open-transfers-6.json": json.dumps({"pid": dead, "transfers": 5}), "open-transfers-7.json": "[" * 100000}
    for name, text in bad.items():
        (folder / name).write_text(text)
    (folder / f"open-transfers-{dead}-a.json").write_text(json.dumps({"pid": dead, "transfers": ["t-boom"]}))
    (folder / f"open-transfers-{dead}-b.json").write_text(json.dumps({"pid": dead, "transfers": ["t-orphan"]}))
    old = time.time() - relay.LOG_KEEP_S - 60
    for name in ("open-transfers-1.json", "open-transfers-3.json", "open-transfers-4.json"):
        os.utime(folder / name, (old, old))
    engine = _StubEngine({"t-boom": RuntimeError("boom")}, launch={"state": str(tmp_path / "state")})
    assert relay.TransferJournal(folder).abort_orphans(engine) == 1 and engine.calls == ["t-boom", "t-orphan"]
    assert sorted(f.name for f in folder.glob("open-transfers-*.json")) == sorted([  # unparseable ones go once old
        "open-transfers-2.json", "open-transfers-5.json", "open-transfers-6.json", "open-transfers-7.json",
        f"open-transfers-{dead}-a.json"])
    assert "RuntimeError: boom" in (folder / "host-errors.log").read_text()


def _proc_start_epoch(pid: int) -> int:
    """A process's start in seconds since the epoch, from /proc: the boot time plus its start in clock ticks."""
    with open("/proc/stat", encoding="ascii") as f:
        btime = next(int(line.split()[1]) for line in f if line.startswith("btime "))
    return btime + relay.process_start_time(pid) // os.sysconf("SC_CLK_TCK")


@pytest.mark.skipif(not os.access("/bin/ps", os.X_OK) or not os.path.exists("/proc/stat")
                    or relay.process_start_time(os.getpid()) is None, reason="/bin/ps, and /proc (Linux) to compare with")
def test_start_times_from_ps_are_the_same_whatever_tz_each_host_has():
    """macOS reads start times with `ps -o lstart=` (procps ps prints the same text). Hosts with different TZ settings,
    on a machine whose own zone is not UTC, must compute one value for one process, its real start time; otherwise a
    host takes a live session for an ended one and aborts its uploads."""
    code = ("import os, subprocess, sys\n"
            "sys.path[:0] = [%r, %r]\n"
            "run = subprocess.run\n"
            "def zoned(argv, **kw):  # ps uses the machine's zone when its environment names none: here UTC-7\n"
            "    env = dict(kw.pop('env', None) or os.environ)\n"
            "    env.setdefault('TZ', 'XYZ7')\n"
            "    return run(argv, env=env, **kw)\n"
            "subprocess.run = zoned\n"
            "from pitrelay_host import relay\n"
            "print(relay._ps_start_time(int(sys.argv[1])))\n") % (str(ROOT / "host"), str(ROOT / "collector" / "src"))
    other = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
    try:
        assert wait_until(lambda: relay.process_start_time(other.pid) is not None, 5)
        seen = {}
        for tz in ("UTC0", "ABC-9"):  # POSIX TZ strings (UTC and UTC+9): no zone database needed
            done = subprocess.run([sys.executable, "-I", "-B", "-c", code, str(other.pid)], capture_output=True,
                                  text=True, timeout=30, env={**os.environ, "TZ": tz})
            assert done.returncode == 0, done.stderr[-2000:]
            seen[tz] = int(done.stdout)
        assert seen["UTC0"] == seen["ABC-9"] and abs(seen["UTC0"] - _proc_start_epoch(other.pid)) <= 1, seen
    finally:
        other.kill()
        other.wait()
    assert relay._lstart_seconds("Sat Oct  3 07:04:05 2026\n") == calendar.timegm((2026, 10, 3, 7, 4, 5, 0, 0, 0))
    assert relay._ps_start_time(_dead_pid()) is None


@pytest.mark.skipif(not os.path.exists("/proc/stat") or relay.process_start_time(os.getpid()) is None,
                    reason="process start times from /proc (Linux)")
def test_journals_belong_to_one_process_instance_and_a_reused_pid_is_recognised(tmp_path):
    folder = tmp_path / "state" / "host"
    folder.mkdir(parents=True)
    me, started = os.getpid(), relay.process_start_time(os.getpid())
    j = relay.TransferJournal(folder)
    j.observe({"name": "pitrelay_artifact_upload_begin"}, _engine_reply("ok", id="t-mine"))
    assert re.fullmatch(rf"open-transfers-{me}-[0-9a-f]{{12}}\.json", j.path.name)
    assert json.loads(j.path.read_text()) == {"pid": me, "started": started, "transfers": ["t-mine"]}
    other = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
    try:
        assert wait_until(lambda: relay.process_start_time(other.pid) is not None, 5)
        files = {  # name: (pid, started, transfer, orphaned)
            f"open-transfers-{me}.json": (me, None, "t-old-format", True),  # an earlier host version's file with this pid
            f"open-transfers-{me}-0000aaaa0000.json": (me, started - 1, "t-before-reboot", True),
            f"open-transfers-{other.pid}-0000bbbb0000.json": (other.pid, started - 1, "t-pid-reused", True),
            f"open-transfers-{other.pid}-0000cccc0000.json": (other.pid, relay.process_start_time(other.pid), "t-live", False),
            f"open-transfers-{me}-0000dddd0000.json": (me, started, "t-live-here", False),
        }
        for name, (pid, start, tid, _) in files.items():
            (folder / name).write_text(json.dumps({"pid": pid, "started": start, "transfers": [tid]}))
        engine = _StubEngine()
        assert j.abort_orphans(engine) == 3
        assert sorted(engine.calls) == sorted(tid for _, _, tid, orphan in files.values() if orphan)
        for name, (pid, start, tid, orphan) in files.items():
            assert (folder / name).exists() is not orphan
    finally:
        other.kill()
        other.wait()
    j.observe({"name": "pitrelay_artifact_upload_begin"}, _engine_reply("ok", id="t-mine-2"))
    assert json.loads(j.path.read_text())["transfers"] == ["t-mine", "t-mine-2"]
    assert json.loads((folder / f"open-transfers-{me}-0000dddd0000.json").read_text())["transfers"] == ["t-live-here"]


def test_a_journal_left_under_this_pid_is_aborted_at_start_and_never_overwritten(host, tmp_path):
    left = tmp_path / "h0" / "state" / "host" / f"open-transfers-{os.getpid()}.json"
    left.parent.mkdir(parents=True)
    left.write_text(json.dumps({"pid": os.getpid(), "transfers": ["transfer-from-before-reboot"]}))
    h = host()
    assert h.server.engine.orphans_done.wait(30)
    aborts = [m["params"]["arguments"]["transfer_id"] for m in h.engine_received()
              if (m.get("params") or {}).get("name") == "pitrelay_artifact_upload_abort"]
    assert aborts == ["transfer-from-before-reboot"] and not left.exists()
    tid = h.call("pitrelay_artifact_upload_begin", {})[0]["result"]["id"]
    assert h.server.engine.journal.path != left
    assert json.loads(h.server.engine.journal.path.read_text())["transfers"] == [tid]


def test_a_journal_without_a_start_time_under_this_pid_is_an_earlier_processes(host, tmp_path, monkeypatch):
    """Where no start time can be read (written so on Windows or macOS when that failed), a file under this process's
    own pid that is not its own file was left by an earlier process with the same pid."""
    left = tmp_path / "h0" / "state" / "host" / f"open-transfers-{os.getpid()}-0123456789ab.json"
    left.parent.mkdir(parents=True)
    left.write_text(json.dumps({"pid": os.getpid(), "started": None, "transfers": ["transfer-earlier-process"]}))
    h = host()
    assert h.server.engine.orphans_done.wait(30)
    aborts = [m["params"]["arguments"]["transfer_id"] for m in h.engine_received()
              if (m.get("params") or {}).get("name") == "pitrelay_artifact_upload_abort"]
    assert aborts == ["transfer-earlier-process"] and not left.exists()


def test_a_relayed_finish_that_the_engine_refused_keeps_the_transfer_journaled(host):
    h = host(config={"answers": {"pitrelay_artifact_upload_finish": {
        "status": "blocked", "result": {"code": "TRANSFER_INCOMPLETE", "message": "Not all declared bytes have arrived"}}}})
    tid = h.call("pitrelay_artifact_upload_begin", {})[0]["result"]["id"]
    assert h.call("pitrelay_artifact_upload_finish", {"transfer_id": tid})[0]["status"] == "blocked"
    assert json.loads(h.server.engine.journal.path.read_text())["transfers"] == [tid]
    assert h.call("pitrelay_artifact_upload_abort", {"transfer_id": tid})[0]["status"] == "ok"
    assert not h.server.engine.journal.path.exists()


# --- dialogs and progress ---------------------------------------------------------------------


def test_progress_notifications_carry_the_callers_token_and_increase(host):
    h = host()
    ctx = relay.CallContext(h.server, 1, {"_meta": {"progressToken": "tok-1"}})
    ctx.progress("a", force=True)
    ctx.progress("b")  # throttled
    ctx.progress("c", force=True)
    assert wait_until(lambda: len(h.notifications("notifications/progress")) == 2, 5)
    sent = [m["params"] for m in h.notifications("notifications/progress")]
    assert [p["progressToken"] for p in sent] == ["tok-1", "tok-1"] and sent[0]["progress"] < sent[1]["progress"]
    quiet = relay.CallContext(h.server, 2, {})
    quiet.progress("x", force=True)  # no token, no notification
    time.sleep(0.2)
    assert len(h.notifications("notifications/progress")) == 2


def test_dialog_outcomes_are_reported_exactly(host):
    h = host()
    ctx = relay.CallContext(h.server, 1, {})
    schema = {"ok": {"type": "boolean", "title": "OK", "default": False}}
    for answer, expected in (({"action": "accept", "content": {"ok": True}}, "accept"), ({"action": "decline"}, "decline"),
                             ({"action": "cancel"}, "cancel"), ({"error": {"code": -32602, "message": "bad schema"}}, "error")):
        h.answer = lambda params, a=answer: a
        assert h.server.elicit("Allow?", schema, ["ok"], 10, ctx)["action"] == expected
    sent = h.elicitations[0]["params"]
    assert sent == {"message": "Allow?", "requestedSchema": {"type": "object", "properties": schema, "required": ["ok"]}}


def test_a_cancelled_tool_withdraws_its_open_dialog(host):
    h = host()
    h.answer = lambda params: None  # the person never answers
    ctx = relay.CallContext(h.server, 1, {})
    import threading
    out = {}
    t = threading.Thread(target=lambda: out.update(h.server.elicit("Allow?", {"ok": {"type": "boolean"}}, ["ok"], 30, ctx)))
    t.start()
    assert wait_until(lambda: h.elicitations, 5)
    ctx.cancelled.set()
    t.join(5)
    assert out["action"] == "cancel"
    rid = h.elicitations[0]["id"]
    # Sent before elicit returns; the harness reads it from the pipe a moment later.
    assert wait_until(lambda: any(m["params"]["requestId"] == rid for m in h.notifications("notifications/cancelled")), 5)


def test_no_dialogs_without_the_client_capability(host):
    h = host(capabilities={})
    with pytest.raises(relay.NoElicitation):
        h.server.elicit("Allow?", {"ok": {"type": "boolean"}}, ["ok"], 5, relay.CallContext(h.server, 1, {}))


# --- the protocol channel and shutdown (a real host process) -------------------------------------


def test_stray_writes_to_stdout_never_reach_the_protocol(tmp_path):
    code = ("import os, sys; sys.path.insert(0, %r)\n"
            "from pitrelay_host.main import protocol_streams\n"
            "i, o = protocol_streams()\n"
            "os.write(1, b'stray child-style write\\n'); print('stray print')\n"
            "os.system('echo from a child process')\n"
            "o.write(b'{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}\\n'); o.flush()\n") % str(ROOT / "host")
    done = subprocess.run([sys.executable, "-I", "-B", "-c", code], capture_output=True, timeout=30)
    assert done.stdout == b'{"jsonrpc":"2.0","id":1,"result":{}}\n'
    assert b"stray print" in done.stderr and b"from a child process" in done.stderr


def _host_process(tmp_path, config=None):
    plugin = tmp_path / "plugin"
    shutil_copy = __import__("shutil").copytree
    shutil_copy(ROOT / "host", plugin / "host", ignore=__import__("shutil").ignore_patterns("__pycache__"))
    # As setup does: the host imports the collector's package from its own folder (python -I ignores PYTHONPATH).
    shutil_copy(ROOT / "collector" / "src" / "pitrelay_collector", plugin / "host" / "pitrelay_collector",
                ignore=__import__("shutil").ignore_patterns("__pycache__"))
    (plugin / "engine").mkdir()
    (plugin / "engine" / "pitrelay.jar").write_bytes(b"fake")
    state = tmp_path / "state"
    for sub in ("jvm-home", "tmp", "host"):
        (state / sub).mkdir(parents=True)
    if config:
        (state / "fake-engine.json").write_text(json.dumps(config))
    (plugin / "host" / "launch.json").write_text(json.dumps({
        "schema_version": "1.0", "java": str(fake_java(tmp_path)), "state": str(state), "workspace": None,
        "workspace_grants": [], "lc_all": None, "collector": False, "collector_store": None, "host_notes": True,
        "tool_name_prefix": PREFIX, "engine_sha256": None}))
    p = subprocess.Popen([sys.executable, "-I", "-B", "-X", "utf8", str(plugin / "host" / "gateway.py")],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p.stdin.write(encode({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
        "protocolVersion": "2025-11-25", "capabilities": {}, "clientInfo": {"name": "t"}}}))
    p.stdin.flush()
    assert json.loads(p.stdout.readline())["id"] == 1
    p.stdin.write(encode({"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": "pitrelay_echo",
                                                                                      "arguments": {}}}))
    p.stdin.flush()
    assert json.loads(p.stdout.readline())["id"] == 2
    return p, plugin, state


@pytest.mark.skipif(os.name != "posix", reason="POSIX signals")
@pytest.mark.parametrize("how", ["eof", "sigint", "sigterm"])
def test_the_host_exits_within_claude_codes_half_second_and_the_engine_follows(tmp_path, how):
    p, plugin, state = _host_process(tmp_path)
    p.stdin.write(encode({"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {
        "name": "pitrelay_slow", "arguments": {"seconds": 2}}}))
    p.stdin.flush()
    time.sleep(0.3)
    t = time.monotonic()
    if how == "eof":
        p.stdin.close()
    else:
        p.send_signal(signal.SIGINT if how == "sigint" else signal.SIGTERM)
    p.wait(timeout=5)
    assert time.monotonic() - t < 0.5
    assert not list(plugin.rglob("__pycache__"))  # -B: the verified plugin folder is never written
    # The engine reads end-of-input, finishes its current request and exits.
    out = subprocess.run(["pgrep", "-f", str(state / "engine")], capture_output=True, text=True)
    assert wait_until(lambda: subprocess.run(["pgrep", "-f", str(state / "engine")], capture_output=True).returncode != 0, 10), out.stdout


# --- host notes against the real v11 engine ---------------------------------------------------------


def _upload(h, data: bytes, name: str):
    begin = h.call_result("pitrelay_artifact_upload_begin", {"kind": "log", "filename": name, "byte_size": len(data),
                                                             "sha256": hashlib.sha256(data).hexdigest()})
    tid = text_of(begin)["result"]["id"]
    for off in range(0, len(data), 49152):
        h.call_result("pitrelay_artifact_upload_chunk", {"transfer_id": tid, "offset": off,
                                                         "data_base64": base64.b64encode(data[off:off + 49152]).decode()})
    fin = h.call_result("pitrelay_artifact_upload_finish", {"transfer_id": tid})
    return text_of(fin)["result"]["id"], begin


def _notes(result):
    return [c["text"] for c in result["content"][1:]]


@needs_engine
def test_notes_explain_misleading_v11_results_and_never_change_the_engines_answer(host):
    h = host(real_jar=real_engine_jar())
    v2, begin = _upload(h, synthetic.revlog_v2(), "v2.revlog")
    assert _notes(begin) and "pass this transfer's id" in _notes(begin)[0] and "transfer_id" not in text_of(begin)["result"]
    r = h.call_result("pitrelay_log_inspect", {"artifact_id": v2, "format": "rev_native"})
    env = text_of(r)
    assert env["status"] == "partial" and "host_compatibility" not in env  # the engine's own answer, unchanged
    assert len(r["content"]) == 2 and r["content"][1]["text"].startswith(
        "Host note (PitRelay for Claude Code, not the PitRelay engine; revlog_v2, engine issue 1)")
    assert "REVLOG v2.0" in r["content"][1]["text"]
    stats = h.call_result("pitrelay_signal_statistics", {"artifact_id": v2, "format": "rev_native", "entry": "x",
                                                         "start_us": 0, "end_us": 10})
    assert text_of(stats)["status"] == "no_match" and "revlog_v2" in _notes(stats)[0]
    log, _ = _upload(h, synthetic.dslog_v4(1761206400, 300, pd_type=33), "a.dslog")
    ev, _ = _upload(h, synthetic.dsevents_v4(1761206400, ["Info: one", "Warning: two"]), "b.dsevents")
    wrong = h.call_result("pitrelay_log_inspect", {"artifact_id": log, "format": "dsevents_v4"})
    assert text_of(wrong)["status"] == "partial" and 'format "dslog_v4"' in _notes(wrong)[0]
    wrong = h.call_result("pitrelay_log_inspect", {"artifact_id": ev, "format": "dslog_v4"})
    assert text_of(wrong)["status"] == "partial" and 'format "dsevents_v4"' in _notes(wrong)[0]
    for aid, fmt in ((log, "dslog_v4"), (ev, "dsevents_v4")):
        right = h.call_result("pitrelay_log_inspect", {"artifact_id": aid, "format": fmt})
        assert text_of(right)["status"] == "ok" and len(right["content"]) == 1
    v1, _ = _upload(h, synthetic.revlog_v1(), "v1.revlog")
    r1 = h.call_result("pitrelay_log_inspect", {"artifact_id": v1, "format": "rev_native"})
    assert text_of(r1)["status"] == "partial" and len(r1["content"]) == 1  # v1: the engine's issues are accurate
    csv, _ = _upload(h, b"t,v\n0,12\n1,6\n", "c.csv")
    bad = h.call_result("pitrelay_log_import_csv", {"artifact_id": csv, "timestamp_column": "t", "value_column": "v",
                                                    "time_unit": "ns", "clock": "c", "sampling_policy": "periodic",
                                                    "unit": "V"})
    assert text_of(bad)["status"] == "unsupported" and len(bad["content"]) == 1 and "isError" not in bad
    status, _ = h.call("host_status")
    assert status["compatibility"]["notes_active"] is True


@needs_engine
def test_notes_can_be_switched_off_and_never_appear_for_another_engine_build(host, tmp_path):
    off = host(real_jar=real_engine_jar(), host_notes=False)
    v2, begin = _upload(off, synthetic.revlog_v2(), "v2.revlog")
    r = off.call_result("pitrelay_log_inspect", {"artifact_id": v2, "format": "rev_native"})
    assert len(begin["content"]) == 1 and len(r["content"]) == 1
    assert off.call("host_status")[0]["compatibility"]["notes_active"] is False
    off.close()
    # A different engine build (here: the fake engine) gets no notes, whatever it answers.
    other = host(config={})
    assert other.call("host_status")[0]["compatibility"]["notes_active"] is False
    r = other.call_result("pitrelay_echo", {"artifact_id": "a", "format": "rev_native", "status": "partial"})
    assert len(r["content"]) == 1


@needs_engine
def test_real_engine_tool_names_fit_and_instructions_are_the_engines(host):
    h = host(real_jar=real_engine_jar())
    tools = h.request("tools/list", {})["result"]["tools"]
    assert len([t for t in tools if t["name"].startswith("pitrelay_")]) == 107
    assert max(len(PREFIX + t["name"]) for t in tools) == 64
    assert h.init["result"]["instructions"].startswith("PitRelay defaults to Standard Access")
    assert "jar 66de12d3968b" in h.init["result"]["serverInfo"]["title"]


@needs_engine
@pytest.mark.skipif(os.name != "posix", reason="POSIX record locks")
def test_a_transfer_the_engine_kept_open_is_aborted_by_a_later_host_once_it_can_be(host, tmp_path):
    import fcntl
    a = host(real_jar=real_engine_jar())
    data = os.urandom(60000)
    begin = a.call_result("pitrelay_artifact_upload_begin", {"kind": "log", "filename": "x.bin", "byte_size": len(data),
                                                             "sha256": hashlib.sha256(data).hexdigest()})
    tid = text_of(begin)["result"]["id"]
    a.call_result("pitrelay_artifact_upload_chunk", {"transfer_id": tid, "offset": 0,
                                                     "data_base64": base64.b64encode(data[:49152]).decode()})
    fin = text_of(a.call_result("pitrelay_artifact_upload_finish", {"transfer_id": tid}))
    assert (fin["status"], fin["result"]["code"]) == ("blocked", "TRANSFER_INCOMPLETE")  # finish too early
    journal = a.server.engine.journal.path
    assert json.loads(journal.read_text())["transfers"] == [tid]
    a.close()
    journal.write_text(json.dumps({**json.loads(journal.read_text()), "pid": _dead_pid()}))  # its host process ended
    part = next(a.state.glob(f"engine/ws-*/transfers/{tid}.part"))
    with open(part.with_suffix(".lock"), "r+b") as held:
        fcntl.lockf(held, fcntl.LOCK_EX | fcntl.LOCK_NB)  # another process holds the transfer: blocked TRANSFER_BUSY
        b = Harness(tmp_path / "b", real_jar=real_engine_jar(), state=a.state)
        try:
            assert b.server.engine.orphans_done.wait(60)
        finally:
            b.close()
    assert json.loads(journal.read_text())["transfers"] == [tid] and part.exists()
    c = Harness(tmp_path / "c", real_jar=real_engine_jar(), state=a.state)
    try:
        assert c.server.engine.orphans_done.wait(60)
        assert not journal.exists() and not part.exists()
        r = text_of(c.call_result("pitrelay_artifact_upload_abort", {"transfer_id": tid}))
        assert r["status"] == "ok" and r["result"]["state"] == "aborted"
    finally:
        c.close()


# --- content checks (shared with the collector) -------------------------------------------------


def test_content_checks_used_by_the_notes():
    assert formats.revlog_header_version(synthetic.revlog_v2()) == (2, 0)
    assert formats.revlog_header_version(synthetic.revlog_v1()) is None
    assert formats.revlog_header_version(b"") is None and formats.revlog_header_version(b"\x0f") is None
    log = synthetic.dslog_v4(1_760_000_000, 50, pd_type=25)
    ev = synthetic.dsevents_v4(1_760_000_000, ["Info: a", "Warning: b", "x" * 300])
    assert formats.ds_content_format(log) == "dslog" and formats.ds_content_format(ev) == "dsevents"
    assert formats.ds_content_format(b"\x00\x00\x00\x03" + log[4:]) is None  # not version 4
    assert formats.ds_content_format(synthetic.voltage_fixture_wpilog()) is None
    assert host_compat.RULES and {r["engine_issue"] for r in host_compat.RULES} == {1, 2, 3}


def test_the_engine_gets_exactly_the_workspace_grants_from_setup(tmp_path):
    from pitrelay_host.engine import engine_argv
    launch = {"java": "/j/bin/java", "state": str(tmp_path / "state"), "workspace": str(tmp_path / "ws"),
              "workspace_grants": ["project_read", "propose"]}
    argv = engine_argv(launch, tmp_path / "plugin")
    assert argv[argv.index("--grants") + 1] == "project_read,propose"
    assert argv[argv.index("--workspace") + 1] == str(tmp_path / "ws") and "--workspace-disclosure" in argv
    assert "--grants" not in engine_argv({**launch, "workspace": None, "workspace_grants": []}, tmp_path / "plugin")
