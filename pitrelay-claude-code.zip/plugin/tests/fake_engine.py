"""A stand-in for the PitRelay engine's MCP stdio server, for host tests that need exact control.

Started by a fake `java` (see tests/host_harness.py); it ignores the Java arguments. Behavior comes from
<state>/fake-engine.json, and every message it receives is appended to <state>/fake-engine-received.jsonl.

Tools: echo (returns its arguments), slow (sleeps `seconds`), crash (exits at once), nan (returns NaN in a field),
unicode (returns a text with unusual characters), ask_client (sends a request to the client), notify (sends a
notification), plus any names in the config's extra_tools. The config's "answers" maps a tool name to the envelope
it answers instead. Like the real engine it handles one request at a time and answers a line over 1 MiB with an
id:null error. With "never_answer" it is a start that hangs: it answers nothing and exits when its input ends, and
appends "start <time>" and "end <time>" (time.time()) to <state>/fake-engine-starts.txt.
"""
import json
import os
import sys
import time

state = None
for i, arg in enumerate(sys.argv):
    if arg == "--state" and i + 1 < len(sys.argv):
        state = sys.argv[i + 1]
root = os.path.dirname(state) if state else os.getcwd()
try:
    with open(os.path.join(root, "fake-engine.json"), encoding="utf-8") as f:
        config = json.load(f)
except (OSError, ValueError):
    config = {}
if config.get("never_answer"):
    with open(os.path.join(root, "fake-engine-starts.txt"), "a", encoding="utf-8") as f:
        f.write(f"start {time.time()}\n")
    sys.stdin.read()
    with open(os.path.join(root, "fake-engine-starts.txt"), "a", encoding="utf-8") as f:
        f.write(f"end {time.time()}\n")
    sys.exit(0)
time.sleep(config.get("start_delay_s", 0))
log = open(os.path.join(root, "fake-engine-received.jsonl"), "a", encoding="utf-8")
out = sys.stdout


def send(msg):
    out.write(json.dumps(msg) + "\n")
    out.flush()


def result_text(payload):
    return {"content": [{"type": "text", "text": json.dumps(payload) if not isinstance(payload, str) else payload}]}


TOOLS = [{"name": n, "description": f"fake {n}", "inputSchema": {"type": "object"},
          "_meta": {"pitrelay/operation": n.replace("pitrelay_", "").replace("_", ".")}}
         for n in ["pitrelay_echo", "pitrelay_slow", "pitrelay_crash", "pitrelay_nan", "pitrelay_unicode",
                   "pitrelay_ask_client", "pitrelay_notify", "pitrelay_artifact_upload_begin",
                   "pitrelay_artifact_upload_finish", "pitrelay_artifact_upload_abort", *config.get("extra_tools", [])]]
busy_left = int(config.get("busy_times", 0))
transfers = 0

for raw in sys.stdin:
    log.write(raw if raw.endswith("\n") else raw + "\n")
    log.flush()
    if len(raw.encode("utf-8")) > 1024 * 1024:
        send({"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Request exceeds 1 MiB"}})
        continue
    try:
        msg = json.loads(raw)
    except ValueError:
        send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "INVALID_JSON"}})
        continue
    method, rid = msg.get("method"), msg.get("id")
    if method is None:
        send({"jsonrpc": "2.0", "id": rid, "error": {"code": -32600, "message": "Missing method"}})
        continue
    if rid is None:
        continue
    if method == "initialize":
        if config.get("print_junk"):
            out.write("this is not json\n")
        send({"jsonrpc": "2.0", "id": rid, "result": {"protocolVersion": "2025-06-18", "capabilities": {"tools": {}},
                                                      "serverInfo": {"name": "pitrelay", "version": "fake-1"},
                                                      "instructions": config.get("instructions", "FAKE ENGINE INSTRUCTIONS")}})
    elif method == "tools/list":
        send({"jsonrpc": "2.0", "id": rid, "result": {"tools": TOOLS}})
    elif method == "tools/call":
        name = msg["params"]["name"]
        args = msg["params"].get("arguments") or {}
        if name in config.get("answers", {}):
            send({"jsonrpc": "2.0", "id": rid, "result": result_text(config["answers"][name])})
            continue
        if name == "pitrelay_crash":
            sys.exit(3)
        if name == "pitrelay_slow":
            time.sleep(float(args.get("seconds", 1)))
        if name == "pitrelay_ask_client":
            send({"jsonrpc": "2.0", "id": "engine-req-1", "method": "roots/list", "params": {}})
        if name == "pitrelay_notify":
            send({"jsonrpc": "2.0", "method": "notifications/message", "params": {"level": "info", "data": "x"}})
        if name == "pitrelay_nan":
            out.write(json.dumps({"jsonrpc": "2.0", "id": rid, "result": {**result_text({"status": "ok"}),
                                                                           "_meta": {"value": float("nan")}}}) + "\n")
            out.flush()
            continue
        if name == "pitrelay_unicode":
            send({"jsonrpc": "2.0", "id": rid, "result": result_text('{"status":"ok","text":"\\u00e9\\u2028\\ud800\\u202e x"}')})
            continue
        if name == "pitrelay_artifact_upload_begin":
            if busy_left > 0:
                busy_left -= 1
                send({"jsonrpc": "2.0", "id": rid, "result": result_text({"status": "blocked", "result": {
                    "code": "TRANSFER_BUSY", "message": "Another process is admitting a transfer"}})})
                continue
            transfers += 1
            send({"jsonrpc": "2.0", "id": rid, "result": result_text({"status": "ok", "result": {
                "id": f"transfer-{os.getpid()}-{transfers}", "max_chunk_bytes": 49152}})})
            continue
        if name in ("pitrelay_artifact_upload_finish", "pitrelay_artifact_upload_abort"):
            send({"jsonrpc": "2.0", "id": rid, "result": result_text({"status": "ok", "result": {
                "transfer_id": args.get("transfer_id")}})})
            continue
        status = args.get("status", "ok")
        send({"jsonrpc": "2.0", "id": rid, "result": {**result_text({"status": status, "operation": name,
                                                                     "request_id": f"req-{rid}", "result": {"echo": args}}),
                                                      **({"isError": True} if status == "error" else {})}})
    else:
        send({"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": "Method not found"}})
