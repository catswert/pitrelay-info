"""Re-run the mutation checks quoted in docs/TESTING.md.

Each mutant re-introduces, in a temporary copy of this project, a defect that an independent review found (or
that a fix guards against), then runs that area's tests. Every mutant must be KILLED (its tests fail).

    python3 tools/mutants.py [name-substring ...]

Run it with a Python that has the collector's dependencies (paramiko, keyring, pytest); set PITRELAY_ENGINE_JAR
to include the tests that need the real engine.
"""
import concurrent.futures
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
TESTS = {
    "generator": sorted(str(p.relative_to(SRC)) for p in (SRC / "tests").glob("test_configure*.py")),
    "host": ["tests/test_host.py", "tests/test_collector_tools.py", "tests/test_compat_notes.py"],
    "collector": ["collector/tests"],
}
# Generator mutants: configure_claude.py, checked by the generator tests.
MUTANTS = {
 "M07a os.rename everywhere": ('    if sys.platform == "win32":\n        os.rename(source, destination)  # never replaces on Windows\n        return',
                              '    if True:\n        os.rename(source, destination)  # never replaces on Windows\n        return'),
 "M07b no RENAME_NOREPLACE": ("-100, os.fsencode(destination), 1]", "-100, os.fsencode(destination), 0]"),
 "M08a no package recheck": ('                raise SetupError(f"Copied file changed during preparation: {row[\'path\']}")', '                pass'),
 "M08b no overlay recheck": ('                raise SetupError(f"Copied overlay file changed during preparation: {rel}")', '                pass'),
 "M10a size-only compare": ('if files[rel].stat().st_size != listed[rel]["byte_size"] or digest(files[rel]) != listed[rel]["sha256"]:',
                            'if files[rel].stat().st_size != listed[rel]["byte_size"]:'),
 "M10b anchor ignored": ('if manifest_sha256 is not None and hashlib.sha256(raw).hexdigest() != manifest_sha256:', 'if False:'),
 "M10c verify exit 0": ('            result = {"result": "FAIL", "problems": [str(e)]}\n        print(json.dumps(result, indent=2))\n        return 0 if result["result"] == "PASS" else 1',
                         '            result = {"result": "FAIL", "problems": [str(e)]}\n        print(json.dumps(result, indent=2))\n        return 0'),
 "M10d no overlay inventory check": ('                problems.append(f"overlay file differs from the reviewed inventory: {rel}")', '                pass'),
 "M10e java sha ignored": ('            elif digest(java) != receipt.get("java_executable_sha256") or launcher_now != launcher_then:\n                if runtime["major"] != recorded.get("major"):',
                            '            elif False:\n                if runtime["major"] != recorded.get("major"):'),
 "M10e2 unanchored java change ignored": ('        if digest(java) != receipt.get("java_executable_sha256"):\n            problems.append(f"the Java recorded at setup ({java}) {unanchored_change}")',
                                          '        if False:\n            problems.append(f"the Java recorded at setup ({java}) {unanchored_change}")'),
 "M10f env ignored in verify": ('        if servers != mcp_config(str(server_python), extra_env, plugin):',
                                 '        if {k: {kk: vv for kk, vv in v.items() if kk != "env"} for k, v in servers["mcpServers"].items()} != {k: {kk: vv for kk, vv in v.items() if kk != "env"} for k, v in mcp_config(str(server_python), extra_env, plugin)["mcpServers"].items()}:'),
 "M05b _JAVA_OPTIONS not blanked": ('INJECTION_VARIABLES = ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "CLASSPATH")', 'INJECTION_VARIABLES = ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "CLASSPATH")'),
 "M05c probe env unfiltered": ('    env = {k: v for k, v in os.environ.items() if k.upper() not in INJECTION_VARIABLES}\n    if _LINUX_LIKE:', '    env = dict(os.environ)\n    if _LINUX_LIKE:'),
 "M11a no user.home/tmpdir": ('''    args = ["-Xmx384m", f"-Duser.home={state / 'jvm-home'}", f"-Djava.io.tmpdir={state / 'tmp'}",''', '''    args = ["-Xmx384m",'''),
 "M11b no --mode mcp": ('''"--state", str(state / "engine"), "--mode", "mcp"]''', '''"--state", str(state / "engine")]'''),
 "M12a .lsp.json allowed": ('RESERVED_PACKAGE_FILES = (".mcp.json", ".lsp.json",', 'RESERVED_PACKAGE_FILES = (".mcp.json",'),
 "M12b settings.json allowed": ('"settings.json", "SKILL.md"', '"SKILL.md"'),
 "M12c output-styles/monitors allowed": ('"output-styles/", "outputStyles/", "monitors/", ', ''),
 "M13 context/agent allowed": ('FORBIDDEN_SKILL_KEYS = ("allowed-tools", "hooks", "context", "agent", "model")', 'FORBIDDEN_SKILL_KEYS = ("allowed-tools", "hooks", "model")'),
 "M14 Java 17 refused": ('if not m or int(m[1]) < 17:', 'if not m or int(m[1]) <= 17:'),
 "M15 no java_real overlap check": ('        if within(java_real, folder):\n            raise SetupError(f"Select an independently installed Java, not one inside the {name} folder")\n        if within(python_base, folder)',
                                    '        if False:\n            raise SetupError(f"Select an independently installed Java, not one inside the {name} folder")\n        if within(python_base, folder)'),
 "M16 ${ only for state": ('    for role, value in (("Java", str(java_real)), ("Python", str(server_python)), ("state", str(state)),\n                        ("output", str(output)), *((("workspace", str(workspace)),) if workspace is not None else ())):\n        if "${" in value:',
                            '    for role, value in (("state", str(state)),):\n        if "${" in value:'),
 "M17 workspace plugin-folder unchecked": ('if name != "package" and any(within(folder, d) for d in claude_plugin_dirs()):', 'if name not in ("package", "workspace") and any(within(folder, d) for d in claude_plugin_dirs()):'),
 "M18 workspace links unchecked": ('    for value, role in ((package, "package"), (state, "state"), (output, "output"),\n                        *(((workspace, "workspace"),) if workspace is not None else ()),\n                        *(((collector_store, "collector store"),) if collector else ())):\n        no_links(value, role)',
                                   '    for value, role in ((package, "package"), (state, "state"), (output, "output"),\n                        *(((collector_store, "collector store"),) if collector else ())):\n        no_links(value, role)'),
 "M22 verify ignores workspace": ('        workspace = Path(receipt["workspace"]) if receipt.get("workspace") else None', '        workspace = None'),
 "M23 ~/.claude ignored": ('    roots = [Path.home() / ".claude"]', '    roots = []'),
 "HIGH no file-set check": ('        problems += [f"file not produced by setup: {p}" for p in sorted(set(files) - expected_files)]', '        pass'),
 "HIGH no generated-metadata check": ('                    problems.append(f"{rel} differs from what setup writes")', '                    pass'),
 "F06 CRLF not normalized": ('    return path.read_bytes().replace(b"\\r\\n", b"\\n")', '    return path.read_bytes()'),
 "F06 OS metadata shipped": ('            if "__pycache__" in parts or path.name in OS_METADATA or path.name.startswith("._"):',
                              '            if "__pycache__" in parts:'),
 "F07 injected env restorable": ('    return {**allowed, **{k: "" for k in INJECTION_VARIABLES}}',
                                 '    return {**{k: "" for k in INJECTION_VARIABLES}, **extra}'),
 "F07 wrapper launcher accepted": ('            if runtime["launcher"] != launcher_now:', '            if False:'),
 "F09 locale only for non-ASCII": ('    if sys.platform == "darwin":  # macOS Java always uses UTF-8 for file names',
                                   '    if sys.platform == "darwin" or not non_ascii:'),
 "F12 reserved paths case-sensitive": ('        folded = p.casefold()  # APFS and NTFS are case-insensitive: Hooks/ is hooks/ there',
                                       '        folded = p'),
 "F12 BOM front matter accepted": ('    text = data.decode("utf-8", errors="replace").lstrip("\\ufeff")', '    text = data.decode("utf-8", errors="replace")'),
 "F13 receipt rows unchecked": ('                raise SetupError(f"malformed file row {r!r:.120}")', '                pass'),
 "G01 wrapper launcher in the venv accepted": ('    elif not is_link(py):\n        problems.append("the collector\'s Python environment starts bin/python',
                                               '    elif False:\n        problems.append("the collector\'s Python environment starts bin/python'),
 "G02 dist-packages allowed": ('            elif d.lower() == "dist-packages" or rel.lower() in ("local", "lib64"):', '            elif False:'),
 "G03 changed install record trusted": ('               "changed since setup" if digest(record) != records[name] else None)',
                                        '               None)'),
 "G04 unanchored verify runs the receipt's programs": ('    anchored = receipt_sha256 is not None\n', '    anchored = True\n'),
 "G05 receipt mismatch checked further": ('    if receipt_sha256 is not None and hashlib.sha256(receipt_bytes).hexdigest() != receipt_sha256:\n        return {',
                                          '    if False:\n        return {'),
 "G06 target markers ignored": ('                if marker is None or any(evaluate_marker(marker, {**env, "extra": e}) is not False for e in ("", *extras)):',
                                '                if marker is None:'),
 "G07 1.x state with host refused": ('STATE_1X = {"engine", "jvm-home", "tmp", "host"}', 'STATE_1X = {"engine", "jvm-home", "tmp"}'),
 "G08 shim pinned as is": ('    elif probed is not None and not _same(probed, selected):\n        base = probed',
                           '    elif False:\n        base = probed'),
 "G09 raw SQLite URI in setup": ('    return sqlite3.connect(Path(db).as_uri() + "?mode=ro", uri=True, timeout=10)',
                                 '    return sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)'),
 "G13 java bytes changed at the same version accepted": (
     '                elif not native_executable(java) or runtime["version"] == recorded.get("version"):',
     '                elif False:'),
 "G14 bytecode listed without a hash trusted": (
     '                if os.path.isfile(target) and os.path.normcase(target) != os.path.normcase(str(record)) and (',
     '                if False and ('),
 "G15 repeated pyvenv setting accepted": ("    if len(cfg) != len(pairs):", "    if False:"),
 "G16 escaped desktop paths missed": ("    return any(n in t for n in needles for t in texts)",
                                      "    return any(needles[0] in t for t in texts)"),
 "G10 front matter loose": ('        if not m:\n            refuse(number, f"{line[:40]!r} is not a plain \'key: value\' line")',
                            '        if not m:\n            continue'),
 "G11 store may overlap the state": ('        for name in ("package", "state", "output", *(("workspace",) if workspace is not None else ())):',
                                     '        for name in ("package", "output", *(("workspace",) if workspace is not None else ())):'),
 "G12 collector skill shipped without the collector": ('if collector or not rel.startswith(COLLECTOR_ONLY_OVERLAY)}', 'if True}'),
 "F14 old generator reported as tampering": ('    if not same_overlay:\n', '    if False:\n'),
 "G17 bytecode keys case-folded": ('                rel = env_key(target, env_dir)', '                rel = env_key(os.path.normcase(target), env_dir)'),
 "G18 script put in place of the python run and accepted": (
     '    elif digest(python) != python_rec.get("executable_sha256") and not (\n'
     '            native_executable(python) and native_executable(Path(os.path.realpath(python)))):',
     '    elif False:'),
 "G19 other python bytes of the same build accepted": (
     '                if isinstance(python_rec.get("sys_version"), str) and now["sys_version"] == python_rec["sys_version"]:',
     '                if False:'),
 "G20 java link resolved": ('        if len(chain) > 1 and names_version(real, full_version):', '        if False:'),
 "G27 java alternatives link pinned": ('        if len(chain) > 1 and names_version(real, full_version):', '        if len(chain) > 1:'),
 "G21 version-named java folder without a warning": (
     '    if names_version(pinned, full_version) and not names_version(Path(os.path.abspath(java_given)), full_version):',
     '    if False:'),
 "G22 java link through the workspace pinned": (
     '                           and not any(lies_in(q, folder) for q in chain[i:] for folder in avoid)), real)',
     '                           and not any(lies_in(p, folder) for folder in avoid)), real)'),
 "G23 venv base pinned resolved": ('        base = next((f / name for f in folders', '        base = next((f / name for f in ()'),
 "G24 kept hash taken as typed": ('    normalized = value.strip().lower() if isinstance(value, str) else ""',
                                  '    normalized = value if isinstance(value, str) else ""'),
 "G25 reused state gets the default store": ('        collector_store = store_before or default_collector_store()',
                                             '        collector_store = default_collector_store()'),
 "G26 reuse with other access not warned": ('        warnings += reuse_warnings(previous, state, workspace)', '        pass'),
 "G32 base python pinned inside another environment": (
     '                     and not (f.parent / "pyvenv.cfg").is_file() and _same(f / name, reference)), None)',
     '                     and _same(f / name, reference)), None)'),
 "G28 same-version java redirect accepted": ('                        runtime["version"] != recorded.get("version"):',
                                             '                        True:'),
 "G29 changed java script run by verify": ('            java_checked = True\n', '            java_checked = False\n'),
 "G30 script base python accepted": ('    if not native_executable(Path(os.path.realpath(python_base))):', '    if False:'),
 "G31 python reached through the workspace": ('                lies_in(q, folder) for q in link_chain(python_base)):',
                                              '                False for q in link_chain(python_base)):'),
}

# Host and collector mutants: (area, file, [(old, new), ...]).
CT = "host/pitrelay_host/collector_tools.py"
RL = "host/pitrelay_host/relay.py"
C = "collector/src/pitrelay_collector/"
AREA_MUTANTS = {
 "T01 any dialog answer accepted": ("host", CT, [('if action == "accept" and answer["content"].get(gate) is True and all(',
                                                  'if action in ("accept", "decline", "cancel") or all(')]),
 "T02 long dialog shown cut short": ("host", CT, [("        if len(text) > DIALOG_LIMIT:", "        if False:")]),
 "T03 robot contacted before the dialog": ("host", CT, [(
     '            self.ask(ctx, message, {"allow": {"type": "boolean", "title": "Allow this source", "default": False}}, "allow")',
     '            self._preview_key(candidate) if candidate.kind == "sftp" else None\n'
     '            self.ask(ctx, message, {"allow": {"type": "boolean", "title": "Allow this source", "default": False}}, "allow")')]),
 "T04 key trust pre-ticked": ("host", CT, [('"trust": {"type": "boolean", "title": "Trust this host key", "default": False}',
                                            '"trust": {"type": "boolean", "title": "Trust this host key", "default": True}')]),
 "T05 replace-or-add not required": ("host", CT, [('            required = ("how",)  # no default: the person says which',
                                                   '            required = ()')]),
 "T06 new folders not a widening": ("host", CT, [(' or not b["directories"] <= a["directories"]', '')]),
 "T07 proposal resolved before the dialog": ("host", CT, [("                                           touch_filesystem=False)",
                                                           "                                           touch_filesystem=True)")]),
 "T08 project folder not checked": ("host", CT, [('        problem = self.m["projectscan"].project_root_problem(spelled)',
                                                  "        problem = None")]),
 "T09 hidden project folder asked about": ("host", CT, [("                or any(part.startswith(\".\") for part in spelled.parts[1:])\n", "")]),
 "T10 uploads inside the workflow": ("host", CT, [("        call = self.server.engine.call_tool\n",
                                                   '        call = lambda n, a: self.server.engine.call_tool(n, {**a, "workflow_id": "wf"})\n')]),
 "T11 failed upload not aborted": ("host", CT, [("            if not finished:  # never leave a half-written transfer in the engine's state",
                                                 "            if False:")]),
 "T12 one failure loses the supply": ("host", CT, [("                except Exception as e:  # one recording's failure never discards the ones already supplied",
                                                    "                except ZeroDivisionError as e:")]),
 "T13 person's packages pruned": ("host", CT, [(
     "            if rank < KEEP_PACKAGES or any(str(z) in in_use or _holds_person_content(z, pkg) for z in parts):",
     "            if rank < KEEP_PACKAGES:")]),
 "T22 parts of an export pruned apart": ("host", CT, [(
     "            if rank < KEEP_PACKAGES or any(str(z) in in_use or _holds_person_content(z, pkg) for z in parts):",
     "            if rank < KEEP_PACKAGES or any(str(z) in in_use or _holds_person_content(z, pkg) for z in parts[:1]):")]),
 "T14 background off stops any owner": ("host", CT, [(
     '        if not isinstance(info, dict) or info.get("ident") != "claude" or info.get("pid") != holder.get("pid"):',
     "        if not isinstance(info, dict):")]),
 "T15 background started next to an owner": ("host", CT, [(
     '        if self.app is None and holder is not None and self.m["lock"].StoreLock(self.root).is_held_elsewhere():',
     "        if False:")]),
 "T16 reader ignores pause": ("host", CT, [('            if store.meta_get("paused", ""):\n                raise ToolError("PAUSED"',
                                            '            if False:\n                raise ToolError("PAUSED"')]),
 "T17 package text unescaped": ("host", CT, [("    return printable(value, limit) if isinstance(value, str) else value",
                                              "    return value")]),
 "T18 delete ids not deduplicated": ("host", CT, [(
     '        ids = list(dict.fromkeys(_capture_number(x) for x in arguments.get("capture_ids") or []))',
     '        ids = [_capture_number(x) for x in arguments.get("capture_ids") or []]')]),
 "T19 outside package looked at before the dialog": ("host", CT, [(
     "        return [path], False\n",
     "        if not path.is_file():\n            raise ToolError(\"REFUSED\", \"no such package\")\n        return [path], False\n")]),
 "T20 supply path shown unnormalized": ("host", CT, [("{_shown(os.path.normpath(paths[0]))} (path proposed by",
                                                      "{_shown(paths[0])} (path proposed by")]),
 "T23 project in the home folder refused": ("host", CT, [("key(spelled) in {key(x) for x in (home, *home.parents)}",
                                                          "key(spelled) in lowered and key(home) in lowered")]),
 "T24 project holding the store accepted": ("host", CT, [(
     "                or any(key(spelled) in {key(y) for y in (x, *x.parents)} for x in private)):  # or around them",
     "                ):")]),
 "T25 proposals not held to the stricter rules": ("host", CT, [(
     "            cfgmod.check_proposal(candidate)  # stricter rules for what Claude proposes (hidden folders, shares, ...)",
     "            pass")]),
 "T26 outside package routes trusted": ("host", CT, [("hand.build_plan(manifest, trusted_routes=internal)",
                                                      "hand.build_plan(manifest, trusted_routes=True)")]),
 "T27 automatic collection left on after off": ("host", CT, [('                if previous == "0":', "                if False:")]),
 "T28 dialog text shortened": ("host", CT, [("    return printable(str(value), 1_000_000)", "    return printable(str(value), 30)")]),
 "T21 revlog note says intact": ("host", "host/pitrelay_host/compat.py", [(
     "decoded: the 'Unknown REV native record ID' issues come from that missing support. Other issues ",
     "decoded, not that the file is damaged. Other issues ")]),
 "M09c grants ignored": ("host", "host/pitrelay_host/engine.py", [('"--grants", ",".join(launch["workspace_grants"])',
                                                                 '"--grants", "project_read"')]),
 "R01 changed jar not refused": ("host", RL, [("        if expected and self.jar_sha256 != expected:", "        if False:")]),
 "R02 refusal forgotten": ("host", RL, [("        self.refused = problem\n", "        self.refused = None\n")]),
 "R03 journal drops open transfers": ("host", RL, [(
     "                if not isinstance(tid, str) or tid not in self.open or not self.settled(name, env, tid):",
     "                if not isinstance(tid, str) or tid not in self.open:")]),
 "R04 refused aborts forgotten": ("host", RL, [("            if not left:\n                f.unlink(missing_ok=True)",
                                               "            if True:\n                f.unlink(missing_ok=True)")]),
 "R05 reused pid adopted": ("host", RL, [("        return now is not None and now != started  # the pid now belongs to a later process",
                                         "        return False")]),
 "R06 damaged journal stops cleanup": ("host", RL, [('            except Exception:\n                launch = getattr(engine, "launch", None)',
                                                    '            except ZeroDivisionError:\n                launch = getattr(engine, "launch", None)')]),
 "R07 failed first start never retried": ("host", RL, [(
     "        if self.status != \"failed\" or self.refused or self.tools is not None or self._auto_starts >= AUTO_START_RETRIES:",
     "        if True:")]),
 "R08 tool name type unchecked": ("host", RL, [("        if not isinstance(name, str):", "        if False:")]),
 "R09 failing message ends the server": ("host", RL, [("            self.dispatch(msg)\n        except Exception as e:",
                                                      "            self.dispatch(msg)\n        except ZeroDivisionError as e:")]),
 "R10 deep nesting ends the server": ("host", RL, [("                except (ValueError, RecursionError):  # RecursionError: nested deeper than the parser allows",
                                                   "                except ValueError:")]),
 "R11 ps start time read in the host's zone": ("host", RL, [(
     '    return calendar.timegm(time.strptime(text.strip(), "%a %b %d %H:%M:%S %Y"))',
     '    return int(time.mktime(time.strptime(text.strip(), "%a %b %d %H:%M:%S %Y")))')]),
 "R12 ps prints the system zone": ("host", RL, [('env={"LC_ALL": "C", "TZ": "UTC0", "PATH": "/usr/bin:/bin"}',
                                                 'env={"LC_ALL": "C", "PATH": "/usr/bin:/bin"}')]),
 "R13 own retry timed from the start of a failed start": ("host", RL, [(
     "        return self._last_failure + RESTART_BACKOFF_S * 2 ** self._auto_starts - time.monotonic()",
     "        return self._last_start + RESTART_BACKOFF_S * 2 ** self._auto_starts - time.monotonic()")]),
 "R14 restart guard timed from the start of a failed start": ("host", RL, [(
     "time.monotonic() - max(self._last_start, self._last_failure) < RESTART_BACKOFF_S:",
     "time.monotonic() - self._last_start < RESTART_BACKOFF_S:")]),
 "R15 running restart reported as failed": ("host", RL, [(
     '            self.status = "starting"  # what host_status reports while the start runs (up to START_TIMEOUT_S)\n', "")]),
 "R16 host_status ignores a running start": ("host", RL, [(
     '            if self.status == "starting":\n                self._cv.wait_for(lambda: self.status != "starting", wait)\n'
     "                return\n", "")]),
 "R17 call timeout hides a running start": ("host", RL, [(
     '                                    + ("; it is still being started" if self.status == "starting" else "")) from None',
     "                                    ) from None")]),
 "K01 network paths accepted": ("collector", C + "config.py", [('    return t.startswith(("\\\\\\\\", "//")) or t.startswith(("\\\\/", "/\\\\"))',
                                                              "    return False")]),
 "K02 zero records are evidence": ("collector", C + "formats.py", [("    if len(types) < 3 or not any(head[20:i]):",
                                                                   "    if len(types) < 3:")]),
 "K03 other analyzer versions reused": ("collector", C + "store.py", [(
     '        return info if isinstance(info, dict) and info.get("analyzer_version") == ANALYZER_VERSION else None',
     "        return info")]),
 "K04 raw SQLite URI": ("collector", C + "store.py", [(
     '            c = sqlite3.connect(self.db_path.absolute().as_uri() + "?mode=ro", uri=True, timeout=30)',
     '            c = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True, timeout=30)')]),
 "K05 systemcore stored as a new auth value": ("collector", C + "config.py", [
     ('            clean["auth"], clean["password_preset"] = "password", "systemcore"', "            pass"),
     ('            src.auth, src.password_preset = "password", "systemcore"', "            pass")]),
 "K06 keyring calls pile up": ("collector", C + "secrets.py", [("    if not _slot.acquire(timeout=timeout):",
                                                                "    if not _slot.acquire(timeout=timeout) and False:")]),
 "K07 locked store reads as no password": ("collector", C + "sources.py", [("            raise AuthFailed(str(e)) from None",
                                                                            "            return None")]),
 "K08 poll request skips backoff": ("collector", C + "collector.py", [(
     "            for src in self.config.load().sources:  # as sync_once: a source in backoff is tried now too",
     "            for src in []:")]),
 "K09 poll request lost while paused": ("collector", C + "collector.py", [(
     "        if raw is None or raw == self._seen_poll_request or self.is_paused():",
     "        if raw is None or raw == self._seen_poll_request:")]),
 "K10 percent unescaped in Exec": ("collector", C + "autostart.py", [('.replace("\\\\", "\\\\\\\\").replace("%", "%%")', '.replace("\\\\", "\\\\\\\\")')]),
 "K11 any folder is a robot project": ("collector", C + "projectscan.py", [(
     "    if not any((real / m).exists() for m in PROJECT_MARKERS) and not _robotpy_project(real):", "    if False:")]),
 "K12 registry auth not detected": ("collector", C + "projectscan.py", [(
     r"""re.compile(r"(?i)[\"']auth[\"']\s*:\s*[\"'][A-Za-z0-9+/]{8,}={0,2}[\"']")""", 're.compile(r"(?!)")')]),
 "K13 credential files collected by a text pattern": ("collector", C + "collector.py", [(
     "p.lower()) for p in src.text_patterns) and not credential_file_name(name)", "p.lower()) for p in src.text_patterns)")]),
 "K14 encrypted key passphrase by keyword": ("collector", C + "sources.py", [(
     'pkey = paramiko.PKey.from_path(src.key_file, passphrase.encode("utf-8"))',
     "pkey = paramiko.PKey.from_path(src.key_file, passphrase=passphrase)")]),
 "K15 one source's error stops the others": ("collector", C + "collector.py", [(
     '            log.exception("Unexpected error while collecting from source %s", src.id)\n', "            raise\n")]),
 "K16 unknown login preset unchecked": ("collector", C + "sources.py", [(
     "            if src.password_preset not in PASSWORD_PRESETS:", "            if False:")]),
 "K17 disguised addresses accepted": ("collector", C + "config.py", [("            if _disguised_address(h):", "            if False:")]),
 "K18 catch-all text pattern accepted": ("collector", C + "config.py", [(
     "        if sum(fnmatch.fnmatchcase(n, low) for n in _UNRELATED_NAMES) >= 2:", "        if False:")]),
 "K19 locked keyring shown as no password": ("collector", C + "secrets.py", [(
     '        except SecretStoreUnavailable:\n            return "unavailable"\n        except Exception:\n            return "unavailable"\n',
     '        except Exception:\n            return "not_stored"\n')]),
 "K20 outside package routes trusted": ("collector", C + "handoff.py", [(
     '(c.get("pitrelay") if trusted_routes else None)', '(c.get("pitrelay"))')]),
 "K21 hidden log folder proposed": ("collector", C + "config.py", [(
     '        if any(part.startswith(".") and part not in (".", "..") for part in parts):', "        if False:")]),
}


def _mutants():
    for name, (old, new) in MUTANTS.items():
        yield name, "generator", "configure_claude.py", [(old, new)]
    for name, (area, rel, pairs) in AREA_MUTANTS.items():
        yield name, area, rel, pairs


def _run(name, area, rel, pairs):
    with tempfile.TemporaryDirectory() as td:
        dst = Path(td) / "proj"
        shutil.copytree(SRC, dst, ignore=shutil.ignore_patterns(".git", "__pycache__", ".venv", ".pytest_cache"))
        p = dst / rel
        s = p.read_text(encoding="utf-8")
        for old, new in pairs:
            if s.count(old) != 1:
                return name, f"NOT APPLIED (count {s.count(old)}) in {rel}"
            s = s.replace(old, new)
        p.write_text(s, encoding="utf-8")
        env = {**os.environ, "HOME": td, "PYTHONDONTWRITEBYTECODE": "1",
               "PYTHONPATH": os.pathsep.join([str(dst / "collector" / "src"), str(dst / "host")])}
        probe = subprocess.run([sys.executable, "-B", "-c", "import pitrelay_collector, pitrelay_host; "
                                "print(pitrelay_collector.__file__); print(pitrelay_host.__file__)"],
                               capture_output=True, text=True, env=env, cwd=td)
        if any(not line.startswith(str(dst)) for line in probe.stdout.split()) or probe.returncode:
            return name, "NOT RUN (the copy's packages were not the ones imported)"
        r = subprocess.run([sys.executable, "-B", "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider",
                            *[str(dst / t) for t in TESTS[area]]], capture_output=True, text=True, timeout=1800,
                           env=env, cwd=dst)
        last = [line for line in r.stdout.splitlines() if "passed" in line or "failed" in line or "error" in line][-1:]
        return name, ("KILLED " if r.returncode else "SURVIVED ") + (last[0] if last else "")


def main(argv):
    wanted = [m for m in _mutants() if not argv or any(a in m[0] for a in argv)]
    # The unmutated copy must pass, or a failure would be counted as a kill.
    for area in sorted({m[1] for m in wanted}):
        _, verdict = _run(f"baseline {area}", area, "README.md", [])
        if not verdict.startswith("SURVIVED"):
            print(f"Baseline {area} tests do not pass on an unmutated copy ({verdict}); fix that first.")
            return 2
        print(f"baseline {area}: {verdict.split(' ', 1)[1]}", flush=True)
    results = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, (os.cpu_count() or 2) // 2)) as pool:
        for name, verdict in pool.map(lambda m: _run(*m), wanted):
            results[name] = verdict
            print(f"{verdict:70s} {name}", flush=True)
    bad = [k for k, v in results.items() if not v.startswith("KILLED")]
    print(f"{len(results) - len(bad)} of {len(results)} mutants killed" + (f"; not killed: {bad}" if bad else ""))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
