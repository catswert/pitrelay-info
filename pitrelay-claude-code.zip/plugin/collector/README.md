# PitRelay Collector

A standalone companion to [PitRelay](https://catswert.github.io/pitrelay-info/) that **automatically collects FRC robot diagnostic logs** and exports a verified ZIP for analysis. Configure it once, turn on automatic collection, and it keeps gathering new and growing logs from the robot and the Driver Station laptop. When you need them, pick a date range (or everything retained) and click **Export for PitRelay**.

Collection never involves Claude, Codex or any other model, cloud service or subscription. AI analysis only happens later, if you give the package to PitRelay.

The same collector is also built into **PitRelay for Claude Code** ([../README.md](../README.md)), where Claude Code sets it up, exports and hands the package to the PitRelay engine. Both use the same store by default; only one process collects with a store at a time, and the others read it.

## What it does

* **Collects** `.wpilog` (WPILib, AdvantageKit and the 2027 FIRST Driver Station), `.revlog`, `.hoot`, `.dslog`/`.dsevents`. With your explicit opt-in it also collects CSV files from folders you select and named diagnostic text files such as `FRC_UserProgram.log`.
* **Reads robot files over SFTP**, read-only, with a pinned host key.
* **Reads local or mounted folders**, such as the Driver Station's `Log Files` folder or vendor tool output.
* **Collects automatically.** It polls on a bounded schedule and reconnects with backoff. It downloads only new bytes of growing files and follows renames (for example `FRC_TBD_*.wpilog` → `FRC_<date>.wpilog`). It also handles rotation, truncation and same-path replacement without ever overwriting earlier evidence.
* **Preserves originals.** Bytes are stored append-only and committed in SHA-256-hashed segments. Nothing is converted, renamed inside the file, re-timed or filled in.
* **Exports** an ordinary, documented ZIP that is verified before it is reported as done:
  * `manifest.json` with hashes, statuses with reasons, formats, clocks, relationships and the PitRelay route for each file;
  * `collection-status.json` with availability gaps and errors;
  * optional attributed `observations.json`;
  * optional derived conversions and selected source code.
* **Hands off to PitRelay.** It extracts a package safely and, if you have the PitRelay engine, supplies each file to the right engine operation.

## Architecture (deliberately small)

The collector is one Python 3.10+ package running as one process:

* **Collector thread** (`collector.py`). It polls sources through a read-only interface (`sources.py`): local folders, or SFTP via paramiko. The interface has no write, rename, delete or command methods.
* **Store** (`store.py`). A SQLite (WAL) catalog plus one append-only file per capture. An OS-level lock guarantees a single collector per store, and interrupted writes are rolled back at the next start.
* **Local web UI** (`webui.py`, `static/`). It listens on `127.0.0.1` only and serves the Status, Setup and Export pages.
* **CLI** (`cli.py`). Use it for everything else, including verify, extract and the engine handoff.
* **Dependencies:** `paramiko` (SFTP) and `keyring` (OS credential store) only.

A browser UI was chosen over a native toolkit because it needs no extra GUI runtime on Windows or macOS, works when the collector is started at login with no window, and could be exercised end to end in headless Chromium during development.

## Quick start

```bash
pip install .                       # see docs/INSTALL.md for Windows/macOS step by step
pitrelay-collector init             # creates the store; collection and launch-at-login stay OFF
pitrelay-collector run              # starts collecting + opens the UI in your browser
```

In the UI:

1. **Setup:** choose the controller/season, or inspect your robot project folder. Then add sources:
   * a **robot SFTP** source, e.g. addresses `172.22.11.2, 10.TE.AM.2`, user `lvuser`, folders `/home/lvuser/logs` and `/u/logs`;
   * a **local folder** source on the Driver Station laptop for `C:\Users\Public\Documents\FRC\Log Files`.
2. **Status:** click **Enable automatic collection**. On the first robot connection, compare the shown host-key fingerprint and click **Trust**.
3. **Export:** choose recordings, optionally add observations or robot source code, and click **Export for PitRelay**.

Hand the ZIP to PitRelay with `pitrelay-collector extract <zip> <folder>` (see [docs/PITRELAY_HANDOFF.md](docs/PITRELAY_HANDOFF.md)).

## Documentation

| Topic | File |
|---|---|
| Installation and startup on Windows and macOS (and Linux for development) | [docs/INSTALL.md](docs/INSTALL.md) |
| One-time robot logging setup, matched to your season and vendors | [docs/ROBOT_SETUP.md](docs/ROBOT_SETUP.md) |
| Export package format (schema 1.0) | [docs/PACKAGE_SCHEMA.md](docs/PACKAGE_SCHEMA.md) and [samples/pitrelay-collection-sample.zip](samples/pitrelay-collection-sample.zip) |
| Giving packages to PitRelay | [docs/PITRELAY_HANDOFF.md](docs/PITRELAY_HANDOFF.md) |
| How collection decides statuses and handles growth, renames and gaps | [docs/COLLECTION.md](docs/COLLECTION.md) |
| Tests: exact commands, results, what was not verified | [docs/TESTING.md](docs/TESTING.md) |
| Issues found in the PitRelay v11 engine during integration | [../docs/PITRELAY_ENGINE_ISSUES.md](../docs/PITRELAY_ENGINE_ISSUES.md) |

## Safety boundaries (enforced in code)

* Reads **only** the folders you authorize. Filesystem roots, your entire home folder and the collector's own store are refused, also when an authorized path later resolves to one of them. Links inside authorized folders are never followed.
* **Never** writes to, renames or deletes anything on a source. It never runs remote commands, deploys code, or sends robot-control values.
* SFTP host identity is pinned. An unknown or changed key stops the connection **before any password is sent**.
* Passwords live in the OS credential store (Windows Credential Manager or macOS Keychain), never in config, logs or exports.
* Nothing is uploaded anywhere. Packages are private and **not anonymized**.
* Storage quota: when full, collection stops and alerts. **Nothing is deleted automatically.** Local deletion is an explicit, typed-confirmation action that later exports disclose.
* Launch-at-login is off until you explicitly turn it on.
* The local UI listens on 127.0.0.1 only and needs a per-run token sent in a request header; no cookie is used, so other programs on the same computer cannot pick up the session.

## Verification status (summary)

| Area | Status |
|---|---|
| Automated tests (173) on Linux, Python 3.10, 3.11 and 3.13, including real SSH/SFTP to a local test server; 15 of 15 mutation checks killed | **PASS** |
| End-to-end handoff to the supplied PitRelay v11 engine (synthetic voltage fixture: mean 10.8 V, min 6 V) | **PASS** |
| Web UI driven in headless Chromium | **PASS** |
| Windows and macOS installation, launch-at-login, keychain, file sharing | **UNVERIFIED** (not run on those OSes) |
| A real roboRIO/Systemcore, a real Driver Station, real REV/CTRE logs, CTRE Owlet | **UNVERIFIED** (not available; synthetic fixtures only) |

Details are in [docs/TESTING.md](docs/TESTING.md).

## License

No license has been chosen yet; that decision belongs to the project owner. The collector contains no code copied from WPILib, AdvantageScope, REV or CTRE. Their published formats and documentation were read to implement compatible, read-only parsing, and are cited in [docs/ROBOT_SETUP.md](docs/ROBOT_SETUP.md).
