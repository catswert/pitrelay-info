"""Start the real collector app against synthetic sources for a UI check (sandboxed home, fake keychain)."""
from pathlib import Path
import sys, os, json, time, tempfile
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src")); sys.path.insert(0, str(ROOT / "tests"))

from sftp_server import FakeRobotSFTP
from pitrelay_collector.app import App, setup_logging
from pitrelay_collector.autostart import Autostart
from pitrelay_collector.config import ConfigManager, CollectorConfig, SourceConfig
from pitrelay_collector.secrets import MemorySecrets
from pitrelay_collector import synthetic
base = Path(sys.argv[1]); base.mkdir(parents=True, exist_ok=True)
robot = base / "robotfs"; (robot / "home/lvuser/logs").mkdir(parents=True, exist_ok=True)
(robot / "home/lvuser/logs/FRC_TBD_5f3a.wpilog").write_bytes(synthetic.counter_wpilog(3000))
ds = base / "ds"; ds.mkdir(exist_ok=True)
(ds / "2026_10_23 08_00_00 Thu.dslog").write_bytes(synthetic.dslog_v4(1761206400, 500))
(ds / "2026_10_23 08_00_00 Thu.dsevents").write_bytes(synthetic.dsevents_v4(1761206400, ["Info: synthetic"]))
(ds / "voltage_SYNTHETIC.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
(ds / "x.hoot").write_bytes(synthetic.fake_hoot())
srv = FakeRobotSFTP(robot).start()
store = base / "store"
cm = ConfigManager(store); store.mkdir(exist_ok=True)
cfg = CollectorConfig(collection_enabled=False, bandwidth_limit_bps=None, active_window_s=10, complete_after_s=20)
cfg.sources += [SourceConfig(id="src-robot", alias="robot", kind="sftp", hosts=["127.0.0.1"], port=srv.port, username="lvuser",
                             directories=["/home/lvuser/logs", "/u/logs"], poll_interval_s=5, role="robot"),
                SourceConfig(id="src-ds", alias="ds-laptop", kind="local", directories=[str(ds)], poll_interval_s=5, role="driver_station")]
cm.save(cfg)
setup_logging(store, console=False)
app = App(store, secrets=MemorySecrets(), autostart=Autostart(home=base / "fakehome")).open().start(ui=True, port=0)
(base / "url.txt").write_text(app.ui.login_url)
(base / "launch.txt").write_text(app.ui.launch_url())  # what `run`/`open-ui` hand to the browser: a single-use code
print("READY", app.ui.login_url, flush=True)
try:
    app.wait()
finally:
    app.shutdown(); srv.stop()
    print("mutations:", srv.mutations(), "exec:", srv.log.of("exec"), flush=True)
