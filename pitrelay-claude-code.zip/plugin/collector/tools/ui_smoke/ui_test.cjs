const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const http = require("http");
const fs = require("fs");
const url = fs.readFileSync(process.argv[2] + "/url.txt", "utf8").trim();
const launchUrl = fs.readFileSync(process.argv[2] + "/launch.txt", "utf8").trim();
const port = new URL(url).port;
const shots = process.argv[3];
function raw(method, path, headers, body) {
  return new Promise((res) => {
    const r = http.request({ host: "127.0.0.1", port, path, method, headers }, (resp) => {
      let d = ""; resp.on("data", (c) => (d += c)); resp.on("end", () => res([resp.statusCode, d.slice(0, 120)]));
    });
    if (body) r.write(body); r.end();
  });
}
(async () => {
  const out = {};
  out.unauthApi = await raw("GET", "/api/status", { Host: `127.0.0.1:${port}` });
  out.cookieOnly = await raw("GET", "/api/status", { Host: `127.0.0.1:${port}`, Cookie: "pitrelay_session=" + new URL(url).hash.slice(7) });
  out.rebinding = await raw("GET", "/api/status", { Host: `evil.example:${port}` });
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
  await page.goto(launchUrl);  // single-use launch code, exchanged by the page for the session token
  await page.waitForSelector("#state:not(.s-unknown)");
  out.urlAfterLogin = page.url();  // the code must be gone from the address bar
  const reuse = await browser.newPage();
  await reuse.goto(launchUrl);  // the same code a second time: refused
  await reuse.waitForSelector("#signin:not([hidden])");
  out.launchCodeReuseRefused = true;
  await reuse.close();
  await page.waitForSelector("#state:not(.s-unknown)");
  out.state1 = await page.textContent("#state");
  await page.screenshot({ path: `${shots}/1-status-disabled.png`, fullPage: true });
  // A request without the Authorization header (what a cross-site form or another tab could send) is refused
  out.noAuthHeader = await page.evaluate(async () => { const r = await fetch("/api/control", { method: "POST", headers: { "Content-Type": "application/json" }, body: '{"action":"pause"}' }); return r.status; });
  out.cookies = await page.context().cookies();
  await page.click("#btn-enable");
  await page.waitForSelector("text=Trust this key", { timeout: 30000 });
  out.state2 = await page.textContent("#state");
  out.fingerprintShown = await page.textContent(".fingerprint");
  await page.screenshot({ path: `${shots}/2-host-key-confirm.png`, fullPage: true });
  await page.click("text=Trust this key");
  await page.waitForFunction(() => [...document.querySelectorAll(".src .pill")].every((p) => p.textContent === "connected"), null, { timeout: 30000 });
  await page.waitForTimeout(2500);
  out.state3 = await page.textContent("#state");
  out.captures = await page.textContent("#cap-total");
  await page.screenshot({ path: `${shots}/3-status-collecting.png`, fullPage: true });
  await page.click('button[data-tab="setup"]');
  await page.waitForSelector("#sources-list .src");
  await page.click("#btn-new-source");
  await page.selectOption('select[name="role"]', "driver_station");
  await page.click("#btn-suggest");
  await page.waitForTimeout(500);
  out.suggested = await page.inputValue('textarea[name="directories"]');
  await page.screenshot({ path: `${shots}/4-setup.png`, fullPage: true });
  // Limits form: the shown default (e.g. "20.0") and round values must be submittable
  out.quotaShown = await page.inputValue('input[name="quota_gib"]');
  await page.fill('input[name="quota_gib"]', "40");
  await page.fill('input[name="min_free_gib"]', "0.5");
  await page.click('#settings-form button[type="submit"]');
  await page.waitForFunction(() => document.querySelector("#toast").textContent.includes("Limits saved"), null, { timeout: 10000 });
  out.quotaSaved = await page.evaluate(async () => (await (await fetch("/api/config", { headers: { Authorization: "Bearer " + sessionStorage.getItem("pitrelay-collector-token") } })).json()).quota_bytes);
  await page.click('button[data-tab="export"]');
  await page.click("#btn-all");
  await page.waitForSelector("#cap-rows tr td.name");
  out.rows = await page.$$eval("#cap-rows tr", (r) => r.map((x) => x.textContent.replace(/\s+/g, " ").trim()));
  await page.fill("#obs-author", "Synthetic tester");
  await page.fill("#obs-when", "synthetic run, t=2 s");
  await page.fill("#obs-text", "SYNTHETIC: voltage dipped to 6 V in the fixture.");
  await page.click("#btn-add-obs");
  await page.fill("#ex-label", "SYNTHETIC UI TEST - not robot data");
  await page.click("#btn-export");
  await page.waitForSelector(".result", { timeout: 60000 });
  out.exportResult = (await page.textContent(".result")).replace(/\s+/g, " ").slice(0, 400);
  await page.screenshot({ path: `${shots}/5-export-done.png`, fullPage: true });
  const [dl] = await Promise.all([page.waitForEvent("download", { timeout: 20000 }), page.click(".result button.link")]);
  const dlPath = await dl.path();
  out.download = { name: dl.suggestedFilename(), bytes: fs.statSync(dlPath).size, magic: fs.readFileSync(dlPath).subarray(0, 2).toString() };
  const signedOut = await browser.newPage();
  await signedOut.goto(url.split("#")[0]);
  await signedOut.waitForSelector("#signin:not([hidden])");
  out.signedOutPage = (await signedOut.textContent("#signin")).replace(/\s+/g, " ").trim();
  await signedOut.close();
  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await mobile.goto(url);
  await mobile.waitForSelector("#state:not(.s-unknown)");
  out.mobileOverflow = await mobile.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
  await mobile.screenshot({ path: `${shots}/6-mobile.png`, fullPage: true });
  page.on("dialog", (d) => d.accept());
  await page.click('button[data-tab="status"]');
  await page.click("#btn-stop");
  await page.waitForSelector("#offline:not([hidden])", { timeout: 20000 });
  out.afterStop = await page.textContent("#state");
  await page.screenshot({ path: `${shots}/7-stopped.png` });
  out.jsErrors = errors;
  console.log(JSON.stringify(out, null, 1));
  await browser.close();
})().catch((e) => { console.error("FAILED", e); process.exit(1); });
