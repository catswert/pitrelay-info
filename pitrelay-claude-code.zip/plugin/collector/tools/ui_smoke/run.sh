#!/bin/sh
# Browser check of the real web UI against synthetic sources (fake robot SFTP server, fake keychain,
# sandboxed HOME for the autostart toggle). Requires Node.js with Playwright and a Chromium build.
#   PLAYWRIGHT_MODULE=$(npm root -g)/playwright sh tools/ui_smoke/run.sh
set -eu
here="$(cd "$(dirname "$0")" && pwd)"
repo="$here/../.."
work="$(mktemp -d)"
mkdir -p "$work/shots"
"${PYTHON:-$repo/.venv/bin/python}" "$here/launch.py" "$work" > "$work/app.log" 2>&1 &
i=0; while [ ! -f "$work/url.txt" ] && [ $i -lt 60 ]; do sleep 0.5; i=$((i+1)); done
node "$here/ui_test.cjs" "$work" "$work/shots"
sleep 2
tail -1 "$work/app.log"
echo "screenshots: $work/shots"
