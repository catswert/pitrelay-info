"""Re-run the mutation checks quoted in docs/TESTING.md.

Each mutant re-introduces a defect that an independent review found (or that a fix guards against), in a
temporary copy of the project, and runs the tests meant to catch it. Every mutant must be KILLED (tests fail).

    python tools/mutants.py            # targeted tests per mutant (fast)
    python tools/mutants.py --full     # the whole suite per mutant (slow)
"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
C = "src/pitrelay_collector/collector.py"
MUTANTS = [
    ("file changed mid-transfer is committed", C, "                    if again != local_head:", "                    if False:",
     "rewritten_during_a_transfer"),
    ("no rollback of a partial chunk", C, "            out.truncate(offset)\n            out.flush()", "            pass\n            out.flush()",
     "disk_full_in_the_middle"),
    ("same-size rewrite deferred forever", C, '                    self.store.update_capture(cap["id"], observed_mtime=-1.0)\n', "",
     "same_size_rewrite"),
    ("generated collision name reused", "src/pitrelay_collector/export.py", "            while candidate.casefold() in used:",
     "            while False:", "collision_names_never_collide"),
    ("pause ignored inside a chunk", C, "                            if got and self.halted():", "                            if False:",
     "production_size_chunk"),
    ("CLI source edits never synced", C, "        if sig != self._synced_sources:", "        if False:", "sources_added_by_another"),
    ("web UI API without the token", "src/pitrelay_collector/webui.py",
     "                    if not self._auth_ok():\n                        raise ApiError(401", "                    if False:\n                        raise ApiError(401",
     "requires_session_token"),
    ("paramiko prints raw banners", [("src/pitrelay_collector/app.py", "    lib.propagate = False\n    quiet_library_loggers()", "    pass"),
                                     ("src/pitrelay_collector/util.py", '    lib = logging.getLogger("paramiko")\n    if not lib.handlers:',
                                      '    return\n    if False:')], None, None, "hostile_ssh_banner"),
    ("backoff survives a restart", C, "self._failed_signature.get(src.id) == _source_signature(src)",
     "self._failed_signature.get(src.id, _source_signature(src)) == _source_signature(src)", "restart_retries"),
    ("online-only file taken as removed", C, '                        info["online_only_skipped"] += 1\n                        files[e.path] = e',
     '                        info["online_only_skipped"] += 1', "goes_online_only"),
    ("online-only placeholder read", C, '            if e.kind == "online_only":\n', '            if False:\n', "goes_online_only"),
    ("handoff skips the folder check", "src/pitrelay_collector/handoff.py", '    if not check["ok"]:\n        raise HandoffError',
     '    if False:\n        raise HandoffError', "handoff_refuses"),
    ("other store versions touched", "src/pitrelay_collector/cli.py", "    if args.cmd not in STORELESS_COMMANDS:",
     "    if False:", "another_version"),
    ("bandwidth limit ignored", C, "        if not self.rate or n <= 0:\n            return", "        return", "bandwidth_limit"),
    ("deletion hashes before the tombstone", "src/pitrelay_collector/store.py",
     '                w.execute("UPDATE captures SET deleted_at=?, deleted_note=? WHERE id=?", (self.clock.time(), note, cid))',
     '                pass', "racing_the_deletion or full_disk_is_consistent"),
]


def main() -> int:
    full = "--full" in sys.argv
    failures = 0
    for name, rel, old, new, tests in MUTANTS:
        edits = rel if isinstance(rel, list) else [(rel, old, new)]
        with tempfile.TemporaryDirectory() as td:
            dst = Path(td) / "proj"
            shutil.copytree(ROOT, dst, ignore=shutil.ignore_patterns(".git", ".venv", "__pycache__", "build", "*.egg-info"))
            applied = True
            for path, before, after in edits:
                target = dst / path
                text = target.read_text()
                if text.count(before) != 1:
                    applied = False
                    break
                target.write_text(text.replace(before, after))
            if not applied:
                print(f"NOT APPLIED  {name} (the code changed; update this mutant)")
                failures += 1
                continue
            cmd = [sys.executable, "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider", str(dst / "tests")]
            if not full:
                cmd += ["-k", tests]
            env = dict(os.environ, PYTHONPATH=str(dst / "src"))
            r = subprocess.run(cmd, capture_output=True, text=True, cwd=dst, env=env, timeout=1800)
            killed = r.returncode != 0
            failures += not killed
            print(f"{'KILLED  ' if killed else 'SURVIVED'}  {name}")
    print("all mutants killed" if not failures else f"{failures} mutant(s) not killed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
