"""Regenerate samples/pitrelay-collection-sample.zip from SYNTHETIC data.

Everything in the sample is synthetic and labelled as such. It runs the real
collector (local-folder sources, simulated clock) and the real exporter, so the
sample shows genuine statuses, rename history, relationships and limitations.

    python samples/make_sample.py
"""

import datetime
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from pitrelay_collector import synthetic  # noqa: E402
from pitrelay_collector.collector import Collector  # noqa: E402
from pitrelay_collector.config import CollectorConfig, ConfigManager, SourceConfig  # noqa: E402
from pitrelay_collector.export import ExportOptions, export_package  # noqa: E402
from pitrelay_collector.package import verify_package  # noqa: E402
from pitrelay_collector.secrets import MemorySecrets  # noqa: E402
from pitrelay_collector.store import Store  # noqa: E402
from pitrelay_collector.util import FakeClock  # noqa: E402

LABEL = "SYNTHETIC SAMPLE - generated test data, not recorded by any robot"
START = 1_792_756_800  # 2026-10-23T12:00:00Z: the simulated collector clock and synthetic DS log start
DS_NAME = datetime.datetime.fromtimestamp(START, datetime.timezone.utc).strftime("%Y_%m_%d %H_%M_%S %a")


def main() -> int:
    out = Path(__file__).resolve().parent
    work = Path(tempfile.mkdtemp(prefix="pitrelay-sample-"))
    try:
        robot = work / "robot-usb-logs"
        ds = work / "ds-laptop-log-files"
        robot.mkdir()
        ds.mkdir()
        clock = FakeClock(start=float(START))
        store = Store(work / "store", clock).open_owner()
        cm = ConfigManager(work / "store")
        cfg = CollectorConfig(collection_enabled=True, bandwidth_limit_bps=None, active_window_s=60, complete_after_s=300)
        cfg.sources = [
            SourceConfig(id="src-robot", alias="robot", kind="local", role="robot", directories=[str(robot)], poll_interval_s=10),
            SourceConfig(id="src-ds", alias="ds-laptop", kind="local", role="driver_station", directories=[str(ds)],
                         poll_interval_s=10, include_csv=True),
        ]
        cm.save(cfg)
        store.sync_sources(cfg.sources)
        col = Collector(store, cm, clock=clock, secrets=MemorySecrets(), jitter=False)

        def step(n=1):
            for _ in range(n):
                clock.advance(10)
                col.tick(force=True)

        growing = synthetic.counter_wpilog(4000, entry_name="/SyntheticFixture/Counter")
        (robot / "FRC_TBD_6c1f2a.wpilog").write_bytes(growing[:20_000])
        (robot / "voltage_SYNTHETIC.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
        (robot / "SYNTHETIC.revlog").write_bytes(synthetic.revlog_v2())
        (robot / "SYNTHETIC_placeholder.hoot").write_bytes(synthetic.fake_hoot())
        step()
        # DataLogManager-style rename once the Driver Station connects, while the file keeps growing.
        (robot / "FRC_TBD_6c1f2a.wpilog").rename(robot / "FRC_20261023_120010.wpilog")
        with open(robot / "FRC_20261023_120010.wpilog", "ab") as f:
            f.write(growing[20_000:])
        (ds / f"{DS_NAME}.dslog").write_bytes(synthetic.dslog_v4(START, 300))
        (ds / f"{DS_NAME}.dsevents").write_bytes(synthetic.dsevents_v4(START, ["Info: SYNTHETIC event"]))
        (ds / "voltage_SYNTHETIC.csv").write_bytes(b"time_s,voltage\n0,12\n1,12\n2,6\n3,12\n4,12\n")
        step(40)
        # A recording removed from the source before it was fully transferred: a 'partial' capture with a gap.
        cm.update(lambda c: (setattr(c, "chunk_bytes", 64 * 1024), setattr(c, "max_bytes_per_cycle", 64 * 1024)))
        (ds / "SYNTHETIC_removed_early.wpilog").write_bytes(synthetic.counter_wpilog(12_000))
        step()
        (ds / "SYNTHETIC_removed_early.wpilog").unlink()
        step()
        cm.update(lambda c: (setattr(c, "max_bytes_per_cycle", 256 * 1024 * 1024), setattr(c, "chunk_bytes", 4 * 1024 * 1024)))
        # A capture the user deliberately deleted from the local store: listed under omissions with its hash.
        (ds / "SYNTHETIC_scratch.wpilog").write_bytes(synthetic.counter_wpilog(50))
        step()
        scratch = next(c["id"] for c in store.captures() if c["path"].endswith("SYNTHETIC_scratch.wpilog"))
        store.delete_captures([scratch], "SYNTHETIC EXAMPLE: test recording deleted by the user")
        # A recording still being written at export time (an identified prefix).
        (robot / "FRC_20261023_121000.wpilog").write_bytes(synthetic.counter_wpilog(500))
        step()
        voltage_id = next(c["id"] for c in store.captures() if c["path"].endswith("voltage_SYNTHETIC.wpilog"))
        # A tiny synthetic robot project: source files are included, a credential file is excluded.
        project = work / "robot-project"
        (project / "src/main/java/frc/robot").mkdir(parents=True)
        (project / "src/main/java/frc/robot/Robot.java").write_text(
            "// SYNTHETIC SAMPLE robot code\npublic class Robot { /* DataLogManager.start(); */ }\n")
        (project / "build.gradle").write_text('plugins { id "edu.wpi.first.GradleRIO" version "2026.2.1" }\n')
        (project / ".env").write_text("SYNTHETIC_TOKEN=not-a-real-secret\n")
        res = export_package(store, cm.load(), ExportOptions(
            out_dir=work / "out", package_label=LABEL, source_project_dir=project,
            observations=[{"author": "Sample author (synthetic)", "observed_time_as_stated": "about 2 s into the fixture",
                           "text": "SYNTHETIC EXAMPLE: the battery voltage appeared to dip once.",
                           "related_capture_ids": [voltage_id]}]))
        store.close()
        if not res.ok:
            print("export failed:", res.error)
            return 1
        produced = Path(res.archives[0]["path"])
        rep = verify_package(produced)
        assert rep["ok"], rep["errors"]
        target = out / "pitrelay-collection-sample.zip"
        shutil.copyfile(produced, target)
        digest = res.archives[0]["sha256"]
        (out / (target.name + ".sha256")).write_text(f"{digest}  {target.name}\n", encoding="utf-8")
        print(f"wrote {target} ({target.stat().st_size} bytes, {rep['files_checked']} files verified)")
        return 0
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
