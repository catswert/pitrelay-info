# Installs PitRelay Collector for the current user (no administrator rights).
# UNVERIFIED: written for Windows PowerShell 5.1+/PowerShell 7, not executed on Windows for this release.
# It does NOT enable launch at login or automatic collection.
#
# Run it from the project folder with (the default execution policy blocks unsigned scripts):
#   powershell -NoProfile -ExecutionPolicy Bypass -File scripts\install-windows.ps1
$ErrorActionPreference = "Stop"

function Invoke-Checked([string]$what, [scriptblock]$command) {
    # Windows PowerShell 5.1 does not stop on a failing native program, so check its exit code explicitly.
    & $command
    if ($LASTEXITCODE -ne 0) { throw "$what failed (exit code $LASTEXITCODE)" }
}

$project = Split-Path -Parent $PSScriptRoot
$venv = Join-Path $env:LOCALAPPDATA "PitRelayCollector\venv"

# Pick a Python 3.10 or later (the py launcher may default to an older 3.x).
$python = $null
foreach ($v in @("3.13", "3.12", "3.11", "3.10")) {
    & py "-$v" -c "import sys" 2>$null
    if ($LASTEXITCODE -eq 0) { $python = @("py", "-$v"); break }
}
if (-not $python) { throw "Python 3.10 or later is required. Install it from python.org (tick 'Add python.exe to PATH') and run this again." }

Invoke-Checked "Creating the virtual environment" { & $python[0] $python[1] -m venv $venv }
$py = Join-Path $venv "Scripts\python.exe"
Invoke-Checked "Upgrading pip" { & $py -m pip install --upgrade pip }
Invoke-Checked "Installing PitRelay Collector" { & $py -m pip install $project }
Invoke-Checked "Creating the store" { & (Join-Path $venv "Scripts\pitrelay-collector.exe") init }
Write-Host ""
Write-Host "Installed. Start it with:"
Write-Host "  & `"$venv\Scripts\pitrelay-collector.exe`" run"
