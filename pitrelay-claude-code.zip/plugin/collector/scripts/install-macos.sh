#!/bin/sh
# Installs PitRelay Collector for the current user.
# UNVERIFIED: written for macOS with python.org or Homebrew Python 3.10+, not executed on macOS for this release.
# It does NOT enable launch at login or automatic collection.
set -eu
project="$(cd "$(dirname "$0")/.." && pwd)"
venv="$HOME/Library/Application Support/PitRelayCollector/venv"
python3 -m venv "$venv"
"$venv/bin/python" -m pip install --upgrade pip
"$venv/bin/python" -m pip install "$project"
"$venv/bin/pitrelay-collector" init
echo
echo "Installed. Start it with:"
echo "  \"$venv/bin/pitrelay-collector\" run"
