"""Read-only inspection of a robot project the user explicitly selects.

Two jobs:

1. Detect the season, vendor libraries and logging calls so the collector can
   explain the one-time logging setup that matches *that* project's versions
   (not whatever documentation is newest).
2. Choose which source files may be included in an export: ordinary source
   and build-description files only, never credentials, build outputs, VCS
   metadata or links. Nothing found here is ever executed.

Guidance statements cite the documentation revision they were checked against
(see docs/ROBOT_SETUP.md). They describe what to configure; the collector never
edits or deploys robot code.
"""

from __future__ import annotations

import fnmatch
import json
import os
import re
from pathlib import Path

from .sources import is_link_like

SOURCE_EXTS = {".java", ".kt", ".kts", ".cpp", ".cc", ".c", ".h", ".hpp", ".py", ".gradle", ".json", ".toml", ".yaml", ".yml"}
SKIP_DIRS = {".git", ".gradle", "build", "bin", "out", ".idea", ".vscode", "node_modules", "__pycache__", ".venv", "venv",
             "logs", "ctre_sim", "simgui", "networktables", ".pytest_cache"}
ALLOWED_HIDDEN_DIRS = {".wpilib"}
EXCLUDED_NAMES = ["gradle.properties", "local.properties", ".env", ".env.*", "*.env", "*secret*", "*credential*",
                  "*password*", "*token*", "*.pem", "*.key", "*.p12", "*.pfx", "*.jks", "*.keystore", "id_rsa*",
                  "id_ed25519*", "id_ecdsa*", ".netrc", "*.wpilog", "*.hoot", "*.revlog"]
CREDENTIAL_PATTERNS = [
    ("private key block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("GitHub token", re.compile(r"\b(ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}\b|\bgithub_pat_[A-Za-z0-9_]{20,}")),
    ("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("Slack token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}")),
    ("API secret key", re.compile(r"\bsk-[A-Za-z0-9_-]{20,}")),
    # A credential-like name (also inside longer names: dbPassword, ROBOT_PASSWORD, kTbaAuthKey), optionally
    # quoted as a JSON/YAML key, assigned a value of 6+ characters (JSON, YAML, TOML, code). A quoted value runs to
    # its closing quote, whatever punctuation it holds; an unquoted one stops at code punctuation. The name starts
    # after a non-word character and its parts are bounded, so a long run of word characters is scanned in linear
    # time (an unanchored, unbounded prefix made the scan quadratic).
    ("assigned password/secret/key value", re.compile(
        r"(?i)(?<![A-Za-z0-9_])[A-Za-z0-9_]{0,64}?(?:password|passwd|passphrase|pwd|secret|api[_-]?key|access[_-]?key"
        r"|access[_-]?token|auth[_-]?(?:token|key)|private[_-]?key|token|bearer)[A-Za-z0-9_]{0,64}[\"']?\s*[:=]\s*"
        r"(?:\"[^\"\n]{6,}\"|'[^'\n]{6,}'|[^\"'\s,;{}()]{6,})")),
    # Short names that would match too much as parts of longer names (bypass, compass), only as whole keys.
    ("assigned pw/pass value", re.compile(
        r"(?i)(?<![A-Za-z0-9_])[\"']?(?:pw|pass)[\"']?\s*[:=]\s*(?:\"[^\"\n]{4,}\"|'[^'\n]{4,}'|[^\"'\s,;{}()]{6,})")),
    ("registry auth value", re.compile(r"(?i)[\"']auth[\"']\s*:\s*[\"'][A-Za-z0-9+/]{8,}={0,2}[\"']")),  # Docker config.json
    ("key or certificate data", re.compile(r"(?i)\b[a-z-]*(?:key|certificate|token)-data\s*:\s*[A-Za-z0-9+/=]{20,}")),  # kubeconfig
]
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_TOTAL_BYTES = 50 * 1024 * 1024
MAX_FILES = 5000

DOC_CITATIONS = {
    "wpilib_2025": "WPILib frc-docs branch 2025, source/docs/software/telemetry/datalog.rst and datalog-download.rst",
    "wpilib_2026": "allwpilib tag v2026.2.2, wpilibj/src/main/java/edu/wpi/first/wpilibj/DataLogManager.java (Javadoc)",
    "wpilib_2027": "WPILib frc-docs branch 2027/main, source/docs/software/telemetry/datalog-download.rst",
    "ctre_2025": "CTRE Phoenix6-Documentation tag 2025, source/docs/api-reference/api-usage/signal-logging.rst",
    "ctre_2026": "CTRE Phoenix6-Documentation main (2026 at the time checked), source/docs/api-reference/api-usage/signal-logging.rst",
    "akit": "AdvantageKit main (checked 2026-10), akit/src/main/java/org/littletonrobotics/junction/wpilog/WPILOGWriter.java",
    "rev": "REV @rev-robotics/revlog-converter 2.0.0 README (REVLOG v1 = REVLib 2025 to 2027.0.0-alpha-8)",
    "ni_ds": "WPILib frc-docs branch 2025, source/docs/software/driverstation/driver-station-log-viewer.rst",
    "first_ds": "WPILib frc-docs main, source/docs/software/firstdriverstation/first-driver-station-log-viewer.rst",
}


def _excluded_by_name(name: str) -> str | None:
    low = name.lower()
    for pattern in EXCLUDED_NAMES:
        if fnmatch.fnmatchcase(low, pattern):
            return f"file name matches excluded pattern {pattern!r} (credentials, local config or logs)"
    return None


def _credential_hit(text: str) -> str | None:
    for label, rx in CREDENTIAL_PATTERNS:
        if rx.search(text):
            return f"possible credential detected ({label}); excluded without copying"
    return None


def _is_link(path: Path) -> bool:
    """Symbolic links, and on Windows also directory junctions and other path-redirecting reparse points."""
    is_junction = getattr(path, "is_junction", None)  # Python 3.12+
    try:
        st = os.lstat(path)
    except OSError:
        return True  # cannot tell: do not follow
    return is_link_like(st, path.is_symlink(), bool(is_junction and is_junction()))


PROJECT_MARKERS = ("build.gradle", "build.gradle.kts", ".wpilib", "vendordeps", "robot.py")


def project_root_problem(root: Path) -> str | None:
    """Why `root` is not a robot project folder that may be included in a package, or None.

    Source code is read only from a folder that looks like a robot project, never from a filesystem root, the home
    folder or a folder above it, or a hidden folder (.ssh, .docker, ...)."""
    root = Path(root)
    try:
        real = root.resolve(strict=True)
    except OSError:
        return "the folder does not exist or cannot be read"
    if not real.is_dir():
        return "it is not a folder"
    if real == Path(real.anchor):
        return "it is a whole drive or filesystem root"
    home = Path.home().resolve()
    if real == home or real in home.parents:
        return "it is your home folder or a folder that contains it"
    if any(part.startswith(".") for part in real.relative_to(real.anchor).parts):
        return "it is a hidden folder or inside one"
    if not any((real / m).exists() for m in PROJECT_MARKERS) and not _robotpy_project(real):
        return ("it does not look like a robot project (no build.gradle, .wpilib, vendordeps, robot.py, or "
                "pyproject.toml naming robotpy)")
    return None


def _robotpy_project(root: Path) -> bool:
    try:
        text = (root / "pyproject.toml").read_text(encoding="utf-8", errors="replace")[:200_000]
    except OSError:
        return False
    return "robotpy" in text.lower()


def select_source_files(root: Path) -> tuple[list[dict], list[dict]]:
    """Return (included, excluded). included: {rel, path, size}; excluded: {rel, reason}."""
    root = Path(root)
    if not root.is_dir():
        raise ValueError(f"Not a folder: {root}")
    included: list[dict] = []
    excluded: list[dict] = []
    total = 0
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        rel_dir = Path(dirpath).relative_to(root)
        keep = []
        for d in sorted(dirnames):
            full = Path(dirpath) / d
            rel = (rel_dir / d).as_posix()
            if _is_link(full):
                excluded.append({"rel": rel + "/", "reason": "symbolic link or junction (not followed)"})
            elif d in SKIP_DIRS or (d.startswith(".") and d not in ALLOWED_HIDDEN_DIRS):
                excluded.append({"rel": rel + "/", "reason": "build output, VCS metadata, cache or hidden folder"})
            else:
                keep.append(d)
        dirnames[:] = keep
        for name in sorted(filenames):
            full = Path(dirpath) / name
            rel = (rel_dir / name).as_posix()
            if _is_link(full):
                excluded.append({"rel": rel, "reason": "symbolic link or junction (not followed)"})
                continue
            reason = _excluded_by_name(name)  # disclosed even for non-source types (e.g. .env, id_rsa)
            if reason is None and os.path.splitext(name)[1].lower() not in SOURCE_EXTS:
                continue  # silently ignore unrelated file types (not counted as exclusions)
            if reason is None:
                size = full.stat().st_size
                if size > MAX_FILE_BYTES:
                    reason = f"larger than {MAX_FILE_BYTES} bytes"
                elif len(included) >= MAX_FILES or total + size > MAX_TOTAL_BYTES:
                    reason = "source selection size limit reached"
                else:
                    try:
                        text = full.read_bytes().decode("utf-8", errors="replace")
                    except OSError as e:
                        reason = f"unreadable: {e.__class__.__name__}"
                    else:
                        reason = _credential_hit(text)
            if reason:
                excluded.append({"rel": rel, "reason": reason})
                continue
            included.append({"rel": rel, "path": str(full), "size": size})
            total += size
    return included, excluded


_GRADLERIO = re.compile(r"GradleRIO[\"'\)]*\s*version\s*[\"']([^\"']+)[\"']")
CALLS = {
    "wpilib_datalog": re.compile(r"DataLogManager\s*(\.|::)\s*[Ss]tart\b"),
    "ds_datalog": re.compile(r"DriverStation\s*(\.|::)\s*[Ss]tart_?[Dd]ata_?[Ll]og\b"),
    "akit_logger_start": re.compile(r"\bLogger\s*\.\s*start\s*\("),
    "akit_wpilog_writer": re.compile(r"\bWPILOGWriter\b"),
    "ctre_start": re.compile(r"SignalLogger\s*(\.|::)\s*[Ss]tart\s*\("),
    "ctre_set_path": re.compile(r"SignalLogger\s*(\.|::)\s*[Ss]et_?[Pp]ath\s*\(\s*\"([^\"]*)\""),
    "ctre_auto_off": re.compile(r"SignalLogger\s*(\.|::)\s*[Ee]nable_?[Aa]uto_?[Ll]ogging\s*\(\s*(false|False)"),
    "rev_status_logger": re.compile(r"\bStatusLogger\b"),
    "urcl": re.compile(r"\bURCL\s*\.\s*start\b"),
    "epilogue": re.compile(r"@Logged\b|\bEpilogue\s*\.\s*bind\b"),
}


def inspect_project(root: Path) -> dict:
    """Detect versions and logging configuration; return facts plus setup guidance."""
    root = Path(root)
    facts: dict = {"root_name": root.name, "wpilib_version": None, "season": None, "language": None, "team_number_present": False,
                   "vendordeps": [], "calls": {}, "ctre_paths": [], "scanned_files": 0}
    for build in ("build.gradle", "build.gradle.kts"):
        p = root / build
        if p.is_file() and not p.is_symlink():
            m = _GRADLERIO.search(p.read_text(encoding="utf-8", errors="replace"))
            if m:
                facts["wpilib_version"] = m.group(1)
                if re.match(r"^\d{4}", m.group(1)):
                    facts["season"] = int(m.group(1)[:4])
    prefs = root / ".wpilib" / "wpilib_preferences.json"
    if prefs.is_file() and not prefs.is_symlink():
        try:
            data = json.loads(prefs.read_text(encoding="utf-8"))
            facts["language"] = data.get("currentLanguage")
            facts["team_number_present"] = "teamNumber" in data
            if facts["season"] is None and str(data.get("projectYear", "")).isdigit():
                facts["season"] = int(data["projectYear"])
        except (OSError, ValueError):
            pass
    vd = root / "vendordeps"
    if vd.is_dir():
        for p in sorted(vd.glob("*.json")):
            if p.is_symlink():
                continue
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                facts["vendordeps"].append({"name": str(data.get("name"))[:80], "version": str(data.get("version"))[:40],
                                            "frcYear": data.get("frcYear")})
            except (OSError, ValueError):
                facts["vendordeps"].append({"name": p.name, "version": None, "error": "unreadable vendordep JSON"})
    included, _ = select_source_files(root)
    for item in included:
        if not item["rel"].endswith((".java", ".kt", ".cpp", ".cc", ".h", ".hpp", ".py")):
            continue
        facts["scanned_files"] += 1
        text = Path(item["path"]).read_text(encoding="utf-8", errors="replace")
        for key, rx in CALLS.items():
            for m in rx.finditer(text):
                facts["calls"].setdefault(key, []).append(item["rel"])
                if key == "ctre_set_path":
                    facts["ctre_paths"].append(m.group(2)[:200])
                break
    return {"facts": facts, "profile": _profile(facts), "guidance": _guidance(facts)}


def _has_vendordep(facts, *needles) -> dict | None:
    for v in facts["vendordeps"]:
        name = (v.get("name") or "").lower()
        if any(n in name for n in needles):
            return v
    return None


def _profile(facts) -> dict:
    season = facts["season"]
    calls = facts["calls"]
    return {
        "controller": "systemcore" if season and season >= 2027 else (None if season is None else "roborio (1 or 2: not detectable from code)"),
        "season": season,
        "wpilib_datalog": bool(calls.get("wpilib_datalog")),
        "advantagekit": bool(_has_vendordep(facts, "advantagekit") or calls.get("akit_logger_start")),
        "rev_status_logger": None if not _has_vendordep(facts, "revlib") else "revlib present; logging behavior not asserted",
        "ctre_signal_logger": None if not _has_vendordep(facts, "phoenix (v6)", "phoenix6", "phoenix 6") else
        ("explicit start" if calls.get("ctre_start") else "automatic (version-dependent)"),
    }


def _guidance(facts) -> list[dict]:
    g: list[dict] = []
    season = facts["season"]
    calls = facts["calls"]
    akit = _has_vendordep(facts, "advantagekit") or calls.get("akit_logger_start")

    def add(level, topic, text, cite, snippet=None):
        item = {"level": level, "topic": topic, "text": text, "documentation": DOC_CITATIONS[cite]}
        if snippet:
            item["proposed_snippet_not_applied"] = snippet
        g.append(item)

    if season is None:
        add("warning", "season", "The WPILib/GradleRIO version could not be read from build.gradle, so version-specific "
            "guidance below may not match this robot. Select the season manually in Setup.", "wpilib_2025")
    if season is not None and season >= 2027:
        add("info", "controller", "A 2027 project targets Systemcore. WPILib's 2027 documentation lists log folders "
            "/home/systemcore/logs or /u/logs, SFTP user 'systemcore' (password 'systemcore'), and the file prefix WPILib_ "
            "instead of FRC_.", "wpilib_2027")
    if not calls.get("wpilib_datalog") and not akit:
        add("action", "wpilib_datalog",
            "No DataLogManager.start() or AdvantageKit logger was found. WPILib documents that by default no telemetry is "
            "recorded on the robot, so there may be no .wpilog files to collect. One-time setup (your team's decision; the "
            "collector never edits or deploys code): start DataLogManager in the Robot constructor or robotInit, and "
            "optionally record DS/joystick data.", "wpilib_2026" if season == 2026 else "wpilib_2025",
            snippet="DataLogManager.start();\nDriverStation.startDataLog(DataLogManager.getLog());")
    elif calls.get("wpilib_datalog"):
        add("info", "wpilib_datalog", "DataLogManager is started. On a roboRIO it writes to a USB drive's logs folder if one "
            "is attached, otherwise /home/lvuser/logs. Files start as FRC_TBD_*.wpilog and are renamed once the DS connects; "
            "the collector follows that rename. DataLogManager deletes FRC_TBD files at startup and old FRC_ files when space "
            "is low, so collect promptly.", "wpilib_2026" if season == 2026 else "wpilib_2025")
        if not calls.get("ds_datalog"):
            add("info", "ds_datalog", "DriverStation.startDataLog(...) was not found; DataLogManager does not record "
                "joystick data by default.", "wpilib_2025")
    if akit:
        add("info", "advantagekit", "AdvantageKit's WPILOGWriter writes to /U/logs on the robot by default (renaming "
            "akit_*.wpilog files once the time is known). Add /U/logs as an authorized folder.", "akit")
    ctre = _has_vendordep(facts, "phoenix (v6)", "phoenix6", "phoenix 6")
    if ctre:
        if calls.get("ctre_auto_off") and not calls.get("ctre_start"):
            add("action", "ctre_signal_logger", "SignalLogger.enableAutoLogging(false) is called and SignalLogger.start() "
                "was not found, so Phoenix 6 may produce no .hoot files.", "ctre_2026")
        elif season is not None and season <= 2025 and not calls.get("ctre_start"):
            add("info", "ctre_signal_logger", "Phoenix 6 (2025 docs): signal logging starts automatically only during an "
                "FRC match. Practice sessions are not logged unless SignalLogger.start() is called.", "ctre_2025")
        elif season == 2026:
            add("info", "ctre_signal_logger", "Phoenix 6 (2026 docs): logging is enabled by default on a roboRIO 2, or a "
                "roboRIO 1 with a USB drive, once the robot is enabled or the DS connects.", "ctre_2026")
        paths = [p for p in facts["ctre_paths"] if p.startswith("/")]
        add("info", "ctre_paths", "Each CAN bus gets its own .hoot file inside a date/time subfolder, so use a recursive "
            "depth of at least 1. " + (f"SignalLogger.setPath() targets: {', '.join(paths)}. Add them as authorized folders."
                                       if paths else "No absolute setPath() target was found; the CTRE documentation checked "
                                       "does not state the default folder, so confirm it on the robot."), "ctre_2026")
        add("info", "ctre_conversion", ".hoot files need CTRE's Owlet (or Tuner X) to convert. The collector preserves them "
            "either way and only runs an Owlet you install and configure yourself.", "ctre_2026")
    if _has_vendordep(facts, "revlib"):
        add("info", "rev_status_logger", "REVLib is present. REV's StatusLogger writes .revlog files (format v1 from REVLib "
            "2025). REV's documentation site could not be retrieved for this release, so the collector does not assert when "
            "it logs or where; check the REVLib documentation for your version and add that folder.", "rev")
    if season is not None and season >= 2027:
        add("info", "driver_station", "The FIRST Driver Station (2027) writes .wpilog files to Public "
            "Documents\\FIRSTDriverStation\\Logs (Windows) or ~/.firstds; legacy .dslog/.dsevents are not produced.", "first_ds")
    else:
        add("info", "driver_station", "The NI Driver Station writes .dslog/.dsevents pairs to C:\\Users\\Public\\Documents\\"
            "FRC\\Log Files on the Driver Station laptop. Add it as a local folder source on that laptop.", "ni_ds")
    return g
