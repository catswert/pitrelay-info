"""Durable local store: catalog (SQLite, WAL) plus append-only capture files.

Layout of a store directory::

    config.json            collector configuration (no secrets)
    state.sqlite3          catalog: captures, hashed segments, events, availability
    captures/<source_id>/<capture_id>.bin
                           original bytes, append-only; only [0, committed_size) counts
    exports/               default export destination
    diagnostics/           rotating collector log (never contains credentials)
    collector.lock         single-owner OS lock

Integrity model
---------------
A capture's bytes become *committed* only after (1) they are written and fsynced
to the capture file and then (2) a segment row with offset, length and SHA-256
is committed to the catalog in the same transaction that advances
``committed_size``. Bytes past ``committed_size`` are uncommitted and are
truncated during recovery. Committed bytes are never rewritten; a later
version of a remote file becomes a new capture. Export re-verifies every
segment hash, so silent modification of the local store is detected.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

from .formats import ANALYZER_VERSION
from .lock import ExportsBusy, ReadersLock, StoreLock
from .util import Clock, printable

log = logging.getLogger("pitrelay_collector")

STORE_SCHEMA_VERSION = 1
EVENT_LEVELS = ("debug", "info", "warning", "error")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sources(
  source_id TEXT PRIMARY KEY, alias TEXT NOT NULL, kind TEXT NOT NULL, role TEXT NOT NULL,
  public_json TEXT NOT NULL, first_configured REAL NOT NULL, last_configured REAL NOT NULL, removed_at REAL);
CREATE TABLE IF NOT EXISTS captures(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id TEXT NOT NULL,
  path TEXT NOT NULL,
  original_name TEXT NOT NULL,
  names_json TEXT NOT NULL,
  presence TEXT NOT NULL,
  first_seen REAL NOT NULL,
  last_seen REAL NOT NULL,
  missing_since REAL,
  first_acquired REAL,
  last_acquired REAL,
  committed_size INTEGER NOT NULL DEFAULT 0,
  observed_size INTEGER NOT NULL,
  max_observed_size INTEGER NOT NULL,
  observed_mtime REAL,
  last_change REAL NOT NULL,
  quiet_s REAL NOT NULL DEFAULT 0,
  reconnects_since_change INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  status_reasons_json TEXT NOT NULL,
  checks_json TEXT NOT NULL,
  flags_json TEXT NOT NULL DEFAULT '{}',
  predecessor_id INTEGER,
  file_id TEXT,
  data_file TEXT NOT NULL,
  deleted_at REAL,
  deleted_note TEXT,
  error TEXT);
DROP INDEX IF EXISTS captures_present_path;
CREATE UNIQUE INDEX IF NOT EXISTS captures_present_path_v2 ON captures(source_id, path)
  WHERE presence = 'present' AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS captures_source ON captures(source_id, presence);
CREATE TABLE IF NOT EXISTS segments(
  capture_id INTEGER NOT NULL, seq INTEGER NOT NULL, offset INTEGER NOT NULL, length INTEGER NOT NULL,
  sha256 TEXT NOT NULL, acquired_at REAL NOT NULL, checks TEXT NOT NULL,
  PRIMARY KEY(capture_id, seq));
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, t REAL NOT NULL, level TEXT NOT NULL, kind TEXT NOT NULL,
  source_id TEXT, capture_id INTEGER, message TEXT NOT NULL, data_json TEXT);
CREATE INDEX IF NOT EXISTS events_t ON events(t);
CREATE TABLE IF NOT EXISTS source_state(
  source_id TEXT PRIMARY KEY, state TEXT NOT NULL, since REAL, last_attempt REAL, last_success REAL,
  last_error TEXT, failures INTEGER NOT NULL DEFAULT 0, next_attempt REAL, pending_host_key_json TEXT,
  connected_host TEXT, dirs_json TEXT);
CREATE TABLE IF NOT EXISTS availability(
  id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT NOT NULL, start REAL NOT NULL, end REAL);
CREATE TABLE IF NOT EXISTS runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, started REAL NOT NULL, heartbeat REAL NOT NULL, ended REAL);
CREATE TABLE IF NOT EXISTS format_cache(
  capture_id INTEGER PRIMARY KEY, size INTEGER NOT NULL, info_json TEXT NOT NULL);
"""

CAPTURE_JSON_FIELDS = ("names_json", "status_reasons_json", "checks_json", "flags_json")


class StoreError(RuntimeError):
    pass


class CaptureDeleted(StoreError):
    """The user deleted this capture while it was being collected; stop appending to it."""


class Store:
    def __init__(self, root: Path, clock: Clock | None = None):
        self.root = Path(root)
        self.clock = clock or Clock()
        self.lock = StoreLock(self.root)
        self.db_path = self.root / "state.sqlite3"
        self.owner = False
        self.run_id: int | None = None
        self._local = threading.local()
        self._conns: list[tuple[threading.Thread, sqlite3.Connection]] = []
        self._conns_lock = threading.Lock()
        self._write_lock = threading.RLock()
        self._usage: int = 0
        self.readers_lock = ReadersLock(self.root)

    # --- lifecycle ---------------------------------------------------------

    @staticmethod
    def ensure_layout(root: Path) -> None:
        root = Path(root)
        for sub in ("", "captures", "exports", "diagnostics"):
            d = root / sub
            d.mkdir(parents=True, exist_ok=True)
            if os.name == "posix":
                try:
                    os.chmod(d, 0o700)
                except OSError:
                    pass
        if os.name == "nt":  # pragma: no cover - Windows only
            marker = root / ".owner-only"
            if not marker.exists():
                problem = restrict_to_current_user(root)
                if problem is None:
                    marker.write_text("permissions restricted to the current user and SYSTEM\n", encoding="utf-8")
                else:
                    log.warning("could not restrict store permissions: %s", problem)

    @classmethod
    def create(cls, root: Path, clock: Clock | None = None) -> None:
        """Create the layout and an empty catalog without recording a collector run."""
        store = cls(root, clock)
        store.check_version()  # never run this version's schema statements on a store from another version
        cls.ensure_layout(store.root)
        store.lock.acquire()
        try:
            store.owner = True
            store.conn().executescript(_SCHEMA)
            with store.write() as w:
                if store._meta_get(w, "schema_version") is None:
                    store._meta_set(w, "schema_version", str(STORE_SCHEMA_VERSION))
                    store._meta_set(w, "store_id", os.urandom(8).hex())
                    store._meta_set(w, "created_at", repr(store.clock.time()))
        finally:
            store.run_id = None
            store.close()

    def check_version(self) -> None:
        """Refuse a store written by an incompatible collector version (a missing store is fine)."""
        if not self.db_path.exists():
            return
        try:
            if str(self.db_path).startswith(("\\\\", "//")):  # a network share has no file URI SQLite accepts
                c = sqlite3.connect(str(self.db_path), timeout=30)
                c.execute("PRAGMA query_only=ON")
            else:  # as_uri() percent-encodes '#', '?' and '%', which would otherwise end the path and open another file
                c = sqlite3.connect(self.db_path.absolute().as_uri() + "?mode=ro", uri=True, timeout=30)
            try:
                row = c.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
            finally:
                c.close()
        except sqlite3.Error as e:
            raise StoreError(f"The collector store at {self.root} cannot be read: {e}") from None
        if row is not None and row[0] != str(STORE_SCHEMA_VERSION):
            raise StoreError("Store schema version is not supported by this collector version; nothing was changed")

    def open_owner(self) -> "Store":
        """Become the single writer for this store and recover from interruption."""
        self.check_version()
        self.ensure_layout(self.root)
        self.lock.acquire()
        try:
            self.owner = True
            c = self.conn()
            c.executescript(_SCHEMA)
            with self.write() as w:
                if self._meta_get(w, "schema_version") is None:
                    self._meta_set(w, "schema_version", str(STORE_SCHEMA_VERSION))
                    self._meta_set(w, "store_id", os.urandom(8).hex())
                    self._meta_set(w, "created_at", repr(self.clock.time()))
                elif int(self._meta_get(w, "schema_version")) != STORE_SCHEMA_VERSION:
                    raise StoreError("Store schema version is not supported by this collector version")
            self._recover()
            now = self.clock.time()
            with self.write() as w:
                self.run_id = w.execute("INSERT INTO runs(started, heartbeat) VALUES(?, ?)", (now, now)).lastrowid
            self._usage = self._committed_total()
        except BaseException:
            self.close()
            raise
        return self

    def open_reader(self) -> "Store":
        """Read-only use (e.g. a CLI export while the collector runs)."""
        if not self.db_path.exists():
            raise StoreError(f"No collector store found at {self.root}")
        self.owner = False
        try:
            version = self._meta_get(self.conn(), "schema_version")
        except sqlite3.Error as e:
            self.close()
            raise StoreError(f"The collector store at {self.root} cannot be read: {e}") from None
        if version is not None and version != str(STORE_SCHEMA_VERSION):
            self.close()
            raise StoreError("Store schema version is not supported by this collector version; it was not read")
        return self

    def close(self) -> None:
        if self.owner and self.run_id is not None:
            try:
                with self.write() as w:
                    now = self.clock.time()
                    w.execute("UPDATE runs SET heartbeat=?, ended=? WHERE id=?", (now, now, self.run_id))
                    w.execute("UPDATE availability SET end=? WHERE end IS NULL", (now,))
            except sqlite3.Error:
                pass
        with self._conns_lock:
            for _, c in self._conns:
                try:
                    c.close()
                except sqlite3.Error:
                    pass
            self._conns.clear()
        self._local = threading.local()
        if self.owner:
            self.lock.release()
        self.owner = False
        self.run_id = None

    def conn(self) -> sqlite3.Connection:
        c = getattr(self._local, "conn", None)
        if c is None:
            c = sqlite3.connect(str(self.db_path), timeout=30, isolation_level=None, check_same_thread=False)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA busy_timeout=30000")
            if self.owner:
                c.execute("PRAGMA journal_mode=WAL")
                c.execute("PRAGMA synchronous=FULL")
            c.execute("PRAGMA foreign_keys=ON")
            self._local.conn = c
            with self._conns_lock:
                # Request threads (web UI) come and go; close connections whose thread has ended
                # so a long-running collector does not accumulate open database handles.
                alive = []
                for t, old in self._conns:
                    if t.is_alive():
                        alive.append((t, old))
                    else:
                        try:
                            old.close()
                        except sqlite3.Error:
                            pass
                alive.append((threading.current_thread(), c))
                self._conns = alive
        return c

    @contextmanager
    def write(self):
        if not self.owner:
            raise StoreError("This store was opened read-only")
        with self._write_lock:
            c = self.conn()
            c.execute("BEGIN IMMEDIATE")
            try:
                yield c
            except BaseException:
                c.execute("ROLLBACK")
                raise
            else:
                c.execute("COMMIT")

    @contextmanager
    def snapshot(self):
        """A consistent read snapshot (WAL read transaction)."""
        c = self.conn()
        c.execute("BEGIN")
        try:
            yield c
        finally:
            c.execute("COMMIT")

    # --- meta --------------------------------------------------------------

    @staticmethod
    def _meta_get(c, key):
        row = c.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return None if row is None else row[0]

    @staticmethod
    def _meta_set(c, key, value):
        c.execute("INSERT INTO meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))

    def meta_get(self, key: str, default=None):
        v = self._meta_get(self.conn(), key)
        return default if v is None else v

    def meta_set(self, key: str, value: str) -> None:
        with self.write() as w:
            self._meta_set(w, key, value)

    def post_request(self, key: str, value: str, kind: str, message: str) -> None:
        """A request from another process to the owner, through the catalog (works on a read-only open, as the
        CLI's pause does): for example 'paused' or 'poll_request'. The owner acts on it at its next check."""
        c = self.conn()
        c.execute("INSERT INTO meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                  (key, value))
        c.execute("INSERT INTO events(t, level, kind, message) VALUES(?, 'info', ?, ?)", (self.clock.time(), kind, message))

    # --- recovery ----------------------------------------------------------

    def _recover(self) -> None:
        c = self.conn()
        now = self.clock.time()
        last = c.execute("SELECT id, heartbeat, ended FROM runs ORDER BY id DESC LIMIT 1").fetchone()
        if last is not None and last["ended"] is None:
            with self.write() as w:
                w.execute("UPDATE runs SET ended=? WHERE id=?", (last["heartbeat"], last["id"]))
                w.execute("UPDATE availability SET end=? WHERE end IS NULL", (last["heartbeat"],))
            self.add_event("warning", "unclean_shutdown",
                           "The previous collector run ended without a clean shutdown; nothing was observed between its "
                           "last heartbeat and this start.", data={"last_heartbeat": last["heartbeat"], "restart": now})
        else:
            with self.write() as w:
                w.execute("UPDATE availability SET end=? WHERE end IS NULL", (now,))
        for row in c.execute("SELECT * FROM captures WHERE deleted_at IS NOT NULL").fetchall():
            self._finish_deletion(self._row_to_capture(row))  # a deletion interrupted by a crash or a full disk
        rows = c.execute("SELECT * FROM captures WHERE deleted_at IS NULL").fetchall()
        for row in rows:
            cap = self._row_to_capture(row)
            path = self.data_path(cap)
            doomed = path.with_name(path.name + ".deleting")
            if doomed.exists() and not path.exists():
                doomed.rename(path)  # a deletion that was refused or undone: the capture keeps its bytes
            committed = cap["committed_size"]
            if not path.exists():
                if committed > 0:
                    self._mark_damaged(cap, "capture file is missing from the store")
                continue
            size = path.stat().st_size
            if size > committed:
                with open(path, "r+b") as f:
                    f.truncate(committed)
                    f.flush()
                    os.fsync(f.fileno())
                self.add_event("info", "recovered_uncommitted", f"Discarded {size - committed} uncommitted bytes after interruption; "
                               "they will be fetched again if still available.", source_id=cap["source_id"], capture_id=cap["id"],
                               data={"discarded_bytes": size - committed})
            elif size < committed:
                self._mark_damaged(cap, f"capture file has {size} bytes but {committed} were committed")
                continue
            seg = c.execute("SELECT * FROM segments WHERE capture_id=? ORDER BY seq DESC LIMIT 1", (cap["id"],)).fetchone()
            if seg is not None:
                with open(path, "rb") as f:
                    f.seek(seg["offset"])
                    digest = _sha256_stream(f, seg["length"])
                if digest != seg["sha256"]:
                    self._mark_damaged(cap, f"last committed segment {seg['seq']} fails its SHA-256 check")

    def _mark_damaged(self, cap: dict, reason: str) -> None:
        self.mark_damaged(cap["id"], reason)

    def mark_damaged(self, capture_id: int, reason: str) -> bool:
        """Flag a capture whose local copy failed an integrity check and stop tracking it.

        The capture is kept (and excluded from exports with a disclosed reason); it becomes
        'detached' so the source file, if still there, is collected again as a new capture.
        Returns False if the capture was deleted meanwhile (nothing to report).
        """
        with self.write() as w:
            row = w.execute("SELECT deleted_at, presence, source_id FROM captures WHERE id=?", (capture_id,)).fetchone()
            if row is None or row["deleted_at"] is not None:
                return False
            presence = "detached" if row["presence"] == "present" else row["presence"]
            w.execute("UPDATE captures SET error=?, presence=? WHERE id=?", ("store integrity: " + reason, presence, capture_id))
        self.add_event("error", "store_damaged", f"Store integrity problem for capture {capture_id}: {reason}. The capture is "
                       "kept but excluded from exports; the source file is collected again if it is still there.",
                       source_id=row["source_id"], capture_id=capture_id)
        return True

    # --- sources -----------------------------------------------------------

    def sync_sources(self, sources) -> None:
        now = self.clock.time()
        with self.write() as w:
            ids = []
            for s in sources:
                ids.append(s.id)
                w.execute(
                    "INSERT INTO sources(source_id, alias, kind, role, public_json, first_configured, last_configured) "
                    "VALUES(?,?,?,?,?,?,?) ON CONFLICT(source_id) DO UPDATE SET alias=excluded.alias, kind=excluded.kind, "
                    "role=excluded.role, public_json=excluded.public_json, last_configured=excluded.last_configured, removed_at=NULL",
                    (s.id, s.alias, s.kind, s.role, json.dumps(s.public_dict()), now, now))
            placeholders = ",".join("?" * len(ids)) or "''"
            w.execute(f"UPDATE sources SET removed_at=? WHERE removed_at IS NULL AND source_id NOT IN ({placeholders})", (now, *ids))

    def known_sources(self) -> list[dict]:
        rows = self.conn().execute("SELECT * FROM sources ORDER BY first_configured, source_id").fetchall()
        return [dict(r) | {"public": json.loads(r["public_json"])} for r in rows]

    def get_source_state(self, source_id: str) -> dict | None:
        row = self.conn().execute("SELECT * FROM source_state WHERE source_id=?", (source_id,)).fetchone()
        if row is None:
            return None
        d = dict(row)
        d["pending_host_key"] = json.loads(d.pop("pending_host_key_json") or "null")
        d["dirs"] = json.loads(d.pop("dirs_json") or "null")
        return d

    def set_source_state(self, source_id: str, **fields) -> None:
        if "pending_host_key" in fields:
            fields["pending_host_key_json"] = json.dumps(fields.pop("pending_host_key"))
        if "dirs" in fields:
            fields["dirs_json"] = json.dumps(fields.pop("dirs"))
        with self.write() as w:
            w.execute("INSERT OR IGNORE INTO source_state(source_id, state) VALUES(?, 'unknown')", (source_id,))
            if fields:
                sets = ", ".join(f"{k}=?" for k in fields)
                w.execute(f"UPDATE source_state SET {sets} WHERE source_id=?", (*fields.values(), source_id))

    def mark_available(self, source_id: str, available: bool, t: float) -> None:
        with self.write() as w:
            open_row = w.execute("SELECT id FROM availability WHERE source_id=? AND end IS NULL", (source_id,)).fetchone()
            if available and open_row is None:
                w.execute("INSERT INTO availability(source_id, start) VALUES(?, ?)", (source_id, t))
            elif not available and open_row is not None:
                w.execute("UPDATE availability SET end=? WHERE id=?", (t, open_row["id"]))

    def availability(self, source_id: str | None = None) -> list[dict]:
        q, args = "SELECT * FROM availability", ()
        if source_id:
            q, args = q + " WHERE source_id=?", (source_id,)
        return [dict(r) for r in self.conn().execute(q + " ORDER BY start", args).fetchall()]

    def runs(self) -> list[dict]:
        return [dict(r) for r in self.conn().execute("SELECT * FROM runs ORDER BY started").fetchall()]

    def heartbeat(self) -> None:
        if self.owner and self.run_id is not None:
            with self.write() as w:
                w.execute("UPDATE runs SET heartbeat=? WHERE id=?", (self.clock.time(), self.run_id))

    # --- events ------------------------------------------------------------

    def add_event(self, level: str, kind: str, message: str, source_id: str | None = None,
                  capture_id: int | None = None, data: dict | None = None) -> None:
        assert level in EVENT_LEVELS
        with self.write() as w:
            w.execute("INSERT INTO events(t, level, kind, source_id, capture_id, message, data_json) VALUES(?,?,?,?,?,?,?)",
                      (self.clock.time(), level, kind, source_id, capture_id, printable(message, 2000),
                       json.dumps(data) if data is not None else None))

    def events(self, since: float | None = None, until: float | None = None, min_level: str = "debug", limit: int = 500,
               source_id: str | None = None) -> list[dict]:
        levels = EVENT_LEVELS[EVENT_LEVELS.index(min_level):]
        q = f"SELECT * FROM events WHERE level IN ({','.join('?' * len(levels))})"
        args: list = list(levels)
        if since is not None:
            q += " AND t >= ?"
            args.append(since)
        if until is not None:
            q += " AND t < ?"
            args.append(until)
        if source_id is not None:
            q += " AND source_id = ?"
            args.append(source_id)
        q += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        out = []
        for r in self.conn().execute(q, args).fetchall():
            d = dict(r)
            d["data"] = json.loads(d.pop("data_json") or "null")
            out.append(d)
        return out

    def event_count(self, since=None, until=None, min_level="debug") -> int:
        levels = EVENT_LEVELS[EVENT_LEVELS.index(min_level):]
        q = f"SELECT COUNT(*) FROM events WHERE level IN ({','.join('?' * len(levels))})"
        args: list = list(levels)
        if since is not None:
            q += " AND t >= ?"
            args.append(since)
        if until is not None:
            q += " AND t < ?"
            args.append(until)
        return self.conn().execute(q, args).fetchone()[0]

    # --- captures ----------------------------------------------------------

    @staticmethod
    def _row_to_capture(row) -> dict:
        d = dict(row)
        for key in CAPTURE_JSON_FIELDS:
            d[key[:-5]] = json.loads(d.pop(key))
        return d

    def data_path(self, cap: dict) -> Path:
        return self.root / cap["data_file"]

    def create_capture(self, source_id: str, path: str, name: str, size: int, mtime: float | None, now: float,
                       predecessor_id: int | None = None, file_id: str | None = None) -> int:
        with self.write() as w:
            cid = w.execute(
                "INSERT INTO captures(source_id, path, original_name, names_json, presence, first_seen, last_seen, "
                "committed_size, observed_size, max_observed_size, observed_mtime, last_change, status, "
                "status_reasons_json, checks_json, predecessor_id, file_id, data_file) "
                "VALUES(?,?,?,?, 'present', ?,?, 0, ?,?,?,?, 'active', ?, ?, ?, ?, '')",
                (source_id, path, name, json.dumps([{"path": path, "first_seen": now}]), now, now, size, size, mtime, now,
                 json.dumps(["newly discovered; transfer pending"]), json.dumps({"counts": {}, "recent": []}),
                 predecessor_id, file_id)).lastrowid
            rel = f"captures/{source_id}/{cid:08d}.bin"
            w.execute("UPDATE captures SET data_file=? WHERE id=?", (rel, cid))
            # Create the data file inside the transaction: if this fails (e.g. disk full) the
            # catalog row is rolled back, so no capture ever exists without its file.
            p = self.root / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "wb") as f:
                f.flush()
                os.fsync(f.fileno())
        return cid

    def get_capture(self, capture_id: int) -> dict | None:
        row = self.conn().execute("SELECT * FROM captures WHERE id=?", (capture_id,)).fetchone()
        return None if row is None else self._row_to_capture(row)

    def captures(self, source_id: str | None = None, presence: tuple | None = None, include_deleted: bool = False,
                 conn=None) -> list[dict]:
        q, args = "SELECT * FROM captures WHERE 1=1", []
        if not include_deleted:
            q += " AND deleted_at IS NULL"
        if source_id is not None:
            q += " AND source_id=?"
            args.append(source_id)
        if presence:
            q += f" AND presence IN ({','.join('?' * len(presence))})"
            args.extend(presence)
        rows = (conn or self.conn()).execute(q + " ORDER BY id", args).fetchall()
        return [self._row_to_capture(r) for r in rows]

    def update_capture(self, capture_id: int, conn=None, **fields) -> None:
        for key in list(fields):
            if key in ("names", "status_reasons", "checks", "flags"):
                fields[key + "_json"] = json.dumps(fields.pop(key))
        if not fields:
            return
        sets = ", ".join(f"{k}=?" for k in fields)
        if conn is not None:
            conn.execute(f"UPDATE captures SET {sets} WHERE id=?", (*fields.values(), capture_id))
        else:
            with self.write() as w:
                w.execute(f"UPDATE captures SET {sets} WHERE id=?", (*fields.values(), capture_id))

    def record_check(self, capture_id: int, check: str, result: str, detail: str = "", conn=None) -> None:
        """Remember a consistency check: a count per '<check>:<result>' plus a bounded recent history."""
        if conn is not None:
            self._count_checks(conn, capture_id, [(check, result)], detail)
        else:
            with self.write() as w:
                self._count_checks(w, capture_id, [(check, result)], detail)

    def _count_checks(self, w, capture_id: int, performed: list[tuple[str, str]], detail: str | None) -> None:
        row = w.execute("SELECT checks_json FROM captures WHERE id=?", (capture_id,)).fetchone()
        checks = json.loads(row[0]) if row and row[0] else {"counts": {}, "recent": []}
        checks.setdefault("counts", {})
        checks.setdefault("recent", [])
        for check, result in performed:
            key = f"{check}:{result}"
            checks["counts"][key] = checks["counts"].get(key, 0) + 1
            if detail is not None:
                checks["recent"] = (checks["recent"] + [{"t": self.clock.time(), "check": check, "result": result,
                                                         "detail": detail}])[-25:]
        w.execute("UPDATE captures SET checks_json=? WHERE id=?", (json.dumps(checks), capture_id))

    def segments(self, capture_id: int, upto: int | None = None, conn=None) -> list[dict]:
        rows = (conn or self.conn()).execute("SELECT * FROM segments WHERE capture_id=? ORDER BY seq", (capture_id,)).fetchall()
        segs = [dict(r) for r in rows]
        if upto is not None:
            segs = [s for s in segs if s["offset"] + s["length"] <= upto]
        return segs

    def commit_segment(self, capture_id: int, offset: int, length: int, sha256: str, checks: str, now: float,
                       performed: list[tuple[str, str]] | None = None) -> None:
        """Record bytes [offset, offset+length) as committed. Caller fsynced them already.

        `performed` lists the checks that passed for this segment; they are counted in the same transaction.
        """
        with self.write() as w:
            row = w.execute("SELECT committed_size, first_acquired, deleted_at FROM captures WHERE id=?", (capture_id,)).fetchone()
            if row["deleted_at"] is not None:
                raise CaptureDeleted(f"capture {capture_id} was deleted by the user during collection")
            if row["committed_size"] != offset:
                raise StoreError(f"Segment offset {offset} does not continue committed size {row['committed_size']}")
            seq = w.execute("SELECT COALESCE(MAX(seq), -1) + 1 FROM segments WHERE capture_id=?", (capture_id,)).fetchone()[0]
            w.execute("INSERT INTO segments(capture_id, seq, offset, length, sha256, acquired_at, checks) VALUES(?,?,?,?,?,?,?)",
                      (capture_id, seq, offset, length, sha256, now, checks))
            w.execute("UPDATE captures SET committed_size=?, last_acquired=?, first_acquired=COALESCE(first_acquired, ?) WHERE id=?",
                      (offset + length, now, now, capture_id))
            if performed:
                self._count_checks(w, capture_id, performed, None)
        self._usage += length

    def _committed_total(self) -> int:
        return self.conn().execute("SELECT COALESCE(SUM(committed_size), 0) FROM captures WHERE deleted_at IS NULL").fetchone()[0]

    @property
    def usage_bytes(self) -> int:
        return self._usage if self.owner else self._committed_total()

    # --- format cache --------------------------------------------------------

    def format_cache_get(self, capture_id: int, size: int) -> dict | None:
        row = self.conn().execute("SELECT size, info_json FROM format_cache WHERE capture_id=?", (capture_id,)).fetchone()
        if row is None or row["size"] != size:
            return None
        info = json.loads(row["info_json"])
        # An analysis by another analyzer version may identify the file differently: analyze it again.
        return info if isinstance(info, dict) and info.get("analyzer_version") == ANALYZER_VERSION else None

    def format_cache_put(self, capture_id: int, size: int, info: dict) -> None:
        if not self.owner:
            return
        with self.write() as w:
            w.execute("INSERT INTO format_cache(capture_id, size, info_json) VALUES(?,?,?) ON CONFLICT(capture_id) "
                      "DO UPDATE SET size=excluded.size, info_json=excluded.info_json", (capture_id, size, json.dumps(info)))

    # --- export coordination and user deletion -----------------------------

    @contextmanager
    def export_guard(self):
        """Exports hold a shared lock; user deletion (in any process) waits for them to finish."""
        with self.readers_lock.shared():
            yield

    def delete_captures(self, capture_ids: list[int], note: str) -> list[int]:
        """Explicit, user-requested deletion of local captures (never remote files).

        The catalog keeps a tombstone (identity, size, final hash, who/why) so
        later exports disclose that evidence was deliberately removed.
        """
        try:
            with self.readers_lock.exclusive(timeout=60):
                return self._delete_locked(capture_ids, note)
        except ExportsBusy:
            raise StoreError("An export is still running; try deleting again after it finishes") from None

    def _delete_locked(self, capture_ids: list[int], note: str) -> list[int]:
        deleted = []
        for cid in capture_ids:
            cap = self.get_capture(cid)
            if cap is None:
                continue
            if cap["deleted_at"] is not None:
                if self._finish_deletion(cap):  # an earlier deletion was interrupted; complete it
                    deleted.append(cid)
                continue
            # 1. Tombstone first. From this commit on, commit_segment refuses the capture, so the bytes that are
            #    deleted (and hashed below) are exactly the committed size read here.
            with self.write() as w:
                row = w.execute("SELECT committed_size, deleted_at FROM captures WHERE id=?", (cid,)).fetchone()
                if row["deleted_at"] is not None:
                    continue
                size = row["committed_size"]
                w.execute("UPDATE captures SET deleted_at=?, deleted_note=? WHERE id=?", (self.clock.time(), note, cid))
            self._usage -= size
            # 2. Move the file aside. If it is in use (Windows refuses), undo the tombstone: nothing has changed.
            path = self.data_path(cap)
            doomed = path.with_name(path.name + ".deleting")
            if path.exists():
                try:
                    path.rename(doomed)
                except OSError:
                    with self.write() as w:
                        w.execute("UPDATE captures SET deleted_at=NULL, deleted_note=NULL WHERE id=?", (cid,))
                    self._usage += size
                    raise
            # 3. Record what was deleted, then drop its segments and bytes. If this is interrupted, the capture is
            #    already excluded from exports, and the next deletion call or start finishes it (_finish_deletion).
            cap = dict(cap, committed_size=size, deleted_at=True)
            digest = self._finish_deletion(cap, announce=False)
            deleted.append(cid)
            self.add_event("warning", "user_deleted_capture",
                           f"Capture {cid} ({cap['original_name']!r}, {size} bytes) deleted from the local store "
                           f"by user request: {note}", source_id=cap["source_id"], capture_id=cid,
                           data={"sha256": digest, "size": size})
        return deleted

    def _finish_deletion(self, cap: dict, announce: bool = True):
        """Complete the deletion of a tombstoned capture: hash, drop segments, remove its bytes. Idempotent.

        Returns the deleted bytes' SHA-256 when called from a deletion in progress; otherwise whether anything
        was left to finish.
        """
        path = self.data_path(cap)
        doomed = path.with_name(path.name + ".deleting")
        if path.exists() and not doomed.exists():
            path.rename(doomed)
        cid = cap["id"]
        row = self.conn().execute("SELECT flags_json, committed_size FROM captures WHERE id=?", (cid,)).fetchone()
        flags = json.loads(row["flags_json"] or "{}")
        has_segments = self.conn().execute("SELECT 1 FROM segments WHERE capture_id=? LIMIT 1", (cid,)).fetchone()
        if not announce or (has_segments or doomed.exists() or "deleted_sha256" not in flags):
            digest = flags.get("deleted_sha256")
            if digest is None and doomed.exists():
                with open(doomed, "rb") as f:
                    digest = _sha256_stream(f, row["committed_size"])
            with self.write() as w:
                w.execute("UPDATE captures SET flags_json=? WHERE id=?",
                          (json.dumps(flags | {"deleted_sha256": digest}), cid))
                w.execute("DELETE FROM segments WHERE capture_id=?", (cid,))
                w.execute("DELETE FROM format_cache WHERE capture_id=?", (cid,))
            try:
                doomed.unlink()
            except FileNotFoundError:
                pass
            if not announce:
                return digest
            self.add_event("info", "deletion_completed", f"Finished deleting capture {cid}, which an interruption had "
                           "left half-deleted; its bytes are removed and its tombstone kept", capture_id=cid,
                           source_id=cap["source_id"])
            return True
        return False

def restrict_to_current_user(path: Path) -> str | None:  # pragma: no cover - Windows only
    """Windows: replace inherited permissions with full control for the current user and SYSTEM only.

    A store on another drive (e.g. D:\\PitRelay) would otherwise inherit that drive's default
    permissions, which let other local accounts read the UI sign-in file and the captures.
    Returns None on success or a description of the problem.
    """
    import subprocess
    system32 = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32"
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        out = subprocess.run([str(system32 / "whoami.exe"), "/user", "/fo", "csv", "/nh"], capture_output=True, text=True,
                             timeout=30, check=True, creationflags=flags).stdout
        sid = out.strip().rsplit(",", 1)[-1].strip().strip('"')
        if not sid.startswith("S-1-"):
            return "could not determine the current user's security identifier"
        subprocess.run([str(system32 / "icacls.exe"), str(path), "/inheritance:r", "/grant:r", f"*{sid}:(OI)(CI)F",
                        "/grant:r", "*S-1-5-18:(OI)(CI)F"], capture_output=True, timeout=60, check=True, creationflags=flags)
    except (OSError, subprocess.SubprocessError) as e:
        return f"{e.__class__.__name__}: {e}"
    return None


def _sha256_stream(f, length: int, block: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    remaining = length
    while remaining > 0:
        data = f.read(min(block, remaining))
        if not data:
            break
        h.update(data)
        remaining -= len(data)
    return h.hexdigest()


def sha256_file_prefix(path: Path, length: int) -> str:
    with open(path, "rb") as f:
        return _sha256_stream(f, length)
