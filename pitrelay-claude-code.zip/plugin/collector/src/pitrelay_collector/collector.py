"""The background collection engine.

One worker thread polls each enabled source on its own schedule. A poll:

1. lists the authorized directories (bounded depth and file count; links skipped);
2. reconciles every tracked file: growth, unchanged, truncated/replaced (detected
   by size decrease or by re-reading head/middle/tail windows of the captured
   prefix), or missing;
3. matches new paths against missing/replaced captures by content to follow
   renames and rotations (e.g. DataLogManager renaming FRC_TBD_*.wpilog while
   it is still being written);
4. fetches only new bytes, in hashed, fsynced, committed segments, under the
   bandwidth limit, per-cycle budget and storage quota;
5. classifies each capture (active, idle, complete, partial, uncertain) with reasons.

The collector never writes to a source. Nothing here calls a model, a cloud
service or anything outside the configured sources and the local store.
"""

from __future__ import annotations

import fnmatch
import hashlib
import json
import logging
import os
import posixpath
import random
import shutil
import threading
from dataclasses import dataclass

from . import formats
from .config import (DEFAULT_LOG_EXTENSIONS, CollectorConfig, ConfigManager, SourceConfig, credential_file_name,
                     resolved_folder_problem)
from .sources import (HostKeyMismatch, HostKeyUnknown, LocalFS, SourceError, SourceUnreachable, connect_sftp,
                      host_key_matches)
from .store import CaptureDeleted, Store, StoreError
from .util import Clock, human_bytes, printable, utc_iso

log = logging.getLogger("pitrelay_collector")

WINDOW = 4096  # bytes per consistency-check window
FULL_COMPARE = 256 * 1024  # prefixes up to this size are compared in full
MIN_MATCH_BYTES = 64  # minimum captured prefix to follow a rename by content
READ_BLOCK = 256 * 1024


class QuotaBlocked(Exception):
    pass


class LocalStoreError(Exception):
    pass


class CaptureDamaged(Exception):
    """A capture's local copy is missing or shorter than its committed size (store damage)."""


class BandwidthLimiter:
    """Token bucket shared by all transfers (None = unlimited)."""

    def __init__(self, clock: Clock, stop: threading.Event):
        self.clock = clock
        self.stop = stop
        self.rate: float | None = None
        self.tokens = 0.0
        self.last = clock.monotonic()

    def configure(self, rate_bps: int | None) -> None:
        self.rate = float(rate_bps) if rate_bps else None

    def acquire(self, n: int) -> None:
        if not self.rate or n <= 0:
            return
        now = self.clock.monotonic()
        self.tokens = min(self.rate, self.tokens + (now - self.last) * self.rate)
        self.last = now
        self.tokens -= n
        if self.tokens < 0:
            self.clock.wait(self.stop, -self.tokens / self.rate)
            now2 = self.clock.monotonic()
            self.tokens = min(0.0, self.tokens + (now2 - now) * self.rate)
            self.last = now2


@dataclass
class _Conn:
    fs: object
    signature: tuple


def _source_signature(src: SourceConfig) -> tuple:
    return (src.kind, tuple(src.hosts), src.port, src.username, src.auth, src.key_file,
            tuple(k.get("key_b64") for k in src.trusted_host_keys))


def _wanted(name: str, src: SourceConfig) -> bool:
    ext = formats.extension_of(name)
    if ext in DEFAULT_LOG_EXTENSIONS:
        return True
    if ext == ".csv" and src.include_csv:
        return True
    low = name.lower()
    # A text pattern names diagnostic text files; it never brings in keys, credential or hidden files, whatever it says.
    return any(fnmatch.fnmatchcase(low, p.lower()) for p in src.text_patterns) and not credential_file_name(name)


class Collector:
    def __init__(self, store: Store, config: ConfigManager, clock: Clock | None = None, secrets=None,
                 connect=None, rng: random.Random | None = None, jitter: bool = True):
        self.store = store
        self.config = config
        self.clock = clock or store.clock
        if secrets is None:
            from .secrets import KeyringSecrets
            secrets = KeyringSecrets()
        self.secrets = secrets
        self.connect = connect or connect_sftp
        self.rng = rng or random.Random()
        self.jitter = jitter
        self.stop_event = threading.Event()
        self.wake_event = threading.Event()
        self.limiter = BandwidthLimiter(self.clock, self.stop_event)
        self._conns: dict[str, _Conn] = {}
        self._session: dict[str, int] = {}
        self._last_listing: dict[str, tuple[float, int]] = {}
        self._next_poll: dict[str, float] = {}
        self._conditions: dict[tuple, str] = {}
        self._thread: threading.Thread | None = None
        self._last_heartbeat = 0.0
        # Restored so that a block recorded by an earlier run is cleared (with an event) once storage allows.
        self.quota_blocked: str | None = store.meta_get("quota_blocked", "") or None
        self.store_write_error: str | None = None
        self.running = False
        self._halt = threading.Event()  # pause/disable requested: stop reading from sources now
        self._failed_signature: dict[str, tuple] = {}
        self._synced_sources: str | None = None
        self.cycles = 0  # completed scheduling cycles (lets a caller wait for a poll it requested)
        self.in_cycle = False
        self._one_off = threading.Event()  # poll every source once even though automatic collection is off
        self._reconnect = threading.Event()  # drop connections before the next cycle (a new connected observation)
        self._seen_poll_request: str | None = store.meta_get("poll_request", "") or None

    # --- lifecycle and controls -------------------------------------------------------

    def start(self) -> None:
        self.stop_event.clear()
        self._thread = threading.Thread(target=self.run, name="pitrelay-collector", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 30.0) -> None:
        self.stop_event.set()
        self.wake_event.set()
        if self._thread is not None:
            self._thread.join(timeout)
        self._close_all()

    def wake(self) -> None:
        self.wake_event.set()

    def run(self) -> None:
        self.running = True
        try:
            while not self.stop_event.is_set():
                self.in_cycle = True
                try:
                    delay = self.tick()
                except Exception as e:  # never let one bad cycle kill the collector
                    log.exception("collector cycle failed")
                    self._condition(("internal_error",), "error", "internal_error",
                                    f"Collector cycle failed: {e.__class__.__name__}: {printable(str(e))}")
                    delay = 5.0
                finally:
                    self.in_cycle = False
                    self.cycles += 1
                self.wake_event.clear()
                if self.stop_event.is_set():
                    break
                # Wake at least every 2 s, so a poll requested by another process (poll_request) starts promptly.
                self.clock.wait(self.wake_event, min(delay, 2.0))
        finally:
            self.running = False

    def is_paused(self) -> bool:
        return bool(self.store.meta_get("paused", ""))

    def halted(self) -> bool:
        """True when reading must stop now: shutdown, pause or disable (also when set by another process)."""
        if self.stop_event.is_set() or self._halt.is_set():
            return True
        try:
            if self.is_paused() or (not self.config.load().collection_enabled and not self._one_off.is_set()):
                self._halt.set()
                return True
        except Exception:  # an unreadable config is reported by the next tick; keep transferring
            pass
        return False

    def pause(self) -> None:
        self._halt.set()
        if not self.is_paused():
            self.store.meta_set("paused", repr(self.clock.time()))
            self.store.add_event("info", "paused", "Collection paused by the user")
        self.wake()

    def resume(self) -> None:
        if self.is_paused():
            self.store.meta_set("paused", "")
            self.store.add_event("info", "resumed", "Collection resumed by the user")
        self._next_poll.clear()
        self.wake()

    def set_enabled(self, enabled: bool) -> None:
        if not enabled:
            self._halt.set()

        def apply(cfg: CollectorConfig):
            cfg.collection_enabled = enabled
        self.config.update(apply)
        self.store.add_event("info", "enabled" if enabled else "disabled",
                             "Automatic collection enabled" if enabled else "Automatic collection disabled")
        self._next_poll.clear()
        self.wake()

    def poll_now(self) -> None:
        self._next_poll.clear()
        for src in self.config.load().sources:
            self.store.set_source_state(src.id, next_attempt=None)
        self.wake()

    def sync_once(self, reconnect: bool = False) -> None:
        """Poll every enabled source once now, even if automatic collection is off (not while paused)."""
        if reconnect:
            self._reconnect.set()
        self._one_off.set()
        self.poll_now()

    def trust_host_key(self, source_id: str, fingerprint: str, replace: bool = True, key: dict | None = None) -> dict:
        """Trust exactly the key the user saw (matched by fingerprint): the pending one, or `key` read just before.

        replace=False adds it to the trusted keys (a second robot answering at the same addresses, e.g. a practice
        robot); replace=True makes it the only one (the controller was re-imaged)."""
        state = self.store.get_source_state(source_id) or {}
        pending = key or state.get("pending_host_key")
        if not pending or pending.get("fingerprint") != fingerprint:
            raise ValueError("That fingerprint is not the key currently presented by this source; reconnect and compare again")

        def apply(cfg: CollectorConfig):
            src = cfg.source_by_id(source_id)
            if src is None:
                raise ValueError("Unknown source")
            entry = {"type": pending["type"], "fingerprint": pending["fingerprint"], "key_b64": pending["key_b64"],
                     "trusted_at": utc_iso(self.clock.time())}
            # Replacing is the default: after a re-image the old key must stop being accepted.
            kept = [] if replace else [k for k in src.trusted_host_keys if k.get("key_b64") != entry["key_b64"]]
            src.trusted_host_keys = kept + [entry]
        self.config.update(apply)
        self.store.set_source_state(source_id, pending_host_key=None, failures=0, next_attempt=None, state="unknown")
        self.store.add_event("warning", "host_key_trusted",
                             f"User trusted host key {fingerprint} for this source" + ("" if replace else " (in addition)"),
                             source_id=source_id, data={"fingerprint": fingerprint, "type": pending["type"],
                                                        "replaced_previous": replace})
        self._drop_conn(source_id)
        self._next_poll.pop(source_id, None)
        self.wake()
        return pending

    # --- scheduling -------------------------------------------------------------------

    def tick(self, force: bool = False) -> float:
        cfg = self.config.load()
        self.limiter.configure(cfg.bandwidth_limit_bps)
        mono = self.clock.monotonic()
        if mono - self._last_heartbeat >= 10 or force:
            self.store.heartbeat()
            self._last_heartbeat = mono
        configured = {s.id for s in cfg.sources}
        for sid in list(self._conns):
            if sid not in configured:
                self._drop_conn(sid)
        self._sync_sources(cfg)
        self._update_quota_state(cfg)
        self._take_poll_request()
        one_off = self._one_off.is_set()
        if (not cfg.collection_enabled and not one_off) or self.is_paused():
            self._one_off.clear()
            self._halt.set()
            self._close_all()
            return 5.0
        self._halt.clear()
        if self._reconnect.is_set():
            self._reconnect.clear()
            self._close_all()
        if one_off:
            force = True
        delays = []
        for src in cfg.sources:
            if self.halted():
                break
            if not src.enabled:
                self._drop_conn(src.id)
                self.store.set_source_state(src.id, state="disabled")
                continue
            due = self._next_poll.get(src.id, 0.0)
            if force or mono >= due:
                self.poll_source(src, cfg)
                self._next_poll[src.id] = self.clock.monotonic() + src.poll_interval_s
            delays.append(self._next_poll[src.id] - self.clock.monotonic())
        if one_off:
            self._one_off.clear()
            if not cfg.collection_enabled:
                self._close_all()  # a one-off sync leaves no connection open while collection is off
        return max(0.5, min(delays)) if delays else 5.0

    def _take_poll_request(self) -> None:
        """A poll requested by another process (a second Claude Code session): store meta 'poll_request'.

        While paused the request stays pending (it runs on resume); the requester sees the pause itself."""
        try:
            raw = self.store.meta_get("poll_request", "") or None
        except Exception:
            return
        if raw is None or raw == self._seen_poll_request or self.is_paused():
            return
        self._seen_poll_request = raw
        try:
            req = json.loads(raw)
        except ValueError:
            return
        if req.get("reconnect"):
            self._reconnect.set()
        if req.get("once"):
            self._one_off.set()
            for src in self.config.load().sources:  # as sync_once: a source in backoff is tried now too
                self.store.set_source_state(src.id, next_attempt=None)
        self._next_poll.clear()

    def _sync_sources(self, cfg: CollectorConfig) -> None:
        """Keep the catalog's source list in step with config.json, including edits made by the CLI."""
        sig = json.dumps([s.public_dict() for s in cfg.sources], sort_keys=True)
        if sig != self._synced_sources:
            self.store.sync_sources(cfg.sources)
            self._synced_sources = sig

    # --- connections ------------------------------------------------------------------

    def _drop_conn(self, source_id: str) -> None:
        conn = self._conns.pop(source_id, None)
        if conn is not None:
            try:
                conn.fs.close()
            except Exception:
                pass
        self.store.mark_available(source_id, False, self.clock.time())

    def _close_all(self) -> None:
        for sid in list(self._conns):
            self._drop_conn(sid)
        for row in self.store.availability():
            if row["end"] is None:
                self.store.mark_available(row["source_id"], False, self.clock.time())

    def _get_fs(self, src: SourceConfig, cfg: CollectorConfig):
        sig = _source_signature(src)
        conn = self._conns.get(src.id)
        if conn is not None and conn.signature == sig and getattr(conn.fs, "alive", True):
            return conn.fs
        if conn is not None:
            self._drop_conn(src.id)
        if src.kind == "local":
            fs = LocalFS()
        else:
            fs = self.connect(src, self.secrets.get, cfg.connect_timeout_s, cfg.io_timeout_s)
        self._conns[src.id] = _Conn(fs, sig)
        self._session[src.id] = self._session.get(src.id, 0) + 1
        return fs

    # --- one poll -----------------------------------------------------------------------

    def poll_source(self, src: SourceConfig, cfg: CollectorConfig) -> None:
        now = self.clock.time()
        state = self.store.get_source_state(src.id) or {}
        if (state.get("next_attempt") and now < state["next_attempt"] and src.id not in self._conns
                and self._failed_signature.get(src.id) == _source_signature(src)):
            # Backing off. A changed address, credential setting or trusted key retries at once, and so does
            # the first poll of a new collector run (the failure was recorded under the previous run's settings).
            return
        self.store.set_source_state(src.id, last_attempt=now)
        try:
            fs = self._get_fs(src, cfg)
            self._collect(src, fs, cfg)
            if not getattr(fs, "alive", True):
                raise SourceUnreachable("The connection closed during the poll")
        except SourceError as e:
            self._drop_conn(src.id)
            self._source_failed(src, cfg, e, state)
            return
        except (OSError, EOFError) as e:
            self._drop_conn(src.id)
            self._source_failed(src, cfg, SourceUnreachable(f"Connection lost: {e.__class__.__name__}: {printable(str(e))}"), state)
            return
        except Exception as e:
            if e.__class__.__module__.startswith("paramiko"):
                self._drop_conn(src.id)
                self._source_failed(src, cfg, SourceUnreachable(f"Connection lost: {e.__class__.__name__}: {printable(str(e))}"), state)
                return
            if isinstance(e, StoreError):
                raise  # the store itself: every source would fail the same way
            # Anything else is this source's problem: it never stops the other sources from being collected.
            log.exception("Unexpected error while collecting from source %s", src.id)
            self._drop_conn(src.id)
            self._source_failed(src, cfg, SourceError(f"Unexpected error: {e.__class__.__name__}: {printable(str(e))}"), state)
            return
        self._source_ok(src, state)

    def _source_ok(self, src: SourceConfig, prev: dict) -> None:
        now = self.clock.time()
        host = getattr(self._conns.get(src.id).fs, "host", "local") if src.id in self._conns else None
        changed = prev.get("state") != "connected"
        fields = dict(state="connected", last_success=now, last_error=None, failures=0, next_attempt=None,
                      pending_host_key=None, connected_host=host)
        if changed:
            fields["since"] = now
        self.store.set_source_state(src.id, **fields)
        self.store.mark_available(src.id, True, now)
        self._failed_signature.pop(src.id, None)
        if changed:
            self.store.add_event("info", "source_connected", f"Collecting from {src.alias}" + (f" via {host}" if host and host != "local" else ""),
                                 source_id=src.id)
        self._clear_condition(("source_problem", src.id))

    def _source_failed(self, src: SourceConfig, cfg: CollectorConfig, err: SourceError, prev: dict) -> None:
        now = self.clock.time()
        failures = int(prev.get("failures") or 0) + 1
        delay = min(cfg.backoff_max_s, cfg.backoff_initial_s * (2 ** min(failures - 1, 20)))
        if self.jitter:
            delay *= self.rng.uniform(0.8, 1.2)
        if isinstance(err, (HostKeyUnknown, HostKeyMismatch)):
            delay = cfg.backoff_max_s
        self._failed_signature[src.id] = _source_signature(src)
        message = printable(str(err), 500)  # may quote text the remote device sent (e.g. an SSH banner)
        fields = dict(state=err.state, last_error=message, failures=failures, next_attempt=now + delay)
        if prev.get("state") != err.state:
            fields["since"] = now
        if isinstance(err, (HostKeyUnknown, HostKeyMismatch)):
            fields["pending_host_key"] = err.key_info
        self.store.set_source_state(src.id, **fields)
        self.store.mark_available(src.id, False, now)
        level = "error" if isinstance(err, HostKeyMismatch) or err.state == "auth_failed" else "warning"
        if isinstance(err, SourceUnreachable) and prev.get("state") not in ("connected",):
            level = "info"  # still unavailable (e.g. robot off); the availability gap is recorded separately
        self._condition(("source_problem", src.id), level, err.state, message, source_id=src.id,
                        data={"retry_after_s": round(delay, 1)})

    # --- conditions: events emitted once per change, not every cycle --------------------

    def _condition(self, key: tuple, level: str, kind: str, message: str, source_id=None, capture_id=None, data=None):
        if self._conditions.get(key) == message:
            return
        self._conditions[key] = message
        self.store.add_event(level, kind, message, source_id=source_id, capture_id=capture_id, data=data)

    def _clear_condition(self, key: tuple, resolved_message: str | None = None, source_id=None) -> None:
        if self._conditions.pop(key, None) is not None and resolved_message:
            self.store.add_event("info", "resolved", resolved_message, source_id=source_id)

    # --- listing ------------------------------------------------------------------------

    def _list(self, src: SourceConfig, fs, cfg: CollectorConfig):
        """Return (files by path, listed roots, unlisted prefixes, per-directory status)."""
        files: dict[str, object] = {}
        roots: list[str] = []
        unlisted: list[str] = []
        status: dict[str, dict] = {}
        seen_roots: set[str] = set()
        count = 0
        truncated = False
        for d in src.directories:
            try:
                real = fs.realpath(os.path.expanduser(d) if src.kind == "local" else d)
                if src.kind == "local" and not os.path.isdir(real):
                    raise FileNotFoundError(real)
            except PermissionError:
                status[d] = {"status": "permission_denied"}
                continue
            except (FileNotFoundError, NotADirectoryError):
                status[d] = {"status": "not_found"}
                continue
            except OSError as e:
                # A generic SFTP failure status (no errno) is about this path, not the connection,
                # unless the connection itself is gone (paramiko's "Socket is closed" has no errno).
                if e.errno is not None or isinstance(e, TimeoutError) or not getattr(fs, "alive", True):
                    raise
                status[d] = {"status": f"resolve_failed: {printable(str(e), 80)}"}
                continue
            problem = resolved_folder_problem(real, src.kind, self.store.root)
            if problem:
                status[d] = {"status": f"refused: {problem}", "realpath": real}
                self._condition(("folder_refused", src.id, d), "warning", "folder_refused",
                                f"{printable(d)} at {src.alias} is not collected: {problem} ({printable(real)})",
                                source_id=src.id)
                continue
            self._clear_condition(("folder_refused", src.id, d))
            if real in seen_roots:
                status[d] = {"status": "duplicate", "realpath": real}
                continue
            seen_roots.add(real)
            info = {"status": "ok", "realpath": real, "files": 0, "links_skipped": 0, "online_only_skipped": 0,
                    "subdir_errors": 0}
            queue = [(real, 0)]
            root_ok = False
            while queue:
                path, depth = queue.pop(0)
                try:
                    entries = fs.listdir(path)
                except PermissionError:
                    if path == real:
                        info["status"] = "permission_denied"
                    else:
                        info["subdir_errors"] += 1
                    unlisted.append(path)
                    continue
                except (FileNotFoundError, NotADirectoryError):
                    if path == real:
                        info["status"] = "not_found"
                    unlisted.append(path)
                    continue
                except OSError as e:
                    # A generic SFTP failure status (no errno) is a per-directory problem, not a lost
                    # connection; timeouts and socket errors still propagate as connection loss.
                    if e.errno is not None or isinstance(e, TimeoutError) or not getattr(fs, "alive", True):
                        raise
                    if path == real:
                        info["status"] = f"list_failed: {printable(str(e), 80)}"
                    else:
                        info["subdir_errors"] += 1
                    unlisted.append(path)
                    continue
                if path == real:
                    root_ok = True
                for e in sorted(entries, key=lambda x: x.name):
                    if e.kind == "link":
                        info["links_skipped"] += 1
                    elif e.kind == "online_only" and _wanted(e.name, src):
                        # Listed (so a tracked capture is not taken as removed) but never read: reading a cloud
                        # placeholder would start a download.
                        info["online_only_skipped"] += 1
                        files[e.path] = e
                    elif e.kind == "dir":
                        if depth < src.recursive_depth:
                            queue.append((e.path, depth + 1))
                    elif e.kind == "file" and _wanted(e.name, src):
                        if count >= cfg.max_files_per_source:
                            truncated = True
                            unlisted.append(path)
                            break
                        files[e.path] = e
                        info["files"] += 1
                        count += 1
            if root_ok:
                roots.append(real)
            status[d] = info
        if truncated:
            self._condition(("listing_truncated", src.id), "warning", "listing_truncated",
                            f"More than {cfg.max_files_per_source} matching files at {src.alias}; only the first "
                            f"{cfg.max_files_per_source} are tracked. Narrow the authorized folders or raise the limit.",
                            source_id=src.id)
        else:
            self._clear_condition(("listing_truncated", src.id))
        return files, roots, unlisted, status

    @staticmethod
    def _under(path: str, prefixes: list[str], sep: str) -> bool:
        return any(path == p or path.startswith(p.rstrip(sep) + sep) for p in prefixes)

    # --- core reconciliation ------------------------------------------------------------

    def _collect(self, src: SourceConfig, fs, cfg: CollectorConfig) -> None:
        now = self.clock.time()
        mono = self.clock.monotonic()
        sep = "/" if src.kind == "sftp" else os.sep
        files, roots, unlisted, dir_status = self._list(src, fs, cfg)
        self.store.set_source_state(src.id, dirs=dir_status)
        if src.kind == "local" and not roots:
            raise SourceUnreachable("None of the configured folders is currently accessible")
        session = self._session.get(src.id, 0)
        last = self._last_listing.get(src.id)
        new_session = last is None or last[1] != session  # reconnected, resumed, or the collector restarted
        continuous = not new_session and (mono - last[0]) <= 3 * src.poll_interval_s
        dt = (mono - last[0]) if continuous else 0.0  # a slow poll is unobserved time, not a reconnection

        def judged(path: str) -> bool:
            return self._under(path, roots, sep) and not self._under(path, unlisted, sep)

        configured_roots = [d.get("realpath") for d in dir_status.values() if d.get("realpath")]
        present = self.store.captures(src.id, presence=("present",))
        by_path = {c["path"]: c for c in present}
        candidates: list[dict] = []
        new_content: list[tuple] = []
        batch: list[tuple[int, dict]] = []  # routine per-poll updates, applied in one transaction
        for path, cap in by_path.items():
            e = files.get(path)
            if e is None:
                if judged(path):
                    self._mark_gone(cap, "missing", "no longer present at the source", now)
                    candidates.append(self.store.get_capture(cap["id"]))
                elif configured_roots and not self._under(path, configured_roots, sep) and all(
                        s.get("status") in ("ok", "duplicate") for s in dir_status.values()):
                    self._mark_gone(cap, "missing", "its folder is no longer an authorized collection folder", now)
                continue
            if e.kind == "online_only":
                # Still at the source, but its bytes are in the cloud (e.g. OneDrive "free up space"): keep the
                # capture as it is and read nothing until the file is local again.
                batch.append((cap["id"], dict(last_seen=now)))
                continue
            if (cap["error"] or "").startswith("store integrity"):
                if self.store.mark_damaged(cap["id"], cap["error"][len("store integrity: "):]):
                    new_content.append((e, cap))  # collect the source file again as a new capture
                continue
            if e.size < cap["observed_size"]:
                # Shorter than when last seen: truncated or replaced, even if still longer than what was captured.
                self._mark_gone(cap, "replaced", f"size decreased from {cap['observed_size']} to {e.size} bytes "
                                f"(truncated or replaced at the same path)", now)
                candidates.append(self.store.get_capture(cap["id"]))
                new_content.append((e, cap))
                continue
            changed = e.size != cap["observed_size"] or e.mtime != cap["observed_mtime"]
            if changed and cap["committed_size"] > 0:
                try:
                    ok, detail = self._spot_check(fs, cap)
                except CaptureDamaged as d:
                    if self.store.mark_damaged(cap["id"], str(d)):
                        new_content.append((e, cap))
                    continue
                self.store.record_check(cap["id"], "prefix_recheck", "match" if ok else "mismatch", detail)
                if not ok:
                    self._mark_gone(cap, "replaced", f"previously captured bytes no longer match ({detail})", now)
                    candidates.append(self.store.get_capture(cap["id"]))
                    new_content.append((e, cap))
                    continue
            fields = dict(last_seen=now)
            if changed:
                fields.update(observed_size=e.size, max_observed_size=max(cap["max_observed_size"], e.size),
                              observed_mtime=e.mtime, last_change=now, quiet_s=0.0, reconnects_since_change=0)
                if cap["flags"].get("was_complete"):
                    fields["flags"] = {k: v for k, v in cap["flags"].items() if k != "was_complete"}
            else:
                fields.update(quiet_s=cap["quiet_s"] + dt,
                              reconnects_since_change=cap["reconnects_since_change"] + (1 if new_session else 0))
            if e.file_id and not cap["file_id"]:
                fields["file_id"] = e.file_id
            batch.append((cap["id"], fields))
        if batch:
            with self.store.write() as w:
                for cid, fields in batch:
                    self.store.update_capture(cid, conn=w, **fields)
        # A capture the user deleted locally while its file was still on the source leaves a tombstone.
        # The identical file (same path, size and mtime) is not collected again; a changed file is.
        tombstones = {c["path"]: c for c in self.store.captures(src.id, presence=("present",), include_deleted=True)
                      if c["deleted_at"] is not None}
        for path, e in files.items():
            if path in by_path or e.kind == "online_only":
                continue
            t = tombstones.get(path)
            if t is not None and e.size == t["observed_size"] and e.mtime == t["observed_mtime"]:
                continue
            new_content.append((e, None))

        # Only captures that disappeared in this same poll can be continued by a new path. A real
        # rename or rotation shows both changes at the same listing; matching older disappearances
        # risks attaching an unrelated file whose bytes merely begin the same way.
        for e, predecessor in sorted(new_content, key=lambda t: t[0].path):
            match = self._match_candidate(fs, e, candidates)
            if match is not None:
                candidates.remove(match)
                self._rebind(match, e, now)
            else:
                try:
                    cid = self.store.create_capture(src.id, e.path, e.name, e.size, e.mtime, now,
                                                    predecessor_id=predecessor["id"] if predecessor else None, file_id=e.file_id)
                except OSError as err:
                    self._local_failure(err)  # reported once; nothing is half-created, retried next poll
                    break
                if predecessor:
                    self.store.add_event("info", "same_path_successor",
                                         f"New content at {printable(e.path)} recorded as capture {cid}; previous capture "
                                         f"{predecessor['id']} is preserved unchanged", source_id=src.id, capture_id=cid,
                                         data={"predecessor": predecessor["id"]})

        self._fetch_pending(src, fs, cfg)
        self._classify_source(src, cfg)
        self._last_listing[src.id] = (self.clock.monotonic(), session)

    def _mark_gone(self, cap: dict, presence: str, reason: str, now: float) -> None:
        # Note: a size seen at this path now belongs to the new content, not to this capture,
        # so observed/max-observed sizes are deliberately left as last seen for this capture.
        self.store.update_capture(cap["id"], presence=presence, missing_since=now)
        self.store.add_event("info" if presence == "missing" else "warning", f"capture_{presence}",
                             f"{printable(cap['path'])}: {reason}. Captured bytes ({cap['committed_size']}) are preserved.",
                             source_id=cap["source_id"], capture_id=cap["id"])

    def _rebind(self, cap: dict, e, now: float) -> None:
        names = cap["names"] + [{"path": e.path, "first_seen": now}]
        changed = e.size != cap["observed_size"]
        fields = dict(presence="present", path=e.path, names=names, missing_since=None, last_seen=now,
                      observed_size=e.size, max_observed_size=max(cap["max_observed_size"], e.size), observed_mtime=e.mtime)
        if changed:
            fields.update(last_change=now, quiet_s=0.0, reconnects_since_change=0)
            if cap["flags"].get("was_complete"):
                fields["flags"] = {k: v for k, v in cap["flags"].items() if k != "was_complete"}
        if e.file_id:
            fields["file_id"] = e.file_id
        self.store.update_capture(cap["id"], **fields)
        old = cap["path"]
        self.store.add_event("info", "capture_renamed",
                             f"{printable(old)} continues as {printable(e.path)} (captured prefix verified by content)",
                             source_id=cap["source_id"], capture_id=cap["id"], data={"from": old, "to": e.path})

    # --- consistency checks -------------------------------------------------------------

    def _local_read(self, cap: dict, offset: int, n: int) -> bytes:
        """Read committed bytes of a capture's local copy; damage is reported, never mistaken for a source change."""
        try:
            with open(self.store.data_path(cap), "rb") as f:
                f.seek(offset)
                data = f.read(n)
        except OSError as e:
            raise CaptureDamaged(f"local copy unreadable ({e.__class__.__name__})") from None
        if len(data) < n and offset + n <= cap["committed_size"]:
            raise CaptureDamaged(f"local copy is shorter than its {cap['committed_size']} committed bytes")
        return data

    def _windows(self, size: int) -> list[tuple[int, int]]:
        if size <= FULL_COMPARE:
            return [(0, size)]
        mid = size // 2 - WINDOW // 2
        return [(0, WINDOW), (mid, WINDOW), (size - WINDOW, WINDOW)]

    def _compare_windows(self, reader, cap: dict, size: int) -> tuple[bool, str]:
        for off, ln in self._windows(size):
            remote = reader.read_at(off, ln)
            self.limiter.acquire(len(remote))
            if remote != self._local_read(cap, off, ln):
                return False, f"bytes {off}-{off + ln} differ"
        if size <= FULL_COMPARE:
            return True, f"entire {size}-byte captured prefix re-read and matched"
        return True, f"head, middle and tail {WINDOW}-byte windows of the {size}-byte captured prefix matched"

    def _spot_check(self, fs, cap: dict) -> tuple[bool, str]:
        try:
            reader = fs.open(cap["path"])
        except FileNotFoundError:
            return True, "file vanished before the check; reconciled next poll"
        try:
            return self._compare_windows(reader, cap, cap["committed_size"])
        finally:
            reader.close()

    def _match_candidate(self, fs, e, candidates: list[dict]) -> dict | None:
        eligible = [c for c in candidates if MIN_MATCH_BYTES <= c["committed_size"] <= e.size
                    and c["path"] != e.path  # sealed as replaced at this path: a rotation continues elsewhere
                    and not (e.file_id and c["file_id"] and e.file_id != c["file_id"])]  # different local file identity
        if not eligible:
            return None
        try:
            reader = fs.open(e.path)
        except (FileNotFoundError, PermissionError):
            return None
        try:
            head = reader.read_at(0, min(WINDOW, e.size))
            self.limiter.acquire(len(head))
            for c in sorted(eligible, key=lambda c: (-c["committed_size"], -c["last_seen"])):
                n = min(WINDOW, c["committed_size"])
                try:
                    if head[:n] != self._local_read(c, 0, n):
                        continue
                    ok, detail = self._compare_windows(reader, c, c["committed_size"])
                except CaptureDamaged as d:
                    self.store.mark_damaged(c["id"], str(d))
                    continue
                self.store.record_check(c["id"], "rename_continuity", "match" if ok else "mismatch", f"{printable(e.path)}: {detail}")
                if ok:
                    return c
        finally:
            reader.close()
        return None

    # --- transfers ----------------------------------------------------------------------

    def _update_quota_state(self, cfg: CollectorConfig) -> int:
        """Bytes that may still be stored; records (and clears) the blocked state as it changes."""
        remaining = cfg.quota_bytes - self.store.usage_bytes
        try:
            free = shutil.disk_usage(self.store.root).free - cfg.min_free_bytes
        except OSError:
            free = remaining
        allowed = min(remaining, free)
        if allowed <= 0:
            reason = (f"storage quota reached ({human_bytes(self.store.usage_bytes)} of {human_bytes(cfg.quota_bytes)})"
                      if remaining <= 0 else f"free disk space is below the configured minimum ({human_bytes(cfg.min_free_bytes)})")
            if self.quota_blocked != reason:
                self.quota_blocked = reason
                self.store.meta_set("quota_blocked", reason)
                self.store.add_event("error", "quota_blocked",
                                     f"Collection stopped acquiring new bytes: {reason}. Nothing was deleted. Raise the quota, "
                                     "free disk space or explicitly delete exported captures to resume.")
        elif self.quota_blocked is not None:
            self.quota_blocked = None
            self.store.meta_set("quota_blocked", "")
            self.store.add_event("info", "quota_resumed", "Storage is available again; transfers resumed")
        return allowed

    def _quota_allowance(self, cfg: CollectorConfig) -> int:
        allowed = self._update_quota_state(cfg)
        if allowed <= 0:
            raise QuotaBlocked(self.quota_blocked)
        return allowed

    def _fetch_pending(self, src: SourceConfig, fs, cfg: CollectorConfig) -> None:
        pending = [c for c in self.store.captures(src.id, presence=("present",)) if c["observed_size"] > c["committed_size"]]
        pending.sort(key=lambda c: (c["first_seen"], c["id"]))
        budget = cfg.max_bytes_per_cycle
        for cap in pending:
            if budget <= 0 or self.halted():
                break
            try:
                fetched = self._fetch(fs, cap, cfg, budget)
                budget -= fetched
                self._clear_condition(("read_error", cap["id"]))
                if fetched and cap["error"] == "permission denied at source":
                    self.store.update_capture(cap["id"], error=None)  # only a resolved read problem is cleared
            except (QuotaBlocked, LocalStoreError):
                break  # stop transferring this cycle; listing and status classification still complete
            except CaptureDamaged as d:
                self.store.mark_damaged(cap["id"], str(d))  # its source file is collected again next poll
            except CaptureDeleted:
                continue  # the user deleted it mid-transfer; nothing more is appended
            except PermissionError as e:
                self._condition(("read_error", cap["id"]), "warning", "permission_denied",
                                f"Permission denied reading {printable(cap['path'])}; it will be retried. ({printable(str(e), 120)})",
                                source_id=src.id, capture_id=cap["id"])
                self.store.update_capture(cap["id"], error="permission denied at source")
            except FileNotFoundError:
                continue  # vanished since listing; reconciled next poll

    def _fetch(self, fs, cap: dict, cfg: CollectorConfig, budget: int) -> int:
        start = cap["committed_size"]
        target = cap["observed_size"]
        if target <= start:
            return 0
        reader = fs.open(cap["path"])
        fetched = 0
        try:
            if start > 0:
                n = min(WINDOW, start)
                remote = reader.read_at(0, n)
                self.limiter.acquire(len(remote))
                if remote != self._local_read(cap, 0, n):
                    self.store.record_check(cap["id"], "pre_transfer_head", "mismatch", "head differs; transfer deferred")
                    # Force the full prefix re-check next poll even if the listing shows the same size and time,
                    # so a same-size rewrite is recorded as a replacement instead of being deferred forever.
                    self.store.update_capture(cap["id"], observed_mtime=-1.0)
                    return 0
            path = self.store.data_path(cap)
            if not path.exists():
                raise CaptureDamaged("local copy is missing")
            try:
                out = open(path, "r+b")
            except OSError as e:
                raise self._local_failure(e) from None
            with out:
                if os.fstat(out.fileno()).st_size < start:
                    # Never "truncate" upward: that would zero-fill committed bytes.
                    raise CaptureDamaged(f"local copy is shorter than its {start} committed bytes")
                try:
                    out.truncate(start)  # discard bytes from any earlier interrupted attempt
                except OSError as e:
                    raise self._local_failure(e) from None
                offset = start
                while offset < target and fetched < budget and not self.halted():
                    allowed = self._quota_allowance(cfg)
                    want = min(cfg.chunk_bytes, target - offset, budget - fetched, allowed)
                    h = hashlib.sha256()
                    got = 0
                    try:
                        while got < want:
                            if got and self.halted():
                                break  # pause/disable/stop: commit what was read, then stop reading
                            # Remote read: errors here mean the source/connection failed.
                            piece = reader.read_at(offset + got, min(READ_BLOCK, want - got))
                            if not piece:
                                break
                            self.limiter.acquire(len(piece))
                            # Local write: errors here mean the store failed (e.g. disk full).
                            try:
                                out.seek(offset + got)
                                out.write(piece)
                            except OSError as e:
                                raise self._local_failure(e) from None
                            h.update(piece)
                            got += len(piece)
                        if got == 0:
                            break
                        try:
                            out.flush()
                            os.fsync(out.fileno())
                        except OSError as e:
                            raise self._local_failure(e) from None
                    except BaseException:
                        self._rollback(out, offset)  # uncommitted bytes never survive a failure
                        raise
                    # Verify-before-commit: re-read the head through the same open handle.
                    n = min(WINDOW, offset + got)
                    try:
                        again = reader.read_at(0, n)
                        self.limiter.acquire(len(again))
                        out.seek(0)
                        local_head = out.read(n)
                    except BaseException:
                        self._rollback(out, offset)
                        raise
                    if again != local_head:
                        self._rollback(out, offset)
                        flags = dict(cap["flags"], inconsistent_transfer=True)
                        self.store.update_capture(cap["id"], flags=flags)
                        cap["flags"] = flags
                        self.store.record_check(cap["id"], "post_chunk_head", "mismatch", f"chunk at {offset} discarded")
                        self.store.add_event("warning", "changed_during_transfer",
                                             f"{printable(cap['path'])} changed while it was being transferred; the uncommitted "
                                             f"chunk at offset {offset} was discarded and earlier bytes are preserved",
                                             source_id=cap["source_id"], capture_id=cap["id"])
                        break
                    checks = ("pre:head" if start > 0 else "pre:first-bytes") + ";post:head-reread"
                    self.store.commit_segment(cap["id"], offset, got, h.hexdigest(), checks, self.clock.time(),
                                              performed=[("post_chunk_head", "match"), ("segment_sha256", "recorded")])
                    offset += got
                    fetched += got
                    if got < want:
                        break  # fewer bytes than listed (shrinking/rotating, or halted); reconcile next poll
        finally:
            reader.close()
        if fetched:
            if self.store_write_error:
                self.store.add_event("info", "store_write_resumed", "Local store writes succeeded again")
                self.store_write_error = None
        return fetched

    @staticmethod
    def _rollback(out, offset: int) -> None:
        try:
            out.truncate(offset)
            out.flush()
            os.fsync(out.fileno())
        except OSError:
            pass  # recovery at next start truncates to the committed size anyway

    def _local_failure(self, e: OSError) -> LocalStoreError:
        msg = f"Writing to the local store failed: {e.__class__.__name__}: {printable(str(e), 200)}"
        if self.store_write_error != msg:
            self.store_write_error = msg
            self.store.add_event("error", "store_write_failed", msg + ". Uncommitted bytes were discarded; collection retries next poll.")
        return LocalStoreError(msg)

    # --- status classification ----------------------------------------------------------

    def _classify_source(self, src: SourceConfig, cfg: CollectorConfig) -> None:
        caps = self.store.captures(src.id)
        sep = "/" if src.kind == "sftp" else os.sep
        changes: list[tuple[int, dict]] = []
        newest_by_dir: dict[str, float] = {}
        for c in caps:
            d = c["path"].rsplit(sep, 1)[0]
            newest_by_dir[d] = max(newest_by_dir.get(d, 0.0), c["first_seen"])
        for c in caps:
            d = c["path"].rsplit(sep, 1)[0]
            newer = newest_by_dir.get(d, 0.0) > c["last_change"]
            struct_ok = None
            if c["presence"] == "present" and c["committed_size"] == c["observed_size"] and (
                    c["quiet_s"] >= cfg.complete_after_s or (c["reconnects_since_change"] >= 1 and newer)):
                struct_ok = self._structure_ok(c)
            status, reasons = classify(c, cfg, struct_ok, newer)
            flags = dict(c["flags"])
            if status == "complete":
                flags["was_complete"] = True
            if status != c["status"] or reasons != c["status_reasons"] or flags != c["flags"]:
                changes.append((c["id"], dict(status=status, status_reasons=reasons, flags=flags)))
        if changes:
            with self.store.write() as w:
                for cid, fields in changes:
                    self.store.update_capture(cid, conn=w, **fields)

    def _structure_ok(self, cap: dict) -> bool | None:
        info = self.store.format_cache_get(cap["id"], cap["committed_size"])
        if info is None:
            info = formats.analyze_file(self.store.data_path(cap), cap["committed_size"], cap["original_name"])
            self.store.format_cache_put(cap["id"], cap["committed_size"], info)
        return formats.structure_complete(info)


def classify(cap: dict, cfg: CollectorConfig, struct_ok: bool | None, newer_in_dir: bool) -> tuple[str, list[str]]:
    """Acquisition status of a capture, with human-readable reasons. Pure function."""
    committed = cap["committed_size"]
    if cap["presence"] == "present":
        pending = cap["observed_size"] - committed
        quiet = cap["quiet_s"]
        if cap["flags"].get("inconsistent_transfer"):
            return "uncertain", ["the start of the file changed while it was being transferred; captured bytes may mix "
                                 "versions of the file"]
        if quiet < cfg.active_window_s:
            reasons = [f"changed within the last {int(cfg.active_window_s)} s of observation; may still be recording"]
            if pending > 0:
                reasons.append(f"{pending} observed bytes not yet transferred")
            return "active", reasons
        if pending > 0:
            return "partial", [f"{pending} bytes observed at the source are not yet captured (transfer in progress, or "
                               "blocked by quota or errors)"]
        basis = None
        if quiet >= cfg.complete_after_s:
            basis = f"unchanged for at least {int(cfg.complete_after_s)} s of continuous connected observation"
        elif cap["reconnects_since_change"] >= 1 and newer_in_dir:
            basis = ("unchanged across a new connection to the source (reconnection, resume or collector restart) while "
                     "a newer recording appeared in the same folder")
        if basis is not None:
            if struct_ok is False:
                return "partial", ["the final record is incomplete (or the record structure breaks); the writer probably "
                                   "stopped mid-record", basis]
            return "complete", [basis, "all observed bytes were captured",
                                "format structure ends on a record boundary" if struct_ok else
                                "format structure not checkable; completeness rests on observation only",
                                "the collector cannot see whether the writer closed the file"]
        return "idle", [f"unchanged for at least {int(cfg.active_window_s)} s; the writer may still have the file open, "
                        "so it is not considered complete yet"]
    if cap["presence"] == "detached":
        return "uncertain", ["the local copy failed an integrity check, so this capture is excluded from exports; the "
                             "source file (if still present) was collected again as a new capture"]
    where = "removed from the source" if cap["presence"] == "missing" else "replaced or truncated at the same path"
    gap = cap["max_observed_size"] - committed
    since = utc_iso(cap.get("missing_since"))
    if gap > 0:
        return "partial", [f"{where} (noticed {since}) before {gap} observed bytes were transferred; those bytes could not "
                           "be recovered"]
    if cap["flags"].get("was_complete") or cap["status"] == "complete":
        return "complete", [f"was complete before it was {where} (noticed {since})"] + [
            r for r in cap["status_reasons"] if not r.startswith("was complete")][:3]
    return "uncertain", [f"{where} (noticed {since}); all {committed} bytes seen up to the previous observation were "
                         "captured, but anything written after that observation was never seen"]
