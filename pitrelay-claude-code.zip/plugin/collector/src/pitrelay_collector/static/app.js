"use strict";
// PitRelay Collector UI. All server-provided text is inserted with textContent (never innerHTML):
// file names, log messages and errors come from robots and are untrusted.

// The session token arrives in the URL fragment (never sent to a server). It is kept in sessionStorage, which
// is scoped to this exact origin including the port, and removed from the address bar.
const TOKEN_KEY = "pitrelay-collector-token";
let TOKEN = (() => {
  const m = /(?:^#|&)token=([A-Za-z0-9_-]+)/.exec(location.hash);
  if (m) {
    try { sessionStorage.setItem(TOKEN_KEY, m[1]); } catch (e) { /* storage blocked: keep it for this page only */ }
    history.replaceState(null, "", location.pathname);
    return m[1];
  }
  try { return sessionStorage.getItem(TOKEN_KEY); } catch (e) { return null; }
})();
// A browser started by the collector gets a single-use launch code instead of the token (#launch=...).
const LAUNCH = (/(?:^#|&)launch=([A-Za-z0-9_-]+)/.exec(location.hash) || [])[1];
if (LAUNCH) history.replaceState(null, "", location.pathname);

async function exchangeLaunchCode() {
  const r = await fetch("/api/launch", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code: LAUNCH }) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.token) return null;
  try { sessionStorage.setItem(TOKEN_KEY, data.token); } catch (e) { /* keep it for this page only */ }
  return data.token;
}
const $ = (id) => document.getElementById(id);
let lastStatus = null;
let config = null;
let observations = [];
let captureRows = [];

function el(tag, attrs, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (v === true) e.setAttribute(k, "");
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const c of children.flat()) if (c != null) e.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return e;
}

function showSignIn() {
  $("signin").hidden = false;
  document.querySelector("main").hidden = true;
}

async function api(path, body) {
  const headers = { Authorization: "Bearer " + (TOKEN || "") };
  const opts = body === undefined ? { headers } : {
    method: "POST", headers: { ...headers, "Content-Type": "application/json" }, body: JSON.stringify(body),
  };
  const r = await fetch(path, opts);
  const data = await r.json().catch(() => ({}));
  if (r.status === 401) showSignIn();
  if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data;
}

async function download(path) {
  const t = await api("/api/download-ticket", { path });
  location.assign(t.url);
}

function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (t.hidden = true), 5000);
}

async function act(fn, okMsg) {
  try { const r = await fn(); if (okMsg) toast(okMsg); return r; }
  catch (e) { toast("Error: " + e.message); return null; }
}

const fmtTime = (iso) => (iso ? new Date(iso).toLocaleString() : "—");
function fmtBytes(n) {
  if (n == null) return "unknown";
  const u = ["B", "KiB", "MiB", "GiB", "TiB"]; let i = 0; let v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return (i ? v.toFixed(1) : v) + " " + u[i];
}
const STATE_LABEL = { collecting: "Collecting", disconnected: "Disconnected", paused: "Paused", disabled: "Disabled",
  stopped: "Stopped", no_sources: "No sources", sources_disabled: "All sources disabled", blocked: "Storage full" };

// --- tabs ---------------------------------------------------------------------------------
document.querySelectorAll(".tabs button").forEach((b) => b.addEventListener("click", () => {
  document.querySelectorAll(".tabs button").forEach((x) => x.setAttribute("aria-selected", x === b ? "true" : "false"));
  document.querySelectorAll(".tab").forEach((s) => (s.hidden = s.id !== "tab-" + b.dataset.tab));
  if (b.dataset.tab === "export") loadCaptures();
  if (b.dataset.tab === "setup") loadConfig();
}));

// --- status ---------------------------------------------------------------------------------
async function refresh() {
  try {
    const s = await api("/api/status");
    lastStatus = s;
    $("offline").hidden = true;
    renderStatus(s);
  } catch (e) {
    if (!$("signin").hidden) return;
    $("offline").hidden = false;
    const st = $("state");
    st.className = "state s-stopped";
    st.textContent = "Stopped / unreachable";
  }
}

function renderStatus(s) {
  const st = $("state");
  st.className = "state s-" + s.overall;
  st.textContent = STATE_LABEL[s.overall] || s.overall;
  $("state-help").textContent = s.overall_help;
  $("btn-enable").textContent = s.collection_enabled ? "Disable automatic collection" : "Enable automatic collection";
  $("btn-enable").className = s.collection_enabled ? "" : "primary";
  $("btn-pause").textContent = s.paused ? "Resume" : "Pause";
  $("btn-pause").disabled = !s.collection_enabled;
  $("last-success").textContent = fmtTime(s.last_successful_collection_utc);
  $("cap-total").textContent = String(s.captures.total) + " (" + fmtBytes(s.captures.bytes) + ")";
  $("cap-breakdown").textContent = Object.entries(s.captures.by_status).map(([k, v]) => `${v} ${k}`).join(" · ");
  const st2 = s.storage;
  const pct = st2.quota_bytes ? Math.min(100, (100 * st2.usage_bytes) / st2.quota_bytes) : 0;
  $("storage-text").textContent = `${fmtBytes(st2.usage_bytes)} of ${fmtBytes(st2.quota_bytes)}`;
  const bar = $("storage-bar");
  bar.style.width = pct.toFixed(1) + "%";
  bar.className = pct >= 95 || st2.blocked ? "full" : "";
  $("storage-free").textContent = `Free disk: ${fmtBytes(st2.free_disk_bytes)} (keeping ${fmtBytes(st2.min_free_bytes)} free)`;

  const alerts = $("alerts");
  alerts.replaceChildren(...s.alerts.map((a) => el("div", { class: "alert " + a.level },
    a.source ? el("strong", { text: a.source + ": " }) : null, a.message || "")));

  $("sources-status").replaceChildren(...(s.sources.length ? s.sources.map(renderSourceStatus)
    : [el("p", { class: "muted", text: "No sources yet. Add the robot and any Driver Station folders in Setup." })]));
  $("events").replaceChildren(...s.recent_events.map((e) => el("tr", { class: "level-" + e.level },
    el("td", { text: fmtTime(e.t_utc) }), el("td", { text: e.level }), el("td", { text: e.message }))));
  $("store-path").textContent = s.store;
  renderAutostart(s.autostart);
}

function renderSourceStatus(src) {
  const kv = el("dl", { class: "kv" },
    el("dt", { text: "Last success" }), el("dd", { text: fmtTime(src.last_success_utc) }),
    el("dt", { text: "Captures" }), el("dd", { text: String(src.captures) }));
  if (src.connected_host && src.connected_host !== "local") kv.append(el("dt", { text: "Via" }), el("dd", { text: src.connected_host }));
  if (src.last_error) kv.append(el("dt", { text: "Last problem" }), el("dd", { text: src.last_error }));
  if (src.next_attempt_utc && src.raw_state !== "connected") kv.append(el("dt", { text: "Next retry" }), el("dd", { text: fmtTime(src.next_attempt_utc) }));
  if (src.directories) {
    // Show where a linked folder (e.g. /u/logs) actually leads, since that is the folder being read.
    const dirs = Object.entries(src.directories).map(([d, info]) =>
      `${d}${info.realpath && info.realpath !== d ? ` → ${info.realpath}` : ""}: ${info.status}`
      + `${info.files != null ? ` (${info.files} files)` : ""}`
      + `${info.online_only_skipped ? `, ${info.online_only_skipped} online-only skipped` : ""}`);
    kv.append(el("dt", { text: "Folders" }), el("dd", { text: dirs.join("; ") }));
  }
  const box = el("div", { class: "src" },
    el("div", { class: "head" }, el("span", { class: "name", text: src.alias }),
      el("span", { class: "pill " + src.state, text: src.state.replace(/_/g, " ") }),
      el("span", { class: "muted small", text: src.kind === "sftp" ? "SFTP" : "local folder" })), kv);
  const key = src.pending_host_key;
  if (key && (src.raw_state === "host_key_untrusted" || src.raw_state === "host_key_mismatch")) {
    const changed = src.raw_state === "host_key_mismatch";
    box.append(el("div", { class: "alert " + (changed ? "error" : "warning") },
      el("p", { text: changed
        ? "The robot presented a DIFFERENT identity key than the one you trusted. This is expected after re-imaging the controller; otherwise it may be a different device. Collection is refused until you decide."
        : "First connection: confirm this is your robot's identity key before any login is attempted." }),
      el("p", {}, `${key.type} `, el("span", { class: "fingerprint", text: key.fingerprint }), ` at ${key.host}`),
      el("button", { class: changed ? "danger" : "primary", onclick: () => act(
        () => api("/api/trust", { source_id: src.id, fingerprint: key.fingerprint }).then(refresh),
        "Host key trusted") }, changed ? "I re-imaged it: trust the new key" : "Trust this key")));
  }
  return box;
}

$("btn-enable").addEventListener("click", () => act(() => api("/api/control",
  { action: lastStatus && lastStatus.collection_enabled ? "disable" : "enable" }).then(refresh)));
$("btn-pause").addEventListener("click", () => act(() => api("/api/control",
  { action: lastStatus && lastStatus.paused ? "resume" : "pause" }).then(refresh)));
$("btn-poll").addEventListener("click", () => act(() => api("/api/control", { action: "poll_now" }), "Checking sources"));
$("btn-stop").addEventListener("click", () => {
  if (confirm("Stop the collector? Nothing will be collected until it is started again.")) {
    act(() => api("/api/control", { action: "stop" }), "Collector stopping");
  }
});

// --- setup ----------------------------------------------------------------------------------
async function loadConfig() {
  config = await act(() => api("/api/config"));
  if (!config) return;
  const p = config.robot_profile;
  $("prof-controller").value = p.controller || "";
  $("prof-season").value = p.season || "";
  $("sources-list").replaceChildren(...config.sources.map((s) => el("div", { class: "src" },
    el("div", { class: "head" }, el("span", { class: "name", text: s.alias }),
      el("span", { class: "muted small", text: `${s.kind === "sftp" ? "SFTP " + s.hosts.join(", ") : "local"} · ${s.directories.join(", ")}` }),
      el("button", { onclick: () => editSource(s) }, "Edit"),
      el("button", { class: "danger-outline", onclick: () => {
        if (confirm(`Remove source "${s.alias}"? Its collected captures are kept.`))
          act(() => api("/api/sources/delete", { id: s.id }).then(loadConfig), "Source removed");
      } }, "Remove")),
    s.kind === "sftp" ? el("div", { class: "muted small" }, "Trusted key: ",
      s.trusted_host_keys.length ? el("span", { class: "fingerprint", text: s.trusted_host_keys[0].fingerprint }) : "none yet (confirm on the Status tab)",
      s.auth === "password" ? ` · password ${s.password_state === "unavailable" ? "unknown: the system credential store is locked or unavailable" : s.has_password ? "stored in system keychain" : "NOT set"}` : "") : null)));
  const f = $("settings-form");
  f.bandwidth_kib.value = config.bandwidth_limit_bps ? Math.round(config.bandwidth_limit_bps / 1024) : "";
  f.quota_gib.value = (config.quota_bytes / 1024 ** 3).toFixed(1);
  f.min_free_gib.value = (config.min_free_bytes / 1024 ** 3).toFixed(1);
  f.active_window_s.value = config.active_window_s;
  f.complete_after_s.value = config.complete_after_s;
  f.owlet_path.value = config.owlet_path || "";
}

function setKindVisibility() {
  const f = $("source-form");
  const sftp = f.kind.value === "sftp";
  f.querySelectorAll(".sftp-only").forEach((x) => (x.hidden = !sftp));
  f.querySelector(".key-only").hidden = f.auth.value !== "key";
  f.querySelector(".pw-only").hidden = f.auth.value !== "password";
}
$("source-form").kind.addEventListener("change", setKindVisibility);
$("source-form").auth.addEventListener("change", setKindVisibility);

function editSource(s) {
  const f = $("source-form");
  f.reset();
  f.id.value = s ? s.id : "";
  if (s) {
    for (const k of ["kind", "alias", "role", "poll_interval_s", "port", "username", "auth", "recursive_depth"]) f[k].value = s[k];
    f.key_file.value = s.key_file || "";
    f.hosts.value = s.hosts.join(", ");
    f.directories.value = s.directories.join("\n");
    f.text_patterns.value = s.text_patterns.join(", ");
    f.include_csv.checked = s.include_csv;
    f.enabled.checked = s.enabled;
  } else {
    f.username.value = "lvuser";
  }
  $("source-editor-title").textContent = s ? `Edit source "${s.alias}"` : "Add a source";
  $("source-editor").open = true;
  setKindVisibility();
}
$("btn-new-source").addEventListener("click", () => editSource(null));
$("btn-cancel-source").addEventListener("click", () => ($("source-editor").open = false));

$("source-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const f = ev.target;
  const split = (v, re) => v.split(re).map((x) => x.trim()).filter(Boolean);
  const src = {
    kind: f.kind.value, alias: f.alias.value, role: f.role.value, poll_interval_s: Number(f.poll_interval_s.value),
    directories: split(f.directories.value, /\n/), recursive_depth: Number(f.recursive_depth.value),
    text_patterns: split(f.text_patterns.value, /,/), include_csv: f.include_csv.checked, enabled: f.enabled.checked,
    hosts: split(f.hosts.value, /,/), port: Number(f.port.value), username: f.username.value, auth: f.auth.value,
    key_file: f.key_file.value || null,
  };
  if (f.id.value) src.id = f.id.value;
  const cfg = await act(() => api("/api/sources", { source: src }), "Source saved");
  if (!cfg) return;
  if (src.kind === "sftp" && src.auth === "password" && f.password.value) {
    await act(() => api("/api/secret", { source_id: cfg.saved_id, name: "password", value: f.password.value }), "Password stored in the system keychain");
    f.password.value = "";
  }
  loadConfig();
});

$("btn-suggest").addEventListener("click", async () => {
  const f = $("source-form");
  const r = await act(() => api("/api/suggest-dirs?role=" + encodeURIComponent(f.role.value)));
  if (!r) return;
  if (!r.directories.length) { $("suggest-note").textContent = "No documented default for this role; enter the folder yourself."; return; }
  f.directories.value = r.directories.join("\n");
  $("suggest-note").textContent = "Documented defaults for the selected profile. Remove any that do not apply.";
});

$("btn-save-profile").addEventListener("click", () => act(() => api("/api/settings", { robot_profile: {
  controller: $("prof-controller").value || null, season: $("prof-season").value ? Number($("prof-season").value) : null,
} }), "Profile saved"));

$("btn-inspect").addEventListener("click", async () => {
  const r = await act(() => api("/api/inspect-project", { path: $("proj-path").value, apply: $("proj-apply").checked }));
  if (!r) return;
  const f = r.facts;
  const head = el("p", { class: "muted", text: `Detected WPILib ${f.wpilib_version || "unknown"} (season ${f.season || "unknown"}), `
    + `${f.vendordeps.length} vendor libraries, ${f.scanned_files} source files scanned. Nothing was run or changed.` });
  $("guidance").replaceChildren(head, ...r.guidance.map((g) => el("div", { class: "guide " + g.level },
    el("div", { text: g.text }), el("div", { class: "muted small", text: "Checked against: " + g.documentation }),
    g.proposed_snippet_not_applied ? el("pre", { text: "// Proposed (not applied):\n" + g.proposed_snippet_not_applied }) : null)));
  if ($("proj-apply").checked) loadConfig();
});

$("settings-form").addEventListener("submit", (ev) => {
  ev.preventDefault();
  const f = ev.target;
  act(() => api("/api/settings", {
    bandwidth_limit_bps: f.bandwidth_kib.value ? Number(f.bandwidth_kib.value) * 1024 : null,
    quota_bytes: Math.round(Number(f.quota_gib.value) * 1024 ** 3),
    min_free_bytes: Math.round(Number(f.min_free_gib.value) * 1024 ** 3),
    active_window_s: Number(f.active_window_s.value), complete_after_s: Number(f.complete_after_s.value),
    owlet_path: f.owlet_path.value || null,
  }).then(loadConfig), "Limits saved");
});

function renderAutostart(a) {
  if (!a) return;
  const b = $("btn-autostart");
  $("autostart-text").textContent = !a.supported ? "Not supported on this platform."
    : (a.enabled ? `Enabled: the collector starts when you log in (${a.mechanism}).` : "Off. The collector runs only when you start it.")
      + (a.verified_on_this_platform ? "" : " (Platform behavior UNVERIFIED in this release.)");
  b.textContent = a.enabled ? "Turn off launch at login" : "Launch collector at login";
  b.disabled = !a.supported;
  b.onclick = () => {
    if (a.enabled) return act(() => api("/api/autostart", { enable: false }).then(refresh), "Launch at login turned off");
    if (confirm("Start PitRelay Collector automatically every time you log in to this computer? You can turn this off here at any time."))
      act(() => api("/api/autostart", { enable: true, confirm: true }).then(refresh), "Launch at login turned on");
  };
}

// --- export -----------------------------------------------------------------------------------
const localToIso = (v) => (v ? new Date(v).toISOString() : null);

async function loadCaptures(all) {
  if (all) { $("ex-from").value = ""; $("ex-to").value = ""; }
  const qs = new URLSearchParams();
  if ($("ex-from").value) qs.set("since", localToIso($("ex-from").value));
  if ($("ex-to").value) qs.set("until", localToIso($("ex-to").value));
  const r = await act(() => api("/api/captures?" + qs));
  if (!r) return;
  captureRows = r.captures;
  $("cap-rows").replaceChildren(...(captureRows.length ? captureRows.map((c) => el("tr", {},
    el("td", {}, el("input", { type: "checkbox", class: "cap-pick", "data-id": String(c.id), checked: true, "aria-label": "include" })),
    el("td", { text: c.source }), el("td", { class: "name", text: c.name, title: (c.reasons || []).join("; ") }),
    el("td", {}, el("span", { class: "pill " + c.status, text: c.status })), el("td", { text: fmtBytes(c.size) }),
    el("td", { text: fmtTime(c.first_seen_utc) })))
    : [el("tr", {}, el("td", { colspan: "6", class: "muted", text: "No captures in this range yet." }))]));
  $("cap-all").checked = true;
}
$("btn-list").addEventListener("click", () => loadCaptures(false));
$("btn-all").addEventListener("click", () => loadCaptures(true));
$("cap-all").addEventListener("change", (e) => document.querySelectorAll(".cap-pick").forEach((x) => (x.checked = e.target.checked)));
const pickedIds = () => [...document.querySelectorAll(".cap-pick")].filter((x) => x.checked).map((x) => Number(x.dataset.id));

function renderObservations() {
  $("obs-list").replaceChildren(...observations.map((o, i) => el("div", { class: "obs" },
    el("div", {}, el("strong", { text: (o.author || "anonymous") + (o.observed_time_as_stated ? ` (${o.observed_time_as_stated})` : "") + ": " }), o.text),
    el("button", { onclick: () => { observations.splice(i, 1); renderObservations(); } }, "Remove"))));
}
$("btn-add-obs").addEventListener("click", () => {
  const text = $("obs-text").value.trim();
  if (!text) return toast("Write what happened first.");
  observations.push({ author: $("obs-author").value.trim(), observed_time_as_stated: $("obs-when").value.trim(), text });
  $("obs-text").value = ""; $("obs-when").value = "";
  renderObservations();
});

$("btn-export").addEventListener("click", async () => {
  const ids = pickedIds();
  if (!ids.length) return toast("Select at least one capture (use \"All retained\" to list them).");
  const body = { capture_ids: ids, observations, source_project_dir: $("ex-src").value.trim(), out_dir: $("ex-out").value.trim(),
    max_archive_mb: $("ex-max").value ? Number($("ex-max").value) : null, label: $("ex-label").value.trim(), convert_hoot: $("ex-hoot").checked };
  const btn = $("btn-export");
  btn.disabled = true;
  $("export-result").replaceChildren(el("p", { class: "muted", text: "Exporting and verifying… collection continues meanwhile." }));
  const r = await act(() => api("/api/export", body));
  if (!r) { btn.disabled = false; return; }
  const poll = async () => {
    const j = await api("/api/export/" + r.job).catch(() => null);
    if (!j || j.state === "running") return setTimeout(poll, 1000);
    btn.disabled = false;
    if (!j.ok) {
      $("export-result").replaceChildren(el("div", { class: "result fail" }, el("strong", { text: "Export failed. No package was produced." }), el("p", { text: j.error || "" })));
      return;
    }
    $("export-result").replaceChildren(el("div", { class: "result ok" },
      el("strong", { text: `Exported and verified ${j.archives.length} package${j.archives.length > 1 ? "s" : ""}.` }),
      ...j.archives.map((a) => el("div", {},
        el("p", {}, el("button", { type: "button", class: "link", text: a.path.split(/[\\/]/).pop(),
          onclick: () => act(() => download(a.path)) }),
          ` · ${fmtBytes(a.size_bytes)} · ${a.captures} captures · ${a.verified_files} files hash-verified`),
        el("p", { class: "muted small" }, "SHA-256 ", el("span", { class: "fingerprint", text: a.sha256 })),
        el("p", { class: "muted small", text: "Saved at " + a.path }))),
      ...(j.warnings || []).map((w) => el("p", { class: "muted", text: "Note: " + w })),
      el("p", { class: "muted small", text: "Private package, not anonymized. Give it to PitRelay with: pitrelay-collector extract <zip> <folder>." })));
  };
  poll();
});

$("btn-delete").addEventListener("click", () => {
  const ids = pickedIds();
  if (!ids.length) return toast("Select the captures to delete in the list above.");
  act(() => api("/api/delete-captures", { ids, confirm: $("del-confirm").value.trim() }).then((r) => {
    $("del-confirm").value = "";
    loadCaptures(false);
    toast(`Deleted ${r.deleted.length} local capture(s).`);
  }));
});

(async () => {
  if (LAUNCH) TOKEN = (await exchangeLaunchCode()) || TOKEN;
  if (TOKEN) {
    refresh();
    setInterval(refresh, 3000);
    setKindVisibility();
  } else {
    showSignIn();
  }
})();
