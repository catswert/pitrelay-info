"""Expected PitRelay routes for collected files.

Facts below were observed by running the PitRelay local package supplied for
this project (``pitrelay-0.1.0-dev-20261006-v11``; engine
``engine/pitrelay.jar`` SHA-256
66de12d3968b0c7e360754fabb6db4661416b61129b3b2751bf19952c93ac5d2) in Standard
Access through its CLI/MCP interface (``help``, ``capability.list``,
``artifact.upload_*``, ``log.inspect``, ``log.import_csv``,
``signal.statistics``). They describe that engine build only. A different
PitRelay version may behave differently; the handoff command re-checks the
engine it is given rather than trusting this table.
"""

from __future__ import annotations

ENGINE_PROFILE = {
    "name": "PitRelay",
    "package": "pitrelay-0.1.0-dev-20261006-v11 (internal local package)",
    "engine_sha256": "66de12d3968b0c7e360754fabb6db4661416b61129b3b2751bf19952c93ac5d2",
    "handshake_version": "0.1.0-dev",
    "tool_contract": "2.0",
    "access": "Standard Access (supplied artifacts)",
    "observed_by": "PitRelay Collector developers running the engine CLI/MCP on Linux with OpenJDK 21",
}

UPLOAD_LIMIT_BYTES = 64 * 1024 * 1024  # artifact.upload_begin: "up to 64MiB"
UPLOAD_CHUNK_BYTES = 49152  # artifact.upload_chunk: "at most 49152 decoded bytes"
# log.inspect reported index budget for WPILOG input.
WPILOG_INDEX_BUDGET = {
    "input_bytes": 64 * 1024 * 1024,
    "record_payload_bytes": 2 * 1024 * 1024,
    "records": 400_000,
    "samples": 200_000,
    "entries": 10_000,
}


def pitrelay_route(info: dict, size: int) -> dict:
    """Map a format analysis to the engine operation that should receive the file."""
    fmt = info.get("detected_format")
    version = info.get("format_version")
    route: dict = {"engine_profile": "v11 local package (see manifest.pitrelay_engine_profile)", "verified_against_engine": False}
    limitations: list[str] = []
    if size > UPLOAD_LIMIT_BYTES:
        limitations.append(f"{size} bytes exceeds the engine's 64 MiB per-artifact upload limit; the original is preserved "
                           "but cannot be supplied to this engine whole. Compression does not change this limit.")
    if fmt == "wpilog" and version == "1.0":
        route.update(operation="log.inspect", format_argument=None, upload_kind="log",
                     description="WPILOG is auto-detected by log.inspect; then use log.entries / signal.* operations.")
        st = info.get("structure") or {}
        det = info.get("details") or {}
        if (st.get("records") or 0) > WPILOG_INDEX_BUDGET["records"]:
            limitations.append(f"{st['records']} records exceed the engine's reported index budget of 400000 records; the index may be incomplete.")
        if (st.get("data_records") or 0) > WPILOG_INDEX_BUDGET["samples"]:
            limitations.append(f"{st['data_records']} data records exceed the engine's reported budget of 200000 samples; the index may be incomplete.")
        if (det.get("distinct_entry_names") or 0) > WPILOG_INDEX_BUDGET["entries"]:
            limitations.append("More than 10000 entries exceed the engine's reported entry budget.")
        if (det.get("max_record_payload_bytes") or 0) > WPILOG_INDEX_BUDGET["record_payload_bytes"]:
            limitations.append("A record payload exceeds the engine's reported 2 MiB record budget.")
        if st.get("trailing_incomplete_bytes"):
            limitations.append("Final record is incomplete; the engine reports this as integrity 'truncated_tail'.")
        route["verified_against_engine"] = True
    elif fmt == "wpilog":
        route.update(operation=None, description=f"WPILOG version {version} is not the specified 1.0 format.")
        limitations.append("Engine support for this WPILOG version was not observed.")
    elif fmt == "dslog" and version == "4":
        route.update(operation="log.inspect", format_argument="dslog_v4", upload_kind="log",
                     description="Pass format 'dslog_v4' explicitly; the engine does not auto-detect DS logs.")
        limitations.append("The engine's dslog_v4 adapter keeps power-distribution blocks raw (currents are not decoded) and "
                           "uses an implicit 20 ms record cadence, not measured loop timing.")
        route["verified_against_engine"] = True
    elif fmt == "dsevents" and version == "4" and not (info.get("structure") or {}).get("stopped_early"):
        route.update(operation="log.inspect", format_argument="dsevents_v4", upload_kind="log",
                     description="Pass format 'dsevents_v4' explicitly.")
        route["verified_against_engine"] = True
    elif fmt in ("dslog", "dsevents"):
        route.update(operation=None, description="Only NI Driver Station version 4 is accepted by the engine ('Only native DS version4 is supported').")
        limitations.append("Preserved original; no engine adapter for this DS file version/structure.")
    elif fmt == "revlog":
        route.update(operation="log.inspect", format_argument="rev_native", upload_kind="log",
                     description="Pass format 'rev_native' explicitly.")
        limitations.append("The engine's REV adapter decodes REV SPARK status frames from its pinned layout; other devices or "
                           "newer firmware may decode partially. Decoding of real REV logs was not verified by the collector.")
        if version and not version.startswith("1"):
            limitations.append("REVLOG v2 (written by REVLib releases after 2027.0.0-alpha-8): the PitRelay v11 engine decodes "
                               "REVLOG v1 only and answers 'partial' with record IDs 3 (header) and 6 (frames) unknown, decoding "
                               "nothing; an engine build with REVLOG 2.x support decodes it. Check the engine's answer: if it "
                               "decoded nothing, convert the file to WPILOG with REV's own tools.")
        route["verified_against_engine"] = False  # the route is accepted, but no real REV log was ever decoded
    elif fmt == "hoot":
        route.update(operation=None, upload_kind="log",
                     description="CTRE hoot requires conversion. The engine's log.convert.* operations reported "
                                 "'blocked_host_configuration' (an exact host-pinned utility is required).")
        limitations.append("Collected; conversion unavailable unless a compatible CTRE Owlet is configured. A derived WPILOG, "
                           "if present in derived/, can be supplied to log.inspect instead.")
    elif fmt == "csv":
        route.update(operation="log.import_csv", upload_kind="log",
                     description="CSV requires explicit mappings: timestamp_column, value_column, time_unit (us|ms|s), clock, "
                                 "sampling_policy and unit (or unknown_unit_reason). Then use signal.* with entry '$derived'.")
        limitations.append("The collector does not infer column meaning, time units, clocks or units for CSV files.")
        route["verified_against_engine"] = True
    elif fmt == "text":
        route.update(operation=None, description="Diagnostic text; no engine telemetry adapter. Read it directly as untrusted text.")
    else:
        route.update(operation=None, description="Unrecognized or empty content; preserved without analysis support.")
    route["limitations"] = limitations
    return route
