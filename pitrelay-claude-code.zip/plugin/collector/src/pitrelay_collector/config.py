"""Collector configuration: sources, limits and the robot profile.

The configuration file never contains secrets. Passwords and key passphrases
live in the operating system's credential store (see secrets.py); the config
only records which authentication method a source uses.
"""

from __future__ import annotations

import copy
import fnmatch
import ipaddress
import json
import os
import posixpath
import re
import secrets as _secrets
import threading
from dataclasses import asdict, dataclass, field
from pathlib import Path, PurePosixPath

from .lock import FileMutex
from .util import atomic_write_json

CONFIG_SCHEMA_VERSION = 1
CONFIG_FILENAME = "config.json"

# File types collected by default. CSV and diagnostic text files are opt-in per
# source because they are only meaningful from explicitly selected folders.
DEFAULT_LOG_EXTENSIONS = (".wpilog", ".revlog", ".hoot", ".dslog", ".dsevents")
AUTH_METHODS = ("blank_password", "systemcore_default", "password", "key")
# A documented, public default login is stored as auth "password" plus a preset, never as a new auth value:
# collectors before 1.1 refuse a whole config.json with an auth value they do not know (they share the default
# store), but ignore unknown keys and only lack the password for that one source.
PASSWORD_PRESETS = {"systemcore": "systemcore"}  # WPILib frc-docs 2027 (datalog-download): user and password
SOURCE_KINDS = ("sftp", "local")
SOURCE_ROLES = ("robot", "coprocessor", "driver_station", "vendor_tool", "other")

KIB = 1024
MIB = 1024 * KIB
GIB = 1024 * MIB


class ConfigError(ValueError):
    """A configuration value failed validation; the message is user-facing."""


@dataclass
class SourceConfig:
    id: str
    alias: str
    kind: str  # "sftp" | "local"
    directories: list[str]
    role: str = "other"
    enabled: bool = True
    recursive_depth: int = 2
    include_csv: bool = False
    # Explicitly selected diagnostic text files (glob patterns on file names),
    # e.g. ["FRC_UserProgram.log"]. Empty means none are collected.
    text_patterns: list[str] = field(default_factory=list)
    poll_interval_s: float = 30.0
    # SFTP only
    hosts: list[str] = field(default_factory=list)
    port: int = 22
    username: str = ""
    auth: str = "blank_password"
    password_preset: str | None = None  # with auth "password": a documented default login (PASSWORD_PRESETS)
    key_file: str | None = None
    # Pinned host keys: [{"type": "ssh-ed25519", "fingerprint": "SHA256:...", "key_b64": "...", "trusted_at": "..."}]
    trusted_host_keys: list[dict] = field(default_factory=list)

    @staticmethod
    def new_id() -> str:
        return "src-" + _secrets.token_hex(5)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "SourceConfig":
        known = {f for f in cls.__dataclass_fields__}
        clean = {k: v for k, v in data.items() if k in known}
        if clean.get("auth") == "systemcore_default":
            clean["auth"], clean["password_preset"] = "password", "systemcore"
        return cls(**clean)

    @property
    def auth_choice(self) -> str:
        """The login as chosen in Setup or a tool: one of AUTH_METHODS."""
        if self.auth == "password" and self.password_preset == "systemcore":
            return "systemcore_default"
        return self.auth

    def public_dict(self) -> dict:
        """Description safe for exports and UI (no credentials, no usernames)."""
        d = {
            "id": self.id,
            "alias": self.alias,
            "kind": self.kind,
            "role": self.role,
            "enabled": self.enabled,
            "directories": list(self.directories),
            "recursive_depth": self.recursive_depth,
            "include_csv": self.include_csv,
            "text_patterns": list(self.text_patterns),
        }
        if self.kind == "sftp":
            d["hosts"] = list(self.hosts)
            d["port"] = self.port
            d["host_key_fingerprints"] = [k.get("fingerprint") for k in self.trusted_host_keys]
        return d


@dataclass
class RobotProfile:
    """What the user selected or what project inspection detected.

    None means unknown. Detection never silently overrides a user selection;
    `basis` records where each value came from.
    """

    controller: str | None = None  # "roborio1" | "roborio2" | "systemcore" | None
    season: int | None = None
    wpilib_datalog: bool | None = None
    advantagekit: bool | None = None
    rev_status_logger: bool | None = None
    ctre_signal_logger: bool | None = None
    basis: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict | None) -> "RobotProfile":
        data = data or {}
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class CollectorConfig:
    schema_version: int = CONFIG_SCHEMA_VERSION
    # Automatic collection is off until the user explicitly enables it.
    collection_enabled: bool = False
    sources: list[SourceConfig] = field(default_factory=list)
    bandwidth_limit_bps: int | None = 1 * MIB
    quota_bytes: int = 20 * GIB
    min_free_bytes: int = 1 * GIB
    max_bytes_per_cycle: int = 256 * MIB
    chunk_bytes: int = 4 * MIB
    max_files_per_source: int = 5000
    # A capture is "active" if it changed within this window of connected observation.
    active_window_s: float = 120.0
    # Unchanged for this long (connected observation only) before "complete" is considered.
    complete_after_s: float = 1800.0
    backoff_initial_s: float = 5.0
    # A robot is unreachable during every match and comes back when it is tethered in the pit: retry often enough
    # to catch that window (a failed TCP connect on a LAN costs almost nothing).
    backoff_max_s: float = 30.0
    connect_timeout_s: float = 10.0
    io_timeout_s: float = 30.0
    owlet_path: str | None = None
    robot_profile: RobotProfile = field(default_factory=RobotProfile)
    ui_port: int = 0  # 0 = choose a free port

    def to_dict(self) -> dict:
        d = asdict(self)
        d["sources"] = [s.to_dict() for s in self.sources]
        d["robot_profile"] = self.robot_profile.to_dict()
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "CollectorConfig":
        data = dict(data)
        version = data.get("schema_version", CONFIG_SCHEMA_VERSION)
        if version != CONFIG_SCHEMA_VERSION:
            raise ConfigError(f"Unsupported config schema_version {version!r}; expected {CONFIG_SCHEMA_VERSION}")
        sources = [SourceConfig.from_dict(s) for s in data.pop("sources", [])]
        profile = RobotProfile.from_dict(data.pop("robot_profile", None))
        known = {f for f in cls.__dataclass_fields__}
        cfg = cls(**{k: v for k, v in data.items() if k in known})
        cfg.sources = sources
        cfg.robot_profile = profile
        return cfg

    def source_by_id(self, source_id: str) -> SourceConfig | None:
        return next((s for s in self.sources if s.id == source_id), None)

    def source_by_alias(self, alias: str) -> SourceConfig | None:
        return next((s for s in self.sources if s.alias.lower() == alias.lower()), None)


# --- validation ---------------------------------------------------------------

_ALIAS_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _.-]{0,39}$")
_HOST_RE = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*\.?$")


def validate_host(host: str) -> str:
    host = host.strip()
    try:
        ipaddress.ip_address(host)
        return host
    except ValueError:
        pass
    if not _HOST_RE.match(host):
        raise ConfigError(f"Invalid host name or IP address: {host!r}")
    return host


def _is_filesystem_root(path: str) -> bool:
    p = Path(path)
    return p == Path(p.anchor)


def _same_path(a: Path, b: Path) -> bool:
    """Same file system object. Identity-based, so case-insensitive volumes (macOS, Windows) cannot slip past."""
    try:
        return os.path.samefile(a, b)
    except OSError:
        return os.path.normcase(str(a)).casefold() == os.path.normcase(str(b)).casefold()


def _within(child: Path, parent: Path) -> bool:
    """`child` is `parent` or lies inside it (compared by identity at every level)."""
    return any(_same_path(p, parent) for p in [child, *child.parents])


def _within_text(child: Path, parent: Path) -> bool:
    """`child` is `parent` or lies inside it, by spelling only (no file system access; case-insensitive)."""
    key = os.path.normcase(str(parent)).casefold()
    return any(os.path.normcase(str(p)).casefold() == key for p in [child, *child.parents])


def resolved_folder_problem(real: str, kind: str, store_root: Path | None) -> str | None:
    """Re-check an authorized folder after links in its own path were resolved (e.g. /u/logs -> /media/sda1/logs).

    validate_source checks the path as typed; this checks where it actually leads at poll time.
    """
    if kind == "sftp":
        return "it resolves to the remote filesystem root, which is too broad" if posixpath.normpath(real) == "/" else None
    if _is_filesystem_root(real):
        return "it resolves to a whole drive or filesystem root, which is too broad"
    try:
        rp = Path(real).resolve()
        if _same_path(rp, Path.home().resolve()):
            return "it resolves to your entire home folder, which is too broad"
        if store_root is not None:
            rr = Path(store_root).resolve()
            if _within(rp, rr) or _within(rr, rp):
                return "it resolves to a folder that contains or is inside the collector's own store"
    except OSError:
        pass
    return None


def merge_source(existing: SourceConfig | None, data: dict) -> SourceConfig:
    """`existing` changed by `data`, or a new source from `data`. A chosen auth replaces a stored login preset."""
    merged = (existing.to_dict() if existing else {"id": SourceConfig.new_id(), "directories": []}) | data
    if "auth" in data:
        merged["password_preset"] = None
    return SourceConfig.from_dict(merged)


def is_network_path(text: str) -> bool:
    """A UNC, device or extended path (\\\\server\\share, //server/share, \\\\?\\...). Even checking whether one exists makes
    Windows contact that server and offer the user's credentials, so these are refused before any file access."""
    t = str(text).strip()
    return t.startswith(("\\\\", "//")) or t.startswith(("\\/", "/\\"))


# File names a text pattern never collects: keys, certificates, credential stores and environment files.
CREDENTIAL_FILE_NAMES = (".env", ".env.*", "*.env", "*secret*", "*credential*", "*password*", "*token*", "*.pem",
                         "*.key", "*.p12", "*.pfx", "*.jks", "*.keystore", "id_rsa*", "id_dsa*", "id_ecdsa*",
                         "id_ed25519*", ".netrc", "authorized_keys", "known_hosts")
# Names of unrelated files: a text pattern that matches several of them is a catch-all, not a specific file name.
_UNRELATED_NAMES = ("a", "x.bin", "photo.jpg", "notes.md", "data", "report.docx")


def credential_file_name(name: str) -> bool:
    low = name.lower()
    return low.startswith(".") or any(fnmatch.fnmatchcase(low, pat) for pat in CREDENTIAL_FILE_NAMES)


def check_proposal(src: SourceConfig) -> None:
    """Stricter rules for a source someone else proposed (Claude), checked by the text alone before the person is asked.

    validate_source stays as it was, because it also runs when a saved config is loaded: a rule added there would make
    an existing store unusable for this and older collectors. These rules apply only to new proposals."""
    for d in src.directories:
        if is_network_path(d):
            raise ConfigError(f"Network shares and device paths are not accepted here: {d!r}. The person can map or "
                              "mount the share, copy the logs to a local folder, or add it on the collector page")
        parts = PurePosixPath(d).parts if src.kind == "sftp" else Path(d).parts
        if any(part.startswith(".") and part not in (".", "..") for part in parts):
            raise ConfigError(f"A hidden folder is not accepted as a log folder: {d!r}")
    if src.kind == "sftp":
        for h in src.hosts:
            if _disguised_address(h):
                raise ConfigError(f"{h!r} reads as a numeric address in a form that hides which machine it is; write the "
                                  "address in its usual form (for example 10.12.34.2)")
        if src.auth_choice == "key" and src.key_file is not None and (
                is_network_path(src.key_file) or not os.path.isabs(src.key_file)):
            raise ConfigError("The private key file must be an absolute path on this computer")
    for pattern in src.text_patterns:
        low = pattern.lower()
        if sum(fnmatch.fnmatchcase(n, low) for n in _UNRELATED_NAMES) >= 2:
            raise ConfigError(f"Text pattern {pattern!r} matches almost any file; name the specific files")
        if credential_file_name(pattern) or any(fnmatch.fnmatchcase(n, low) for n in
                                                ("id_rsa", "id_ed25519", ".env", "server.key", "cert.pem",
                                                 "credentials.json", "app.keystore", "secrets.yaml")):
            raise ConfigError(f"Text pattern {pattern!r} would match keys or credential files")


def _disguised_address(host: str) -> bool:
    """A name the resolver reads as an IPv4 address although it is not written as one (octal, hex, short or integer
    forms such as 010.012.034.002, 0x7f.1 or 2130706433), so a dialog would show one address and another is contacted."""
    try:
        ipaddress.ip_address(host)
        return False  # the canonical spelling, as shown
    except ValueError:
        pass
    labels = host.rstrip(".").split(".")
    return all(re.fullmatch(r"(0[xX][0-9a-fA-F]*|[0-9]+)", label) for label in labels if label) or \
        bool(re.fullmatch(r"[0-9]+", labels[-1] if labels else ""))


def validate_source(src: SourceConfig, store_root: Path | None = None, others: list[SourceConfig] = (),
                    touch_filesystem: bool = True) -> SourceConfig:
    """Validate and normalize a source in place; raise ConfigError on problems.

    touch_filesystem=False checks only what the text itself shows (for a proposal not confirmed yet): local folders
    are then compared with the home folder and the store by their spelling, without resolving links."""
    src.alias = src.alias.strip()
    if not _ALIAS_RE.match(src.alias):
        raise ConfigError("Alias must be 1-40 characters: letters, digits, space, '_', '.', '-'")
    if any(o.id != src.id and o.alias.lower() == src.alias.lower() for o in others):
        raise ConfigError(f"Another source already uses the alias {src.alias!r}")
    if src.kind not in SOURCE_KINDS:
        raise ConfigError(f"Source kind must be one of {SOURCE_KINDS}")
    if src.role not in SOURCE_ROLES:
        raise ConfigError(f"Source role must be one of {SOURCE_ROLES}")
    if not (0 <= int(src.recursive_depth) <= 5):
        raise ConfigError("Recursive depth must be between 0 and 5")
    src.recursive_depth = int(src.recursive_depth)
    if not (5 <= float(src.poll_interval_s) <= 3600):
        raise ConfigError("Poll interval must be between 5 and 3600 seconds")
    src.poll_interval_s = float(src.poll_interval_s)
    src.text_patterns = [p.strip() for p in src.text_patterns if p and p.strip()]
    for pattern in src.text_patterns:
        if "/" in pattern or "\\" in pattern or pattern in ("*", "*.*"):
            raise ConfigError(f"Text pattern {pattern!r} must name specific files (no paths, not '*')")

    dirs = [d.strip() for d in src.directories if d and d.strip()]
    if not dirs:
        raise ConfigError("At least one authorized directory is required")
    if src.kind == "sftp":
        normalized = []
        for d in dirs:
            if not d.startswith("/"):
                raise ConfigError(f"Remote directory must be an absolute POSIX path: {d!r}")
            n = posixpath.normpath(d)
            if n == "/":
                raise ConfigError("The remote filesystem root is too broad; choose the log directory itself")
            if any(part == ".." for part in PurePosixPath(n).parts):
                raise ConfigError(f"Remote directory may not contain '..': {d!r}")
            normalized.append(n)
        src.directories = list(dict.fromkeys(normalized))
        src.hosts = [validate_host(h) for h in src.hosts if h and h.strip()]
        if not src.hosts:
            raise ConfigError("An SFTP source needs at least one robot/coprocessor address")
        if not (1 <= int(src.port) <= 65535):
            raise ConfigError("Port must be between 1 and 65535")
        src.port = int(src.port)
        src.username = src.username.strip()
        if not src.username:
            raise ConfigError("An SFTP source needs a username (for a roboRIO the documented user is 'lvuser')")
        if src.auth not in AUTH_METHODS:
            raise ConfigError(f"Authentication must be one of {AUTH_METHODS}")
        if src.auth == "systemcore_default":
            src.auth, src.password_preset = "password", "systemcore"
        if src.auth != "password":
            src.password_preset = None
        if src.auth == "key" and not src.key_file:
            raise ConfigError("Key authentication needs a private key file path")
    else:
        normalized = []
        home = Path.home().resolve() if touch_filesystem else None
        for d in dirs:
            p = Path(os.path.expanduser(d))
            if not p.is_absolute():
                raise ConfigError(f"Local folder must be an absolute path: {d!r}")
            resolved = Path(os.path.normpath(str(p)))
            if _is_filesystem_root(str(resolved)):
                raise ConfigError("A whole drive/filesystem root is too broad; choose the log folder itself")
            if not touch_filesystem:
                if _within_text(Path(os.path.normpath(os.path.expanduser("~"))), resolved):
                    raise ConfigError("Your entire home folder is too broad; choose the specific log folder")
                if store_root is not None:
                    rr = Path(os.path.normpath(os.path.abspath(store_root)))
                    if _within_text(resolved, rr) or _within_text(rr, resolved):
                        raise ConfigError("A collected folder may not contain or be inside the collector's own store")
                normalized.append(str(resolved))
                continue
            try:
                if _same_path(resolved.resolve(), home):
                    raise ConfigError("Your entire home folder is too broad; choose the specific log folder")
            except OSError:
                pass
            if store_root is not None:
                try:
                    rs, rr = resolved.resolve(), Path(store_root).resolve()
                    if _within(rs, rr) or _within(rr, rs):
                        raise ConfigError("A collected folder may not contain or be inside the collector's own store")
                except OSError:
                    pass
            normalized.append(str(resolved))
        src.directories = list(dict.fromkeys(normalized))
        src.hosts, src.username, src.key_file, src.trusted_host_keys = [], "", None, []
    return src


def validate_config(cfg: CollectorConfig, store_root: Path | None = None) -> CollectorConfig:
    seen = []
    for src in cfg.sources:
        validate_source(src, store_root, seen)
        seen.append(src)
    if len({s.id for s in cfg.sources}) != len(cfg.sources):
        raise ConfigError("Duplicate source ids")
    if cfg.bandwidth_limit_bps is not None and int(cfg.bandwidth_limit_bps) < 16 * KIB:
        raise ConfigError("Bandwidth limit must be at least 16 KiB/s (or unlimited)")
    if int(cfg.quota_bytes) < 16 * MIB:
        raise ConfigError("Storage quota must be at least 16 MiB")
    if int(cfg.min_free_bytes) < 0:
        raise ConfigError("Minimum free disk space cannot be negative")
    if not (64 * KIB <= int(cfg.chunk_bytes) <= 64 * MIB):
        raise ConfigError("Chunk size must be between 64 KiB and 64 MiB")
    if int(cfg.max_bytes_per_cycle) < int(cfg.chunk_bytes):
        raise ConfigError("Per-cycle transfer budget must be at least one chunk")
    if not (10 <= float(cfg.active_window_s) <= float(cfg.complete_after_s)):
        raise ConfigError("Active window must be >= 10 s and no longer than the completion period")
    if not (0 < float(cfg.backoff_initial_s) <= float(cfg.backoff_max_s)):
        raise ConfigError("Backoff must satisfy 0 < initial <= maximum")
    if cfg.owlet_path is not None and cfg.owlet_path.strip() == "":
        cfg.owlet_path = None
    return cfg


class ConfigManager:
    """Thread-safe owner of the config file inside a store directory."""

    def __init__(self, store_root: Path):
        self.store_root = Path(store_root)
        self.path = self.store_root / CONFIG_FILENAME
        self._lock = threading.RLock()
        self._cfg: CollectorConfig | None = None
        self._stamp: tuple | None = None
        self.listeners: list = []

    def load(self) -> CollectorConfig:
        with self._lock:
            return copy.deepcopy(self._load_locked())

    @staticmethod
    def _stamp_of(st) -> tuple:
        # A replaced file (atomic write by another process) can keep a coarse mtime; size and inode tell it apart.
        return (st.st_mtime_ns, st.st_size, getattr(st, "st_ino", 0))

    def _load_locked(self) -> CollectorConfig:
        try:
            stamp = self._stamp_of(self.path.stat())
        except FileNotFoundError:
            if self._cfg is None:
                self._cfg = CollectorConfig()
            return self._cfg
        if self._cfg is None or stamp != self._stamp:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            cfg = validate_config(CollectorConfig.from_dict(data), self.store_root)
            self._cfg, self._stamp = cfg, stamp
        return self._cfg

    def _write_locked(self, cfg: CollectorConfig) -> CollectorConfig:
        cfg = validate_config(copy.deepcopy(cfg), self.store_root)
        atomic_write_json(self.path, cfg.to_dict(), mode=0o600)
        self._cfg = cfg
        self._stamp = self._stamp_of(self.path.stat())
        return cfg

    def save(self, cfg: CollectorConfig) -> CollectorConfig:
        with self._lock, FileMutex(self.store_root / "config.lock"):
            cfg = self._write_locked(cfg)
        for listener in list(self.listeners):
            listener(cfg)
        return copy.deepcopy(cfg)

    def update(self, fn) -> CollectorConfig:
        """Apply fn(cfg) to the current configuration and save it; fn may mutate or return a config.

        The read, fn and the write happen under a cross-process lock, so a change made at the same moment by another
        process (a Claude Code session, the CLI, the collecting process) is never overwritten with a stale copy."""
        with self._lock, FileMutex(self.store_root / "config.lock"):
            self._cfg = None  # always re-read inside the lock
            current = copy.deepcopy(self._load_locked())
            result = fn(current)
            cfg = self._write_locked(result if isinstance(result, CollectorConfig) else current)
        for listener in list(self.listeners):
            listener(cfg)
        return copy.deepcopy(cfg)


def suggested_directories(profile: RobotProfile, role: str) -> list[str]:
    """Documented default log folders for the selected controller/season.

    Sources (verified for this release, see docs/ROBOT_SETUP.md):
      * roboRIO, WPILib 2025/2026 DataLogManager: /home/lvuser/logs or /u/logs (USB)
      * AdvantageKit WPILOGWriter default on robot: /U/logs
      * Systemcore, WPILib 2027 docs: /home/systemcore/logs or /u/logs
      * CTRE hoot logs: folder depends on SignalLogger.setPath(); the CTRE docs
        we checked do not state a default, so none is suggested.
    """
    if role in ("robot",):
        if profile.controller == "systemcore":
            return ["/home/systemcore/logs", "/u/logs"]
        dirs = ["/home/lvuser/logs", "/u/logs"]
        if profile.advantagekit:
            dirs.append("/U/logs")
        return dirs
    if role == "driver_station":
        if profile.season is not None and profile.season >= 2027:
            return [r"C:\Users\Public\Documents\FIRSTDriverStation\Logs", "~/.firstds"]
        return [r"C:\Users\Public\Documents\FRC\Log Files", r"C:\Users\Public\Documents\FRC\Log Files\WPILogs"]
    return []
