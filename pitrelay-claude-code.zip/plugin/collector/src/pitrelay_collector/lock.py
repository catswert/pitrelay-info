"""Single-owner lock for a store directory.

Only one collector process may write to a store at a time. The lock is an
operating-system advisory lock held for the life of the process: if the process
dies, the OS releases it, so there is no stale-lock cleanup to get wrong.

Holder details (pid, host, start time) are written to a separate file because on
Windows the locked byte range cannot be read by other processes.

Network filesystems may not honor these locks; keep the store on a local disk.
"""

from __future__ import annotations

import json
import os
import socket
import time
from contextlib import contextmanager
from pathlib import Path

if os.name == "nt":  # pragma: no cover - exercised only on Windows
    import ctypes
    import msvcrt
    from ctypes import wintypes

    class _OVERLAPPED(ctypes.Structure):
        _fields_ = [("Internal", ctypes.c_void_p), ("InternalHigh", ctypes.c_void_p), ("Offset", wintypes.DWORD),
                    ("OffsetHigh", wintypes.DWORD), ("hEvent", wintypes.HANDLE)]

    _k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _k32.LockFileEx.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                ctypes.POINTER(_OVERLAPPED)]
    _k32.LockFileEx.restype = wintypes.BOOL
    _k32.UnlockFileEx.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(_OVERLAPPED)]
    _k32.UnlockFileEx.restype = wintypes.BOOL
    _LOCKFILE_FAIL_IMMEDIATELY, _LOCKFILE_EXCLUSIVE_LOCK = 0x1, 0x2
else:
    import fcntl


class StoreLocked(RuntimeError):
    def __init__(self, path: Path, holder: dict | None):
        self.path = path
        self.holder = holder or {}
        who = ", ".join(f"{k}={v}" for k, v in self.holder.items()) or "unknown process"
        super().__init__(f"Another collector already owns this store ({who}). Stop it before starting another.")


class StoreLock:
    def __init__(self, store_root: Path):
        self.path = Path(store_root) / "collector.lock"
        self.info_path = Path(store_root) / "collector.lock.info"
        self._fh = None

    @property
    def held(self) -> bool:
        return self._fh is not None

    def _take(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fh = open(self.path, "a+b")
        try:
            if os.name == "nt":  # pragma: no cover
                fh.seek(0)
                msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            fh.close()
            raise StoreLocked(self.path, self.read_holder()) from None
        self._fh = fh

    def acquire(self) -> None:
        if self._fh is not None:
            return
        self._take()
        info = {"pid": os.getpid(), "host": socket.gethostname(), "started_unix": round(time.time(), 3)}
        tmp = self.info_path.with_suffix(".info.tmp")
        tmp.write_text(json.dumps(info), encoding="utf-8")
        os.replace(tmp, self.info_path)

    def release(self) -> None:
        fh, self._fh = self._fh, None
        if fh is None:
            return
        try:
            if os.name == "nt":  # pragma: no cover
                fh.seek(0)
                msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        finally:
            fh.close()

    def read_holder(self) -> dict | None:
        try:
            return json.loads(self.info_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def is_held_elsewhere(self) -> bool:
        """True if another process currently holds the lock (non-destructive probe)."""
        if self._fh is not None:
            return False
        try:
            self._take()
        except StoreLocked:
            return True
        self.release()
        return False


class ExportsBusy(RuntimeError):
    pass


class ReadersLock:
    """Coordinates exports (shared holders) with user deletion (exclusive) across processes.

    A CLI export may run while the collector owns the store, so an in-process counter is not
    enough: deletion takes this lock exclusively and therefore waits for every running export,
    in any process, to finish. Like the owner lock it is released by the OS if a process dies.
    """

    def __init__(self, store_root: Path):
        self.path = Path(store_root) / "exports.lock"

    @staticmethod
    def _try(fh, exclusive: bool, blocking: bool) -> bool:
        if os.name == "nt":  # pragma: no cover
            flags = (_LOCKFILE_EXCLUSIVE_LOCK if exclusive else 0) | (0 if blocking else _LOCKFILE_FAIL_IMMEDIATELY)
            ov = _OVERLAPPED()
            return bool(_k32.LockFileEx(msvcrt.get_osfhandle(fh.fileno()), flags, 0, 1, 0, ctypes.byref(ov)))
        try:
            fcntl.flock(fh.fileno(), (fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH) | (0 if blocking else fcntl.LOCK_NB))
            return True
        except BlockingIOError:
            return False

    @staticmethod
    def _unlock(fh) -> None:
        if os.name == "nt":  # pragma: no cover
            ov = _OVERLAPPED()
            _k32.UnlockFileEx(msvcrt.get_osfhandle(fh.fileno()), 0, 1, 0, ctypes.byref(ov))
        else:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)

    @contextmanager
    def shared(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a+b") as fh:
            if not self._try(fh, exclusive=False, blocking=True):
                raise OSError("could not take the export lock")
            try:
                yield
            finally:
                self._unlock(fh)

    @contextmanager
    def exclusive(self, timeout: float):
        """Wait up to `timeout` seconds for running exports to finish; raises ExportsBusy otherwise."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a+b") as fh:
            deadline = time.monotonic() + timeout
            while not self._try(fh, exclusive=True, blocking=False):
                if time.monotonic() >= deadline:
                    raise ExportsBusy("an export is still running")
                time.sleep(0.1)
            try:
                yield
            finally:
                self._unlock(fh)


class FileMutex:
    """Cross-process mutual exclusion for a short read-modify-write (config.json), waiting up to `timeout` s.

    Several processes change one store's configuration: the collecting process, Claude Code sessions, the CLI."""

    def __init__(self, path: Path, timeout: float = 30.0):
        self.path = Path(path)
        self.timeout = timeout
        self._fh = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fh = open(self.path, "a+b")
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                if os.name == "nt":  # pragma: no cover
                    fh.seek(0)
                    msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    fh.close()
                    raise TimeoutError(f"{self.path.name} stayed locked by another process") from None
                time.sleep(0.05)
        self._fh = fh
        return self

    def __exit__(self, *exc):
        fh, self._fh = self._fh, None
        try:
            if os.name == "nt":  # pragma: no cover
                fh.seek(0)
                msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        finally:
            fh.close()
