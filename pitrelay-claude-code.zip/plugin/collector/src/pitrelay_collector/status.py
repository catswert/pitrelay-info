"""One status snapshot shared by the web UI and the CLI."""

from __future__ import annotations

import shutil
from collections import Counter

from . import __version__
from .config import CollectorConfig
from .store import Store
from .util import utc_iso

STATE_HELP = {
    "collecting": "Collection is running and at least one source is connected.",
    "disconnected": "Collection is running but no source is reachable right now; it keeps retrying with backoff.",
    "paused": "Paused by the user. Nothing is read from any source until you resume.",
    "disabled": "Automatic collection is turned off. Turn it on in Setup.",
    "stopped": "The collector program is not running, so nothing is being collected.",
    "no_sources": "Collection is on but no sources are configured yet.",
    "sources_disabled": "Collection is on but every source is disabled, so nothing is polled. Enable a source in Setup.",
    "blocked": "Running, but storage is full (quota or minimum free space); nothing new is being saved.",
}


def build_status(store: Store, cfg: CollectorConfig, collector=None, running_elsewhere: bool = False) -> dict:
    paused = bool(store.meta_get("paused", ""))
    running = collector is not None or running_elsewhere
    # The owning collector records the current storage block in the catalog and clears it when storage allows.
    blocked = (collector.quota_blocked if collector is not None else (store.meta_get("quota_blocked", "") or None)) if running else None
    sources = []
    connected = 0
    last_success = None
    caps = store.captures()
    by_source = Counter(c["source_id"] for c in caps)
    status_counts = Counter(c["status"] for c in caps)
    for src in cfg.sources:
        st = store.get_source_state(src.id) or {}
        state = st.get("state", "never_polled")
        if not running:
            state_display = "stopped"
        elif not cfg.collection_enabled:
            state_display = "disabled"
        elif paused:
            state_display = "paused"
        elif not src.enabled:
            state_display = "source_disabled"
        else:
            state_display = state
        if running and state == "connected" and cfg.collection_enabled and not paused and src.enabled:
            connected += 1
        if st.get("last_success") and (last_success is None or st["last_success"] > last_success):
            last_success = st["last_success"]
        sources.append({
            "id": src.id, "alias": src.alias, "kind": src.kind, "role": src.role, "enabled": src.enabled,
            "state": state_display, "raw_state": state,
            "since_utc": utc_iso(st.get("since")),
            "last_attempt_utc": utc_iso(st.get("last_attempt")),
            "last_success_utc": utc_iso(st.get("last_success")),
            "last_error": st.get("last_error"),
            "next_attempt_utc": utc_iso(st.get("next_attempt")),
            "failures": st.get("failures", 0),
            "connected_host": st.get("connected_host"),
            "pending_host_key": st.get("pending_host_key"),
            "trusted_host_keys": [k.get("fingerprint") for k in src.trusted_host_keys],
            "directories": st.get("dirs"),
            "captures": by_source.get(src.id, 0),
        })
    if not running:
        overall = "stopped"
    elif not cfg.collection_enabled:
        overall = "disabled"
    elif paused:
        overall = "paused"
    elif blocked:
        overall = "blocked"
    elif not cfg.sources:
        overall = "no_sources"
    elif not any(s.enabled for s in cfg.sources):
        overall = "sources_disabled"
    elif connected:
        overall = "collecting"
    else:
        overall = "disconnected"
    try:
        disk = shutil.disk_usage(store.root)
        free = disk.free
    except OSError:
        free = None
    alerts = []
    for s in sources:
        if s["raw_state"] in ("host_key_mismatch", "auth_failed", "host_key_untrusted", "error"):
            alerts.append({"level": "error" if s["raw_state"] != "host_key_untrusted" else "warning", "source": s["alias"],
                           "message": s["last_error"]})
    if blocked:
        alerts.append({"level": "error", "source": None,
                       "message": f"Collection stopped acquiring new bytes: {blocked}. Nothing was deleted. Raise the quota, "
                                  "free disk space or explicitly delete exported captures to resume."})
    for e in store.events(limit=50, min_level="error"):
        if e["kind"] in ("store_damaged", "store_write_failed", "export_failed", "internal_error"):
            alerts.append({"level": "error", "source": None, "message": e["message"], "t_utc": utc_iso(e["t"])})
    return {
        "version": __version__,
        "store": str(store.root),
        "overall": overall,
        "overall_help": STATE_HELP[overall],
        "process": "running" if running else "stopped",
        "collection_enabled": cfg.collection_enabled,
        "paused": paused,
        "last_successful_collection_utc": utc_iso(last_success),
        "sources": sources,
        "captures": {"total": len(caps), "by_status": dict(status_counts),
                     "bytes": sum(c["committed_size"] for c in caps)},
        "storage": {"usage_bytes": store.usage_bytes, "quota_bytes": cfg.quota_bytes, "free_disk_bytes": free,
                    "min_free_bytes": cfg.min_free_bytes, "blocked": blocked},
        "alerts": alerts[:20],
        "recent_events": [{"t_utc": utc_iso(e["t"]), "level": e["level"], "kind": e["kind"], "message": e["message"]}
                          for e in store.events(limit=40, min_level="info")],
    }
