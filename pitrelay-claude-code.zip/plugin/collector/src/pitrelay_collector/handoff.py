"""Hand a collection package to PitRelay.

Three steps, usable separately:

* extract_package: verify the ZIP, then extract it safely (no traversal, no
  links, no overwrite, hashes re-checked) into a new folder with read-only files.
* build_plan: for each file, the PitRelay operation and explicit format argument
  that applies to *that* engine build, or why none applies.
* EngineSession / handoff_to_engine: optionally drive a local PitRelay engine
  through its own documented MCP stdio interface (artifact.upload_begin/chunk/
  finish, log.inspect, log.import_csv). Every artifact ID recorded comes from
  the engine's responses. The engine's private state is only touched through
  its own operations.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import queue
import shutil
import stat
import subprocess
import sys
import threading
import time
import uuid
import zipfile
from pathlib import Path

from . import compat
from .package import ROOT, expected_files, verify_extracted, verify_package
from .util import atomic_write_json, printable, utc_iso


class HandoffError(RuntimeError):
    pass


# --- extraction -------------------------------------------------------------------------


def extract_package(zip_path: Path, dest_dir: Path) -> dict:
    report = verify_package(Path(zip_path))
    if not report["ok"]:
        raise HandoffError("Package failed verification; nothing was extracted: "
                           + "; ".join(printable(e, 200) for e in report["errors"][:8]))
    manifest = report["manifest"]
    dest_dir = Path(dest_dir)
    if dest_dir.exists() and (not dest_dir.is_dir() or any(dest_dir.iterdir())):
        raise HandoffError(f"{dest_dir} already exists and is not an empty folder; choose a new or empty destination "
                           "(nothing is overwritten)")
    dest_dir.mkdir(parents=True, exist_ok=True)
    final = dest_dir / ROOT
    expected = expected_files(manifest)
    total = sum(e["size_bytes"] for e in expected.values())
    free = shutil.disk_usage(dest_dir).free
    if total > free:
        raise HandoffError(f"Not enough free space: need {total} bytes, have {free}")
    tmp = dest_dir / f".pitrelay-extract-{uuid.uuid4().hex[:8]}"
    tmp_root = tmp / ROOT
    try:
        with zipfile.ZipFile(zip_path) as zf:
            for rel in sorted(list(expected) + ["manifest.json"]):
                info = zf.getinfo(f"{ROOT}/{rel}")
                target = tmp_root.joinpath(*rel.split("/"))
                # Defense in depth: the resolved target must stay inside the temporary root.
                if os.path.commonpath([str(target.resolve()), str(tmp_root.resolve())]) != str(tmp_root.resolve()):
                    raise HandoffError(f"refusing to write outside the destination: {rel}")
                target.parent.mkdir(parents=True, exist_ok=True)
                h = hashlib.sha256()
                n = 0
                with zf.open(info) as src, open(target, "xb") as out:
                    for block in iter(lambda: src.read(1024 * 1024), b""):
                        n += len(block)
                        if rel in expected and n > expected[rel]["size_bytes"]:
                            raise HandoffError(f"{rel} is larger than the manifest states")
                        h.update(block)
                        out.write(block)
                if rel in expected and (h.hexdigest() != expected[rel]["sha256"] or n != expected[rel]["size_bytes"]):
                    raise HandoffError(f"{rel} changed between verification and extraction")
                os.chmod(target, stat.S_IREAD | stat.S_IRGRP | stat.S_IROTH)
        os.replace(tmp_root, final)
    finally:
        if tmp.exists():
            _rmtree_readonly(tmp)
    return {"extracted_to": str(final), "files": len(expected) + 1, "bytes": total, "manifest": manifest}


def _rmtree_readonly(path: Path) -> None:
    def retry(func, p, _exc):
        os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
        func(p)
    if sys.version_info >= (3, 12):
        shutil.rmtree(path, onexc=retry)
    else:  # pragma: no cover
        shutil.rmtree(path, onerror=retry)


# --- plan -----------------------------------------------------------------------------


def build_plan(manifest: dict, trusted_routes: bool = True) -> list[dict]:
    """The engine operation for each recording. trusted_routes=False (a package made elsewhere): the manifest's own
    route block is ignored and the route is derived here from the recorded format, so the operation, format argument
    and upload kind always come from this code, never from text someone else wrote."""
    plan = []
    derived = {d["derived_from_capture_id"]: d for d in manifest.get("derived", [])}
    for c in manifest.get("captures", []):
        route = (c.get("pitrelay") if trusted_routes else None) or compat.pitrelay_route(c["format"], c["size_bytes"])
        item = {
            "capture_id": c["capture_id"],
            "archive_path": c["archive_path"],
            "format": c["format"].get("label"),
            "status": c["acquisition"]["status"],
            "size_bytes": c["size_bytes"],
            "sha256": c["sha256"],
            "operation": route.get("operation"),
            "format_argument": route.get("format_argument"),
            "upload_kind": route.get("upload_kind"),
            "description": route.get("description"),
            "limitations": list(route.get("limitations", [])),
        }
        if c["size_bytes"] > compat.UPLOAD_LIMIT_BYTES:
            item["operation"] = None
            item["blocked"] = "exceeds the engine's 64 MiB per-artifact upload limit"
        d = derived.get(c["capture_id"])
        if d:
            item["derived"] = {"archive_path": d["archive_path"], "sha256": d["sha256"], "size_bytes": d["size_bytes"],
                               "operation": "log.inspect", "format_argument": None, "upload_kind": "log"}
        plan.append(item)
    return plan


def plan_text(plan: list[dict]) -> str:
    lines = ["PITRELAY HANDOFF PLAN", "=====================", "",
             "Operations below were observed on PitRelay 0.1.0-dev (v11 package). Re-check them with `help` on a different build.",
             ""]
    for p in plan:
        # Every value comes from a received manifest: untrusted text, neutralized before display.
        t = {k: printable(str(v), 400) for k, v in p.items() if not isinstance(v, (list, dict))}
        lines.append(f"{t['capture_id']}  {t['archive_path']}")
        lines.append(f"    format: {t['format']}   status: {t['status']}   size: {t['size_bytes']}")
        if p.get("blocked"):
            lines.append(f"    NOT SUPPLIED: {t['blocked']}")
        elif p["operation"]:
            fmt = f" with format '{t['format_argument']}'" if p["format_argument"] else ""
            lines.append(f"    upload (artifact.upload_begin/chunk/finish, kind '{t['upload_kind']}'), then {t['operation']}{fmt}")
        else:
            lines.append(f"    no engine route: {t['description']}")
        if p.get("derived"):
            lines.append(f"    derived WPILOG available: {printable(str(p['derived']['archive_path']))} -> log.inspect")
        for lim in p["limitations"]:
            lines.append(f"    limitation: {printable(str(lim), 400)}")
        lines.append("")
    return "\n".join(lines)


# --- engine session (MCP stdio) ---------------------------------------------------------


class EngineSession:
    """Minimal MCP stdio client for a local PitRelay engine."""

    def __init__(self, java: str, jar: Path, state: Path, stderr_path: Path, timeout: float = 180.0):
        self.timeout = timeout
        self._stderr = open(stderr_path, "ab")
        self.proc = subprocess.Popen(
            [java, "-Xmx384m", "-cp", str(jar), "org.pitrelay.Main", "--state", str(state), "--mode", "mcp"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self._stderr)
        self._q: queue.Queue = queue.Queue()
        self._reader = threading.Thread(target=self._read, daemon=True)
        self._reader.start()
        self._id = 0
        self.tools: dict[str, str] = {}
        self.server_info: dict = {}

    def _read(self):
        for line in self.proc.stdout:
            self._q.put(line)
        self._q.put(None)

    def _send(self, obj):
        self.proc.stdin.write((json.dumps(obj) + "\n").encode("utf-8"))
        self.proc.stdin.flush()

    def _rpc(self, method, params=None):
        self._id += 1
        rid = self._id
        msg = {"jsonrpc": "2.0", "id": rid, "method": method}
        if params is not None:
            msg["params"] = params
        self._send(msg)
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                line = self._q.get(timeout=max(0.1, deadline - time.monotonic()))
            except queue.Empty:
                raise HandoffError(f"engine did not answer {method} within {self.timeout} s") from None
            if line is None:
                raise HandoffError("engine process exited")
            try:
                data = json.loads(line)
            except ValueError:
                continue
            if data.get("id") == rid:
                if "error" in data:
                    raise HandoffError(f"engine protocol error for {method}: {data['error']}")
                return data["result"]

    def start(self) -> dict:
        init = self._rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                                        "clientInfo": {"name": "pitrelay-collector", "version": "1"}})
        self._send({"jsonrpc": "2.0", "method": "notifications/initialized"})
        self.server_info = init.get("serverInfo", {})
        for tool in self._rpc("tools/list", {}).get("tools", []):
            op = (tool.get("_meta") or {}).get("pitrelay/operation")
            if op:
                self.tools[op] = tool["name"]
        return init

    def call(self, operation: str, arguments: dict) -> dict:
        name = self.tools.get(operation)
        if name is None:
            raise HandoffError(f"engine does not expose operation {operation!r}")
        result = self._rpc("tools/call", {"name": name, "arguments": arguments})
        for part in result.get("content", []):
            if part.get("type") == "text":
                try:
                    return json.loads(part["text"])
                except ValueError:
                    break
        raise HandoffError(f"unexpected engine response for {operation}")

    def close(self):
        try:
            self.proc.stdin.close()
            self.proc.wait(timeout=30)
        except Exception:
            self.proc.kill()
        finally:
            self._stderr.close()


def _upload(engine: EngineSession, path: Path, filename: str, kind: str, expected_sha256: str | None = None) -> dict:
    data_len = path.stat().st_size
    if data_len > compat.UPLOAD_LIMIT_BYTES:
        return {"status": "not_supplied", "reason": "exceeds the engine's 64 MiB per-artifact upload limit"}
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    sha = h.hexdigest()
    if expected_sha256 is not None and sha != expected_sha256:
        return {"status": "not_supplied", "reason": "the file differs from its manifest SHA-256; it was not supplied"}
    # Declaring the manifest's hash (not just whatever is on disk now) makes the engine's own check meaningful:
    # bytes that change during the upload are refused by upload_finish.
    sha = expected_sha256 or sha
    begin = engine.call("artifact.upload_begin", {"kind": kind, "filename": filename, "byte_size": data_len, "sha256": sha})
    if begin.get("status") != "ok":
        return {"status": begin.get("status"), "stage": "upload_begin", "engine_result": begin.get("result")}
    transfer = begin["result"].get("id") or begin["result"].get("transfer_id")
    chunk = int(begin["result"].get("max_chunk_bytes") or compat.UPLOAD_CHUNK_BYTES)
    with open(path, "rb") as f:
        offset = 0
        while True:
            block = f.read(chunk)
            if not block:
                break
            r = engine.call("artifact.upload_chunk", {"transfer_id": transfer, "offset": offset,
                                                      "data_base64": base64.b64encode(block).decode("ascii")})
            if r.get("status") != "ok":
                engine.call("artifact.upload_abort", {"transfer_id": transfer})
                return {"status": r.get("status"), "stage": "upload_chunk", "offset": offset, "engine_result": r.get("result")}
            offset += len(block)
    fin = engine.call("artifact.upload_finish", {"transfer_id": transfer})
    if fin.get("status") != "ok":
        return {"status": fin.get("status"), "stage": "upload_finish", "engine_result": fin.get("result")}
    res = fin["result"]
    if res.get("sha256") != sha or res.get("byte_size") != data_len:
        return {"status": "error", "stage": "upload_finish", "reason": "engine reported a different hash/size than supplied",
                "engine_result": res}
    return {"status": "ok", "artifact_id": res.get("id"), "engine_sha256": res.get("sha256"), "byte_size": res.get("byte_size")}


def _summarize_inspect(r: dict) -> dict:
    res = r.get("result") or {}
    keep = ("format", "format_version", "integrity", "complete", "index_complete", "entry_count", "record_count",
            "sample_count", "first_observation_us", "last_observation_us", "issue_total", "code", "message", "clock")
    out = {"status": r.get("status")}
    out.update({k: res[k] for k in keep if k in res})
    if res.get("issues"):
        out["issues"] = res["issues"][:5]
    return out


def handoff_to_engine(extracted_root: Path, java: str, jar: Path, state: Path, out_dir: Path,
                      csv_mappings: dict | None = None) -> dict:
    """Upload each routable file to a local PitRelay engine and inspect it. Returns the receipt."""
    extracted_root = Path(extracted_root)
    check = verify_extracted(extracted_root)
    if not check["ok"]:
        raise HandoffError("The extracted files no longer match their manifest, so nothing was handed off: "
                           + "; ".join(printable(e, 200) for e in check["errors"][:8]))
    if not (extracted_root / "manifest.json").is_file():
        extracted_root = extracted_root / ROOT
    manifest = json.loads((extracted_root / "manifest.json").read_text(encoding="utf-8"))
    plan = build_plan(manifest)
    jar = Path(jar)
    with open(jar, "rb") as f:
        jar_sha = hashlib.sha256(f.read()).hexdigest()
    receipt = {
        "schema": "pitrelay-collector-handoff-receipt", "schema_version": "1.0",
        "started_utc": utc_iso(time.time()),
        "package_id": manifest["package"]["id"],
        "engine": {"jar_sha256": jar_sha, "jar_matches_inspected_v11": jar_sha == compat.ENGINE_PROFILE["engine_sha256"],
                   "state_dir": str(state)},
        "note": "Artifact IDs below are exactly as returned by the engine. The collector did not write to the engine's "
                "state except through these engine operations.",
        "files": [],
    }
    csv_mappings = csv_mappings or {}
    engine = EngineSession(java, jar, Path(state), Path(out_dir) / "handoff-engine-stderr.log")
    try:
        init = engine.start()
        receipt["engine"]["server_info"] = init.get("serverInfo")
        cap = engine.call("capability.list", {})
        receipt["engine"]["implementation_version"] = cap.get("implementation_version")
        receipt["engine"]["conditional_gaps"] = (cap.get("result") or {}).get("conditional_gaps")
        for item in plan:
            rec = {"capture_id": item["capture_id"], "archive_path": item["archive_path"], "sha256": item["sha256"]}
            receipt["files"].append(rec)
            targets = []
            if item.get("derived"):
                targets.append(("derived", item["derived"]["archive_path"], "log", None, "log.inspect", item["derived"]["sha256"]))
            if item.get("blocked"):
                rec["result"] = {"status": "not_supplied", "reason": item["blocked"]}
            elif item["operation"] is None:
                rec["result"] = {"status": "not_supplied", "reason": item["description"]}
            else:
                targets.insert(0, ("original", item["archive_path"], item["upload_kind"], item["format_argument"], item["operation"],
                                   item["sha256"]))
            for role, rel, kind, fmt, op, expected_sha in targets:
                path = extracted_root.joinpath(*rel.split("/"))
                up = _upload(engine, path, path.name, kind, expected_sha)
                entry = {"upload": up}
                if up["status"] == "ok":
                    if op == "log.inspect":
                        args = {"artifact_id": up["artifact_id"]}
                        if fmt:
                            args["format"] = fmt
                        entry["inspect"] = _summarize_inspect(engine.call("log.inspect", args))
                    elif op == "log.import_csv":
                        mapping = csv_mappings.get(item["archive_path"])
                        if mapping:
                            r = engine.call("log.import_csv", {"artifact_id": up["artifact_id"], **mapping})
                            entry["import_csv"] = {"status": r.get("status"), "result": {k: v for k, v in (r.get("result") or {}).items()
                                                                                          if k in ("artifact", "point_count", "mapping", "code", "message")}}
                        else:
                            entry["import_csv"] = {"status": "blocked", "reason": "no explicit column/time/unit/sampling mapping "
                                                   "was supplied; uploaded only"}
                rec[role] = entry
    finally:
        engine.close()
    receipt["finished_utc"] = utc_iso(time.time())
    atomic_write_json(Path(out_dir) / "handoff-receipt.json", receipt)
    return receipt


def statistics(engine: EngineSession, artifact_id: str, entry: str, start_us: int, end_us: int) -> dict:
    """Convenience wrapper used by tests and the guide (signal.statistics, half-open window)."""
    r = engine.call("signal.statistics", {"artifact_id": artifact_id, "entry": entry, "start_us": start_us, "end_us": end_us})
    return r
