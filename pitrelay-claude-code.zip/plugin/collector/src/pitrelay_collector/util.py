"""Small shared helpers: clocks, time formatting, atomic writes and safe names."""

from __future__ import annotations

import datetime as _dt
import json
import logging
import os
import re
import tempfile
import threading
import time
import unicodedata
from pathlib import Path


class Clock:
    """Wall clock + monotonic clock + sleep. Tests substitute FakeClock."""

    def time(self) -> float:
        return time.time()

    def monotonic(self) -> float:
        return time.monotonic()

    def wait(self, event: threading.Event, seconds: float) -> bool:
        """Sleep up to `seconds`, returning early (True) if `event` is set."""
        return event.wait(max(0.0, seconds))


class FakeClock(Clock):
    """Deterministic clock for tests. `wait` advances time instead of sleeping."""

    def __init__(self, start: float = 1_760_000_000.0):
        self._t = float(start)
        self._m = 1000.0
        self._lock = threading.Lock()

    def time(self) -> float:
        with self._lock:
            return self._t

    def monotonic(self) -> float:
        with self._lock:
            return self._m

    def advance(self, seconds: float) -> None:
        with self._lock:
            self._t += seconds
            self._m += seconds

    def wait(self, event: threading.Event, seconds: float) -> bool:
        if event.is_set():
            return True
        self.advance(max(0.0, seconds))
        return event.is_set()


def utc_iso(ts: float | None) -> str | None:
    """Unix seconds -> ISO-8601 UTC string with millisecond precision, or None."""
    if ts is None:
        return None
    dt = _dt.datetime.fromtimestamp(ts, tz=_dt.timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"


def parse_iso(text: str) -> float:
    """Parse an ISO-8601 date or date-time. Naive values are interpreted as UTC."""
    text = text.strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        text += "T00:00:00"
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = _dt.datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_dt.timezone.utc)
    return dt.timestamp()


def fsync_dir(path: Path) -> None:
    """Flush a directory entry to disk where the platform supports it (POSIX)."""
    if os.name != "posix":
        return
    fd = os.open(str(path), os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_write_bytes(path: Path, data: bytes, mode: int | None = None) -> None:
    """Write via a temporary file in the same directory, fsync, then rename over."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        if mode is not None:
            os.chmod(tmp, mode)
        os.replace(tmp, path)
        fsync_dir(path.parent)
    except BaseException:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise


def atomic_write_json(path: Path, obj, mode: int | None = None) -> None:
    atomic_write_bytes(path, (json.dumps(obj, indent=2, sort_keys=False, ensure_ascii=False) + "\n").encode("utf-8"), mode)


# Windows refuses these device names as file names regardless of extension.
_WINDOWS_RESERVED = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
_SAFE_CHARS = re.compile(r"[^A-Za-z0-9._-]+")


def safe_component(name: str, max_len: int = 100, fallback: str = "file") -> str:
    """Turn an untrusted name into a portable single path component.

    Keeps ASCII letters, digits, '.', '_' and '-'; everything else becomes '_'.
    The result is never empty, '.', '..', hidden, a Windows device name, or
    ends with a dot or space. The original name is preserved separately in the
    manifest; this only produces a safe archive member name.
    """
    text = unicodedata.normalize("NFKD", name)
    text = text.encode("ascii", "ignore").decode("ascii")
    text = _SAFE_CHARS.sub("_", text).strip("._ ")
    if not text:
        text = fallback
    if len(text) > max_len:
        stem, dot, ext = text.rpartition(".")
        if dot and 0 < len(ext) <= 12:
            text = stem[: max_len - len(ext) - 1].rstrip("._ ") + "." + ext
        else:
            text = text[:max_len].rstrip("._ ")
    stem = text.split(".", 1)[0].upper()
    if stem in _WINDOWS_RESERVED:
        text = "_" + text
    return text or fallback


def human_bytes(n: int | None) -> str:
    if n is None:
        return "unknown"
    value = float(n)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if value < 1024 or unit == "TiB":
            return f"{value:.0f} {unit}" if unit == "B" else f"{value:.1f} {unit}"
        value /= 1024
    return f"{n} B"


class SafeFormatter(logging.Formatter):
    """Log formatter that neutralizes control characters (keeping line breaks) in the final text.

    Library loggers (e.g. paramiko's transport thread) quote bytes a remote device sent, such as an
    SSH banner; terminal escape sequences in them must never reach a console or log viewer raw.
    """

    def format(self, record: logging.LogRecord) -> str:
        text = super().format(record)
        return "".join(ch if ch == "\n" or ch.isprintable() else f"\\x{ord(ch):02x}" for ch in text)


def quiet_library_loggers() -> None:
    """Keep third-party loggers from printing raw text through logging's last-resort handler."""
    lib = logging.getLogger("paramiko")
    if not lib.handlers:
        lib.addHandler(logging.NullHandler())


def printable(text: str, limit: int = 300) -> str:
    """Neutralize control characters in untrusted text before logging/displaying."""
    cleaned = "".join(ch if ch.isprintable() else f"\\x{ord(ch):02x}" for ch in text)
    return cleaned if len(cleaned) <= limit else cleaned[:limit] + "..."
