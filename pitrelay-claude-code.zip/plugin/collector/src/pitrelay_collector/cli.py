"""Command-line interface: `pitrelay-collector <command>`."""

from __future__ import annotations

import argparse
import getpass
import json
import sys
import webbrowser
from pathlib import Path

from . import __version__
from .autostart import Autostart, default_store_path
from .config import ConfigError, ConfigManager, SourceConfig, validate_source
from .export import ExportOptions, export_package
from .lock import StoreLock, StoreLocked
from .package import verify_extracted, verify_package
from .status import build_status
from .store import Store, StoreError
from .util import human_bytes, parse_iso, printable, quiet_library_loggers


def _store_path(args) -> Path:
    if args.store:
        return Path(args.store).expanduser().resolve()
    from . import autostart
    return Path(autostart.BUNDLED["store"]) if autostart.BUNDLED else default_store_path()


def _print(obj, as_json: bool):
    if as_json:
        print(json.dumps(obj, indent=2))
        return True
    return False


def cmd_init(args) -> int:
    root = _store_path(args)
    if StoreLock(root).is_held_elsewhere():
        print(f"A collector is already running with the store at {root}")
        return 0
    try:
        Store.create(root)
    except StoreError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    cm = ConfigManager(root)
    if not cm.path.exists():
        cm.save(cm.load())
    print(f"Store ready at {root}")
    print("Automatic collection is OFF and launch-at-login is OFF until you turn them on.")
    print("Next: add sources (pitrelay-collector source add-sftp/add-local) or run `pitrelay-collector run` and use Setup.")
    return 0


def cmd_run(args) -> int:
    from .app import App, setup_logging
    root = _store_path(args)
    setup_logging(root, console=not args.quiet)
    app = App(root)
    try:
        app.open()
    except StoreLocked as e:
        print(str(e), file=sys.stderr)
        print("Use `pitrelay-collector open-ui` to open the running collector.", file=sys.stderr)
        return 3
    try:
        app.start(ui=not args.no_ui, port=args.port, open_browser=not args.no_browser and not args.no_ui)
        if app.ui is not None:
            # Only show the token-bearing login link on an interactive terminal, never in redirected logs.
            if sys.stdout is not None and sys.stdout.isatty():  # pythonw (launch at login) has no stdout
                print(f"PitRelay Collector is running. UI: {app.ui.login_url}")
            else:
                print(f"PitRelay Collector is running (UI on 127.0.0.1:{app.ui.port}; open it with: pitrelay-collector open-ui)")
        print("Press Ctrl+C to stop.")
        app.wait()
    finally:
        app.shutdown()
    return 0


def cmd_open_ui(args) -> int:
    root = _store_path(args)
    info_path = root / "ui.json"
    if not StoreLock(root).is_held_elsewhere() or not info_path.exists():
        print("The collector is not running (STOPPED). Start it with: pitrelay-collector run", file=sys.stderr)
        return 1
    info = json.loads(info_path.read_text(encoding="utf-8"))
    if args.print_url:
        print(info["login_url"])
        return 0
    # Ask the running collector for a single-use launch link, so the browser's command line (readable by other
    # local users) never carries the session token.
    import http.client
    try:
        conn = http.client.HTTPConnection("127.0.0.1", int(info["port"]), timeout=10)
        conn.request("POST", "/api/launch-url", body="{}", headers={
            "Host": f"127.0.0.1:{info['port']}", "Authorization": f"Bearer {info['login_url'].split('#token=', 1)[1]}",
            "Content-Type": "application/json"})
        resp = conn.getresponse()
        url = json.loads(resp.read().decode("utf-8"))["url"] if resp.status == 200 else None
        conn.close()
    except (OSError, ValueError, KeyError, IndexError):
        url = None
    if url is None:
        print("The running collector did not answer. Open the link printed by: pitrelay-collector open-ui --print-url",
              file=sys.stderr)
        return 1
    webbrowser.open(url)
    print("Opened the collector UI in your browser.")
    return 0


def cmd_status(args) -> int:
    root = _store_path(args)
    try:
        store = Store(root).open_reader()
    except StoreError as e:
        print(str(e), file=sys.stderr)
        return 1
    try:
        cfg = ConfigManager(root).load()
        st = build_status(store, cfg, None, running_elsewhere=StoreLock(root).is_held_elsewhere())
        st["autostart"] = Autostart().status()
        if _print(st, args.json):
            return 0
        print(f"State: {st['overall'].upper()} - {st['overall_help']}")
        print(f"Last successful collection: {st['last_successful_collection_utc'] or 'never'}")
        print(f"Captures: {st['captures']['total']} ({human_bytes(st['captures']['bytes'])}) {st['captures']['by_status']}")
        print(f"Storage: {human_bytes(st['storage']['usage_bytes'])} of {human_bytes(st['storage']['quota_bytes'])}; "
              f"free disk {human_bytes(st['storage']['free_disk_bytes'])}")
        for s in st["sources"]:
            # Errors can quote text a remote device sent; never pass control sequences to the terminal.
            print(f"  [{s['state']}] {printable(s['alias'])} ({s['kind']}) last success {s['last_success_utc'] or 'never'}"
                  + (f" - {printable(s['last_error'])}" if s["last_error"] else ""))
            for d, info in (s.get("directories") or {}).items():
                real = info.get("realpath")
                print(f"      {printable(d)}" + (f" -> {printable(real)}" if real and real != d else "")
                      + f": {printable(str(info.get('status')))}" + (f" ({info['files']} files)" if info.get("files") is not None else ""))
            if s["pending_host_key"]:
                k = {kk: printable(str(vv)) for kk, vv in s["pending_host_key"].items()}
                print(f"      presented host key {k['type']} {k['fingerprint']} (trust with: pitrelay-collector trust-host "
                      f"--source {printable(s['alias'])} --fingerprint {k['fingerprint']})")
        for a in st["alerts"]:
            print(f"  ! {printable(a['message'], 600)}")
        print(f"Launch at login: {'on' if st['autostart']['enabled'] else 'off'}")
        return 0
    finally:
        store.close()


def _with_config(args, fn) -> int:
    root = _store_path(args)
    try:
        Store(root).check_version()
    except StoreError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    Store.ensure_layout(root)
    cm = ConfigManager(root)
    try:
        cm.update(fn)
    except (ConfigError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    return 0


def cmd_source_add(args) -> int:
    def add(cfg):
        src = SourceConfig(id=SourceConfig.new_id(), alias=args.alias, kind=args.kind, directories=args.dir, role=args.role,
                           recursive_depth=args.depth, include_csv=args.csv, text_patterns=args.text_pattern or [],
                           poll_interval_s=args.interval)
        if args.kind == "sftp":
            src.hosts, src.port, src.username, src.auth, src.key_file = args.host, args.port, args.user, args.auth, args.key_file
        validate_source(src, _store_path(args), cfg.sources)
        cfg.sources.append(src)
        print(f"Added source {src.alias} ({src.id}).")
        if args.kind == "sftp":
            print("Its host key must be confirmed before collection: run the collector and trust it in the UI, or use "
                  "`pitrelay-collector trust-host`.")
    return _with_config(args, add)


def cmd_source_list(args) -> int:
    cfg = ConfigManager(_store_path(args)).load()
    if _print([s.public_dict() | {"auth": s.auth_choice} for s in cfg.sources], args.json):
        return 0
    for s in cfg.sources:
        extra = f" hosts={','.join(s.hosts)} auth={s.auth_choice}" if s.kind == "sftp" else ""
        print(f"{s.alias} [{s.kind}, {'enabled' if s.enabled else 'disabled'}] dirs={s.directories}{extra}")
    return 0


def cmd_source_remove(args) -> int:
    def rm(cfg):
        src = cfg.source_by_alias(args.alias)
        if src is None:
            raise ValueError(f"No source named {args.alias!r}")
        cfg.sources = [s for s in cfg.sources if s.id != src.id]
        print(f"Removed {args.alias}; its captures stay in the store.")
    return _with_config(args, rm)


def cmd_set_password(args) -> int:
    from .secrets import KeyringSecrets, SecretStoreUnavailable
    cfg = ConfigManager(_store_path(args)).load()
    src = cfg.source_by_alias(args.source)
    if src is None:
        print(f"No source named {args.source!r}", file=sys.stderr)
        return 2
    value = getpass.getpass(f"{'Key passphrase' if args.passphrase else 'Password'} for {src.alias}: ")
    try:
        KeyringSecrets().set(src.id, "key_passphrase" if args.passphrase else "password", value)
    except SecretStoreUnavailable as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    print("Stored in the system credential store (not in any collector file).")
    return 0


def cmd_trust_host(args) -> int:
    from .sources import fetch_host_key
    cfg = ConfigManager(_store_path(args)).load()
    src = cfg.source_by_alias(args.source)
    if src is None or src.kind != "sftp":
        print("Unknown SFTP source", file=sys.stderr)
        return 2
    host = args.host or src.hosts[0]
    try:
        key = fetch_host_key(host, src.port, cfg.connect_timeout_s)
    except Exception as e:  # socket errors and SSH negotiation errors alike
        print(f"Could not read the host key from {host}: {e.__class__.__name__}: {printable(str(e))}", file=sys.stderr)
        return 1
    print(f"{host} presents {key['type']} {key['fingerprint']}")
    if args.fingerprint and args.fingerprint != key["fingerprint"]:
        print("This does NOT match the fingerprint you expected. Nothing was trusted.", file=sys.stderr)
        return 4
    if not args.fingerprint:
        answer = input("Trust this key for collection from this robot? Type 'yes' to confirm: ")
        if answer.strip().lower() != "yes":
            print("Not trusted.")
            return 1

    def trust(c):
        s = c.source_by_id(src.id)
        from .util import utc_iso
        import time
        s.trusted_host_keys = [{"type": key["type"], "fingerprint": key["fingerprint"], "key_b64": key["key_b64"],
                                "trusted_at": utc_iso(time.time())}]
    rc = _with_config(args, trust)
    if rc == 0:
        print("Trusted. A running collector picks this up on its next poll.")
    return rc


def _control(args, action) -> int:
    root = _store_path(args)
    if action in ("enable", "disable"):
        def set_enabled(cfg):
            cfg.collection_enabled = action == "enable"
        rc = _with_config(args, set_enabled)
        if rc == 0:
            print(f"Automatic collection {'enabled' if action == 'enable' else 'disabled'}.")
        return rc
    import sqlite3
    import time
    try:
        store = Store(root).open_reader()
    except StoreError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    try:
        c = store.conn()
        c.execute("INSERT INTO meta(key, value) VALUES('paused', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                  (repr(time.time()) if action == "pause" else "",))
        c.execute("INSERT INTO events(t, level, kind, message) VALUES(?, 'info', ?, ?)",
                  (time.time(), "paused" if action == "pause" else "resumed",
                   "Collection paused by the user (CLI)" if action == "pause" else "Collection resumed by the user (CLI)"))
    except sqlite3.Error as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    finally:
        store.close()
    print("Paused." if action == "pause" else "Resumed.")
    return 0


def cmd_export(args) -> int:
    root = _store_path(args)
    try:
        store = Store(root).open_reader()
    except StoreError as e:
        print(f"Export FAILED, no package produced: {e}", file=sys.stderr)
        return 1
    try:
        cfg = ConfigManager(root).load()
        observations = []
        if args.observations:
            observations = json.loads(Path(args.observations).read_text(encoding="utf-8"))
            if isinstance(observations, dict):
                observations = observations.get("observations", [])
        source_ids = None
        if args.source:
            source_ids = []
            for alias in args.source:
                s = cfg.source_by_alias(alias)
                if s is None:
                    print(f"No source named {alias!r}", file=sys.stderr)
                    return 2
                source_ids.append(s.id)
        opts = ExportOptions(
            out_dir=Path(args.out).expanduser() if args.out else root / "exports",
            since=parse_iso(args.since) if args.since else None,
            until=parse_iso(args.until) if args.until else None,
            source_ids=source_ids, capture_ids=args.capture or None, observations=observations,
            source_project_dir=Path(args.include_source).expanduser() if args.include_source else None,
            convert_hoot=args.convert_hoot,
            max_archive_bytes=int(args.max_archive_mb * 1024 * 1024) if args.max_archive_mb else None,
            package_label=args.label)
        running = StoreLock(root).is_held_elsewhere()
        res = export_package(store, cfg, opts, collector_state={"overall": "running" if running else "stopped"})
    finally:
        store.close()
    if _print(res.__dict__, args.json):
        return 0 if res.ok else 1
    if not res.ok:
        print(f"Export FAILED, no package produced: {res.error}", file=sys.stderr)
        return 1
    for a in res.archives:
        print(f"Exported and verified: {a['path']}")
        print(f"  {a['captures']} captures, {a['verified_files']} files hash-checked, SHA-256 {a['sha256']}")
    for w in res.warnings:
        print(f"  note: {w}")
    return 0


def cmd_verify(args) -> int:
    target = Path(args.zip)
    rep = verify_extracted(target) if target.is_dir() else verify_package(target)
    out = {k: v for k, v in rep.items() if k != "manifest"}
    if _print(out, args.json):
        return 0 if rep["ok"] else 1
    if rep["ok"]:
        m = rep["manifest"]
        print(f"OK: {rep['files_checked']} files, {rep['bytes_checked']} bytes match manifest.json "
              f"({printable(str(m['schema']), 60)} {printable(str(m['schema_version']), 20)}, {len(m['captures'])} captures).")
        for w in rep.get("warnings", []):
            print(f"  note: {w}")
        return 0
    print("VERIFICATION FAILED:")
    for e in rep["errors"]:
        print(f"  - {printable(e, 400)}")  # names inside a received package are untrusted text
    return 1


def cmd_extract(args) -> int:
    from .handoff import HandoffError, build_plan, extract_package, plan_text
    try:
        res = extract_package(Path(args.zip), Path(args.dest))
    except HandoffError as e:
        print(f"Not extracted: {e}", file=sys.stderr)
        return 1
    plan = build_plan(res["manifest"])
    dest = Path(args.dest)
    text = plan_text(plan)
    # The destination was empty before extraction, so these never replace a user's file.
    with open(dest / "handoff-plan.json", "x", encoding="utf-8") as f:
        f.write(json.dumps(plan, indent=2))
    with open(dest / "HANDOFF.txt", "x", encoding="utf-8") as f:
        f.write(text)
    print(f"Verified and extracted to {res['extracted_to']} (files are read-only).")
    print(text)
    return 0


def cmd_handoff(args) -> int:
    from .handoff import HandoffError, handoff_to_engine
    mappings = json.loads(Path(args.csv_mappings).read_text(encoding="utf-8")) if args.csv_mappings else None
    try:
        receipt = handoff_to_engine(Path(args.extracted), args.java, Path(args.engine_jar), Path(args.state), Path(args.out),
                                    csv_mappings=mappings)
    except (HandoffError, OSError) as e:
        print(f"Handoff failed: {printable(str(e), 600)}", file=sys.stderr)
        return 1
    if _print(receipt, args.json):
        return 0
    print(f"Engine {receipt['engine'].get('server_info')} (jar matches inspected v11: {receipt['engine']['jar_matches_inspected_v11']})")
    for f in receipt["files"]:
        o = f.get("original") or {}
        up = o.get("upload") or {}
        if up.get("status") == "ok":
            ins = o.get("inspect") or o.get("import_csv") or {}
            print(f"  {printable(str(f['archive_path']))}: artifact {printable(str(up['artifact_id']))} -> "
                  f"{printable(str(ins.get('status')))}")
        else:
            r = f.get("result") or up
            print(f"  {printable(str(f['archive_path']))}: {printable(str(r.get('status')))} {printable(str(r.get('reason', '')))}")
    print(f"Receipt: {Path(args.out) / 'handoff-receipt.json'}")
    return 0


def cmd_autostart(args) -> int:
    a = Autostart()
    if args.action == "enable":
        st = a.enable(_store_path(args))
        print(f"Launch at login ENABLED via {st['mechanism']} at {st['location']}.")
        if not st["verified_on_this_platform"]:
            print("Note: this platform's launch-at-login behavior is UNVERIFIED in this release.")
    elif args.action == "disable":
        st = a.disable()
        print("Launch at login disabled.")
    else:
        st = a.status()
        print(json.dumps(st, indent=2))
    return 0


def cmd_inspect(args) -> int:
    from .projectscan import inspect_project
    r = inspect_project(Path(args.project))
    if _print(r, args.json):
        return 0
    f = r["facts"]
    print(f"WPILib {f['wpilib_version'] or 'unknown'} (season {f['season'] or 'unknown'}); vendor libraries: "
          + (", ".join(f"{v['name']} {v['version']}" for v in f["vendordeps"]) or "none"))
    for g in r["guidance"]:
        print(f"[{g['level']}] {g['text']}\n    (checked against {g['documentation']})")
        if g.get("proposed_snippet_not_applied"):
            print("    proposed, not applied:\n      " + g["proposed_snippet_not_applied"].replace("\n", "\n      "))
    return 0


def cmd_delete(args) -> int:
    root = _store_path(args)
    if StoreLock(root).is_held_elsewhere():
        print("Stop the running collector first, or delete captures from its UI.", file=sys.stderr)
        return 3
    if not args.yes:
        print("Refusing without --yes (this permanently deletes local copies; remote files are never touched).", file=sys.stderr)
        return 2
    try:
        store = Store(root).open_owner()
    except StoreError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    try:
        deleted = store.delete_captures(args.id, args.note or "deleted with the CLI")
    except StoreError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    finally:
        store.close()
    print(f"Deleted local captures: {deleted}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="pitrelay-collector", description="Collect FRC robot logs automatically and export them for PitRelay.")
    p.add_argument("--version", action="version", version=__version__)
    p.add_argument("--store", default=None, help="store folder (default: per-user application data folder)")
    # --store is accepted before or after the command (launch-at-login uses `run --store ...`).
    # SUPPRESS keeps a subcommand from overwriting a value given before it.
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--store", default=argparse.SUPPRESS, help="store folder")
    sub = _Sub(p.add_subparsers(dest="cmd", required=True), common)

    sub.add_parser("init", help="create the store (collection and launch-at-login stay off)").set_defaults(fn=cmd_init)
    r = sub.add_parser("run", help="run the collector and its local web UI")
    r.add_argument("--no-ui", action="store_true")
    r.add_argument("--no-browser", action="store_true")
    r.add_argument("--port", type=int, default=None)
    r.add_argument("--quiet", action="store_true")
    r.set_defaults(fn=cmd_run)
    o = sub.add_parser("open-ui", help="open the running collector's UI")
    o.add_argument("--print-url", action="store_true")
    o.set_defaults(fn=cmd_open_ui)
    s = sub.add_parser("status", help="show collection status")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_status)

    src = _Sub(sub.add_parser("source", help="manage sources").add_subparsers(dest="sub", required=True), common)
    for kind in ("sftp", "local"):
        a = src.add_parser(f"add-{kind}")
        a.add_argument("--alias", required=True)
        a.add_argument("--dir", action="append", required=True, help="authorized folder (repeatable)")
        a.add_argument("--role", default="robot" if kind == "sftp" else "driver_station")
        a.add_argument("--depth", type=int, default=2)
        a.add_argument("--csv", action="store_true", help="also collect CSV files from these folders")
        a.add_argument("--text-pattern", action="append", help="collect matching diagnostic text files (repeatable)")
        a.add_argument("--interval", type=float, default=30.0)
        if kind == "sftp":
            a.add_argument("--host", action="append", required=True, help="address to try (repeatable, in order)")
            a.add_argument("--port", type=int, default=22)
            a.add_argument("--user", default="lvuser")
            a.add_argument("--auth", choices=["blank_password", "systemcore_default", "password", "key"], default="blank_password")
            a.add_argument("--key-file")
        a.set_defaults(fn=cmd_source_add, kind=kind)
    ls = src.add_parser("list")
    ls.add_argument("--json", action="store_true")
    ls.set_defaults(fn=cmd_source_list)
    rm = src.add_parser("remove")
    rm.add_argument("--alias", required=True)
    rm.set_defaults(fn=cmd_source_remove)

    sp = sub.add_parser("set-password", help="store a source password in the system credential store")
    sp.add_argument("--source", required=True)
    sp.add_argument("--passphrase", action="store_true", help="store the private-key passphrase instead")
    sp.set_defaults(fn=cmd_set_password)
    th = sub.add_parser("trust-host", help="confirm an SFTP source's host key")
    th.add_argument("--source", required=True)
    th.add_argument("--host")
    th.add_argument("--fingerprint", help="expected SHA256:... fingerprint (skips the prompt only if it matches)")
    th.set_defaults(fn=cmd_trust_host)
    for action in ("pause", "resume", "enable", "disable"):
        sub.add_parser(action, help=f"{action} automatic collection").set_defaults(fn=lambda a, act=action: _control(a, act))

    e = sub.add_parser("export", help="export a verified ZIP for PitRelay")
    e.add_argument("--since", help="ISO date/time (UTC unless an offset is given)")
    e.add_argument("--until")
    e.add_argument("--source", action="append", help="source alias (repeatable)")
    e.add_argument("--capture", action="append", type=int, help="capture id (repeatable)")
    e.add_argument("--observations", help="JSON file with a list of {author, text, observed_time_as_stated}")
    e.add_argument("--include-source", help="robot project folder to include (never executed)")
    e.add_argument("--convert-hoot", action="store_true", help="run your configured Owlet on .hoot files")
    e.add_argument("--max-archive-mb", type=float)
    e.add_argument("--label")
    e.add_argument("--out", help="output folder (default: <store>/exports)")
    e.add_argument("--json", action="store_true")
    e.set_defaults(fn=cmd_export)
    v = sub.add_parser("verify", help="verify a package's inventory and hashes (a ZIP, or a folder made by extract)")
    v.add_argument("zip", metavar="zip-or-folder")
    v.add_argument("--json", action="store_true")
    v.set_defaults(fn=cmd_verify)
    x = sub.add_parser("extract", help="verify, safely extract and print the PitRelay handoff plan")
    x.add_argument("zip")
    x.add_argument("dest")
    x.set_defaults(fn=cmd_extract)
    h = sub.add_parser("handoff", help="supply an extracted package to a local PitRelay engine")
    h.add_argument("extracted", help="the extracted pitrelay-collection folder")
    h.add_argument("--engine-jar", required=True)
    h.add_argument("--state", required=True, help="PitRelay private state folder (not in use by another engine process)")
    h.add_argument("--java", default="java")
    h.add_argument("--out", required=True, help="folder for the receipt")
    h.add_argument("--csv-mappings", help="JSON {archive_path: {timestamp_column, value_column, time_unit, clock, sampling_policy, unit}}")
    h.add_argument("--json", action="store_true")
    h.set_defaults(fn=cmd_handoff)
    a = sub.add_parser("autostart", help="launch at login (explicit opt-in)")
    a.add_argument("action", choices=["status", "enable", "disable"])
    a.set_defaults(fn=cmd_autostart)
    i = sub.add_parser("inspect-project", help="detect season/vendor logging and print setup guidance")
    i.add_argument("project")
    i.add_argument("--json", action="store_true")
    i.set_defaults(fn=cmd_inspect)
    d = sub.add_parser("delete-captures", help="permanently delete local captures (collector must be stopped)")
    d.add_argument("--id", type=int, action="append", required=True)
    d.add_argument("--note")
    d.add_argument("--yes", action="store_true")
    d.set_defaults(fn=cmd_delete)
    return p


class _Sub:
    """Adds the shared options (currently --store) to every subcommand parser."""

    def __init__(self, action, common):
        self.action, self.common = action, common

    def add_parser(self, name, **kw):
        return self.action.add_parser(name, parents=[self.common], **kw)


STORELESS_COMMANDS = {"verify", "extract", "handoff", "inspect-project"}


def main(argv=None) -> int:
    quiet_library_loggers()  # e.g. trust-host: paramiko must not print a remote banner raw to the terminal
    args = build_parser().parse_args(argv)
    if args.cmd not in STORELESS_COMMANDS:
        try:
            Store(_store_path(args)).check_version()  # a store from another collector version is never touched
        except StoreError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
    return args.fn(args)
