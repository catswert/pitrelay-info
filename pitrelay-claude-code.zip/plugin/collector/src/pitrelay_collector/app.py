"""The running collector process: store owner + collector thread + local web UI."""

from __future__ import annotations

import json
import logging
import logging.handlers
import os
import signal
import threading
import sys
import uuid
import webbrowser
from pathlib import Path

from .autostart import Autostart
from .collector import Collector
from .config import ConfigManager
from .export import ExportOptions, export_package
from .status import build_status
from .store import Store
from .util import Clock, SafeFormatter, atomic_write_json, quiet_library_loggers, utc_iso

log = logging.getLogger("pitrelay_collector")


def setup_logging(store_root: Path, console: bool = True) -> None:
    diag = Path(store_root) / "diagnostics"
    diag.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger("pitrelay_collector")
    if any(getattr(h, "_pitrelay", False) for h in root.handlers):
        return
    fh = logging.handlers.RotatingFileHandler(diag / "collector.log", maxBytes=1024 * 1024, backupCount=5, encoding="utf-8")
    fh.setFormatter(SafeFormatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    fh._pitrelay = True
    root.addHandler(fh)
    if console and sys.stderr is not None:  # pythonw (Windows launch at login) has no console
        ch = logging.StreamHandler()
        ch.setFormatter(SafeFormatter("%(levelname)s %(message)s"))
        ch._pitrelay = True
        root.addHandler(ch)
    root.setLevel(logging.INFO)
    # paramiko logs connection failures quoting what the remote device sent (e.g. its SSH banner). Keep them
    # in the diagnostics file, neutralized, and never on the console via logging's last-resort handler.
    lib = logging.getLogger("paramiko")
    lib.handlers = [h for h in lib.handlers if not isinstance(h, logging.NullHandler)]
    if not any(getattr(h, "_pitrelay", False) for h in lib.handlers):
        lib.addHandler(fh)
    lib.setLevel(logging.WARNING)
    lib.propagate = False
    quiet_library_loggers()


class App:
    def __init__(self, store_root: Path, secrets=None, clock: Clock | None = None, autostart: Autostart | None = None,
                 connect=None, ident: str | None = None):
        self.root = Path(store_root)
        # Who runs this collector, recorded in ui.json: "standalone", "claude" (the background collector of PitRelay
        # for Claude Code) or "claude-session" (inside a Claude Code session). Stopping it is limited by this.
        from . import autostart as _autostart
        self.ident = ident or (_autostart.BUNDLED["ident"] if _autostart.BUNDLED else "standalone")
        self.clock = clock or Clock()
        if secrets is None:
            from .secrets import KeyringSecrets
            secrets = KeyringSecrets()
        self.secrets = secrets
        self.autostart = autostart or Autostart()
        self._connect = connect
        self.store: Store | None = None
        self.config: ConfigManager | None = None
        self.collector: Collector | None = None
        self.ui = None
        self.stop_event = threading.Event()
        self.exports: dict[str, dict] = {}
        self._exports_lock = threading.Lock()

    @property
    def ui_file(self) -> Path:
        return self.root / "ui.json"


    def open(self) -> "App":
        Store.ensure_layout(self.root)
        self.store = Store(self.root, self.clock).open_owner()
        self.config = ConfigManager(self.root)
        cfg = self.config.load()
        if not self.config.path.exists():
            self.config.save(cfg)
        self.store.sync_sources(cfg.sources)
        self.config.listeners.append(lambda c: self.store.sync_sources(c.sources))
        self.collector = Collector(self.store, self.config, clock=self.clock, secrets=self.secrets, connect=self._connect)
        return self

    def start(self, ui: bool = True, port: int | None = None, open_browser: bool = False) -> "App":
        self.collector.start()
        log.info("collector started for store %s", self.root)
        if ui:
            self.start_ui(port, open_browser)
        return self

    def start_ui(self, port: int | None = None, open_browser: bool = False) -> bool:
        """Start the local web UI if it is not running. Returns whether a browser was opened."""
        if self.ui is None:
            from .webui import WebUI
            cfg = self.config.load()
            self.ui = WebUI(self, port if port is not None else cfg.ui_port).start()
            atomic_write_json(self.ui_file, {"pid": os.getpid(), "ident": self.ident, "port": self.ui.port,
                                             "login_url": self.ui.login_url, "started_utc": utc_iso(self.clock.time())},
                              mode=0o600)
            log.info("web UI at http://127.0.0.1:%s/ (open it with: pitrelay-collector open-ui)", self.ui.port)
        if open_browser:
            # The browser's command line carries only a single-use code, never the session token.
            return bool(webbrowser.open(self.ui.launch_url()))
        return False

    def wait(self) -> None:
        def handler(signum, frame):
            self.stop_event.set()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, handler)
            except (ValueError, OSError):
                pass
        while not self.stop_event.wait(1.0):
            pass

    def request_stop(self) -> None:
        self.stop_event.set()

    def shutdown(self) -> None:
        if self.ui is not None:
            self.ui.stop()
            self.ui = None
        try:
            self.ui_file.unlink()
        except FileNotFoundError:
            pass
        if self.collector is not None:
            self.collector.stop()
        if self.store is not None:
            self.store.close()
        log.info("collector stopped")

    # --- operations used by the UI -----------------------------------------------------

    def status(self) -> dict:
        cfg = self.config.load()
        st = build_status(self.store, cfg, self.collector)
        st["autostart"] = self.autostart.status()
        return st

    def start_export(self, opts: ExportOptions) -> str:
        job = uuid.uuid4().hex[:12]
        with self._exports_lock:
            self.exports[job] = {"id": job, "state": "running", "started_utc": utc_iso(self.clock.time())}

        def run():
            try:
                cfg = self.config.load()
                state = {"overall": build_status(self.store, cfg, self.collector)["overall"], "at_utc": utc_iso(self.clock.time())}
                res = export_package(self.store, cfg, opts, collector_state=state)
                outcome = {"state": "succeeded" if res.ok else "failed", "ok": res.ok, "archives": res.archives,
                           "warnings": res.warnings, "error": res.error}
            except Exception as e:  # report, never crash the server
                log.exception("export failed")
                outcome = {"state": "failed", "ok": False, "archives": [], "warnings": [], "error": f"{e.__class__.__name__}: {e}"}
            with self._exports_lock:
                self.exports[job].update(outcome, finished_utc=utc_iso(self.clock.time()))

        threading.Thread(target=run, name=f"export-{job}", daemon=True).start()
        return job

    def export_job(self, job: str) -> dict | None:
        with self._exports_lock:
            j = self.exports.get(job)
            return json.loads(json.dumps(j)) if j else None

    def exported_paths(self) -> set[str]:
        with self._exports_lock:
            return {a["path"] for j in self.exports.values() for a in j.get("archives", [])}
