"""Shared rules for PitRelay collection packages: member-name safety and verification.

The exporter uses these to check what it wrote; `verify` and `extract` use the
same rules on packages received from elsewhere. Archive contents are untrusted.
"""

from __future__ import annotations

import hashlib
import json
import re
import stat
import zipfile
from pathlib import Path

from . import PACKAGE_SCHEMA

ROOT = "pitrelay-collection"
MANIFEST = "manifest.json"
MAX_MEMBERS = 200_000
MAX_MANIFEST_BYTES = 64 * 1024 * 1024
_WINDOWS_RESERVED = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
_COMPONENT_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9._-]{0,254}$")


def unsafe_member_reason(info: zipfile.ZipInfo) -> str | None:
    """Return why a ZIP member is unsafe to extract, or None if it is acceptable."""
    name = info.filename
    if "\\" in name:
        return "backslash in member name"
    if name.startswith("/") or re.match(r"^[A-Za-z]:", name):
        return "absolute path"
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in name) or ":" in name:
        return "control character or ':' in member name"
    if len(name) > 400:
        return "member name too long"
    mode = (info.external_attr >> 16) & 0o170000
    if mode == stat.S_IFLNK:
        return "symbolic link entry"
    if mode not in (0, stat.S_IFREG, stat.S_IFDIR):
        return "special file entry"
    if info.flag_bits & 0x1:
        return "encrypted entry"
    parts = name.rstrip("/").split("/") if info.is_dir() else name.split("/")
    for part in parts:
        if part in ("", ".", ".."):
            return "empty, '.' or '..' path component"
        if not _COMPONENT_RE.match(part) or part.endswith((".", " ")):
            return f"path component {part!r} is not a portable name"
        if part.split(".", 1)[0].upper() in _WINDOWS_RESERVED:
            return f"path component {part!r} is a reserved Windows device name"
    if parts[0] != ROOT:
        return f"member is outside the '{ROOT}/' folder"
    return None


def _sha256_member(zf: zipfile.ZipFile, info: zipfile.ZipInfo) -> tuple[str, int]:
    h = hashlib.sha256()
    n = 0
    with zf.open(info) as f:  # zipfile also checks the CRC-32 at end of stream
        while True:
            block = f.read(1024 * 1024)
            if not block:
                break
            h.update(block)
            n += len(block)
    return h.hexdigest(), n


def expected_files(manifest: dict) -> dict[str, dict]:
    """archive_path -> {size_bytes, sha256, kind} for every file the manifest promises."""
    out: dict[str, dict] = {}

    def add(entry, kind):
        out[entry["archive_path"]] = {"size_bytes": entry["size_bytes"], "sha256": entry["sha256"], "kind": kind}

    for c in manifest.get("captures", []):
        add(c, "capture")
    for d in manifest.get("derived", []):
        add(d, "derived")
    for s in (manifest.get("source_code") or {}).get("files", []):
        add(s, "source")
    for p in manifest.get("package_files", []):
        add(p, "package")
    return out


def verify_package(path: Path, check_hashes: bool = True) -> dict:
    """Check structure, member safety, inventory and every hash. Returns a report dict."""
    report = {"path": str(path), "ok": False, "errors": [], "warnings": [], "files_checked": 0, "bytes_checked": 0,
              "manifest": None}
    errors = report["errors"]
    try:
        zf = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError) as e:
        errors.append(f"not a readable ZIP file: {e}")
        return report
    with zf:
        infos = zf.infolist()
        if len(infos) > MAX_MEMBERS:
            errors.append(f"too many members ({len(infos)})")
            return report
        seen_exact: set[str] = set()
        seen_fold: set[str] = set()
        members: dict[str, zipfile.ZipInfo] = {}
        for info in infos:
            reason = unsafe_member_reason(info)
            if reason:
                errors.append(f"unsafe member {info.filename!r}: {reason}")
                continue
            if info.filename in seen_exact:
                errors.append(f"duplicate member {info.filename!r}")
                continue
            folded = info.filename.casefold()
            if folded in seen_fold:
                errors.append(f"members collide on case-insensitive filesystems: {info.filename!r}")
                continue
            seen_exact.add(info.filename)
            seen_fold.add(folded)
            if not info.is_dir():
                members[info.filename[len(ROOT) + 1:]] = info
        if errors:
            return report
        minfo = members.get(MANIFEST)
        if minfo is None:
            errors.append("manifest.json is missing")
            return report
        if minfo.file_size > MAX_MANIFEST_BYTES:
            errors.append("manifest.json is implausibly large")
            return report
        try:
            manifest = json.loads(zf.read(minfo).decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as e:
            errors.append(f"manifest.json is not valid UTF-8 JSON: {e}")
            return report
        report["manifest"] = manifest
        if manifest.get("schema") != PACKAGE_SCHEMA:
            errors.append(f"unexpected schema {manifest.get('schema')!r}")
            return report
        version = str(manifest.get("schema_version", ""))
        if version.split(".")[0] != "1":
            errors.append(f"unsupported schema_version {version!r} (this tool reads 1.x)")
            return report
        try:
            expected = expected_files(manifest)
        except (KeyError, TypeError) as e:
            errors.append(f"manifest file inventory is malformed: {e}")
            return report
        for rel, exp in sorted(expected.items()):
            info = members.get(rel)
            if info is None:
                errors.append(f"listed file missing from archive: {rel}")
                continue
            if info.file_size != exp["size_bytes"]:
                errors.append(f"size mismatch for {rel}: archive {info.file_size}, manifest {exp['size_bytes']}")
                continue
            if check_hashes:
                try:
                    digest, n = _sha256_member(zf, info)
                except (zipfile.BadZipFile, OSError, EOFError) as e:
                    errors.append(f"cannot read {rel}: {e}")
                    continue
                if digest != exp["sha256"]:
                    errors.append(f"SHA-256 mismatch for {rel}")
                    continue
                report["bytes_checked"] += n
            report["files_checked"] += 1
        for rel in sorted(members):
            if rel != MANIFEST and rel not in expected:
                errors.append(f"unexpected file not listed in manifest: {rel}")
    report["ok"] = not errors
    return report


def verify_extracted(folder: Path) -> dict:
    """Verify an extracted package folder (the `extract` destination, or its pitrelay-collection/ folder).

    Same inventory and hash rules as the ZIP. Links and special files are refused. An extracted folder has no
    archive-level checksum, so this proves the files match their manifest; keep the original ZIP and its .sha256
    to show the manifest itself is the one you received.
    """
    folder = Path(folder)
    root = folder if (folder / MANIFEST).is_file() else folder / ROOT
    report = {"path": str(folder), "ok": False, "errors": [], "warnings": [
        "extracted folder: files were checked against manifest.json; the manifest itself is anchored only by the "
        "original ZIP and its .sha256"], "files_checked": 0, "bytes_checked": 0, "manifest": None}
    errors = report["errors"]
    if not (root / MANIFEST).is_file() or (root / MANIFEST).is_symlink():
        errors.append(f"no {ROOT}/{MANIFEST} found in this folder")
        return report
    files: dict[str, Path] = {}
    pending = [root]
    while pending:
        current = pending.pop()
        for entry in sorted(current.iterdir()):
            rel = entry.relative_to(root).as_posix()
            st = entry.lstat()
            if stat.S_ISLNK(st.st_mode) or getattr(st, "st_file_attributes", 0) & 0x400:
                errors.append(f"link not allowed: {rel}")
            elif stat.S_ISDIR(st.st_mode):
                pending.append(entry)
            elif stat.S_ISREG(st.st_mode):
                files[rel] = entry
            else:
                errors.append(f"special file not allowed: {rel}")
        if len(files) > MAX_MEMBERS:
            errors.append("too many files")
            return report
    if errors:
        return report
    try:
        if files[MANIFEST].stat().st_size > MAX_MANIFEST_BYTES:
            errors.append("manifest.json is implausibly large")
            return report
        manifest = json.loads(files[MANIFEST].read_bytes().decode("utf-8"))
    except (ValueError, UnicodeDecodeError, OSError) as e:
        errors.append(f"manifest.json is not valid UTF-8 JSON: {e}")
        return report
    report["manifest"] = manifest
    if not isinstance(manifest, dict) or manifest.get("schema") != PACKAGE_SCHEMA:
        errors.append(f"unexpected schema {manifest.get('schema') if isinstance(manifest, dict) else None!r}")
        return report
    version = str(manifest.get("schema_version", ""))
    if version.split(".")[0] != "1":
        errors.append(f"unsupported schema_version {version!r} (this tool reads 1.x)")
        return report
    try:
        expected = expected_files(manifest)
    except (KeyError, TypeError) as e:
        errors.append(f"manifest file inventory is malformed: {e}")
        return report
    for rel, exp in sorted(expected.items()):
        p = files.get(rel)
        if p is None:
            errors.append(f"listed file missing from folder: {rel}")
            continue
        size = p.stat().st_size
        if size != exp["size_bytes"]:
            errors.append(f"size mismatch for {rel}: folder {size}, manifest {exp['size_bytes']}")
            continue
        h = hashlib.sha256()
        with open(p, "rb") as f:
            for block in iter(lambda: f.read(1024 * 1024), b""):
                h.update(block)
        if h.hexdigest() != exp["sha256"]:
            errors.append(f"SHA-256 mismatch for {rel}")
            continue
        report["files_checked"] += 1
        report["bytes_checked"] += size
    for rel in sorted(files):
        if rel != MANIFEST and rel not in expected:
            errors.append(f"unexpected file not listed in manifest: {rel}")
    report["ok"] = not errors
    return report
