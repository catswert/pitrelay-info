"""Credential storage in the operating system's protected store.

Uses the `keyring` package: Windows Credential Manager, macOS Keychain, or a
Secret Service backend on Linux. Secrets never go into config.json, the
catalog, diagnostic logs or exported packages. If no secure backend exists the
collector refuses to store a password instead of falling back to a plain file.

A roboRIO's documented `lvuser` login has a blank password; that case uses the
"blank_password" auth method and needs no stored secret at all.
"""

from __future__ import annotations

import threading
import time

SERVICE = "PitRelayCollector"


class SecretStoreUnavailable(RuntimeError):
    pass


KEYRING_TIMEOUT_S = 10.0
_slot = threading.BoundedSemaphore(1)  # one credential-store call at a time in this process


def _bounded(fn, timeout: float = KEYRING_TIMEOUT_S):
    """Run a credential-store call with a time limit: a locked store can wait for an unlock prompt nobody sees
    (SSH, headless Linux, a background process), and must never stall collection.

    Only one call runs at a time. A call that did not answer keeps its slot until the store answers it, so later
    calls are refused after the time limit instead of piling up threads that all wait for the same prompt."""
    deadline = time.monotonic() + timeout
    if not _slot.acquire(timeout=timeout):
        raise SecretStoreUnavailable("The system credential store has not answered an earlier request yet (it may be "
                                     "locked and waiting for an unlock prompt); unlock it, or use key-file authentication")
    box: dict = {}
    done = threading.Event()

    def run():
        try:
            box["value"] = fn()
        except BaseException as e:  # handed to the caller
            box["error"] = e
        finally:
            _slot.release()
            done.set()
    threading.Thread(target=run, name="pitrelay-keyring", daemon=True).start()
    if not done.wait(max(0.0, deadline - time.monotonic())):
        raise SecretStoreUnavailable("The system credential store did not answer (it may be locked and waiting for an "
                                     "unlock prompt); unlock it, or use key-file authentication")
    if "error" in box:
        raise box["error"]
    return box.get("value")


class KeyringSecrets:
    def _keyring(self):
        try:
            import keyring
            from keyring.backends import fail
        except ImportError as e:  # pragma: no cover
            raise SecretStoreUnavailable("The 'keyring' package is not installed") from e
        backend = keyring.get_keyring()
        # Refuse the null backend and the plain-file backends from keyrings.alt.
        if isinstance(backend, fail.Keyring) or type(backend).__module__.startswith("keyrings.alt"):
            raise SecretStoreUnavailable("No secure credential store is available on this computer (keyring backend: "
                                         f"{type(backend).__name__}). Use key-file authentication or a blank-password account.")
        return keyring

    def get(self, source_id: str, name: str) -> str | None:
        """The stored secret, or None when none is stored. Raises SecretStoreUnavailable when the store cannot be
        asked (none available, locked, not answering): that is not the same as no password being stored."""
        try:
            return _bounded(lambda: self._keyring().get_password(SERVICE, f"{source_id}:{name}"))
        except SecretStoreUnavailable:
            raise
        except Exception:  # other backend errors must not crash collection
            return None

    def set(self, source_id: str, name: str, value: str) -> None:
        kr = _bounded(self._keyring)
        try:
            _bounded(lambda: kr.set_password(SERVICE, f"{source_id}:{name}", value))
        except SecretStoreUnavailable as e:
            raise SecretStoreUnavailable(f"{e}. If the store was waiting for an unlock prompt, the secret may still be "
                                         "stored once it is unlocked; the source's state then shows whether it works") \
                from None
        except Exception as e:
            raise SecretStoreUnavailable(f"Could not store the secret: {e.__class__.__name__}") from None

    def delete(self, source_id: str, name: str) -> None:
        try:
            _bounded(lambda: self._keyring().delete_password(SERVICE, f"{source_id}:{name}"))
        except Exception:
            pass

    def has(self, source_id: str, name: str) -> bool:
        try:
            return self.get(source_id, name) is not None
        except SecretStoreUnavailable:
            return False

    def state(self, source_id: str, name: str, timeout: float = 2.0) -> str:
        """'stored', 'not_stored' or 'unavailable' (no store, locked, or not answering within `timeout`): for showing,
        so a locked store is never presented as a missing password and never holds up a page for long."""
        try:
            value = _bounded(lambda: self._keyring().get_password(SERVICE, f"{source_id}:{name}"), timeout)
        except SecretStoreUnavailable:
            return "unavailable"
        except Exception:
            return "unavailable"
        return "stored" if value is not None else "not_stored"


class MemorySecrets:
    """In-memory store for tests."""

    def __init__(self):
        self.values: dict[tuple[str, str], str] = {}

    def get(self, source_id, name):
        return self.values.get((source_id, name))

    def set(self, source_id, name, value):
        self.values[(source_id, name)] = value

    def delete(self, source_id, name):
        self.values.pop((source_id, name), None)

    def has(self, source_id, name):
        return (source_id, name) in self.values

    def state(self, source_id, name, timeout: float = 2.0):
        return "stored" if (source_id, name) in self.values else "not_stored"
