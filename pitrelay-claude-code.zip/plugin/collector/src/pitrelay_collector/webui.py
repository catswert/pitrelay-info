"""Local web interface (127.0.0.1 only) for setup, status and export.

Security model: the server listens on the loopback interface only, and every
request must carry a Host header naming the loopback address and our port
(blocks DNS rebinding). The page and its script contain no secrets. Every API
call must present the random session token in an `Authorization: Bearer`
header. The page receives the token in the URL *fragment* (never sent to any
server), keeps it in sessionStorage, which is scoped to this exact origin
including the port, and removes it from the address bar. No cookie is used:
browsers send cookies to every port of 127.0.0.1, so another local program
listening on a different port would receive it. A custom header also cannot be
added by a cross-site page without a CORS preflight, which is never granted,
so no separate CSRF token is needed. Downloads use single-use tickets that
expire after a minute. No secret is ever returned by the API.
"""

from __future__ import annotations

import hmac
import json
import secrets as _secrets
import shutil
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .config import (ConfigError, CollectorConfig, RobotProfile, merge_source, suggested_directories,
                     validate_source)
from .export import ExportOptions, _overlaps
from .projectscan import inspect_project
from .util import parse_iso, utc_iso

TICKET_TTL_S = 60.0
# Fixed, not from the mimetypes module: on Windows it reads the registry, where .js is often mapped to
# text/plain, and with nosniff the browser would then refuse to run the UI script.
STATIC_TYPES = {"app.js": "text/javascript; charset=utf-8", "style.css": "text/css; charset=utf-8"}
MAX_BODY = 2 * 1024 * 1024
SETTINGS_FIELDS = {"bandwidth_limit_bps", "quota_bytes", "min_free_bytes", "max_bytes_per_cycle", "active_window_s",
                   "complete_after_s", "owlet_path", "backoff_initial_s", "backoff_max_s"}
CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; "
       "frame-ancestors 'none'; base-uri 'none'; form-action 'none'")


def _static(name: str) -> bytes:
    return resources.files("pitrelay_collector").joinpath("static", name).read_bytes()


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


class WebUI:
    def __init__(self, app, port: int = 0):
        self.app = app
        self.token = _secrets.token_urlsafe(32)
        self._tickets: dict[str, tuple[str, float]] = {}
        self._launch_codes: dict[str, float] = {}
        self._tickets_lock = threading.Lock()
        self.httpd = ThreadingHTTPServer(("127.0.0.1", port), self._handler())
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self._thread = None

    @property
    def login_url(self) -> str:
        return f"http://127.0.0.1:{self.port}/#token={self.token}"

    def launch_url(self) -> str:
        """A sign-in link safe to hand to a browser on its command line.

        It carries a single-use code that expires after a minute, not the session token. Other local users can
        read a process's command line, but a code that was already exchanged is worthless to them. Unlike a
        private launch file, this also works for sandboxed (snap or Flatpak) browsers that cannot read hidden
        folders.
        """
        code = _secrets.token_urlsafe(24)
        now = time.monotonic()
        with self._tickets_lock:
            self._launch_codes = {k: v for k, v in self._launch_codes.items() if v > now}
            self._launch_codes[code] = now + TICKET_TTL_S
        return f"http://127.0.0.1:{self.port}/#launch={code}"

    def redeem_launch_code(self, code: str) -> bool:
        with self._tickets_lock:
            expiry = self._launch_codes.pop(code, None)
        return expiry is not None and expiry > time.monotonic()

    def issue_ticket(self, path: str) -> str:
        ticket = _secrets.token_urlsafe(24)
        now = time.monotonic()
        with self._tickets_lock:
            self._tickets = {k: v for k, v in self._tickets.items() if v[1] > now}
            self._tickets[ticket] = (path, now + TICKET_TTL_S)
        return ticket

    def redeem_ticket(self, ticket: str) -> str | None:
        with self._tickets_lock:
            entry = self._tickets.pop(ticket, None)
        if entry is None or entry[1] <= time.monotonic():
            return None
        return entry[0]

    def start(self) -> "WebUI":
        self._thread = threading.Thread(target=self.httpd.serve_forever, name="pitrelay-webui", daemon=True)
        self._thread.start()
        return self

    def stop(self) -> None:
        self.httpd.shutdown()
        self.httpd.server_close()

    def _handler(self):
        ui = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "PitRelayCollector"
            sys_version = ""

            def log_message(self, fmt, *args):  # keep tokens and paths out of stderr
                pass

            # --- plumbing ----------------------------------------------------------
            def _send(self, status, body: bytes, ctype="application/json; charset=utf-8", headers=None):
                self.send_response(status)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("Content-Security-Policy", CSP)
                for k, v in (headers or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(body)

            def _json(self, status, obj):
                self._send(status, json.dumps(obj).encode("utf-8"))

            def _host_ok(self) -> bool:
                return self.headers.get("Host", "") in (f"127.0.0.1:{ui.port}", f"localhost:{ui.port}")

            def _auth_ok(self) -> bool:
                scheme, _, value = self.headers.get("Authorization", "").partition(" ")
                return scheme == "Bearer" and hmac.compare_digest(value.strip().encode(), ui.token.encode())

            def _body(self) -> dict:
                n = int(self.headers.get("Content-Length") or 0)
                if n > MAX_BODY:
                    raise ApiError(413, "Request too large")
                raw = self.rfile.read(n) if n else b"{}"
                try:
                    data = json.loads(raw.decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    raise ApiError(400, "Body must be JSON") from None
                if not isinstance(data, dict):
                    raise ApiError(400, "Body must be a JSON object")
                return data

            # --- GET ---------------------------------------------------------------
            def do_GET(self):
                if not self._host_ok():
                    return self._send(403, b"Forbidden host", "text/plain; charset=utf-8")
                url = urlparse(self.path)
                # The page and its assets hold no secrets; the API needs the session token.
                if url.path == "/":
                    return self._send(200, _static("index.html"), "text/html; charset=utf-8")
                if url.path.startswith("/static/"):
                    name = url.path[len("/static/"):]
                    if name not in STATIC_TYPES:
                        return self._send(404, b"not found", "text/plain")
                    return self._send(200, _static(name), STATIC_TYPES[name])
                try:
                    if url.path == "/download":
                        if self.command != "GET":
                            raise ApiError(405, "Use GET")
                        path = ui.redeem_ticket(parse_qs(url.query).get("ticket", [""])[0])
                        if path is None:
                            raise ApiError(403, "This download link has expired or was already used; "
                                                "click the file name in the collector again")
                        return self._download(path)
                    if not self._auth_ok():
                        raise ApiError(401, "Not signed in; open the collector with: pitrelay-collector open-ui")
                    return self._json(200, self._get_api(url))
                except ApiError as e:
                    return self._json(e.status, {"error": str(e)})
                except Exception as e:
                    return self._json(500, {"error": f"{e.__class__.__name__}: {e}"})

            def _download(self, path: str):
                p = Path(path)
                size = p.stat().st_size
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Length", str(size))
                self.send_header("Content-Disposition", f'attachment; filename="{p.name}"')
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                if self.command != "HEAD":
                    with open(p, "rb") as f:
                        shutil.copyfileobj(f, self.wfile, 1024 * 1024)

            def _get_api(self, url):
                app = ui.app
                q = parse_qs(url.query)
                if url.path == "/api/status":
                    return app.status()
                if url.path == "/api/config":
                    return _public_config(app.config.load(), app.secrets)
                if url.path == "/api/captures":
                    return {"captures": _captures(app, q)}
                if url.path == "/api/suggest-dirs":
                    cfg = app.config.load()
                    return {"directories": suggested_directories(cfg.robot_profile, q.get("role", ["robot"])[0])}
                if url.path.startswith("/api/export/"):
                    job = app.export_job(url.path.rsplit("/", 1)[1])
                    if job is None:
                        raise ApiError(404, "Unknown export job")
                    return job
                raise ApiError(404, "Not found")

            # --- POST --------------------------------------------------------------
            def do_POST(self):
                if not self._host_ok():
                    return self._send(403, b"Forbidden host", "text/plain; charset=utf-8")
                origin = self.headers.get("Origin")
                if origin is not None and origin not in (f"http://127.0.0.1:{ui.port}", f"http://localhost:{ui.port}"):
                    return self._json(403, {"error": "Cross-origin request refused"})
                if urlparse(self.path).path == "/api/launch":
                    # Exchange a single-use launch code for the session token (same origin only; the response
                    # cannot be read by another site because no CORS headers are ever sent).
                    try:
                        code = str(self._body().get("code") or "")
                    except ApiError as e:
                        return self._json(e.status, {"error": str(e)})
                    if not ui.redeem_launch_code(code):
                        return self._json(403, {"error": "This sign-in link has expired or was already used. "
                                                          "Run: pitrelay-collector open-ui"})
                    return self._json(200, {"token": ui.token})
                if not self._auth_ok():
                    return self._json(401, {"error": "Not signed in; open the collector with: pitrelay-collector open-ui"})
                try:
                    body = self._body()
                    return self._json(200, self._post_api(urlparse(self.path).path, body))
                except ApiError as e:
                    return self._json(e.status, {"error": str(e)})
                except (ConfigError, ValueError) as e:
                    return self._json(400, {"error": str(e)})
                except Exception as e:
                    return self._json(500, {"error": f"{e.__class__.__name__}: {e}"})

            def _post_api(self, path, body):
                app = ui.app
                col = app.collector
                if path == "/api/control":
                    action = body.get("action")
                    if action == "pause":
                        col.pause()
                    elif action == "resume":
                        col.resume()
                    elif action == "enable":
                        col.set_enabled(True)
                    elif action == "disable":
                        col.set_enabled(False)
                    elif action == "poll_now":
                        col.poll_now()
                    elif action == "stop":
                        threading.Timer(0.3, app.request_stop).start()
                        return {"ok": True, "message": "Collector stopping"}
                    else:
                        raise ApiError(400, "Unknown action")
                    return {"ok": True}
                if path == "/api/sources":
                    return _save_source(app, body.get("source") or {})
                if path == "/api/sources/delete":
                    sid = body.get("id")

                    def drop(cfg: CollectorConfig):
                        if cfg.source_by_id(sid) is None:
                            raise ValueError("Unknown source")
                        cfg.sources = [s for s in cfg.sources if s.id != sid]
                    app.config.update(drop)
                    app.store.add_event("info", "source_removed", "Source removed from configuration; its captures are kept",
                                        source_id=sid)
                    col.wake()
                    return _public_config(app.config.load(), app.secrets)
                if path == "/api/settings":
                    return _save_settings(app, body)
                if path == "/api/trust":
                    key = col.trust_host_key(str(body.get("source_id")), str(body.get("fingerprint")))
                    return {"ok": True, "trusted": key["fingerprint"]}
                if path == "/api/secret":
                    sid, name, value = body.get("source_id"), body.get("name"), body.get("value")
                    if name not in ("password", "key_passphrase") or not isinstance(value, str):
                        raise ApiError(400, "Invalid secret request")
                    if app.config.load().source_by_id(sid) is None:
                        raise ApiError(404, "Unknown source")
                    app.secrets.set(sid, name, value)
                    col.poll_now()
                    return {"ok": True}
                if path == "/api/autostart":
                    if body.get("enable"):
                        if body.get("confirm") is not True:
                            raise ApiError(400, "Enabling launch at login requires explicit confirmation")
                        st = app.autostart.enable(app.root)
                        app.store.add_event("info", "autostart_enabled", f"Launch at login enabled ({st['mechanism']})")
                    else:
                        st = app.autostart.disable()
                        app.store.add_event("info", "autostart_disabled", "Launch at login disabled")
                    return st
                if path == "/api/inspect-project":
                    p = Path(str(body.get("path", ""))).expanduser()
                    if not p.is_absolute() or not p.is_dir():
                        raise ApiError(400, "Enter the absolute path of the robot project folder")
                    result = inspect_project(p)
                    if body.get("apply"):
                        def setprof(cfg: CollectorConfig):
                            prof = result["profile"]
                            cfg.robot_profile = RobotProfile(
                                controller="systemcore" if prof["controller"] == "systemcore" else
                                (cfg.robot_profile.controller or None),
                                season=prof["season"], wpilib_datalog=prof["wpilib_datalog"], advantagekit=prof["advantagekit"],
                                rev_status_logger=bool(prof["rev_status_logger"]), ctre_signal_logger=bool(prof["ctre_signal_logger"]),
                                basis={"detected_from_project": p.name})
                        app.config.update(setprof)
                    return result
                if path == "/api/export":
                    return {"job": app.start_export(_export_options(app, body))}
                if path == "/api/launch-url":
                    return {"url": ui.launch_url()}
                if path == "/api/download-ticket":
                    target = str(body.get("path") or "")
                    if target not in app.exported_paths():
                        raise ApiError(404, "Only archives exported by this collector session can be downloaded here")
                    return {"url": "/download?ticket=" + ui.issue_ticket(target)}
                if path == "/api/delete-captures":
                    if body.get("confirm") != "DELETE":
                        raise ApiError(400, "Type DELETE to confirm permanent local deletion")
                    ids = [int(x) for x in body.get("ids", [])]
                    note = str(body.get("note") or "deleted from the web UI")[:200]
                    return {"deleted": app.store.delete_captures(ids, note)}
                raise ApiError(404, "Not found")

            do_HEAD = do_GET

        return Handler


def _public_config(cfg: CollectorConfig, secrets) -> dict:
    d = cfg.to_dict()
    store_answers = True
    for s, src in zip(d["sources"], cfg.sources):
        s["trusted_host_keys"] = [{"type": k.get("type"), "fingerprint": k.get("fingerprint"), "trusted_at": k.get("trusted_at")}
                                  for k in src.trusted_host_keys]
        state = None
        if src.kind == "sftp" and src.auth_choice == "password":
            # Asked once per source with a short limit; after one store that does not answer, not again this request.
            state = secrets.state(src.id, "password") if store_answers else "unavailable"
            store_answers = state != "unavailable"
        s["password_state"] = state
        s["has_password"] = state == "stored"
        s["auth"] = src.auth_choice  # a documented default login is shown as its own choice
        s.pop("password_preset", None)
    return d


def _save_source(app, data: dict) -> dict:
    data = dict(data)
    data.pop("trusted_host_keys", None)  # host keys are only trusted through the explicit trust action
    data.pop("has_password", None)
    data.pop("password_state", None)
    data.pop("password_preset", None)  # follows the auth choice

    saved = {}

    def apply(cfg: CollectorConfig):
        existing = cfg.source_by_id(data.get("id", "")) if data.get("id") else None
        merged = merge_source(existing, data)
        if existing:
            # Keep pins when addresses change: the same robot is reachable at several addresses
            # (USB, tether, radio) and the key check happens on every connection anyway.
            merged.trusted_host_keys = existing.trusted_host_keys
        src = validate_source(merged, app.root, [s for s in cfg.sources if s.id != merged.id])
        cfg.sources = [s for s in cfg.sources if s.id != src.id] + [src]
        saved["id"] = src.id
    app.config.update(apply)
    app.collector.poll_now()
    return _public_config(app.config.load(), app.secrets) | {"saved_id": saved["id"]}


def _save_settings(app, body: dict) -> dict:
    def apply(cfg: CollectorConfig):
        for k, v in body.items():
            if k in SETTINGS_FIELDS:
                if k == "owlet_path":
                    setattr(cfg, k, (str(v).strip() or None) if v is not None else None)
                elif k == "bandwidth_limit_bps":
                    setattr(cfg, k, int(v) if v not in (None, "", 0) else None)
                else:
                    setattr(cfg, k, type(getattr(cfg, k))(v))
            elif k == "robot_profile" and isinstance(v, dict):
                cur = cfg.robot_profile.to_dict()
                cur.update({kk: vv for kk, vv in v.items() if kk in ("controller", "season", "wpilib_datalog", "advantagekit",
                                                                    "rev_status_logger", "ctre_signal_logger")})
                cur["basis"] = dict(cur.get("basis") or {}, manual_selection=True)
                cfg.robot_profile = RobotProfile.from_dict(cur)
    app.config.update(apply)
    app.collector.wake()
    return _public_config(app.config.load(), app.secrets)


def _captures(app, q) -> list[dict]:
    since = parse_iso(q["since"][0]) if q.get("since", [""])[0] else None
    until = parse_iso(q["until"][0]) if q.get("until", [""])[0] else None
    aliases = {s["source_id"]: s["alias"] for s in app.store.known_sources()}
    out = []
    for c in app.store.captures():
        if not _overlaps(c, since, until):
            continue
        fmt = app.store.format_cache_get(c["id"], c["committed_size"])
        out.append({"id": c["id"], "source": aliases.get(c["source_id"], c["source_id"]), "source_id": c["source_id"],
                    "name": c["path"].replace("\\", "/").rsplit("/", 1)[-1], "status": c["status"],
                    "reasons": c["status_reasons"], "presence": c["presence"], "size": c["committed_size"],
                    "observed": c["observed_size"], "first_seen_utc": utc_iso(c["first_seen"]),
                    "last_acquired_utc": utc_iso(c["last_acquired"]), "format": fmt.get("label") if fmt else None})
    return out


def _export_options(app, body: dict) -> ExportOptions:
    out_dir = str(body.get("out_dir") or "").strip()
    out = Path(out_dir).expanduser() if out_dir else app.root / "exports"
    if not out.is_absolute():
        raise ApiError(400, "Export folder must be an absolute path")
    proj = str(body.get("source_project_dir") or "").strip()
    max_mb = body.get("max_archive_mb")
    return ExportOptions(
        out_dir=out,
        since=parse_iso(body["since"]) if body.get("since") else None,
        until=parse_iso(body["until"]) if body.get("until") else None,
        source_ids=body.get("source_ids") or None,
        capture_ids=[int(x) for x in body["capture_ids"]] if body.get("capture_ids") else None,
        observations=[o for o in body.get("observations", []) if isinstance(o, dict)],
        source_project_dir=Path(proj).expanduser() if proj else None,
        convert_hoot=bool(body.get("convert_hoot")),
        max_archive_bytes=int(float(max_mb) * 1024 * 1024) if max_mb not in (None, "", 0) else None,
        package_label=(str(body.get("label")).strip()[:120] or None) if body.get("label") else None,
    )
