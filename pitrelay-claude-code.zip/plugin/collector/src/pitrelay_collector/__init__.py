"""PitRelay Collector: automatic, read-only collection of FRC robot diagnostic logs."""

__version__ = "0.1.0"

# Version of the exported ZIP package layout and manifest (see docs/PACKAGE_SCHEMA.md).
PACKAGE_SCHEMA = "pitrelay-collection"
PACKAGE_SCHEMA_VERSION = "1.0"
