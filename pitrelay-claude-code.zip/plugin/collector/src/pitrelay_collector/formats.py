"""Read-only format identification and structure checks for collected files.

These functions never modify data. They answer: what does the content (not
just the file extension) say this file is, which version, does its record
structure end cleanly or with an incomplete final record, and what original
clock information does it carry?

Format references (checked for this release; see docs/ROBOT_SETUP.md):

* WPILOG: WPILib Data Log File Format Specification 1.0, allwpilib v2026.2.2
  wpiutil/doc/datalog.adoc. AdvantageKit writes WPILOG with extra header
  "AdvantageKit" (AdvantageKit WPILOGConstants.extraHeader).
* NI Driver Station .dslog/.dsevents (legacy NI DS, 2010-2026): big-endian int32
  version (4 = current) followed by a LabVIEW timestamp; record layouts from
  AdvantageScope's DSLogReader/DSEventsReader (BSD-3-Clause).
* The newer FIRST Driver Station (2027 docs) writes .wpilog files, not .dslog.
* REV .revlog: record framing and version header from REV's own
  @rev-robotics/revlog-converter 2.0.0 (BSD-3-Clause). v2 files begin with record
  id 3 whose payload starts with "REVLOG" + major + minor; v1 (REVLib 2025
  through 2027.0.0-alpha-8) has no header record.
* CTRE .hoot: proprietary; no public specification was available. Only the byte
  at offset 70 is reported, labelled as AdvantageScope's "compliancy" heuristic.
"""

from __future__ import annotations

import codecs
import csv
import io
import struct
from collections import Counter
from pathlib import Path

from .util import printable, utc_iso

ANALYZER_VERSION = "2"  # 2: Driver Station files identified by their records, not their extension
BLOCK = 1024 * 1024
DEFAULT_MAX_SCAN_BYTES = 1024 * 1024 * 1024  # structure walk limit per file
LABVIEW_EPOCH_OFFSET = 2082844800  # seconds from 1904-01-01T00:00:00Z to 1970-01-01T00:00:00Z
MAX_ENTRY_LIST = 300

KNOWN_EXTENSIONS = {
    ".wpilog": "wpilog",
    ".revlog": "revlog",
    ".hoot": "hoot",
    ".dslog": "dslog",
    ".dsevents": "dsevents",
    ".csv": "csv",
}


def extension_of(name: str) -> str:
    dot = name.rfind(".")
    return name[dot:].lower() if dot > 0 else ""


class _Stream:
    """Sequential reader over the first `limit` bytes of a file with a sliding buffer."""

    def __init__(self, f, start: int, limit: int):
        self.f = f
        self.f.seek(start)
        self.pos = start  # absolute offset of buf[0]
        self.limit = limit
        self.read_to = start
        self.buf = b""
        self.eof = False

    def ensure(self, i: int, n: int) -> bool:
        """Make buf[i:i+n] available. Returns False if the data ends first."""
        while len(self.buf) - i < n:
            if self.read_to >= self.limit:
                self.eof = True
                return False
            want = min(max(BLOCK, n), self.limit - self.read_to)
            chunk = self.f.read(want)
            if not chunk:
                self.eof = True
                return False
            self.buf += chunk
            self.read_to += len(chunk)
        return True

    def consume(self, i: int) -> None:
        self.buf = self.buf[i:]
        self.pos += i

    def available(self, i: int) -> int:
        """Bytes from buf[i] to the scan limit (whether or not they are buffered yet)."""
        return self.limit - (self.pos + i)

    def skip(self, i: int, n: int) -> int:
        """Advance past n bytes starting at buf[i] without buffering them; returns the new index."""
        target = self.pos + i + n
        if target <= self.read_to:
            return i + n
        self.f.seek(target)
        self.buf, self.pos, self.read_to = b"", target, target
        return 0


def _result(ext, fmt, version=None, label=None):
    return {
        "analyzer_version": ANALYZER_VERSION,
        "extension": ext,
        "detected_format": fmt,
        "format_version": version,
        "label": label or fmt,
        "evidence": [],
        "extension_consistent": None,
        "structure": {"checked": False},
        "details": {},
        "original_clock": None,
        "producer_hint": None,
    }


# --- content checks (also used by PitRelay for Claude Code's host to explain engine results) ---------------

DS_CONTENT_BYTES = 49152
DS_EVENT_MAX_SKEW_S = 2 * 86400  # events in one dsevents file lie within its session


def revlog_header_version(head: bytes) -> tuple[int, int] | None:
    """(major, minor) when the data begins with a REVLOG header record (id 3, payload 'REVLOG' + major + minor)."""
    if not head:
        return None
    b = head[0]
    idl, szl = (b & 3) + 1, ((b >> 2) & 3) + 1
    hl = 1 + idl + szl
    if len(head) < hl:
        return None
    rid = int.from_bytes(head[1:1 + idl], "little")
    size = int.from_bytes(head[1 + idl:hl], "little")
    payload = head[hl:hl + size]
    if rid == 3 and len(payload) >= 8 and payload[:6] == b"REVLOG":
        return payload[6], payload[7]
    return None


def _printable_ratio(data: bytes) -> float:
    if not data:
        return 1.0
    text = data.decode("utf-8", "replace")
    return sum(1 for ch in text if ch.isprintable() or ch in "\t\r\n") / len(text)


def _dsevents_plausible(head: bytes, header_secs: int) -> bool | None:
    """Event records: LabVIEW time near the header's, a sane length, printable text. None: too short to tell."""
    i, complete = 20, 0
    while i + 20 <= len(head) and complete < 32:
        secs = struct.unpack_from(">q", head, i)[0]
        length = struct.unpack_from(">i", head, i + 16)[0]
        if abs(secs - header_secs) > DS_EVENT_MAX_SKEW_S or not 0 <= length <= 64 * 1024:
            return False
        if i + 20 + length > len(head):
            break
        if _printable_ratio(head[i + 20:i + 20 + length]) < 0.9:
            return False
        complete += 1
        i += 20 + length
    return True if complete else None


def _dslog_plausible(head: bytes) -> bool | None:
    """dslog v4 records: 10 telemetry bytes and a power-distribution header whose type byte (offset 13) selects 25
    (CTRE PDP) or 33 (REV PDH) more bytes, or none. A real log keeps one type. None: too short to tell."""
    i, types = 20, []
    while i + 14 <= len(head) and len(types) < 64:
        pd = head[i + 13]
        size = 14 + {33: 33, 25: 25}.get(pd, 0)
        if i + size > len(head):
            break
        types.append(pd)
        i += size
    if len(types) < 3 or not any(head[20:i]):
        return None  # all-zero records (a file cut short by a power loss) are damage, not evidence of a format
    return len(set(types)) == 1 and types[0] in (0, 25, 33)


def ds_content_format(head: bytes) -> str | None:
    """'dslog' or 'dsevents' when the v4 record structure of `head` clearly matches only that format, else None.

    Both formats share the same 20-byte header (version 4 and a LabVIEW time), so the extension or a format
    argument alone cannot tell them apart."""
    if len(head) < 20 or struct.unpack_from(">i", head, 0)[0] != 4:
        return None
    header_secs = struct.unpack_from(">q", head, 4)[0]
    events, log = _dsevents_plausible(head, header_secs), _dslog_plausible(head)
    if events is True and log is not True:
        return "dsevents"
    if log is True and events is False:
        return "dslog"
    return None


def analyze_file(path: Path, size: int, original_name: str, max_scan_bytes: int = DEFAULT_MAX_SCAN_BYTES) -> dict:
    """Identify the first `size` bytes of `path` (a collected capture)."""
    ext = extension_of(original_name)
    with open(path, "rb") as f:
        head = f.read(min(size, 128))
        if size == 0:
            r = _result(ext, "empty", label="empty file")
            r["evidence"].append("zero bytes captured")
            r["extension_consistent"] = None
            return r
        if head.startswith(b"WPILOG"):
            r = _scan_wpilog(f, size, ext, max_scan_bytes)
            r["extension_consistent"] = ext == ".wpilog"
            if ext != ".wpilog":
                r["evidence"].append(f"content is WPILOG although the extension is {ext or '(none)'}")
            return r
        if ext in (".dslog", ".dsevents"):
            f.seek(0)
            content = ds_content_format(f.read(min(size, DS_CONTENT_BYTES)))
            named = "dslog" if ext == ".dslog" else "dsevents"
            r = _scan_ds(f, size, ext, max_scan_bytes, kind=content or named)
            if content is not None and content != named:
                r["extension_consistent"] = False
                r["evidence"].append(f"the records have the {content} structure although the extension is {ext}")
            return r
        if ext == ".revlog":
            return _scan_revlog(f, size, ext, max_scan_bytes)
        if ext == ".hoot":
            return _scan_hoot(f, size, ext)
        if ext == ".csv":
            return _scan_text(f, size, ext, csv_mode=True)
        if ext == ".wpilog":
            r = _result(ext, "unknown", label="not WPILOG despite .wpilog extension")
            r["evidence"].append("missing 'WPILOG' signature at offset 0")
            r["extension_consistent"] = False
            return r
        return _scan_text(f, size, ext, csv_mode=False)


# --- WPILOG ---------------------------------------------------------------------


def _scan_wpilog(f, size, ext, max_scan_bytes) -> dict:
    r = _result(ext, "wpilog")
    r["evidence"].append("'WPILOG' signature at offset 0")
    st = r["structure"]
    f.seek(0)
    hdr = f.read(12)
    if len(hdr) < 12:
        r["label"] = "WPILOG (header incomplete)"
        st.update(checked=True, records=0, trailing_incomplete_bytes=size, issues=["file ends inside the 12-byte header"])
        return r
    version = struct.unpack_from("<H", hdr, 6)[0]
    extra_len = struct.unpack_from("<I", hdr, 8)[0]
    r["format_version"] = f"{version >> 8}.{version & 0xFF}"
    r["label"] = f"WPILOG {r['format_version']}"
    r["evidence"].append(f"version field 0x{version:04x}")
    if version != 0x0100:
        r["evidence"].append("only WPILOG 1.0 (0x0100) is specified; records were not walked")
        st.update(checked=False, issues=[f"unsupported WPILOG version 0x{version:04x}"])
        return r
    if 12 + extra_len > size:
        st.update(checked=True, records=0, trailing_incomplete_bytes=size - 12, issues=["file ends inside the extra header string"])
        return r
    extra = f.read(min(extra_len, 4096))
    extra_text = extra.decode("utf-8", errors="replace")
    r["details"]["extra_header"] = printable(extra_text, 200)
    if extra_text == "AdvantageKit":
        r["producer_hint"] = "AdvantageKit (WPILOG extra header is exactly 'AdvantageKit')"

    limit = min(size, max_scan_bytes)
    s = _Stream(f, 12 + extra_len, limit)
    records = data_records = 0
    control = Counter()
    active: dict[int, tuple[str, str]] = {}
    entry_list: list[dict] = []
    entries_started = 0
    types = Counter()
    ts_min = ts_max = None
    max_payload = 0
    unknown_id = 0
    spare_bits = 0
    issues: list[str] = []
    names_seen = set()
    i = 0
    trailing = 0
    stopped_early = False
    while True:
        if not s.ensure(i, 1):
            break
        b = s.buf[i]
        idl, szl, tsl = (b & 3) + 1, ((b >> 2) & 3) + 1, ((b >> 4) & 7) + 1
        if b & 0x80:
            spare_bits += 1
        hl = 1 + idl + szl + tsl
        if not s.ensure(i, hl):
            trailing = len(s.buf) - i
            break
        eid = int.from_bytes(s.buf[i + 1:i + 1 + idl], "little")
        psz = int.from_bytes(s.buf[i + 1 + idl:i + 1 + idl + szl], "little")
        ts = int.from_bytes(s.buf[i + 1 + idl + szl:i + hl], "little")
        total = hl + psz
        avail = s.available(i)
        if total > avail:
            # The declared payload runs past the end of the data: an incomplete final
            # record (or corruption). Never buffer a size we cannot satisfy.
            trailing = avail
            break
        records += 1
        max_payload = max(max_payload, psz)
        if eid != 0:
            data_records += 1
            if eid not in active:
                unknown_id += 1
            ts_min = ts if ts_min is None or ts < ts_min else ts_min
            ts_max = ts if ts_max is None or ts > ts_max else ts_max
            if psz > BLOCK:
                i = s.skip(i, total)  # large payload: seek past it without buffering
            else:
                s.ensure(i, total)  # satisfiable because total <= avail
                i += total
            if i > BLOCK:
                s.consume(i)
                i = 0
            continue
        if psz > 16 * 1024 * 1024:
            issues.append(f"implausible {psz}-byte control record at byte {s.pos + i}; walk stopped")
            stopped_early = True
            break
        s.ensure(i, total)
        payload = s.buf[i + hl:i + total]
        ctype = payload[0] if payload else None
        control[{0: "start", 1: "finish", 2: "set_metadata"}.get(ctype, "unknown")] += 1
        if ctype == 0 and len(payload) >= 17:
            try:
                target = struct.unpack_from("<I", payload, 1)[0]
                p = 5
                nl = struct.unpack_from("<I", payload, p)[0]; p += 4
                name = payload[p:p + nl].decode("utf-8", errors="replace"); p += nl
                tl = struct.unpack_from("<I", payload, p)[0]; p += 4
                tname = payload[p:p + tl].decode("utf-8", errors="replace"); p += tl
                if p + 4 > len(payload):
                    raise struct.error("short")
                active[target] = (name, tname)
                entries_started += 1
                types[tname] += 1
                if name not in names_seen:
                    names_seen.add(name)
                    if len(entry_list) < MAX_ENTRY_LIST:
                        entry_list.append({"name": printable(name, 200), "type": printable(tname, 60)})
            except (struct.error, IndexError):
                if len(issues) < 10:
                    issues.append(f"malformed start control record at byte {s.pos + i}")
        elif ctype == 1 and len(payload) >= 5:
            active.pop(struct.unpack_from("<I", payload, 1)[0], None)
        i += total
        if i > BLOCK:
            s.consume(i)
            i = 0
    scanned = s.pos + i
    st.update(
        checked=True,
        stopped_early=stopped_early,
        scanned_bytes=scanned + trailing,
        scan_limited=limit < size,
        records=records,
        data_records=data_records,
        control_records=dict(control),
        trailing_incomplete_bytes=trailing if limit >= size else None,
        issues=issues,
    )
    if trailing and limit >= size:
        st["issues"].append(f"final record incomplete: {trailing} trailing bytes after the last complete record")
    if limit < size:
        st["issues"].append(f"structure walk limited to the first {limit} of {size} bytes")
    if unknown_id:
        st["issues"].append(f"{unknown_id} data records reference an entry id with no active start record")
    if spare_bits:
        st["issues"].append(f"{spare_bits} records set the reserved header bit")
    r["details"].update(
        entries_started=entries_started,
        distinct_entry_names=len(names_seen),
        entry_types=dict(types.most_common(40)),
        entries=entry_list,
        entries_truncated=len(names_seen) > len(entry_list),
        max_record_payload_bytes=max_payload,
        has_systemTime_entry="systemTime" in names_seen,
    )
    r["original_clock"] = {
        "kind": "wpilog_record_timestamps_us",
        "first_data_timestamp_us": ts_min,
        "last_data_timestamp_us": ts_max,
        "note": "Integer microseconds in the log's own clock domain (on a roboRIO, the FPGA time since the robot program "
                "started). Not wall-clock time and not aligned with the collector computer's clock.",
    }
    if "systemTime" in names_seen:
        r["original_clock"]["note"] += " The log contains a 'systemTime' entry that DataLogManager uses to record the robot's " \
                                      "wall clock (only as accurate as the robot's clock)."
    return r


# --- NI Driver Station ------------------------------------------------------------


def _lv_clock(secs: int, frac: int) -> dict:
    return {
        "kind": "ni_ds_labview_header_time",
        "raw_labview_seconds": secs,
        "raw_labview_fraction_u64": str(frac),
        "interpreted_utc_if_labview_utc_epoch": utc_iso(secs - LABVIEW_EPOCH_OFFSET + frac / 2**64),
        "note": "Start time written by the Driver Station computer (its clock, not robot time). The interpretation assumes "
                "the LabVIEW 1904-01-01 UTC epoch; AdvantageScope's reader applies a different fixed offset, so treat the "
                "absolute time as uncertain and keep the raw value.",
    }


def _scan_ds(f, size, ext, max_scan_bytes, kind: str | None = None) -> dict:
    kind = kind or ("dslog" if ext == ".dslog" else "dsevents")
    r = _result(ext, kind)
    st = r["structure"]
    f.seek(0)
    hdr = f.read(20)
    if len(hdr) < 4:
        r["label"] = f"NI DS {kind} (header incomplete)"
        st.update(checked=True, records=0, trailing_incomplete_bytes=size, issues=["file ends inside the version field"])
        return r
    version = struct.unpack_from(">i", hdr, 0)[0]
    r["format_version"] = str(version)
    r["evidence"].append(f"big-endian version field = {version}")
    if version == 4:
        r["label"] = f"NI Driver Station {kind} v4"
        r["extension_consistent"] = True
    elif version == 3:
        r["label"] = f"legacy NI Driver Station {kind} v3"
        r["extension_consistent"] = True
        r["evidence"].append("version 3 predates the v4 layout; only v4 record layouts are walked")
        st.update(checked=False, issues=["version 3 layout not walked"])
        return r
    else:
        r["detected_format"] = "unknown"
        r["label"] = f"unrecognized content with {ext} extension"
        r["extension_consistent"] = False
        r["evidence"].append("version is not a known NI DS log version; this is not an NI DS v3/v4 file (it may come from a "
                             "different Driver Station implementation or be corrupt)")
        return r
    if len(hdr) < 20:
        st.update(checked=True, records=0, trailing_incomplete_bytes=size - 4, issues=["file ends inside the 20-byte header"])
        return r
    secs, frac = struct.unpack_from(">qQ", hdr, 4)
    r["original_clock"] = _lv_clock(secs, frac)
    limit = min(size, max_scan_bytes)
    s = _Stream(f, 20, limit)
    i = records = 0
    trailing = 0
    bad = False
    issues: list[str] = []
    if kind == "dslog":
        pd = Counter()
        while True:
            if not s.ensure(i, 1):
                break
            if not s.ensure(i, 14):
                trailing = len(s.buf) - i
                break
            pd_type = s.buf[i + 13]
            total = 14 + {33: 33, 25: 25}.get(pd_type, 0)
            if not s.ensure(i, total):
                trailing = len(s.buf) - i
                break
            pd[pd_type] += 1
            records += 1
            i += total
            if i > BLOCK:
                s.consume(i)
                i = 0
        if len(pd) > 1:
            issues.append("the power-distribution type byte varies between records; a real dslog v4 keeps one type, so "
                          "this may not be dslog data")
        r["details"]["power_distribution_type_bytes"] = {str(k): v for k, v in pd.most_common(8)}
        r["details"]["note"] = "Record count only; the collector does not decode DS telemetry values."
    else:
        while True:
            if not s.ensure(i, 1):
                break
            if not s.ensure(i, 20):
                trailing = len(s.buf) - i
                break
            length = struct.unpack_from(">i", s.buf, i + 16)[0]
            if length < 0 or length > 1024 * 1024:
                issues.append(f"implausible event text length {length} at byte {s.pos + i}; structure is not dsevents v4 here")
                bad = True
                break
            if not s.ensure(i, 20 + length):
                trailing = len(s.buf) - i
                break
            records += 1
            i += 20 + length
            if i > BLOCK:
                s.consume(i)
                i = 0
        if bad:
            r["extension_consistent"] = False
        r["details"]["note"] = "Event count only; event text is not copied into the manifest."
    st.update(checked=True, stopped_early=bad, scanned_bytes=s.pos + i + trailing, scan_limited=limit < size, records=records,
              trailing_incomplete_bytes=trailing if limit >= size else None, issues=issues)
    if trailing and limit >= size:
        st["issues"].append(f"final record incomplete: {trailing} trailing bytes")
    return r


# --- REV ---------------------------------------------------------------------------


def _scan_revlog(f, size, ext, max_scan_bytes) -> dict:
    r = _result(ext, "revlog", label="REV StatusLogger log (version undetermined)")
    st = r["structure"]
    limit = min(size, max_scan_bytes)
    s = _Stream(f, 0, limit)
    i = records = 0
    ids = Counter()
    first_id = None
    trailing = 0
    stopped_early = False
    issues: list[str] = []
    while True:
        if not s.ensure(i, 1):
            break
        b = s.buf[i]
        idl, szl = (b & 3) + 1, ((b >> 2) & 3) + 1
        hl = 1 + idl + szl
        if not s.ensure(i, hl):
            trailing = len(s.buf) - i
            break
        eid = int.from_bytes(s.buf[i + 1:i + 1 + idl], "little")
        psz = int.from_bytes(s.buf[i + 1 + idl:i + hl], "little")
        if psz > 5 * 1024 * 1024:
            issues.append(f"implausible payload size {psz} at byte {s.pos + i} (REV's converter rejects > 5 MiB)")
            stopped_early = True
            break
        if not s.ensure(i, hl + psz):
            trailing = len(s.buf) - i
            break
        if first_id is None:
            first_id = eid
            payload = s.buf[i + hl:i + hl + psz]
            if eid == 3 and payload[:6] == b"REVLOG" and len(payload) >= 8:
                r["format_version"] = f"{payload[6]}.{payload[7]}"
                r["label"] = f"REVLOG v{r['format_version']}"
                r["evidence"].append("first record is a header record (id 3) beginning with 'REVLOG'")
            elif eid in (1, 2):
                r["format_version"] = "1"
                r["label"] = "REVLOG v1 (inferred)"
                r["evidence"].append("no header record; first record id is a v1 record type (REVLib 2025 to 2027.0.0-alpha-8 "
                                     "per REV's converter)")
            else:
                r["evidence"].append(f"first record id {eid} matches neither the v1 nor v2 framing")
        ids[eid] += 1
        records += 1
        i += hl + psz
        if i > BLOCK:
            s.consume(i)
            i = 0
    r["extension_consistent"] = r["format_version"] is not None
    st.update(checked=True, stopped_early=stopped_early, scanned_bytes=s.pos + i + trailing, scan_limited=limit < size, records=records,
              trailing_incomplete_bytes=trailing if limit >= size else None, issues=issues)
    if trailing and limit >= size:
        st["issues"].append(f"final record incomplete: {trailing} trailing bytes")
    r["details"]["record_ids"] = {str(k): v for k, v in ids.most_common(12)}
    r["original_clock"] = {"kind": "revlog_internal", "note": "REVLOG timestamps are inside record payloads and are not decoded by the collector."}
    return r


# --- CTRE --------------------------------------------------------------------------


def _scan_hoot(f, size, ext) -> dict:
    r = _result(ext, "hoot", label="CTRE hoot (format not independently verified)")
    r["evidence"].append("identified by extension only; no public CTRE hoot specification was available to the collector")
    if size >= 71:
        f.seek(70)
        r["details"]["byte_at_offset_70"] = f.read(1)[0]
        r["details"]["byte_at_offset_70_note"] = (
            "AdvantageScope reads this byte as the hoot 'compliancy' to choose a matching Owlet build (and treats values "
            "below 6 as pre-2024). This is a third-party heuristic, not a CTRE specification.")
    r["original_clock"] = {"kind": "hoot_internal", "note": "Not decoded by the collector; CTRE logs carry CAN timestamps internally."}
    return r


# --- text / CSV ----------------------------------------------------------------------


def _scan_text(f, size, ext, csv_mode: bool) -> dict:
    f.seek(0)
    sample = f.read(min(size, 65536))
    decoder = codecs.getincrementaldecoder("utf-8")()
    try:
        text = decoder.decode(sample, final=len(sample) == size)
        utf8 = True
    except UnicodeDecodeError:
        utf8 = False
        text = ""
    if csv_mode:
        r = _result(ext, "csv", label="CSV text")
        if not utf8:
            r["label"] = "CSV extension, not UTF-8 text"
            r["extension_consistent"] = False
            r["evidence"].append("first 64 KiB are not valid UTF-8")
            return r
        first_line = text.lstrip("﻿").splitlines()[0] if text.strip() else ""
        try:
            header = next(csv.reader(io.StringIO(first_line))) if first_line else []
        except csv.Error:
            header = []
        r["details"]["header_columns"] = [printable(h, 80) for h in header[:50]]
        r["details"]["column_count"] = len(header)
        r["extension_consistent"] = len(header) >= 1
        r["evidence"].append("UTF-8 text; first line parsed as a CSV header")
        r["original_clock"] = {"kind": "csv_columns", "note": "Time columns and units are not inferred; mappings must be supplied explicitly."}
        return r
    if utf8 and "\x00" not in text:
        r = _result(ext, "text", label="UTF-8 text")
        r["details"]["approx_lines_in_first_64KiB"] = text.count("\n")
        r["evidence"].append("valid UTF-8 without NUL bytes in the first 64 KiB")
        return r
    r = _result(ext, "unknown", label="unrecognized binary content")
    r["evidence"].append("not WPILOG and not UTF-8 text")
    return r


def structure_complete(info: dict) -> bool | None:
    """True if the structure walk reached EOF cleanly, False if it found a problem, None if not walked."""
    st = info.get("structure") or {}
    if not st.get("checked") or st.get("scan_limited"):
        return None
    if st.get("trailing_incomplete_bytes") or st.get("stopped_early"):
        return False
    return True
