"""Export selected captures as a verified, ordinary ZIP package for PitRelay.

Steps:
1. Snapshot the catalog (one read transaction): which captures, and exactly how
   many committed bytes of each. Collection may keep appending meanwhile;
   committed bytes never change, so the snapshot prefix is stable.
2. Optionally run a user-installed CTRE Owlet on .hoot captures (derived files).
3. Stream original bytes into a temporary ZIP, re-verifying every stored
   segment's SHA-256 on the way (detects local store corruption).
4. Write manifest.json, collection-status.json, observations.json, README.txt.
5. Re-open the ZIP and verify inventory, sizes and every hash.
6. Atomically rename into place. Only then is the export reported successful.

The package is private and not anonymized. Nothing is uploaded anywhere.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from . import PACKAGE_SCHEMA, PACKAGE_SCHEMA_VERSION, __version__, compat, formats, projectscan
from .config import CollectorConfig
from .package import MANIFEST, ROOT, verify_package
from .store import Store
from .util import fsync_dir, human_bytes, printable, safe_component, utc_iso

METADATA_ALLOWANCE = 256 * 1024  # manifest, status, observations and README per archive (generous)
READ_BLOCK = 1024 * 1024


class ExportError(RuntimeError):
    pass


@dataclass
class ExportOptions:
    out_dir: Path
    since: float | None = None  # collector-clock range [since, until)
    until: float | None = None
    source_ids: list[str] | None = None
    capture_ids: list[int] | None = None
    observations: list[dict] = field(default_factory=list)
    source_project_dir: Path | None = None
    convert_hoot: bool = False
    max_archive_bytes: int | None = None
    package_label: str | None = None
    name_prefix: str = "pitrelay-collection"


@dataclass
class ExportResult:
    ok: bool
    archives: list[dict] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    error: str | None = None


# --- selection --------------------------------------------------------------------------


def _overlaps(cap: dict, since: float | None, until: float | None) -> bool:
    # Activity = when the recording was first seen or was changing/being acquired. A file that merely
    # stays on the robot unchanged is not "active" in later ranges.
    start = cap["first_seen"]
    end = max(cap["last_change"], cap["last_acquired"] or 0.0)
    if since is not None and end < since:
        return False
    if until is not None and start >= until:
        return False
    return True


def _select(store: Store, opts: ExportOptions):
    with store.snapshot() as c:
        all_caps = store.captures(include_deleted=True, conn=c)
        segs = {}
        chosen, deleted, not_selected = [], [], 0
        for cap in all_caps:
            in_scope = (opts.source_ids is None or cap["source_id"] in opts.source_ids) and _overlaps(cap, opts.since, opts.until)
            if opts.capture_ids is not None:
                in_scope = cap["id"] in opts.capture_ids
            if cap["deleted_at"] is not None:
                if in_scope:
                    deleted.append(cap)
                continue
            if not in_scope:
                not_selected += 1
                continue
            chosen.append(cap)
            segs[cap["id"]] = store.segments(cap["id"], upto=cap["committed_size"], conn=c)
        sources = store.known_sources()
    return chosen, segs, deleted, not_selected, sources


# --- archive naming -------------------------------------------------------------------


def _assign_paths(caps: list[dict], source_keys: dict[str, str]) -> dict[int, str]:
    paths: dict[int, str] = {}
    used: set[str] = set()
    for cap in sorted(caps, key=lambda c: (source_keys[c["source_id"]], c["first_seen"], c["id"])):
        base = cap["path"].replace("\\", "/").rsplit("/", 1)[-1]
        name = safe_component(base, fallback=f"capture-{cap['id']}")
        folder = f"logs/{source_keys[cap['source_id']]}"
        candidate = f"{folder}/{name}"
        if candidate.casefold() in used:
            stem, dot, ext = name.rpartition(".")
            if not dot:
                stem, ext = name, ""
            suffix = f".{ext}" if ext else ""
            candidate = f"{folder}/{stem}__c{cap['id']}{suffix}"
            n = 2
            while candidate.casefold() in used:  # the generated name can itself be taken (e.g. logs re-collected from a package)
                candidate = f"{folder}/{stem}__c{cap['id']}-{n}{suffix}"
                n += 1
        used.add(candidate.casefold())
        paths[cap["id"]] = candidate
    return paths


# --- derived conversions (optional, user-installed Owlet) ----------------------------


def _owlet_identity(owlet: str) -> dict:
    info = {"name": "CTRE Owlet (user-installed; not bundled)", "executable_name": Path(owlet).name}
    try:
        with open(owlet, "rb") as f:
            info["executable_sha256"] = hashlib.file_digest(f, "sha256").hexdigest() if hasattr(hashlib, "file_digest") \
                else hashlib.sha256(f.read()).hexdigest()
    except OSError as e:
        info["executable_sha256"] = None
        info["error"] = f"cannot read executable: {e.__class__.__name__}"
    try:
        out = subprocess.run([owlet, "--version"], capture_output=True, text=True, timeout=30)
        info["version_output"] = printable((out.stdout or out.stderr).strip().splitlines()[0] if (out.stdout or out.stderr).strip() else "", 200)
    except (OSError, subprocess.SubprocessError) as e:
        info["version_output"] = None
        info["version_error"] = e.__class__.__name__
    return info


def _convert_hoot(store: Store, cap: dict, owlet: str, workdir: Path, expected_sha: str) -> dict:
    """Run Owlet on an exact copy of the captured prefix. Never runs anything else."""
    src = workdir / f"c{cap['id']}.hoot"
    out = workdir / f"c{cap['id']}.owlet.wpilog"
    with open(store.data_path(cap), "rb") as f, open(src, "wb") as g:
        remaining = cap["committed_size"]
        h = hashlib.sha256()
        while remaining:
            block = f.read(min(READ_BLOCK, remaining))
            if not block:
                break
            h.update(block)
            g.write(block)
            remaining -= len(block)
    if h.hexdigest() != expected_sha:
        return {"ok": False, "reason": "captured bytes changed before conversion"}
    args = [str(src.name), str(out.name), "-f", "wpilog"]
    try:
        proc = subprocess.run([owlet, *args], cwd=str(workdir), capture_output=True, text=True, timeout=600)
    except (OSError, subprocess.SubprocessError) as e:
        return {"ok": False, "reason": f"Owlet could not run: {e.__class__.__name__}: {printable(str(e), 200)}"}
    result = {"exit_code": proc.returncode, "stderr_tail": printable((proc.stderr or "")[-500:], 500),
              "parameters": ["<input.hoot>", "<output.wpilog>", "-f", "wpilog"]}
    if proc.returncode != 0 or not out.exists() or out.stat().st_size == 0:
        return {"ok": False, "reason": "Owlet did not produce a WPILOG (license, compliancy/version mismatch or bad input)", **result}
    return {"ok": True, "path": out, **result}


# --- documents --------------------------------------------------------------------------


def _capture_number(value) -> int | None:
    """Accept 7, "7" or "cap-000007" (the form used in observations.json); anything else is ignored."""
    text = str(value).strip()
    if text.lower().startswith("cap-"):
        text = text[4:]
    return int(text) if text.isascii() and text.isdigit() else None


def _normalize_observations(observations: list[dict], now: float, capture_ids: set[int]) -> list[dict]:
    out = []
    for i, o in enumerate(observations, 1):
        if not isinstance(o, dict):
            continue
        text = str(o.get("text", "")).strip()
        if not text:
            continue
        related = [x for x in (_capture_number(v) for v in o.get("related_capture_ids") or []) if x in capture_ids]
        out.append({
            "id": f"obs-{i:03d}",
            "author": printable(str(o.get("author", "")).strip(), 100) or None,
            "recorded_at_utc": o.get("recorded_at_utc") or utc_iso(now),
            "observed_time_as_stated": printable(str(o.get("observed_time_as_stated", "")).strip(), 200) or None,
            "related_capture_ids": [f"cap-{x:06d}" for x in related],
            "text": text[:10000],
        })
    return out


def build_collection_status(store: Store, cfg: CollectorConfig | None, since, until, sources, source_keys,
                            collector_state: dict | None) -> dict:
    rows = []
    for s in sources:
        st = store.get_source_state(s["source_id"]) or {}
        avail = [a for a in store.availability(s["source_id"])
                 if (until is None or a["start"] < until) and (since is None or (a["end"] or time.time()) >= since)]
        rows.append({
            "source_key": source_keys.get(s["source_id"]),
            "alias": s["alias"],
            "kind": s["kind"],
            "role": s["role"],
            "removed_from_configuration_utc": utc_iso(s["removed_at"]),
            "state_at_export": st.get("state", "never_polled"),
            "state_since_utc": utc_iso(st.get("since")),
            "last_successful_collection_utc": utc_iso(st.get("last_success")),
            "last_error": st.get("last_error"),
            "directories": st.get("dirs"),
            "observed_available_intervals_utc": [[utc_iso(a["start"]), utc_iso(a["end"])] for a in avail],
        })
    runs = [{"started_utc": utc_iso(r["started"]), "ended_utc": utc_iso(r["ended"]), "last_heartbeat_utc": utc_iso(r["heartbeat"])}
            for r in store.runs() if (until is None or r["started"] < until) and (since is None or (r["ended"] or r["heartbeat"]) >= since)]
    events = store.events(since=since, until=until, min_level="info", limit=1000)
    total_events = store.event_count(since=since, until=until, min_level="info")
    return {
        "schema": "pitrelay-collection-status",
        "schema_version": "1.0",
        "clock": "All times are the collector computer's clock (UTC). They are not robot time.",
        "interval_convention": "[start, end); end null means ongoing at export time",
        "collector_state_at_export": collector_state,
        "collector_runs": runs,
        "sources": rows,
        "storage": {
            "usage_bytes": store.usage_bytes,
            "quota_bytes": cfg.quota_bytes if cfg else None,
            "min_free_bytes": cfg.min_free_bytes if cfg else None,
            "retention_policy": "Captures are kept until the user explicitly deletes them. Reaching the quota stops new "
                                "transfers and raises an alert; nothing is deleted automatically. Remote files are never "
                                "deleted or modified.",
        },
        "events": [{"t_utc": utc_iso(e["t"]), "level": e["level"], "kind": e["kind"], "message": e["message"],
                    "source_key": source_keys.get(e["source_id"]), "capture_id": f"cap-{e['capture_id']:06d}" if e["capture_id"] else None}
                   for e in reversed(events)],
        "events_total": total_events,
        "events_truncated": total_events > len(events),
        "gaps_note": "Periods outside 'observed_available_intervals_utc' and outside collector runs were not observed: files "
                     "created and removed entirely within those periods cannot appear in this package.",
    }


def _readme(manifest: dict, label: str | None) -> str:
    caps = manifest["captures"]
    lines = [
        "PITRELAY COLLECTOR PACKAGE",
        "==========================",
        "",
    ]
    if label:
        lines += [f"*** {label} ***", ""]
    lines += [
        f"Created (collector clock, UTC): {manifest['package']['created_at_utc']}",
        f"Collector version: {manifest['collector']['version']}    Package schema: {manifest['schema']} {manifest['schema_version']}",
        "",
        "This is a PRIVATE analysis package. It contains original log bytes exactly as collected and is NOT anonymized or",
        "sanitized. Share it only with people allowed to see this team's data. Nothing was uploaded anywhere.",
        "",
        "LAYOUT",
        "  manifest.json            every file, its SHA-256, status, format and PitRelay route",
        "  collection-status.json   source availability, errors, gaps and storage at export time",
        "  observations.json        optional user observations (attributed statements, not measurements)",
        "  logs/source-NNN/         original bytes, one folder per collection source",
        "  derived/                 optional conversions, each linked to its original by hash",
        "  source/                  optional selected robot source files (never executed)",
        "",
        "CHECK IT:  pitrelay-collector verify <this zip>",
        "USE IT:    pitrelay-collector extract <this zip> <folder>   (then see docs/PITRELAY_HANDOFF.md)",
        "",
        "CAPTURES",
    ]
    for c in caps:
        lines.append(f"  {c['capture_id']}  {c['acquisition']['status']:<9} {c['format']['label'][:34]:<34} "
                     f"{human_bytes(c['size_bytes']):>10}  {c['archive_path']}")
    if not caps:
        lines.append("  (none)")
    lines += [
        "",
        "STATUS MEANINGS",
        "  active     changed recently; the bytes here are an identified prefix of a file still being written",
        "  idle       unchanged recently, but completion has not been established",
        "  complete   unchanged for a long connected observation (or across a reconnect with a newer file), all observed",
        "             bytes captured and, where checkable, the record structure ends cleanly. A file that was complete",
        "             stays complete if it is later removed or replaced at the source (see presence_at_source)",
        "  partial    some observed bytes were never captured, or the final record is incomplete",
        "  uncertain  the source file was removed/replaced before completion was established, changed during",
        "             transfer, or its local copy failed an integrity check; see the reasons",
        "",
        "LIMITATIONS",
        "  * A SHA-256 proves these bytes are the ones collected; it does not prove the robot's recording was complete.",
        "  * Robot timestamps, Driver Station clocks and the collector's clock are different clocks. No alignment is implied.",
        "  * Same-named files from different sources are kept apart by source folder; names were made filesystem-safe and",
        "    the exact original names are in manifest.json.",
    ]
    for lim in manifest.get("limitations", []):
        lines.append(f"  * {lim}")
    return "\n".join(lines) + "\n"


# --- writing ----------------------------------------------------------------------------


def _zip_info(name: str, ts: float | None) -> zipfile.ZipInfo:
    tm = time.gmtime(max(ts or time.time(), 315532800))  # ZIP times cannot precede 1980
    info = zipfile.ZipInfo(f"{ROOT}/{name}", date_time=tm[:6])
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    return info


def _write_bytes(zf: zipfile.ZipFile, name: str, data: bytes, ts: float) -> dict:
    zf.writestr(_zip_info(name, ts), data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    return {"archive_path": name, "size_bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def _stream_capture(zf: zipfile.ZipFile, name: str, store: Store, cap: dict, segs: list[dict], size: int) -> str:
    """Copy [0, size) of a capture into the ZIP while re-verifying stored segment hashes."""
    if sum(s["length"] for s in segs) != size:
        raise ExportError(f"capture {cap['id']}: segment inventory does not cover the snapshot size")
    whole = hashlib.sha256()
    info = _zip_info(name, cap["last_acquired"] or cap["first_seen"])
    with open(store.data_path(cap), "rb") as f, zf.open(info, "w", force_zip64=True) as out:
        expected_offset = 0
        for seg in segs:
            if seg["offset"] != expected_offset:
                raise ExportError(f"capture {cap['id']}: segments are not contiguous at offset {expected_offset}")
            f.seek(seg["offset"])
            h = hashlib.sha256()
            remaining = seg["length"]
            while remaining:
                block = f.read(min(READ_BLOCK, remaining))
                if not block:
                    raise ExportError(f"capture {cap['id']}: store file is shorter than its committed size")
                h.update(block)
                whole.update(block)
                out.write(block)
                remaining -= len(block)
            if h.hexdigest() != seg["sha256"]:
                raise ExportError(f"capture {cap['id']} segment {seg['seq']}: stored bytes no longer match the SHA-256 "
                                  "recorded when they were collected (local store corruption). Deselect it and investigate.")
            expected_offset += seg["length"]
    return whole.hexdigest()


def _archive_names(out_dir: Path, base: str, count: int) -> list[Path]:
    """Names for one export set. A random token shared by all parts keeps concurrent exports apart."""
    while True:
        token = uuid.uuid4().hex[:6]
        names = [out_dir / (f"{base}-{token}" + (f"-part{i}of{count}" if count > 1 else "") + ".zip")
                 for i in range(1, count + 1)]
        if not any(n.exists() for n in names):
            return names


def sweep_interrupted(store: Store, out_dir: Path) -> list[str]:
    """Remove what an export killed mid-way left in out_dir (its work folder and unverified partial archive).

    Only when no export runs in any process: the store's readers lock is taken exclusively without waiting."""
    from .lock import ExportsBusy
    removed: list[str] = []
    out_dir = Path(out_dir)
    if not out_dir.is_dir():
        return removed
    try:
        with store.readers_lock.exclusive(timeout=0):
            for p in out_dir.iterdir():
                if p.name.startswith(".pitrelay-export-") and p.is_dir() and not p.is_symlink():
                    shutil.rmtree(p, ignore_errors=True)
                    removed.append(p.name)
                elif p.name.startswith(".") and ".partial-" in p.name and p.is_file() and not p.is_symlink():
                    try:
                        p.unlink()
                        removed.append(p.name)
                    except OSError:
                        pass
    except ExportsBusy:
        pass
    return removed


def export_package(store: Store, cfg: CollectorConfig | None, opts: ExportOptions, collector_state: dict | None = None,
                   clock_now: float | None = None) -> ExportResult:
    result = ExportResult(ok=False)
    out_dir = Path(opts.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    now = clock_now if clock_now is not None else store.clock.time()
    workdir = Path(tempfile.mkdtemp(prefix=".pitrelay-export-", dir=str(out_dir)))
    partials: list[Path] = []
    try:
        with store.export_guard():
            return _export(store, cfg, opts, collector_state, now, out_dir, workdir, partials, result)
    except (ExportError, OSError, zipfile.BadZipFile, ValueError) as e:
        result.ok = False
        result.error = f"{e.__class__.__name__}: {e}" if not isinstance(e, ExportError) else str(e)
        for p in partials:
            try:
                p.unlink()
            except FileNotFoundError:
                pass
        if store.owner:
            store.add_event("error", "export_failed", f"Export failed and no package was produced: {result.error}")
        return result
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def _export(store, cfg, opts, collector_state, now, out_dir, workdir, partials, result):
    caps, segs, deleted, not_selected, sources = _select(store, opts)
    # A source added from the CLI may not be in the catalog yet; describe it from the configuration.
    known = {s["source_id"] for s in sources}
    for sid in sorted({c["source_id"] for c in caps} - known):
        sc = cfg.source_by_id(sid) if cfg is not None else None
        sources.append({"source_id": sid, "alias": sc.alias if sc else sid, "kind": sc.kind if sc else "unknown",
                        "role": sc.role if sc else None, "removed_at": None if sc else now,
                        "public": sc.public_dict() if sc else {}})
    source_keys = {s["source_id"]: f"source-{i:03d}" for i, s in enumerate(sources, 1)}
    for cap in caps:
        source_keys.setdefault(cap["source_id"], f"source-{len(source_keys) + 1:03d}")
    omissions: list[dict] = []
    if not_selected:
        omissions.append({"kind": "not_selected", "count": not_selected,
                          "reason": "outside the selected date range, sources or capture list"})
    for d in deleted:
        omissions.append({"kind": "deleted_by_user", "capture_id": f"cap-{d['id']:06d}", "original_filename": d["original_name"],
                          "size_bytes": d["committed_size"], "sha256": d["flags"].get("deleted_sha256"),
                          "deleted_at_utc": utc_iso(d["deleted_at"]), "note": d["deleted_note"]})
    exportable = []
    for cap in caps:
        if cap["error"] and cap["error"].startswith("store integrity"):
            omissions.append({"kind": "store_integrity_failure", "capture_id": f"cap-{cap['id']:06d}",
                              "original_filename": cap["original_name"], "reason": cap["error"]})
            result.warnings.append(f"capture {cap['id']} excluded: {cap['error']}")
        elif cap["committed_size"] == 0 and cap["max_observed_size"] > 0:
            omissions.append({"kind": "no_bytes_captured", "capture_id": f"cap-{cap['id']:06d}",
                              "original_filename": cap["original_name"], "observed_size_bytes": cap["max_observed_size"],
                              "reason": cap["error"] or "; ".join(cap["status_reasons"]) or "not yet transferred"})
        else:
            exportable.append(cap)
    caps = exportable
    paths = _assign_paths(caps, source_keys)
    entries: dict[int, dict] = {}
    for cap in caps:
        size = cap["committed_size"]
        info = store.format_cache_get(cap["id"], size)
        if info is None:
            info = formats.analyze_file(store.data_path(cap), size, cap["original_name"])
            store.format_cache_put(cap["id"], size, info)
        entries[cap["id"]] = {"cap": cap, "size": size, "format": info}

    derived_by_cap: dict[int, dict] = {}
    converter = None
    hoots = [e for e in entries.values() if e["format"]["detected_format"] == "hoot"]
    if opts.convert_hoot and hoots:
        owlet = cfg.owlet_path if cfg else None
        if not owlet or not Path(owlet).is_file():
            result.warnings.append("Hoot conversion requested but no Owlet executable is configured; hoot files are included as "
                                   "collected with conversion unavailable.")
        else:
            converter = _owlet_identity(owlet)
            for e in hoots:
                # Hash of the exact prefix that will be exported; _convert_hoot re-checks its copy against it.
                sha = hashlib.sha256()
                with open(store.data_path(e["cap"]), "rb") as f:
                    remaining = e["size"]
                    while remaining:
                        block = f.read(min(READ_BLOCK, remaining))
                        if not block:
                            break
                        sha.update(block)
                        remaining -= len(block)
                conv = _convert_hoot(store, e["cap"], owlet, workdir, sha.hexdigest())
                conv["source_sha256"] = sha.hexdigest()
                derived_by_cap[e["cap"]["id"]] = conv
                if not conv["ok"]:
                    result.warnings.append(f"capture {e['cap']['id']}: hoot conversion failed: {conv['reason']}")

    # Partition into archives (never splitting a file).
    def weight(cid):
        d = derived_by_cap.get(cid)
        return entries[cid]["size"] + (d["path"].stat().st_size if d and d.get("ok") else 0)

    order = [c["id"] for c in sorted(caps, key=lambda c: (source_keys[c["source_id"]], c["first_seen"], c["id"]))]
    source_files, source_excluded = ([], [])
    if opts.source_project_dir:
        source_files, source_excluded = projectscan.select_source_files(Path(opts.source_project_dir))
    parts: list[list[int]] = [[]]
    if opts.max_archive_bytes:
        # Part 1 also carries the selected source code; every part carries the manifest and status files.
        used = sum(f["size"] for f in source_files) + METADATA_ALLOWANCE
        for cid in order:
            w = weight(cid)
            if parts[-1] and used + w > opts.max_archive_bytes:
                parts.append([])
                used = METADATA_ALLOWANCE
            parts[-1].append(cid)
            used += w
    else:
        parts[0] = order
    set_id = str(uuid.uuid4())
    base = f"{opts.name_prefix}-{time.strftime('%Y%m%d-%H%M%SZ', time.gmtime(now))}"
    observations = _normalize_observations(opts.observations, now, {c["id"] for c in caps})
    status_doc = build_collection_status(store, cfg, opts.since, opts.until, sources, source_keys, collector_state)
    inventory = [{"capture_id": f"cap-{cid:06d}", "part": i + 1} for i, part in enumerate(parts) for cid in part]

    final_paths = []
    names = _archive_names(out_dir, base, len(parts))
    for index, part in enumerate(parts, 1):
        final = names[index - 1]
        partial = out_dir / f".{final.name}.partial-{uuid.uuid4().hex[:8]}"
        partials.append(partial)
        manifest = _write_archive(partial, store, cfg, opts, now, entries, segs, part, paths, source_keys, sources,
                                  derived_by_cap, converter, omissions, observations, status_doc,
                                  source_files if index == 1 else [], source_excluded if index == 1 else [],
                                  {"set_id": set_id, "index": index, "count": len(parts), "inventory": inventory} if len(parts) > 1 else None,
                                  opts.max_archive_bytes)
        report = verify_package(partial)
        if not report["ok"]:
            raise ExportError("Verification of the written package failed: " + "; ".join(report["errors"][:5]))
        size = partial.stat().st_size
        if opts.max_archive_bytes and size > opts.max_archive_bytes:
            why = ("it holds a single capture larger than the limit (files are never split)" if len(part) == 1
                   and weight(part[0]) > opts.max_archive_bytes - METADATA_ALLOWANCE else
                   "the selected source code and package metadata did not fit beside its captures")
            result.warnings.append(f"{final.name} is {human_bytes(size)}, more than the requested "
                                   f"{human_bytes(opts.max_archive_bytes)}: {why}")
        final_paths.append((partial, final, manifest, report))
    placed: list[Path] = []
    try:
        for partial, final, manifest, report in final_paths:
            h = hashlib.sha256()
            with open(partial, "r+b") as f:  # writable handle: Windows cannot fsync a read-only one
                os.fsync(f.fileno())
                for block in iter(lambda: f.read(READ_BLOCK), b""):
                    h.update(block)
            digest = h.hexdigest()
            if final.exists():
                raise ExportError(f"{final} appeared while exporting; refusing to overwrite it")
            os.replace(partial, final)
            partials.remove(partial)
            placed.append(final)
            sidecar = final.parent / (final.name + ".sha256")
            sidecar.write_text(f"{digest}  {final.name}\n", encoding="utf-8")
            placed.append(sidecar)
            fsync_dir(final.parent)
            result.archives.append({"path": str(final), "sha256": digest, "size_bytes": final.stat().st_size,
                                    "captures": len(manifest["captures"]), "verified_files": report["files_checked"],
                                    "verified_bytes": report["bytes_checked"], "part": manifest["package"]["part"]})
    except BaseException:
        # A multi-part set is all or nothing: remove parts already placed so no incomplete set remains.
        for p in placed:
            try:
                p.unlink()
            except FileNotFoundError:
                pass
        result.archives = []
        raise
    if store.owner:
        for a in result.archives:
            store.add_event("info", "export_completed", f"Exported and verified {Path(a['path']).name} ({a['captures']} "
                            f"captures, SHA-256 {a['sha256'][:16]}...)", data={"path": a["path"], "sha256": a["sha256"]})
    result.ok = True
    return result


def _write_archive(path, store, cfg, opts, now, entries, segs, part, paths, source_keys, sources, derived_by_cap,
                   converter, omissions, observations, status_doc, source_files, source_excluded, part_info, max_bytes):
    captures_out = []
    derived_out = []
    sha_by_cap: dict[int, str] = {}
    with zipfile.ZipFile(path, "w", allowZip64=True) as zf:
        for cid in part:
            e = entries[cid]
            cap, size = e["cap"], e["size"]
            name = paths[cid]
            digest = _stream_capture(zf, name, store, cap, segs[cid], size)
            sha_by_cap[cid] = digest
            route = compat.pitrelay_route(e["format"], size)
            if max_bytes and size > max_bytes:
                route["limitations"] = route["limitations"] + [f"larger than the requested archive size limit; placed alone in its own archive"]
            entry = {
                "capture_id": f"cap-{cid:06d}",
                "source_key": source_keys[cap["source_id"]],
                "archive_path": name,
                "original_filename": cap["path"].replace("\\", "/").rsplit("/", 1)[-1],
                "original_path": cap["path"],
                "name_history": [{"path": n["path"], "first_seen_utc": utc_iso(n["first_seen"])} for n in cap["names"]],
                "size_bytes": size,
                "sha256": digest,
                "acquisition": {
                    "status": cap["status"],
                    "status_reasons": cap["status_reasons"],
                    "snapshot": _snapshot_text(cap),
                    "captured_bytes": size,
                    "last_observed_source_bytes": cap["observed_size"],
                    "max_observed_source_bytes": cap["max_observed_size"],
                    "unrecovered_gap_bytes": max(0, cap["max_observed_size"] - cap["committed_size"]) if cap["presence"] != "present" else 0,
                    "pending_bytes_at_source": max(0, cap["observed_size"] - cap["committed_size"]) if cap["presence"] == "present" else 0,
                    "presence_at_source": cap["presence"],
                    "first_seen_utc": utc_iso(cap["first_seen"]),
                    "last_seen_utc": utc_iso(cap["last_seen"]),
                    "no_longer_at_path_since_utc": utc_iso(cap["missing_since"]),
                    "first_acquired_utc": utc_iso(cap["first_acquired"]),
                    "last_acquired_utc": utc_iso(cap["last_acquired"]),
                    "quiet_observed_s": round(cap["quiet_s"], 1),
                    "source_reported_mtime_utc": utc_iso(cap["observed_mtime"]),
                    "segments": len(segs[cid]),
                    "consistency_checks": {
                        "performed": cap["checks"]["counts"],
                        "performed_key_format": "<check>:<result>; post_chunk_head:match and segment_sha256:recorded count "
                                                "committed segments; pre_transfer_head appears only on a mismatch",
                        "segment_sha256": "each committed segment was hashed at acquisition and re-verified during this export",
                        "per_chunk": "before each chunk was committed, the file's first bytes were re-read through the same open "
                                     "handle and matched",
                        "meaning": "Hashes prove these bytes are the collected bytes. Prefix re-checks sample the source; they do "
                                   "not prove the source recording was complete or unchanged everywhere.",
                    },
                    "transfer_flags": {k: v for k, v in cap["flags"].items() if k == "inconsistent_transfer"},
                    "last_error": cap["error"],
                },
                "format": e["format"],
                "original_clock": e["format"].get("original_clock"),
                "relationships": [],
                "pitrelay": route,
            }
            if cap["predecessor_id"]:
                entry["relationships"].append({"type": "same_path_successor_of", "capture_id": f"cap-{cap['predecessor_id']:06d}",
                                               "meaning": "this content later appeared at the same path; the earlier capture is preserved"})
            if len(cap["names"]) > 1:
                entry["relationships"].append({"type": "renamed_while_collected", "meaning": "content continuity was verified "
                                               "by re-reading captured bytes at the new path", "names": [n["path"] for n in cap["names"]]})
            d = derived_by_cap.get(cid)
            if d is not None and d.get("ok"):
                dname = "derived/" + name.split("/", 1)[1].rsplit(".", 1)[0] + ".owlet.wpilog"
                data_sha = hashlib.sha256()
                info = _zip_info(dname, now)
                with open(d["path"], "rb") as f, zf.open(info, "w", force_zip64=True) as out:
                    for block in iter(lambda: f.read(READ_BLOCK), b""):
                        data_sha.update(block)
                        out.write(block)
                dsize = d["path"].stat().st_size
                derived_out.append({"archive_path": dname, "size_bytes": dsize, "sha256": data_sha.hexdigest(),
                                    "derived_from_capture_id": f"cap-{cid:06d}", "source_sha256": d["source_sha256"],
                                    "source_matches_capture": d["source_sha256"] == digest,
                                    "converter": converter, "parameters": d["parameters"], "exit_code": d["exit_code"],
                                    "note": "Derived by a user-installed CTRE Owlet. The original .hoot is authoritative."})
                entry["relationships"].append({"type": "has_derived", "archive_path": dname})
                entry["pitrelay"]["derived_wpilog"] = dname
            elif d is not None:
                entry["pitrelay"]["limitations"].append(f"conversion attempted and failed: {d.get('reason')}")
            elif e["format"]["detected_format"] == "hoot":
                entry["pitrelay"]["limitations"].append("collected; conversion unavailable (not requested or no Owlet configured)")
            captures_out.append(entry)
        by_sha: dict[str, list[str]] = {}
        for c in captures_out:
            by_sha.setdefault(c["sha256"], []).append(c["capture_id"])
        for c in captures_out:
            same = [x for x in by_sha[c["sha256"]] if x != c["capture_id"]]
            if same:
                c["relationships"].append({"type": "same_bytes_as", "capture_ids": same,
                                           "meaning": "identical content collected separately (e.g. the same log from two sources)"})
        succ: dict[str, list[str]] = {}
        for c in captures_out:
            for r in c["relationships"]:
                if r["type"] == "same_path_successor_of":
                    succ.setdefault(r["capture_id"], []).append(c["capture_id"])
        for c in captures_out:
            if c["capture_id"] in succ:
                c["relationships"].append({"type": "superseded_at_path_by", "capture_ids": succ[c["capture_id"]]})

        source_entries = []
        for s in source_files:
            rel_parts = [safe_component(p) for p in s["rel"].split("/")]
            name = "source/" + "/".join(rel_parts)
            with open(s["path"], "rb") as f:
                data = f.read(projectscan.MAX_FILE_BYTES + 1)
            if len(data) > projectscan.MAX_FILE_BYTES or projectscan._credential_hit(data.decode("utf-8", errors="replace")):
                source_excluded = source_excluded + [{"rel": s["rel"], "reason": "changed after selection; excluded"}]
                continue
            rec = _write_bytes(zf, name, data, now)
            rec["original_relative_path"] = s["rel"]
            source_entries.append(rec)

        package_files = []
        obs_doc = {"schema": "pitrelay-observations", "schema_version": "1.0",
                   "note": "User-entered observations. Each is an attributed statement, not a measurement or physical ground "
                           "truth. Times are as stated by the author unless marked as collector time.",
                   "observations": observations}
        package_files.append(_write_bytes(zf, "observations.json", _json(obs_doc), now))
        package_files.append(_write_bytes(zf, "collection-status.json", _json(status_doc), now))
        manifest = {
            "schema": PACKAGE_SCHEMA,
            "schema_version": PACKAGE_SCHEMA_VERSION,
            "collector": {"name": "PitRelay Collector", "version": __version__, "python": platform.python_version(),
                          "platform": f"{platform.system()} {platform.release()}"},
            "package": {
                "id": str(uuid.uuid4()),
                "created_at_utc": utc_iso(now),
                "label": opts.package_label,
                "private_not_anonymized": True,
                "selection": {"since_utc": utc_iso(opts.since), "until_utc": utc_iso(opts.until),
                              "source_keys": sorted({source_keys[s] for s in opts.source_ids}) if opts.source_ids else "all",
                              "capture_ids": [f"cap-{x:06d}" for x in opts.capture_ids] if opts.capture_ids else "all in range",
                              "range_basis": "collector-clock activity window [first seen, last change or acquisition] overlapping [since, until)"},
                "part": part_info,
            },
            "clock_domains": {
                "collection_times": "*_utc acquisition fields use the collector computer's clock.",
                "source_reported_mtime_utc": "File modification time as reported by the source filesystem (robot or DS clock; "
                                             "a roboRIO clock may be unset until the Driver Station connects).",
                "original_clock": "Times inside the log, in the log's own clock domain. Never assumed equal to collector time.",
                "alignment": "No clock alignment between sources, logs or the collector is performed or implied.",
            },
            "sources": [{"source_key": source_keys[s["source_id"]], "alias": s["alias"], "kind": s["kind"], "role": s["role"],
                         "directories": s["public"].get("directories"), "hosts": s["public"].get("hosts"),
                         "removed_from_configuration": s["removed_at"] is not None} for s in sources],
            "pitrelay_engine_profile": compat.ENGINE_PROFILE,
            "captures": captures_out,
            "derived": derived_out,
            "source_code": {"included": bool(source_entries), "files": source_entries,
                            "excluded": [{"relative_path": x["rel"], "reason": x["reason"]} for x in source_excluded][:2000],
                            "note": "Selected by the user. Never built or executed by the collector. Credential-like files "
                                    "and contents were excluded automatically; review before sharing."} if (source_entries or source_excluded) else None,
            "omissions": omissions,
            "limitations": [
                "Robot code revision is not inferred from file names or timestamps.",
                "Live NetworkTables data is not collected; only native log files that the robot, Driver Station or tools wrote.",
                "Measurements that the robot never logged cannot be present.",
            ],
            "package_files": package_files,
        }
        readme = _readme(manifest, opts.package_label).encode("utf-8")
        manifest["package_files"].append(_write_bytes(zf, "README.txt", readme, now))
        zf.writestr(_zip_info(MANIFEST, now), _json(manifest), compress_type=zipfile.ZIP_DEFLATED)
    return manifest


def _snapshot_text(cap: dict) -> str:
    if cap["presence"] != "present":
        return "all bytes captured before the source file was removed or replaced at its path"
    if cap["status"] == "complete":
        return "all bytes observed at the source were captured"
    return "an identified prefix: the source file may contain or gain more bytes than this snapshot"


def _json(obj) -> bytes:
    return (json.dumps(obj, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
