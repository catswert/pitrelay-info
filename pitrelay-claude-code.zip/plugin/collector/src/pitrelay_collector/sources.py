"""Read-only access to log sources: local/mounted folders and SFTP.

Both implementations expose only listing, stat and positioned reads. There is
deliberately no write, rename, delete, chmod, mkdir or remote command method:
the collector cannot modify a source through this interface.

SFTP host identity is pinned. An unknown or changed host key stops the
connection before any authentication data is sent; a user must explicitly
trust the presented key (shown by fingerprint) in the UI or CLI.
"""

from __future__ import annotations

import base64
import os
import posixpath
import socket
import stat as statmod
from dataclasses import dataclass

from .util import printable


@dataclass
class Entry:
    path: str
    name: str
    kind: str  # "file" | "dir" | "link" | "other"
    size: int
    mtime: float | None
    file_id: str | None = None


class SourceError(Exception):
    """A source-level problem; `state` is the user-visible source state."""

    state = "error"

    def __init__(self, message: str, host: str | None = None):
        super().__init__(message)
        self.host = host


class SourceUnreachable(SourceError):
    state = "disconnected"


class HostKeyUnknown(SourceError):
    state = "host_key_untrusted"

    def __init__(self, message, host, key_info):
        super().__init__(message, host)
        self.key_info = key_info


class HostKeyMismatch(SourceError):
    state = "host_key_mismatch"

    def __init__(self, message, host, key_info):
        super().__init__(message, host)
        self.key_info = key_info


class AuthFailed(SourceError):
    state = "auth_failed"


def _valid_child_name(name: str) -> bool:
    # Names come from the source and are untrusted.
    return bool(name) and name not in (".", "..") and "/" not in name and "\\" not in name and "\x00" not in name


# --- local -------------------------------------------------------------------------


class _LocalReader:
    def __init__(self, path: str):
        self.f = _open_shared(path)

    def read_at(self, offset: int, n: int) -> bytes:
        self.f.seek(offset)
        out = bytearray()
        while len(out) < n:
            chunk = self.f.read(n - len(out))
            if not chunk:
                break
            out += chunk
        return bytes(out)

    def size(self) -> int:
        return os.fstat(self.f.fileno()).st_size

    def close(self) -> None:
        self.f.close()


def _open_shared(path: str):
    """Open for reading without preventing the writer from renaming/deleting the file.

    On Windows, Python's open() omits FILE_SHARE_DELETE, which would block a
    Driver Station or vendor tool from rotating its own log while we read it.
    """
    if os.name != "nt":
        return open(path, "rb")
    try:  # pragma: no cover - Windows only (UNVERIFIED in this release)
        import ctypes
        import msvcrt
        from ctypes import wintypes

        GENERIC_READ = 0x80000000
        SHARE_ALL = 0x1 | 0x2 | 0x4  # FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE
        OPEN_EXISTING = 3
        FILE_ATTRIBUTE_NORMAL = 0x80
        create = ctypes.windll.kernel32.CreateFileW
        create.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID, wintypes.DWORD,
                           wintypes.DWORD, wintypes.HANDLE]
        create.restype = wintypes.HANDLE
        handle = create(str(path), GENERIC_READ, SHARE_ALL, None, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, None)
        if handle in (None, wintypes.HANDLE(-1).value):
            raise ctypes.WinError()
        fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
        return os.fdopen(fd, "rb")
    except FileNotFoundError:  # pragma: no cover
        raise
    except Exception:  # pragma: no cover - any ctypes/API problem: fall back to a normal read-only open
        return open(path, "rb")


_REPARSE_POINT = 0x400
_RECALL_ON_OPEN = 0x40000
_RECALL_ON_DATA_ACCESS = 0x400000
_NAME_SURROGATE = 0x20000000  # reparse tags that redirect to another path: symlinks, junctions, mount points


def is_link_like(st, is_symlink: bool, is_junction: bool) -> bool:
    """A symlink, junction or other reparse point that names another path (never followed).

    Other reparse points, such as cloud-storage placeholders (OneDrive Files On-Demand), are
    ordinary files and folders.
    """
    if is_symlink or is_junction:
        return True
    if getattr(st, "st_file_attributes", 0) & _REPARSE_POINT:
        tag = getattr(st, "st_reparse_tag", None)
        return tag is None or bool(tag & _NAME_SURROGATE)
    return False


def is_online_only(st) -> bool:
    """A cloud placeholder whose bytes are not on this disk; reading it would start a download."""
    return bool(getattr(st, "st_file_attributes", 0) & (_RECALL_ON_DATA_ACCESS | _RECALL_ON_OPEN))


class LocalFS:
    kind = "local"

    def realpath(self, path: str) -> str:
        return os.path.realpath(path)

    def join(self, directory: str, name: str) -> str:
        return os.path.join(directory, name)

    def listdir(self, path: str) -> list[Entry]:
        out = []
        with os.scandir(path) as it:
            for de in it:
                if not _valid_child_name(de.name):
                    continue
                try:
                    st = de.stat(follow_symlinks=False)
                except OSError:
                    continue
                if is_link_like(st, de.is_symlink(), getattr(de, "is_junction", lambda: False)()):
                    kind = "link"
                elif statmod.S_ISDIR(st.st_mode):
                    kind = "dir"
                elif statmod.S_ISREG(st.st_mode):
                    kind = "online_only" if is_online_only(st) else "file"
                else:
                    kind = "other"
                if kind == "file" and os.name == "nt":  # pragma: no cover - Windows only
                    # Directory-listing data on Windows can lag for a file its writer keeps open (NTFS updates
                    # it lazily) and carries no file identity; ask the file itself (attribute access only).
                    try:
                        st = os.lstat(de.path)
                    except OSError:
                        pass
                file_id = f"{st.st_dev}:{st.st_ino}" if st.st_ino else None
                out.append(Entry(de.path, de.name, kind, st.st_size, st.st_mtime, file_id))
        return out

    def open(self, path: str) -> _LocalReader:
        st = os.lstat(path)
        if not statmod.S_ISREG(st.st_mode):
            raise PermissionError(f"Refusing to read non-regular file {printable(path)}")
        return _LocalReader(path)

    def close(self) -> None:
        pass


# --- SFTP ----------------------------------------------------------------------------


def key_info(key, host: str | None = None) -> dict:
    return {
        "type": key.get_name(),
        "fingerprint": key.fingerprint,  # "SHA256:<base64>" like OpenSSH
        "key_b64": base64.b64encode(key.asbytes()).decode("ascii"),
        "host": host,
    }


def host_key_matches(key, trusted: list[dict]) -> bool:
    blob = base64.b64encode(key.asbytes()).decode("ascii")
    return any(t.get("type") == key.get_name() and t.get("key_b64") == blob for t in trusted)


class _SftpReader:
    def __init__(self, sftp, path: str):
        self.f = sftp.open(path, "rb")  # SFTP_FLAG_READ only

    def read_at(self, offset: int, n: int) -> bytes:
        self.f.seek(offset)
        return self.f.read(n)

    def size(self) -> int:
        return self.f.stat().st_size

    def close(self) -> None:
        self.f.close()


class SftpFS:
    kind = "sftp"

    def __init__(self, transport, sftp, host: str):
        self.transport = transport
        self.sftp = sftp
        self.host = host

    def realpath(self, path: str) -> str:
        return self.sftp.normalize(path)

    def join(self, directory: str, name: str) -> str:
        return posixpath.join(directory, name)

    def listdir(self, path: str) -> list[Entry]:
        out = []
        for a in self.sftp.listdir_attr(path):
            name = a.filename
            if not _valid_child_name(name):
                continue
            mode = a.st_mode
            if mode is None:
                kind = "other"
            elif statmod.S_ISLNK(mode):
                kind = "link"
            elif statmod.S_ISDIR(mode):
                kind = "dir"
            elif statmod.S_ISREG(mode):
                kind = "file"
            else:
                kind = "other"
            out.append(Entry(posixpath.join(path, name), name, kind, a.st_size or 0,
                             float(a.st_mtime) if a.st_mtime is not None else None))
        return out

    def open(self, path: str) -> _SftpReader:
        st = self.sftp.lstat(path)
        if st.st_mode is not None and not statmod.S_ISREG(st.st_mode):
            raise PermissionError(f"Refusing to read non-regular remote file {printable(path)}")
        return _SftpReader(self.sftp, path)

    @property
    def alive(self) -> bool:
        return self.transport.is_active()

    def close(self) -> None:
        try:
            self.sftp.close()
        finally:
            self.transport.close()


def connect_sftp(src, get_secret, connect_timeout: float = 10.0, io_timeout: float = 30.0) -> SftpFS:
    """Connect to the first reachable configured host whose key is trusted.

    get_secret(source_id, name) returns a stored secret or None.
    Raises the most informative SourceError if no host works.
    """
    import paramiko

    errors: list[SourceError] = []
    for host in src.hosts:
        sock = None
        transport = None
        try:
            try:
                sock = socket.create_connection((host, src.port), timeout=connect_timeout)
            except OSError as e:
                raise SourceUnreachable(f"{host}:{src.port} unreachable: {e.__class__.__name__}: {e}", host) from None
            transport = paramiko.Transport(sock)
            transport.banner_timeout = connect_timeout
            transport.auth_timeout = connect_timeout
            try:
                transport.start_client(timeout=connect_timeout)
            except (paramiko.SSHException, OSError, EOFError) as e:
                raise SourceUnreachable(f"SSH negotiation with {host} failed: {e}", host) from None
            key = transport.get_remote_server_key()
            info = key_info(key, host)
            if not src.trusted_host_keys:
                raise HostKeyUnknown(f"{host} presented an untrusted {info['type']} host key {info['fingerprint']}; "
                                     "confirm it before collection can start", host, info)
            if not host_key_matches(key, src.trusted_host_keys):
                raise HostKeyMismatch(
                    f"REMOTE HOST IDENTITY CHANGED for {host}: presented {info['type']} {info['fingerprint']}, expected "
                    f"{', '.join(k.get('fingerprint', '?') for k in src.trusted_host_keys)}. Collection refused. If the robot "
                    "controller was re-imaged this is expected; verify and re-trust it explicitly.", host, info)
            _authenticate(transport, src, get_secret)
            sftp = paramiko.SFTPClient.from_transport(transport)
            sftp.get_channel().settimeout(io_timeout)
            return SftpFS(transport, sftp, host)
        except SourceError as e:
            errors.append(e)
        except (paramiko.SSHException, OSError, EOFError) as e:
            errors.append(SourceUnreachable(f"{host}: {e.__class__.__name__}: {e}", host))
        if transport is not None:
            transport.close()
        elif sock is not None:
            sock.close()
    # Report the most important failure: an identity problem outranks auth, which outranks reachability.
    for cls in (HostKeyMismatch, HostKeyUnknown, AuthFailed, SourceUnreachable, SourceError):
        for e in errors:
            if type(e) is cls:
                raise e
    raise SourceUnreachable("No hosts configured")




def _authenticate(transport, src, get_secret) -> None:
    import paramiko

    from .secrets import SecretStoreUnavailable

    def secret(name: str) -> str | None:
        try:
            return get_secret(src.id, name)
        except SecretStoreUnavailable as e:  # locked or missing store: not the same as no password stored
            raise AuthFailed(str(e)) from None

    user = src.username
    try:
        if src.auth == "blank_password":
            allowed = None
            try:
                transport.auth_none(user)
            except paramiko.BadAuthenticationType as e:
                allowed = e.allowed_types
            except paramiko.AuthenticationException:
                allowed = ["password", "keyboard-interactive"]
            if transport.is_authenticated():
                return
            if allowed is None or "password" in allowed:
                transport.auth_password(user, "", fallback=True)
            elif "keyboard-interactive" in allowed:
                transport.auth_interactive(user, lambda title, instructions, prompts: ["" for _ in prompts])
            else:
                raise AuthFailed(f"Server does not allow blank-password login for {user!r} (allowed: {allowed})")
        elif src.auth == "password" and src.password_preset is not None:
            # A documented, public default login (WPILib's 2027 documentation gives Systemcore's as user and password
            # "systemcore"): not a secret, so not stored. A preset from a newer collector fails this source only.
            from .config import PASSWORD_PRESETS
            if src.password_preset not in PASSWORD_PRESETS:
                raise AuthFailed(f"This source uses a login ({printable(str(src.password_preset), 40)}) that this "
                                 "collector version does not know; choose the login again in Setup")
            transport.auth_password(user, PASSWORD_PRESETS[src.password_preset], fallback=True)
        elif src.auth == "password":
            password = secret("password")
            if password is None:
                raise AuthFailed("No password is stored for this source; set it in Setup")
            transport.auth_password(user, password, fallback=True)
        elif src.auth == "key":
            try:
                try:  # most robot keys are not encrypted: ask the credential store only for one that is
                    pkey = paramiko.PKey.from_path(src.key_file)
                except (paramiko.PasswordRequiredException, TypeError):  # TypeError: cryptography, encrypted key
                    passphrase = secret("key_passphrase")
                    if passphrase is None:
                        raise AuthFailed("The private key is encrypted and no passphrase is stored; set it in Setup") \
                            from None
                    # Positional: the keyword is 'passphrase' before paramiko 5 and 'password' since; bytes for both.
                    pkey = paramiko.PKey.from_path(src.key_file, passphrase.encode("utf-8"))
            except (OSError, paramiko.SSHException, ValueError, TypeError) as e:
                raise AuthFailed(f"Could not load the configured private key: {e.__class__.__name__}") from None
            transport.auth_publickey(user, pkey)
        else:
            raise AuthFailed(f"Unknown authentication method {src.auth!r}")
    except paramiko.AuthenticationException as e:
        raise AuthFailed(f"Authentication failed for {user!r}: {e.__class__.__name__}") from None
    if not transport.is_authenticated():
        raise AuthFailed(f"Authentication failed for {user!r}")


def fetch_host_key(host: str, port: int, timeout: float = 10.0) -> dict:
    """Connect only far enough to read the server's host key (no authentication)."""
    import paramiko

    sock = socket.create_connection((host, port), timeout=timeout)
    transport = paramiko.Transport(sock)
    try:
        transport.banner_timeout = timeout
        transport.start_client(timeout=timeout)
        return key_info(transport.get_remote_server_key(), host)
    finally:
        transport.close()
