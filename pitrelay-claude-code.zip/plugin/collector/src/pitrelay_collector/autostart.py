"""Optional launch-at-login, enabled only by an explicit user action.

Nothing in installation, `init` or the test suite enables this. Each platform
uses a per-user mechanism that the user can inspect and remove by hand:

* Windows: value "PitRelayCollector" under
  HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run (pythonw, no console window).
* macOS: ~/Library/LaunchAgents/org.pitrelay.collector.plist (RunAtLoad). Takes effect
  at the next login; disabling does not stop an already-running collector.
* Linux (development only): ~/.config/autostart/pitrelay-collector.desktop.

Windows and macOS behavior is UNVERIFIED in this release (developed and tested on Linux
with the platform files generated and parsed, not executed by the real OS).
"""

from __future__ import annotations

import os
import platform
import plistlib
import subprocess
import sys
from pathlib import Path

LABEL = "org.pitrelay.collector"
WIN_VALUE = "PitRelayCollector"
WIN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
# The collector bundled with PitRelay for Claude Code registers under its own names, so it never replaces (or is
# replaced by) a standalone collector's login item.
IDENTITIES = {
    "standalone": {"label": LABEL, "win_value": WIN_VALUE, "desktop": "pitrelay-collector.desktop",
                   "name": "PitRelay Collector"},
    "claude": {"label": "org.pitrelay.claude-collector", "win_value": "PitRelayClaudeCollector",
               "desktop": "pitrelay-claude-collector.desktop", "name": "PitRelay Collector (Claude Code)"},
}


# Set by a bundled launcher (PitRelay for Claude Code's host/collector.py): {"script", "ident", "store"}. Commands run
# through it then register the bundled copy under its own login-item names and default to its store.
BUNDLED: dict | None = None


def launch_command(store: Path, python: str | None = None, system: str | None = None, script: str | None = None) -> list[str]:
    """The login command. `script` runs a bundled copy (PitRelay for Claude Code) instead of the installed module."""
    exe = python or sys.executable
    if (system or platform.system()) == "Windows":
        candidate = Path(exe).with_name("pythonw.exe")
        if candidate.exists():
            exe = str(candidate)
    if script:
        return [exe, "-I", "-B", "-X", "utf8", str(script), "run", "--store", str(store), "--no-browser"]
    return [exe, "-m", "pitrelay_collector", "run", "--store", str(store), "--no-browser"]


class WinRegistry:  # pragma: no cover - Windows only
    def get(self, name):
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, WIN_KEY) as k:
                return winreg.QueryValueEx(k, name)[0]
        except FileNotFoundError:
            return None

    def set(self, name, value):
        import winreg
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, WIN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            winreg.SetValueEx(k, name, 0, winreg.REG_SZ, value)

    def delete(self, name):
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, WIN_KEY, 0, winreg.KEY_SET_VALUE) as k:
                winreg.DeleteValue(k, name)
        except FileNotFoundError:
            pass


def _desktop_quote(arg: str) -> str:
    """One Exec argument, per the Desktop Entry spec: inside double quotes ", `, $ and \\ are escaped with a
    backslash; the value is then also a string value, where every backslash is doubled again; '%' starts a field
    code, so a literal one is '%%'."""
    if any(c in arg for c in "\n\r\t"):
        raise ValueError("A launch-at-login path may not contain line breaks or tabs")
    quoted = arg.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`").replace("$", "\\$")
    return '"' + quoted.replace("\\", "\\\\").replace("%", "%%") + '"'


class Autostart:
    def __init__(self, system: str | None = None, home: Path | None = None, registry=None, python: str | None = None,
                 script: str | None = None, ident: str = "standalone"):
        self.system = system or platform.system()
        self.home = Path(home) if home else Path.home()
        self.registry = registry
        if script is None and BUNDLED is not None:
            script, ident = BUNDLED["script"], BUNDLED["ident"]
        self.python = python
        self.script = script
        self.ident = IDENTITIES[ident]

    def _reg(self):
        if self.registry is None:
            self.registry = WinRegistry()
        return self.registry

    @property
    def mac_path(self) -> Path:
        return self.home / "Library" / "LaunchAgents" / f"{self.ident['label']}.plist"

    @property
    def linux_path(self) -> Path:
        return self.home / ".config" / "autostart" / self.ident["desktop"]

    def status(self) -> dict:
        base = {"platform": self.system, "verified_on_this_platform": self.system == "Linux"}
        if self.system == "Windows":
            value = self._reg().get(self.ident["win_value"])
            return base | {"supported": True, "enabled": value is not None, "mechanism": "HKCU Run registry value",
                           "location": f"HKCU\\{WIN_KEY}\\{self.ident['win_value']}", "command": value}
        if self.system == "Darwin":
            enabled = False
            command = None
            if self.mac_path.exists():
                try:
                    data = plistlib.loads(self.mac_path.read_bytes())
                    enabled = data.get("Label") == self.ident["label"] and bool(data.get("RunAtLoad"))
                    command = data.get("ProgramArguments")
                except Exception:
                    enabled = False
            return base | {"supported": True, "enabled": enabled, "mechanism": "LaunchAgent (takes effect at next login)",
                           "location": str(self.mac_path), "command": command}
        if self.system == "Linux":
            return base | {"supported": True, "enabled": self.linux_path.exists(), "mechanism": "XDG autostart (development)",
                           "location": str(self.linux_path), "command": None}
        return base | {"supported": False, "enabled": False, "mechanism": None, "location": None, "command": None}

    def enable(self, store: Path) -> dict:
        cmd = launch_command(Path(store).resolve(), self.python, self.system, self.script)
        if self.system == "Windows":
            self._reg().set(self.ident["win_value"], subprocess.list2cmdline(cmd))
        elif self.system == "Darwin":
            log = Path(store).resolve() / "diagnostics" / "launchd.log"
            plist = {"Label": self.ident["label"], "ProgramArguments": cmd, "RunAtLoad": True, "KeepAlive": False,
                     "ProcessType": "Background", "StandardOutPath": str(log), "StandardErrorPath": str(log)}
            self.mac_path.parent.mkdir(parents=True, exist_ok=True)
            self.mac_path.write_bytes(plistlib.dumps(plist))
        elif self.system == "Linux":
            self.linux_path.parent.mkdir(parents=True, exist_ok=True)
            self.linux_path.write_text(
                f"[Desktop Entry]\nType=Application\nName={self.ident['name']}\n"
                "Comment=Collect FRC robot logs automatically (enabled by the user)\n"
                f"Exec={' '.join(_desktop_quote(a) for a in cmd)}\nNoDisplay=true\nX-GNOME-Autostart-enabled=true\n",
                encoding="utf-8")
        else:
            raise RuntimeError(f"Launch at login is not supported on {self.system}")
        return self.status()

    def disable(self) -> dict:
        if self.system == "Windows":
            self._reg().delete(self.ident["win_value"])
        elif self.system == "Darwin":
            if self.mac_path.exists():
                self.mac_path.unlink()
        elif self.system == "Linux":
            if self.linux_path.exists():
                self.linux_path.unlink()
        return self.status()


def default_store_path(system: str | None = None, home: Path | None = None) -> Path:
    system = system or platform.system()
    home = Path(home) if home else Path.home()
    if system == "Windows":
        base = os.environ.get("LOCALAPPDATA")
        return (Path(base) if base else home / "AppData" / "Local") / "PitRelayCollector"
    if system == "Darwin":
        return home / "Library" / "Application Support" / "PitRelayCollector"
    xdg = os.environ.get("XDG_DATA_HOME")
    return (Path(xdg) if xdg else home / ".local" / "share") / "pitrelay-collector"
