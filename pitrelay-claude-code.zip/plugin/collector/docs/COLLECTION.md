# How collection works

## Polling and limits

* Each enabled source is polled on its own interval (default 30 s). One worker thread polls sources in turn, so the collector never opens many connections at once.
* **Listing:** only the authorized folders are listed, to a bounded subfolder depth (default 2). There is a cap on matching files per source (default 5000).
* **Links:** links found inside an authorized folder (symlinks, Windows junctions and mount points) are never followed. The authorized folder's own path *is* resolved, so a link such as the roboRIO's `/u/logs` leads to its target, and the Status page shows the resolved path. That resolved location is checked again on every poll: if it now leads to a whole drive, your home folder or the collector's store, the folder is refused and an alert says why.
* **Cloud placeholders (Windows, UNVERIFIED):** OneDrive-style files whose bytes are not on the disk are never read, so listing never starts a download.
  * A new file in that state is skipped and counted.
  * A file already captured stays present and unchanged until its bytes are local again. It is not reported as removed, and it is not collected twice.
  * Other cloud-backed files and folders are read normally.
* **Selection:** files are chosen by extension (`.wpilog .revlog .hoot .dslog .dsevents`). CSV and named text files are added only when you opt in for that source. Format is then identified from content.
* **Bandwidth and memory:**
  * a shared token-bucket bandwidth limit (default 1 MiB/s);
  * a per-poll transfer budget per source (default 256 MiB);
  * transfers in 4 MiB chunks, read in 256 KiB blocks;
  * format scanners stream in 1 MiB blocks and skip large payloads.
* **Reconnection:** failures back off exponentially (5 s doubling to 300 s, with jitter) and recover automatically. Host-key problems wait at the maximum until you act. Changing a source's addresses, login settings or trusted key (in the UI or with the CLI) retries it at once.
* **Pause and disable** take effect within one read block (256 KiB), also during a long transfer and also when issued from the CLI in another process. The bytes already read in that chunk are committed; nothing more is read.

## Growing files: incremental and verified

For every tracked file, each poll compares size and modification time.

* **Changed, and not smaller than when last seen:** the collector re-reads parts of the captured prefix from the source and compares them with the stored bytes. For prefixes up to 256 KiB that is the whole prefix; for larger ones, 4 KiB windows at the head, middle and tail. If they match, only the **new bytes** are transferred.
* **Shorter than when last seen, or prefix mismatch:** the file was truncated or replaced at that path, even if it is still longer than what was captured. The existing capture is **sealed and kept** (any bytes it had that were never transferred are reported as a gap), and the new content becomes a **new capture** linked as `same_path_successor_of`. A sealed capture is never continued at the same path.

Each transfer works like this:
1. Open the source file once and check its first 4 KiB against the store.
2. Read the new bytes into the capture's append-only file.
3. `fsync`, then re-read the source's first bytes **through the same open handle** and compare.
4. Commit the chunk to the catalog with its SHA-256.

A mismatch at step 3 discards the uncommitted chunk and flags the capture `uncertain` ("changed during transfer"). Earlier committed bytes are never rewritten.

**What these checks do not prove:**
* A SHA-256 proves the bytes in the package are the bytes collected. It does not prove the source recording was complete or consistent.
* The window re-checks sample the source. A change confined to the middle of a large file between polls could be missed.
* A replacement with identical size and modification time is undetectable without re-reading everything.

## Renames and rotation

A new path is matched to a capture that disappeared (or was replaced) **in the same poll**. The match requires all of the following:
* the new file is at least as long as the captured prefix (minimum 64 bytes);
* the captured prefix matches the new file: in full up to 256 KiB, otherwise by head, middle and tail windows;
* on local sources, both files have the same file identity when the OS reports one.

This follows WPILib's `FRC_TBD_*.wpilog → FRC_<date>.wpilog` rename while the file is still growing, and `log → log.1` style rotation. The capture's `name_history` keeps every name.

Restricting matches to the same poll prevents attaching an unrelated file that merely begins with the same bytes. Two WPILOG files can share a header and early records, and the test suite includes exactly that case. The failure mode is a harmless duplicate capture rather than a false lineage.

## Gaps

* **Unrecovered gap:** a file disappeared or was replaced after the source had shown `N` more bytes than were captured. Those `N` bytes are reported as `unrecovered_gap_bytes`, and the status is `partial`.
* **Unobserved time:** periods when a source was unreachable, collection was paused or disabled, or the collector was not running. They appear as the complement of `observed_available_intervals_utc` and `collector_runs` in `collection-status.json`. Files created and deleted entirely within such a period cannot be known.
* A folder that is temporarily unavailable (USB drive removed, share offline, a transient listing failure) does **not** mark its files missing. Only a successful listing that no longer contains a file does. A capture is treated as no longer authorized only when every configured folder resolved and none contains it.
* **Observation time** accrues only between consecutive polls on the same connection. A slow poll leaves an unobserved gap; it does not count as a reconnection. A *new connection* (reconnecting, resuming, or restarting the collector) is what the reconnection rule for `complete` refers to.

## Local store damage

If a capture's local copy is missing, shorter than its committed size, or fails a segment hash check:
* the capture is flagged `store integrity: …` and becomes `detached`;
* it is excluded from exports and listed under `omissions`;
* the source file, if still present, is collected again from the start as a new capture.

This is reported as a local store problem, never as a change at the source. The collector never "extends" a short local file, which would zero-fill committed bytes, and never clears an integrity flag.

## Durability, restart and ownership

* The catalog is SQLite in WAL mode with `synchronous=FULL`.
* Bytes are fsynced before the catalog row that commits them.
* On start:
  * any uncommitted tail of a capture file is truncated, so it will be re-fetched;
  * the last committed segment of every capture is re-hashed;
  * an interrupted previous run is recorded as `unclean_shutdown`, and its last heartbeat closes open availability intervals.
* Captured files are matched by path and content on restart, so nothing is downloaded twice.
* One collector per store, enforced by an OS file lock. A second `run` exits with a message naming the owner. CLI exports may read the store while the collector runs.
* A store with an unsupported format version is refused by every command, not only by `run`.
* Configuration changes made with the CLI while the collector runs (adding or removing a source, trusting a host key) are picked up on the next poll.

## Exports during collection

An export reads a catalog snapshot (one read transaction) and copies exactly the committed prefix of each capture. Committed bytes never change, so collection can keep appending meanwhile. Local deletion waits until running exports finish, including CLI exports in other processes: exports share an OS lock on `exports.lock` that deletion takes exclusively (it gives up after 60 s and says an export is still running).

## Storage quota and retention

* Before every chunk, the collector checks the quota and the minimum free disk space. When either is reached, it transfers up to the limit, then **stops** and raises an error alert. The blocked state is recorded in the catalog (so `pitrelay-collector status` shows it too) and is cleared, with an event, as soon as storage allows, even while no source is reachable and across restarts.
* Nothing, local or remote, is deleted to make room.
* Collection resumes when you raise the quota, free space, or explicitly delete captures. Deletion uses **typed confirmation** in the UI or `delete-captures --yes`, and leaves a tombstone (name, size, SHA-256, time, note) that later exports list under `omissions`.
* A deleted capture whose file is **still on the source is not downloaded again** while that file is unchanged (same path, size and modification time). If the file changes, it is collected again from the start as new evidence.
* Deleting a capture while it is being transferred is safe:
  * The tombstone is written first, so no further bytes are committed to the capture, and the recorded size and SHA-256 are exactly those of the deleted bytes.
  * On Windows, a file that is in use is refused cleanly and left unchanged.
  * If a deletion is interrupted (full disk, crash), the capture is already excluded from exports. The next deletion or collector start finishes it.
