# Giving a collection package to PitRelay

A collection ZIP is **not** something every PitRelay importer accepts as-is:
* PitRelay's `source.import_zip` imports *source code*. It is not a telemetry importer.
* PitRelay's evidence bundles use a different internal format.

The working route is: verify the ZIP, extract it safely, then supply each log to the PitRelay operation that matches its format.

Everything below was observed on the **PitRelay 0.1.0-dev local package v11** (`engine/pitrelay.jar`, SHA-256 `66de12d3…c5d2`) in **Standard Access** through its CLI and MCP stdio interface, with OpenJDK 21 on Linux. A different engine build may differ. The collector records which build it talked to, and the integration tests re-check behavior against whatever jar you supply.

## 1. Verify and extract

```bash
pitrelay-collector verify  pitrelay-collection-20261023-120700Z.zip
pitrelay-collector extract pitrelay-collection-20261023-120700Z.zip ./handoff
```

`extract` refuses:
* a package that fails verification;
* a destination that already exists and is not empty (so `HANDOFF.txt` or anything else of yours is never replaced);
* any unsafe member: absolute paths, `..`, backslashes, drive letters, links, Windows device names, case-insensitive collisions, or files not listed in the manifest.

It re-hashes every file while extracting, marks the files read-only, and writes `handoff/HANDOFF.txt` and `handoff/handoff-plan.json` describing what to do with each file.

`pitrelay-collector verify <folder>` re-checks an extracted folder later: every listed file, its size and SHA-256, with no extra files or links. The manifest itself is anchored only by the original ZIP and its `.sha256`, so keep those.

## 2a. Automatic handoff to a local engine (optional)

If the PitRelay engine is on this computer (Java 17+):

```bash
pitrelay-collector handoff ./handoff/pitrelay-collection \
    --engine-jar /path/to/pitrelay/engine/pitrelay.jar \
    --state /path/to/a/pitrelay-state-folder \
    --out ./handoff \
    [--java /path/to/java] \
    [--csv-mappings mappings.json]
```

`--java` defaults to `java` on the `PATH`. Windows and macOS often have none there, so name the JDK's `java` (`java.exe`) explicitly.

Before starting the engine, `handoff` re-checks the extracted folder against its manifest, as `verify` does. It refuses to hand off anything if a file changed since extraction. Each upload declares the manifest's SHA-256, so the engine itself rejects bytes that differ.

This starts the engine in `--mode mcp` (stdio). It uses only the engine's own operations:
* `capability.list`
* `artifact.upload_begin` / `artifact.upload_chunk` / `artifact.upload_finish` (byte size and SHA-256 declared; the engine re-verifies them)
* `log.inspect`
* `log.import_csv`

It writes `handoff/handoff-receipt.json` containing the **artifact IDs exactly as the engine returned them**. The collector never invents IDs and never writes to the engine's state folder itself.

* Several PitRelay processes may share one `--state` folder: the v11 engine coordinates them with its own file locks (checked with the v11 jar; see `../../docs/PITRELAY_ENGINE_ISSUES.md`, section 6). An `upload_begin` that races another process's answers `blocked` `TRANSFER_BUSY`; try it again.
* The same bytes uploaded with the same file name and kind get the same engine artifact ID; a different file name or kind gives a different ID. The receipt and manifest record every source either way.
* Files over **64 MiB** are not uploaded. `artifact.upload_begin` is limited to 64 MiB per artifact, and compression does not change that.

## 2b. Manual handoff (what the plan tells you)

Upload a file in up to 49,152-byte chunks:

```json
{"operation":"artifact.upload_begin","kind":"log","filename":"FRC_20261023_120010.wpilog","byte_size":59291,"sha256":"<sha256 from manifest>"}
{"operation":"artifact.upload_chunk","transfer_id":"<result.id from upload_begin>","offset":0,"data_base64":"..."}
{"operation":"artifact.upload_finish","transfer_id":"<same id>"}
```

Note that `upload_begin` returns the transfer ID in the field `id`, while `upload_chunk` and `upload_finish` call it `transfer_id`.

Then use the artifact ID returned by `upload_finish` in the operation for that format:

| Collected file | PitRelay operation (v11) | Notes |
|---|---|---|
| WPILOG 1.0 (`.wpilog`; WPILib, AdvantageKit, FIRST DS 2027) | `log.inspect` with no `format` | Then `log.entries`, `signal.read`, `signal.statistics` (half-open `[start_us, end_us)`). The engine's index budget: 64 MiB input, 2 MiB/record, 400 000 records, 200 000 samples, 10 000 entries. The manifest warns when a file exceeds it. |
| NI DS `.dslog` version 4 | `log.inspect` with `"format": "dslog_v4"` | Must be explicit. The adapter keeps power-distribution current blocks undecoded and uses an implicit 20 ms cadence. |
| NI DS `.dsevents` version 4 | `log.inspect` with `"format": "dsevents_v4"` | Must be explicit. **Pick by content.** The engine reports a mismatched adapter as `partial`, not as an error (see the engine issues report). |
| NI DS version 3 or unknown | none | The engine only supports DS version 4. |
| REV `.revlog` | `log.inspect` with `"format": "rev_native"` | REVLOG v1 (REVLib 2025 – 2027.0.0-alpha-8) is the engine's layout. A synthetic **v2** file produced "Unknown REV native record ID 3/6", so expect partial decoding of v2 logs. |
| CTRE `.hoot` | none directly | `log.convert.*` reported `blocked_host_configuration` (an exact host-pinned utility is required). If the package has `derived/…owlet.wpilog`, supply that to `log.inspect`. The original `.hoot` remains authoritative. |
| CSV | `log.import_csv` | Requires `timestamp_column`, `value_column`, `time_unit` (`us`/`ms`/`s`), `clock`, `sampling_policy` (e.g. `periodic`), and `unit` or `unknown_unit_reason`. Then use `signal.*` with `"entry": "$derived"` on the returned artifact. The collector never guesses these mappings. |
| Diagnostic text | none | Read it as untrusted text. |
| `source/` files | `source.import_zip` (kind `source_archive`) | Zip the selected `source/` files yourself. The engine captures them without executing anything. |

### CSV mapping file for `--csv-mappings`

```json
{"logs/source-001/voltage_SYNTHETIC.csv":
  {"timestamp_column": "time_s", "value_column": "voltage", "time_unit": "s",
   "clock": "ds_csv_relative", "sampling_policy": "periodic", "unit": "V"}}
```

## 2c. With Claude Code

*PitRelay for Claude Code* has this collector built in (see `../../README.md`). There, `/pitrelay:import-collection <zip>` hands the package to `collector_supply_to_engine`: it verifies every hash, streams each recording straight to the engine (the bytes never pass through the conversation, at any access level) and inspects it with the operation for its format. A ZIP from outside the collector store is confirmed by the person in a dialog first. Nothing is extracted.

A Claude Code plugin prepared without the collector (`--without-collector`) verifies the package with this collector's `verify` command and proposes how to bring the recordings in; the command lives in the collector's virtual environment, which is usually not on the `PATH`, so tell Claude its full path, for example:
* `%LOCALAPPDATA%\PitRelayCollector\venv\Scripts\pitrelay-collector.exe` on Windows;
* `~/Library/Application Support/PitRelayCollector/venv/bin/pitrelay-collector` on macOS.

## 3. Check: the synthetic voltage fixture

The test `tests/test_pitrelay_engine.py` performs the whole chain against the real engine:
1. collect `voltage_SYNTHETIC.wpilog` (12, 12, 6, 12, 12 V at 0–4 s);
2. export, verify, extract and hand off;
3. ask PitRelay for `signal.statistics` on `/SyntheticFixture/BatteryVoltage` over `[0, 5000000)` µs.

Result with v11: `count 5, mean 10.8, min 6.0, max 12.0`, with `integrity: complete`. The fixture's bytes are identical before collection, in the store, in the ZIP and in the extracted copy.

```bash
PITRELAY_ENGINE_JAR=/path/to/engine/pitrelay.jar python -m pytest tests/test_pitrelay_engine.py -v
```

Units come only from the log itself. The engine reads a WPILOG entry's metadata key `unit` (the fixture declares `{"unit":"V"}`, so PitRelay reports V); a log without it is reported with an unknown unit. The collector never adds or translates units.
