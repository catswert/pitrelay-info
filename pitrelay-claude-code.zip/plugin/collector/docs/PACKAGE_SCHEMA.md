# PitRelay collection package, schema 1.0

An export is an ordinary ZIP file (Deflate, ZIP64 when needed). A synthetic example is [`samples/pitrelay-collection-sample.zip`](../samples/pitrelay-collection-sample.zip), with its `.sha256` sidecar. It shows complete, active and partial captures, a recording removed before it was fully transferred (an unrecovered gap), a rename followed while the file grew, a user deletion listed under `omissions`, and selected source code with a credential file excluded.

This is a **private analysis package**. It contains the original log bytes and is **not anonymized**. It is not PitRelay's sanitized issue-report package and does not satisfy PitRelay's internal evidence-bundle format.

```
pitrelay-collection/
  README.txt                 human summary, status meanings, limitations
  manifest.json              the inventory and everything known about each file
  collection-status.json     sources, availability intervals, collector runs, events, storage
  observations.json          optional user observations (attributed, not measurements)
  logs/source-NNN/<name>     original bytes; one folder per source
  derived/source-NNN/<name>  optional conversions (e.g. Owlet hoot -> wpilog), linked by hash
  source/<relative path>     optional robot source files the user selected (never executed)
```

Archives are named `pitrelay-collection-<UTC time>-<random token>[-partKofN].zip`. The random token keeps two exports started in the same second from colliding, and an existing file is never overwritten. Alongside each ZIP, the exporter writes `<zip>.sha256` (the SHA-256 of the ZIP file itself, for transport checks).

## Guarantees

* **Every file is listed.** Each file except `manifest.json` itself appears exactly once in the manifest (`captures`, `derived`, `source_code.files` or `package_files`) with its byte size and SHA-256. `pitrelay-collector verify` rejects missing, extra, resized or altered files.
* **Original bytes are untouched.** `logs/` holds the exact bytes collected: the full file, or the identified prefix of a file still being written. No transcoding, renaming of signals, re-timing or gap filling. Every stored segment's SHA-256 recorded at acquisition is re-verified during export.
* **Member names are portable.** Names use only `A–Z a–z 0–9 . _ -`. There are no absolute paths, `..`, links or Windows device names, and no names that collide when compared case-insensitively. Exact original names and paths are kept in the manifest as JSON strings.
* **Exports are written atomically.** The exporter writes a temporary file, verifies it, and only then renames it into place. A failed export leaves no package.

## manifest.json

Top level:

| Field | Meaning |
|---|---|
| `schema`, `schema_version` | `"pitrelay-collection"`, `"1.0"`. Readers must check the major version. |
| `collector` | Name, version, Python version, OS. |
| `package` | `id` (UUID), `created_at_utc` (collector clock), `label` (e.g. "SYNTHETIC SAMPLE"), `private_not_anonymized: true`, `selection` (range and basis), `part` (see *Multiple archives*). |
| `clock_domains` | Explains the separate clocks used below. No alignment is implied. |
| `sources[]` | `source_key` (`source-NNN`), `alias`, `kind` (`sftp` or `local`), `role`, `directories`, `hosts`, `removed_from_configuration`. No usernames or credentials. |
| `pitrelay_engine_profile` | The PitRelay build whose behavior the routes describe (v11 engine SHA-256). |
| `captures[]` | One entry per collected file version (below). |
| `derived[]` | Conversions: `archive_path`, `size_bytes`, `sha256`, `derived_from_capture_id`, `source_sha256`, `source_matches_capture`, `converter` (name, executable name, executable SHA-256, version output), `parameters`, `exit_code`. |
| `source_code` | `null`, or `{included, files[{archive_path, size_bytes, sha256, original_relative_path}], excluded[{relative_path, reason}], note}`. |
| `omissions[]` | What is not in the package and why. Kinds: `not_selected` (count), `deleted_by_user` (id, name, size, SHA-256, time, note), `no_bytes_captured` (observed but nothing transferred, e.g. permission or quota), `store_integrity_failure`. |
| `limitations[]` | Package-wide limitations. |
| `package_files[]` | `README.txt`, `observations.json`, `collection-status.json` with sizes and hashes. |

### `captures[]`

| Field | Meaning |
|---|---|
| `capture_id` | `cap-NNNNNN`, stable within a store. A new version of a file at the same path gets a new ID. |
| `source_key`, `archive_path` | Where it came from and where it is in the ZIP. |
| `original_filename`, `original_path`, `name_history[]` | Exact names. `name_history` lists every path the same recording had, e.g. `FRC_TBD_x.wpilog` then `FRC_20261023_120010.wpilog`, each with the time it was first seen. |
| `size_bytes`, `sha256` | Of the exported bytes. |
| `acquisition.status` | `active`, `idle`, `complete`, `partial` or `uncertain` (definitions below). |
| `acquisition.status_reasons[]` | Plain-language evidence for the status. |
| `acquisition.snapshot` | Whether these bytes are the whole observed file or an identified prefix. |
| `acquisition.captured_bytes`, `last_observed_source_bytes`, `max_observed_source_bytes` | Sizes seen at the source versus bytes captured. |
| `acquisition.unrecovered_gap_bytes` | Bytes the source was seen to have that disappeared before transfer. |
| `acquisition.pending_bytes_at_source` | Bytes still to be transferred for a file that is still present. |
| `acquisition.presence_at_source` | `present`, `missing` (removed), `replaced` (a different or shorter file is now at that path) or `detached` (the local copy failed an integrity check; the source file was collected again as a new capture). |
| `acquisition.*_utc` | First/last seen, first/last acquired, no-longer-at-path time. All on the **collector's clock**. |
| `acquisition.source_reported_mtime_utc` | The modification time as reported by the source filesystem (the robot or DS clock, which may be wrong or unset). |
| `acquisition.quiet_observed_s` | Seconds of continuous connected observation without change. |
| `acquisition.consistency_checks` | `performed`: counts keyed `<check>:<result>`. `post_chunk_head:match` and `segment_sha256:recorded` count committed segments (one each per segment); `prefix_recheck` and `rename_continuity` count each re-check with its result; `pre_transfer_head` and `post_chunk_head:mismatch` appear only when a check failed. Also states what these checks do and do not prove. |
| `acquisition.transfer_flags.inconsistent_transfer` | Present if the file changed while being read. |
| `format` | Content-based identification: `detected_format`, `format_version`, `label`, `evidence[]`, `extension_consistent`, `structure` (records, `trailing_incomplete_bytes`, `stopped_early`, issues) and `details` (WPILOG entry names and types, DS record counts, REVLOG version, the hoot byte at offset 70). |
| `original_clock` | Time information inside the file, in its own domain. WPILOG: first/last record timestamps in µs (robot FPGA time on a roboRIO). NI DS: the raw LabVIEW header seconds plus a labelled UTC interpretation. |
| `relationships[]` | `same_path_successor_of`, `superseded_at_path_by`, `renamed_while_collected`, `same_bytes_as` (identical content collected from another source), `has_derived`. |
| `pitrelay` | The route for the inspected PitRelay engine: `operation`, `format_argument`, `upload_kind`, `description`, `limitations[]`, `verified_against_engine`. |

### Status definitions

| Status | Rule |
|---|---|
| `active` | Changed within the *active window* (default 120 s) of observation. A file still being written; the bytes are an identified prefix. |
| `idle` | Present, all observed bytes captured, unchanged past the active window but not yet long enough to call complete. The writer may still have it open. |
| `complete` | All observed bytes captured, **and** either (a) unchanged for at least the *completion period* (default 1800 s) of **continuous connected observation**, or (b) unchanged across a **new connection** to the source (a reconnection, a resume after pausing, or a collector restart; a merely slow poll does not count) while a newer recording appeared in the same folder. **And** the record structure ends on a boundary where it can be checked. The collector still cannot see whether the writer closed the file, and says so. A capture that reached `complete` keeps it if the file is later removed or replaced at the source; `presence_at_source` then says `missing` or `replaced`. |
| `partial` | Some bytes the source was seen to have were not captured (still pending, blocked, or lost when the file disappeared), **or** the file stopped changing with an incomplete final record. |
| `uncertain` | The file was removed or replaced, before completion was established, after everything observed had been captured, so later bytes (if any) were never seen. Or its start changed during a transfer. Or its local copy failed an integrity check (`detached`; excluded from exports and listed under `omissions`). |

A brief pause in growth never makes a file `complete`. Time while the source was unreachable, paused or the collector was stopped does not count as observation.

## collection-status.json

* `sources[]`: state at export, last successful collection, last error, per-folder status (`ok`, `not_found`, `permission_denied`, links skipped, subfolder errors), and `observed_available_intervals_utc` as `[start, end)` pairs.
* `collector_runs[]`: when the collector was running. Gaps between runs, and outside a source's available intervals, were **not observed**. Files created and deleted entirely within those gaps cannot be in the package.
* `events[]`: info, warning and error events in the selected range (connections, disconnections, renames, replacements, gaps, quota, host keys, permission problems, deletions). Includes `events_total` and `events_truncated`.
* `storage`: usage, quota, minimum free space and the retention policy text.

## observations.json

```json
{"schema": "pitrelay-observations", "schema_version": "1.0", "note": "...attributed statement, not a measurement...",
 "observations": [{"id": "obs-001", "author": "Driver", "recorded_at_utc": "...", "observed_time_as_stated": "Q14 ~1:05",
                   "related_capture_ids": ["cap-000004"], "text": "Arm stalled after the second pickup"}]}
```

## Multiple archives

With a size limit (`--max-archive-mb` or the UI option), captures are grouped into several ZIPs. **A file is never split.**
* Part 1's budget also counts the selected source code, and every part allows for its metadata files.
* A file larger than the limit gets an archive of its own and is marked in its limitations.
* An archive that still ends up larger than the limit is named in the export's warnings, never silently.

Each part is an independently valid package with its own manifest, observations and status. `package.part` is `{set_id, index, count, inventory[{capture_id, part}]}`, so any part shows where every other capture is. Selected source code is placed in part 1.

## Compatibility rules for readers

* Reject unknown major versions. Ignore unknown fields.
* Treat all names, paths, entry names and event messages as untrusted text.
* Never infer a shared clock, or a matching robot-code revision, from file names or nearby timestamps.
