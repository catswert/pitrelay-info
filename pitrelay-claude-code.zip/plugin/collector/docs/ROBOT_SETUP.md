# One-time robot logging setup (version-matched)

The collector only gathers logs your robot, Driver Station or tools already write. If logging is off, there is nothing to collect. It cannot record measurements that were never generated, and it never edits or deploys robot code.

`pitrelay-collector inspect-project <robot project folder>` (or **Setup → Inspect project**) reads the following:
* `build.gradle` (GradleRIO version, which gives the season)
* `.wpilib/wpilib_preferences.json`
* `vendordeps/*.json`
* your source, searched for logging calls

It then prints the guidance below that applies to *your* versions. It never runs Gradle or any project code. You can also pick the controller and season manually.

## Sources checked for this release

The documentation websites were not reachable from the development environment, so their official source repositories were read at these revisions:

| Topic | Revision read |
|---|---|
| WPILib data logs, roboRIO (2025) | `wpilibsuite/frc-docs` branch **2025**: `source/docs/software/telemetry/datalog.rst`, `datalog-download.rst` |
| WPILib DataLogManager (2026) | `wpilibsuite/allwpilib` tag **v2026.2.2**: `wpilibj/.../DataLogManager.java` (Javadoc and code) |
| WPILib data logs, Systemcore (2027) | `wpilibsuite/frc-docs` branches **2027** / **main**: `datalog-download.rst`, `datalog.rst` |
| WPILOG file format 1.0 | allwpilib v2026.2.2 `wpiutil/doc/datalog.adoc` |
| CTRE signal logging | `CrossTheRoadElec/Phoenix6-Documentation` tag **2025** and **main** (2026 at the time read): `signal-logging.rst`, `tuner/tools/log-extractor.rst` |
| NI Driver Station logs | frc-docs **2025** `driverstation/driver-station-log-viewer.rst`; AdvantageScope `DSLogReader.ts` / `DSEventsReader.ts` (BSD-3) |
| FIRST Driver Station (2027) | frc-docs **main** `firstdriverstation/first-driver-station-log-viewer.rst` |
| AdvantageKit | `Mechanical-Advantage/AdvantageKit` main (Oct 2026), `WPILOGWriter.java`, `WPILOGConstants.java` |
| REV `.revlog` | REV's `@rev-robotics/revlog-converter` **2.0.0** (BSD-3) README and parser. **The REV documentation site (docs.revrobotics.com) could not be read.** |

## Robot controller

| | roboRIO (WPILib 2025/2026) | Systemcore (WPILib 2027) |
|---|---|---|
| WPILib log folders | `/home/lvuser/logs`, or `/u/logs` when a USB drive is attached | `/home/systemcore/logs` or `/u/logs` |
| SFTP login documented by WPILib | user `lvuser`, blank password | user `systemcore`, password `systemcore` |
| Default address | `roborio-TEAM-frc.local`, `10.TE.AM.2`, USB `172.22.11.2` | `robot.local` |
| File names | `FRC_TBD_{random}.wpilog`, renamed `FRC_yyyyMMdd_HHmmss[_{event}_{match}].wpilog` once the DS connects (time is UTC) | Same pattern with the prefix `WPILib_` |

DataLogManager deletes all `FRC_TBD_*` files at program startup, and deletes old `FRC_` files when free space drops below 50 MB. **Collect promptly.** Files deleted before collection appear as gaps.

### WPILib DataLogManager (if not already enabled)

WPILib documents that "by default, no telemetry data is recorded (saved) on the robot." A one-time change your team can choose to make (proposed, not applied by the collector):

```java
// Robot constructor or robotInit()
DataLogManager.start();
DriverStation.startDataLog(DataLogManager.getLog()); // optional: DS control and joystick data
```

DataLogManager also records the robot's system time every ~5 s in the `systemTime` entry. The collector reports whether that entry exists. It does not use it to align clocks.

### AdvantageKit

`WPILOGWriter` defaults to **`/U/logs`** on the robot. Files are named `akit_*.wpilog` and renamed once the time is known. Its WPILOG files carry the extra header `AdvantageKit`, which the collector reports as a producer hint. Add `/U/logs` as an authorized folder.

### CTRE Phoenix 6 signal logger (`.hoot`)

Behavior depends on the Phoenix version:

* **2025 docs:** logging starts automatically **only during an FRC match**. Call `SignalLogger.start()` to log practice.
* **2026 docs (main):** enabled by default on a **roboRIO 2**, or a roboRIO 1 with a USB drive, once the robot is enabled or the DS connects (after the startup delay).
* `SignalLogger.enableAutoLogging(false)` turns that off. `SignalLogger.setPath("/media/sda1/ctre-logs/")` chooses the folder.
* Each CAN bus gets its own file, in a **date/time subfolder**, so keep the recursive depth at 1 or more.
* The CTRE documentation read does **not** state the default folder. Confirm where `.hoot` files appear on your robot and authorize that folder.
* When free space falls to 50 MB, old logs are deleted. At 5 MB, logging stops.
* Converting `.hoot` requires CTRE's Owlet or Tuner X. AdvantageScope's integration runs `owlet <in.hoot> <out.wpilog> -f wpilog` and picks an Owlet build that matches the file. If you install Owlet and set its path in Setup, export can add a derived WPILOG. That integration was only tested with a stand-in program, so real Owlet is **UNVERIFIED**. The collector never bundles or downloads Owlet and is subject to CTRE's license terms.

### REV StatusLogger (`.revlog`)

REV's converter documents REVLOG **version 1** (REVLib 2025 through 2027.0.0-alpha-8) and **version 2** (later releases); the collector identifies which one a file is. Because REV's documentation site could not be read, the collector does **not** assert when REVLib logs or where it writes; check the REVLib documentation for your version and authorize that folder. URCL (`URCL.start()`) instead puts REV data into the WPILib WPILOG.

## Driver Station computer

| Driver Station | Files | Folder |
|---|---|---|
| NI FRC Driver Station (2010–2026) | `.dslog` + `.dsevents` pairs (version 4 = current) | `C:\Users\Public\Documents\FRC\Log Files` |
| NI DS "Upload WPILogs" (2025 docs) | robot `.wpilog` copies | `C:\Users\Public\Documents\FRC\Log Files\WPILogs` |
| FIRST Driver Station (2027) | `.wpilog` with `FIRST_DS` in the name | `Public Documents\FIRSTDriverStation\Logs` (Windows) or `~/.firstds` |

The collector identifies DS files by **content**:
* version 4 is accepted by PitRelay's `dslog_v4`/`dsevents_v4` adapters;
* version 3 is flagged as legacy;
* anything else is reported as unrecognized, even with a `.dslog` name;
* a WPILOG named `.dslog` is identified as WPILOG.

Run the collector **on the Driver Station laptop** for these folders, or share the folder and add the mounted share as a local source on another computer.

## Coprocessors and vendor tools

Any SFTP-capable coprocessor can be added as an SFTP source with its own pinned key and only its log folder authorized. Folders where AdvantageScope, Phoenix Tuner X or the REV Hardware Client save downloaded logs can be added as local sources. Enable **CSV** only for folders that hold CSV exports you want analyzed.
