# Testing: commands, results and limits

All test data is **synthetic** and labelled so inside the files. During development the collector never connected to a real robot. The "robot" is a local SSH/SFTP server (`tests/sftp_server.py`) on `127.0.0.1` speaking the real protocol through paramiko, plus temporary folders standing in for a Driver Station.

## How to run

```bash
python -m venv .venv && .venv/bin/pip install -e '.[test]'
.venv/bin/python -m pytest -q                                   # full suite (engine tests SKIP without a jar)
PITRELAY_ENGINE_JAR=/path/to/pitrelay/engine/pitrelay.jar \
  .venv/bin/python -m pytest -q                                 # adds the real PitRelay handoff tests (needs Java 17+)
.venv/bin/python samples/make_sample.py                         # regenerates samples/pitrelay-collection-sample.zip (+ .sha256)
.venv/bin/python tools/mutants.py                               # re-runs the mutation checks (every mutant must be killed)
PLAYWRIGHT_MODULE=$(npm root -g)/playwright sh tools/ui_smoke/run.sh   # optional browser check of the UI
```

## Results recorded for this release (2026-10-23)

Environment: Linux 6.18 x86_64, CPython 3.13.16 / 3.11 / 3.10.20, paramiko 5.1.0, keyring 25.7.0, OpenJDK 21.0.12, PitRelay v11 jar `66de12d3…c5d2`.

| Command | Result |
|---|---|
| `pytest` with `PITRELAY_ENGINE_JAR` set, Python 3.13.16 | **173 passed** (48 s) |
| Same, Python 3.11.17 | **173 passed** |
| Same, Python 3.10.20 | **173 passed** |
| `pytest` without an engine jar, Python 3.13.16 | **170 passed, 3 skipped** (the engine tests; reported as SKIPPED, not PASS) |
| `python tools/mutants.py`: 15 defects found by the reviews, reintroduced one at a time | **15 of 15 killed** (each makes the tests fail) |
| `tools/ui_smoke/run.sh` (headless Chromium 1194, Playwright 1.56.1) | **PASS**; details below |
| `samples/make_sample.py`, then `pitrelay-collector verify` on the result | **PASS** (14 files, 9 captures verified; `tests/test_sample.py` checks the shipped sample and its `.sha256`) |
| `scripts/install-macos.sh` with a temporary `HOME` on Linux | **PASS** (POSIX shell logic and paths with spaces only; not macOS) |

### Coverage by requirement

| Requirement | Tests |
|---|---|
| Every collected extension, with parser-support distinctions by content | `test_formats.py` (14): WPILOG 1.0, version ≠ 1.0, fake `.wpilog`; AdvantageKit header hint; DS v4 / v3 / unknown / WPILOG named `.dslog` / dslog named `.dsevents`; REVLOG v1 and v2; hoot; CSV; text; empty; oversize and index-budget flags |
| Multiple sources and filename collisions | `test_same_filename_on_two_sources_stays_separate`, `test_collisions_and_unsafe_names` (case-insensitive collisions, `CON`, spaces and `;` in names, `same_bytes_as`) |
| Disconnect, reconnect, backoff and interrupted downloads | `test_disconnect_backoff_and_reconnect`, `test_drop_mid_transfer_then_resume` (SFTP); `test_connection_failure_mid_transfer_resumes`, `test_missing_folder_is_disconnected_then_recovers` (local) |
| Growth, active files, incomplete final record, same-path replacement, rename, rotation, truncation | `test_growth_is_fetched_incrementally`, `test_rename_while_growing_follows_the_same_recording`, `test_remote_rename_while_growing_and_missing_usb_folder`, `test_rotation_keeps_both_versions`, `test_truncation_and_replacement_never_overwrite_history`, `test_incomplete_final_record_is_partial_not_complete`, `test_unrelated_file_with_same_prefix_is_not_mistaken_for_a_rename` |
| Statuses: not complete after a brief stop; unobserved time does not count | `test_status_is_not_complete_after_a_brief_pause`, `test_unobserved_time_does_not_count_toward_complete`, `test_complete_after_reconnect_with_newer_recording`, `test_deleted_before_transfer_reports_exact_gap` |
| Restart recovery and duplicate prevention | `test_restart_recovery_and_no_duplicate_download` (simulated power loss after fsync and before commit, then restart: uncommitted bytes truncated, `unclean_shutdown` recorded, only missing bytes fetched, nothing re-read afterwards) |
| Single owner per store | `test_single_owner_per_store`; also checked by hand: a second `pitrelay-collector run` exits 3 and names the owner |
| Permission denial | `test_permission_denied_file_and_folder` (SFTP server denies a file and a folder, then allows them) |
| Changed remote host identity; no login before trust | `test_unknown_host_key_blocks_before_any_login`, `test_trust_requires_the_presented_fingerprint`, `test_changed_host_key_is_refused` (the server confirms no authentication attempts and no reads) |
| Disk full and quota | `test_disk_full_is_reported_and_state_stays_consistent` (injected ENOSPC), `test_quota_stops_transfers_without_deleting` |
| Unsafe paths and links | `test_links_are_not_followed`, `test_depth_limit`, `test_unsafe_member_names_are_rejected` (8 variants), `test_symlink_entries_are_rejected`, `test_duplicate_and_case_colliding_members`, `test_unlisted_files_and_lying_manifest`, config validation tests |
| Export while collection continues | `test_export_while_collection_continues` (three exports while another thread appends and polls; each is an exact verified prefix) |
| Byte-for-byte preservation and ZIP-manifest verification | `test_voltage_fixture_bytes_and_values_survive_collection_and_export`, `test_tampered_bytes_are_detected`, `test_store_corruption_fails_the_export_and_leaves_nothing`, `test_extract_is_safe_readonly_and_never_overwrites` |
| Oversized, malformed and unsupported recordings | `test_oversized_original_is_preserved_and_flagged` (real 65 MiB file), malformed and corrupt cases in `test_formats.py`, hoot conversion available or unavailable |
| No remote mutation | `test_no_remote_mutation_and_no_commands` (server log: no write, rename or remove ops; no exec, shell or pty); `test_collection_never_modifies_the_source` (local tree contents and mtimes unchanged) |
| Actual PitRelay handoff | `test_pitrelay_engine.py` (3): every routed format accepted; the engine reports **count 5, mean 10.8, min 6.0, max 12.0, unit V**; documents the REVLOG v2 gap |
| Synthetic voltage fixture | 12, 12, 6, 12, 12 V at 0–4 s. Identical bytes in source, store, ZIP and extraction. Decoded independently by the test oracle (mean 10.8, min 6) **and** by PitRelay |
| Credentials and secrets | `test_sources_and_secrets_never_leak`, `test_source_code_inclusion_excludes_credentials_and_never_runs` (a `gradlew` that would create a file is never run) |
| UI access control | `test_requires_session_token`, `test_no_cookie_is_issued_or_accepted`, `test_page_and_script_contain_no_secret`, `test_dns_rebinding_host_is_refused`, `test_cross_origin_changes_are_refused`, `test_index_has_strict_csp`, single-use download tickets, typed delete confirmation, autostart confirmation, `test_browser_is_started_with_a_private_file_not_the_token` |
| Findings of the three independent reviews | `test_review_regressions.py` (first review) and `test_review_round2.py` (second and third reviews, including deletion interrupted by a full disk, a commit racing a deletion, cloud placeholders, handoff integrity, store-version refusal by every command, the split-size limit, the bandwidth limit and credential patterns with punctuation or in very long lines). `tests/test_sample.py` keeps the shipped sample valid. Each test was written against a reproduced defect. Each round-2 test was also checked against a deliberately reintroduced defect (mutant): it fails with the mutant and passes without it. Covered: pause or disable during a transfer (including inside a production-size 4 MiB chunk and from another process); a file rewritten mid-transfer; a same-size rewrite caught before transfer; disk filling mid-chunk; a wrong or missing robot password; storage-full state clearing; CLI configuration edits reaching a running collector; cross-process export/delete locking; store version checks; terminal-control sanitizing; credential patterns in JSON, YAML and constants; nested collision names; links re-pointed after configuration |
| Launch at login is opt-in | `test_cli_init_never_enables_collection_or_autostart`; Windows, macOS and Linux entries generated and parsed (`test_windows_run_key` uses a fake registry; `test_macos_launch_agent` parses the plist) |

### Browser check (`tools/ui_smoke`)

Against the real app, with a fake robot that requires host-key trust and a fake DS folder:
* API without the token → 401, even with the old session cookie; DNS-rebinding `Host` → 403; POST without the `Authorization` header → 401; no cookies set;
* the browser is opened with a single-use launch code: the page exchanges it, it is gone from the address bar afterwards, and opening the same link again is refused; a tab opened without a link shows "not signed in";
* Enable → the robot's SHA256 fingerprint is displayed → Trust → **COLLECTING**, 5 captures;
* folder suggestions follow the Driver Station profile;
* the limits form accepts the shown default ("20.0") and saves 40 GiB;
* export with an observation → "Exported and verified 1 package … 8 files hash-verified"; clicking the file name downloads the ZIP through a single-use ticket;
* no horizontal overflow at 390 px width;
* Stop → **"Stopped / unreachable"** banner.

Browser console errors: only the deliberate 401 and connection-refused after stopping. Fake robot: zero mutations, zero exec requests.

## Not run: prerequisites unavailable

| Item | Status |
|---|---|
| Real roboRIO 1/2 or Systemcore over USB, Ethernet or radio | **NOT_RUN**: no robot available (and not authorized) |
| Real NI Driver Station or FIRST Driver Station writing live logs | **NOT_RUN** |
| Real REVLib `.revlog`, real Phoenix `.hoot`, real AdvantageKit logs | **NOT_RUN**: synthetic stand-ins only. Hoot content is a labelled placeholder |
| CTRE Owlet conversion | **NOT_RUN** with real Owlet. The plumbing was tested with a stand-in executable that copies its input |
| Vendor documentation websites | Unreachable from the build environment (proxy policy). Official source repositories were read instead (see ROBOT_SETUP.md); REV's docs site could not be read at all |

## UNVERIFIED behavior (not exercised on the real platform or client)

* **Windows:**
  * installation, and `pythonw` launch-at-login via the HKCU Run key (the `sys.stdout is None` case is tested on Linux);
  * Windows Credential Manager through `keyring`;
  * full-share (`FILE_SHARE_DELETE`) reads of files the Driver Station is writing;
  * fresh `os.lstat` sizes for files the writer keeps open;
  * junction, mount-point and OneDrive placeholder classification (the reparse-tag logic is unit-tested with synthetic stat values);
  * the `msvcrt` store lock and the `LockFileEx` shared export lock;
  * owner-only store permissions via `icacls`;
  * path handling.
* **macOS:** installation, LaunchAgent at next login, Keychain, privacy prompts for Documents and removable volumes, behavior after sleep and wake, case-insensitive path comparisons (implemented by file identity, `os.path.samefile`).
* **Robots:** blank-password login on a real roboRIO (the implementation tries `none`, then an empty password, then keyboard-interactive), OpenSSH behavior on NI Linux RT and Systemcore, `/u` or `/U` USB mount symlinks, DataLogManager's real rename timing, FAT32 mtime granularity, rotation and deletion behavior of real DataLogManager, CTRE and REV loggers.
* **Throughput** at competition scale (hundreds of MB per event), and the effect of the default 1 MiB/s limit on a busy robot radio.
* **PitRelay:** other engine builds than v11, and concurrent use of one engine `--state` folder.
