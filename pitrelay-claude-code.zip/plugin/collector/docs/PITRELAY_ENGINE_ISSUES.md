# PitRelay v11 engine issues

This document moved to [`../../docs/PITRELAY_ENGINE_ISSUES.md`](../../docs/PITRELAY_ENGINE_ISSUES.md), now that the collector is part of PitRelay for Claude Code. It lists each issue with the observed behavior, a suggested engine fix, and what the collector and the Claude Code host do about it.
