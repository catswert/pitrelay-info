# Installing and starting PitRelay Collector

> **Platform status.** The collector was developed and tested on Linux (Python 3.13). The Windows and macOS steps below follow each platform's standard Python tooling, but they were **not executed on Windows or macOS** for this release. Treat them as **UNVERIFIED** until someone has run them on that OS. Please report what happens.

Requirements: Python **3.10 or newer** and about 50 MB for the program. The store needs disk space for the logs you keep (20 GiB quota by default, adjustable). No administrator rights are needed: everything installs per user.

## Windows 10/11 (UNVERIFIED)

1. Install Python from <https://www.python.org/downloads/windows/>. In the installer, tick **"Add python.exe to PATH"**.
2. Open **PowerShell** and run the following from the folder that contains this project:

   ```powershell
   py -m venv "$env:LOCALAPPDATA\PitRelayCollector\venv"
   & "$env:LOCALAPPDATA\PitRelayCollector\venv\Scripts\python.exe" -m pip install .
   & "$env:LOCALAPPDATA\PitRelayCollector\venv\Scripts\pitrelay-collector.exe" init
   & "$env:LOCALAPPDATA\PitRelayCollector\venv\Scripts\pitrelay-collector.exe" run
   ```

   If `py` picks a Python older than 3.10, use for example `py -3.12 -m venv …`.

   Or run `powershell -NoProfile -ExecutionPolicy Bypass -File scripts\install-windows.ps1`. It performs the same steps, picks Python 3.10 or later, stops at the first failing step, and leaves out the final `run`. Windows' default execution policy blocks unsigned scripts, hence the `-ExecutionPolicy Bypass` for this one invocation.
3. Your browser opens the collector. Keep the PowerShell window open while collecting, or turn on launch at login (below).

On the **Driver Station laptop**, add a *local folder* source for `C:\Users\Public\Documents\FRC\Log Files`. That is where the NI Driver Station (2010–2026) writes `.dslog`/`.dsevents`. Add `...\Log Files\WPILogs` if you use the Driver Station's *Upload WPILogs* feature. For the 2027 FIRST Driver Station, use `C:\Users\Public\Documents\FIRSTDriverStation\Logs`.

Notes:
* The collector opens Driver Station files with full read/write/delete sharing, so it cannot block the Driver Station from rotating or deleting its own logs. (UNVERIFIED on Windows.)
* Passwords are stored in **Windows Credential Manager** under "PitRelayCollector".

## macOS 13+ (UNVERIFIED)

1. Install Python 3.10+ from <https://www.python.org/downloads/macos/> or with Homebrew (`brew install python`).
2. In Terminal, from the project folder:

   ```bash
   python3 -m venv "$HOME/Library/Application Support/PitRelayCollector/venv"
   "$HOME/Library/Application Support/PitRelayCollector/venv/bin/python" -m pip install .
   "$HOME/Library/Application Support/PitRelayCollector/venv/bin/pitrelay-collector" init
   "$HOME/Library/Application Support/PitRelayCollector/venv/bin/pitrelay-collector" run
   ```

   `scripts/install-macos.sh` performs the same steps.
3. If you collect from `Documents`, `Desktop` or a USB drive, macOS may ask to allow access, or may silently deny it to background processes. If a folder shows `permission_denied` on the Status page, grant access in **System Settings → Privacy & Security → Files and Folders** (or Full Disk Access) to the Python executable inside the venv. (UNVERIFIED.)
4. Passwords are stored in the **login Keychain**.

## Linux (development)

```bash
python3 -m venv .venv && .venv/bin/pip install -e '.[test]'
.venv/bin/pitrelay-collector init && .venv/bin/pitrelay-collector run
```

Passwords need a Secret Service keyring (GNOME Keyring, KWallet). Without one, the collector refuses to store passwords rather than writing them to a file. Use blank-password or key-file sources instead.

## Starting automatically (opt-in)

Nothing is set to start at login during installation. To turn it on, use **Setup → Start with this computer → Launch collector at login** (you confirm a dialog), or run:

```bash
pitrelay-collector autostart enable     # status | enable | disable
```

| OS | What it creates | Notes |
|---|---|---|
| Windows | `HKCU\Software\Microsoft\Windows\CurrentVersion\Run\PitRelayCollector` → `pythonw.exe -m pitrelay_collector run --store <store> --no-browser` | No console window. UNVERIFIED. |
| macOS | `~/Library/LaunchAgents/org.pitrelay.collector.plist` (RunAtLoad) | Takes effect at the next login. Disabling removes the file; it does not stop a running collector. UNVERIFIED. |
| Linux | `~/.config/autostart/pitrelay-collector.desktop` | Development only. |

When started at login, the collector runs without opening a browser. Run `pitrelay-collector open-ui` to open it. `pitrelay-collector status` works whether or not it is running and clearly reports **STOPPED** when it is not.

**How the UI sign-in works.** Each run creates a new random session token.
* **Opening the browser.** `run` and `open-ui` give the browser `http://127.0.0.1:<port>/#launch=<code>`. The code works once and expires after a minute. The page exchanges it for the token over a same-origin request. Other local users can read a program's command line, but a code that was already used is worthless to them. This also works with sandboxed (snap or Flatpak) browsers.
* **Keeping the token.** The page keeps the token in session storage for that exact address and port, removes it from the address bar, and sends it in a header on every request. No cookie is used, because browsers would send a cookie to every program listening on 127.0.0.1.
* **Other tabs.** A tab opened without a link shows "not signed in"; run `open-ui` again.
* **No browser opens.** `open-ui --print-url` prints a link with the token itself in the URL fragment (on a terminal only). Paste it into the browser.

## Reaching the robot

* **USB:** `172.22.11.2`. **Ethernet or radio:** `10.TE.AM.2` (team 2658 → `10.26.58.2`). **mDNS:** `roborio-TEAM-frc.local` (roboRIO) or `robot.local` (Systemcore, 2027). List several addresses; they are tried in order and the pinned key is checked on every one.
* For a roboRIO, WPILib documents user **`lvuser` with a blank password** (choose "Blank password"). For Systemcore (2027), WPILib documents user and password **`systemcore`**.
* WPILib's documentation notes that SSH log download does not work wirelessly when the radio firewall is enabled, e.g. on the competition field. Expect the robot source to show *disconnected* during matches and to catch up in the pit. Pause collection if your event asks you to keep the field network quiet. The bandwidth limit (default 1 MiB/s) also applies.
* **Re-imaging the controller changes its host key.** The collector then refuses to connect and shows **host key mismatch**. Confirm that you re-imaged it, then trust the new key.

## Moving the store

The store defaults to `%LOCALAPPDATA%\PitRelayCollector` (Windows), `~/Library/Application Support/PitRelayCollector` (macOS) or `~/.local/share/pitrelay-collector` (Linux). To use a different disk, pass `--store <folder>` to every command, either before or after the command name. If launch at login is on, re-run `autostart enable` with the new `--store`. Keep the store on a **local disk**: network shares may not honor the single-owner lock.

The store holds the UI sign-in file, the configuration and your logs, so it is private to your account: on macOS and Linux its folders are `0700`. On Windows, the first time it opens a store, the collector replaces the store folder's inherited permissions with full control for your account and SYSTEM only (`icacls /inheritance:r`), because a folder such as `D:\PitRelay` would otherwise inherit the drive's permissions, which let other local users read it. **UNVERIFIED on Windows in this release.** If it fails, a warning is logged; check the folder's Security tab.

## Upgrading and uninstalling

* **Upgrade:** stop the collector, run `pip install --upgrade .` in the same venv, then start it again. The store format is versioned, and an incompatible store is refused by every command (`run`, `status`, `export`, `pause`…) rather than reinterpreted.
* **Uninstall:**
  1. Run `pitrelay-collector autostart disable`.
  2. Stop the collector.
  3. Delete the `venv` folder.
  4. Delete the store folder **only if you no longer need the collected logs**.
  5. Remove "PitRelayCollector" entries from Credential Manager or Keychain if you stored passwords.
