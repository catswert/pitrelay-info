"""Package verification, unsafe archives, safe extraction and the PitRelay handoff plan."""

import hashlib
import json
import os
import stat
import zipfile

import pytest

from pitrelay_collector import synthetic
from pitrelay_collector.export import ExportOptions, export_package
from pitrelay_collector.handoff import HandoffError, build_plan, extract_package, plan_text
from pitrelay_collector.package import ROOT, verify_package


@pytest.fixture
def package(env, tmp_path):
    d = tmp_path / "src"
    d.mkdir()
    (d / "voltage.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    (d / "a.dslog").write_bytes(synthetic.dslog_v4(1_760_000_000, 20))
    (d / "a.dsevents").write_bytes(synthetic.dsevents_v4(1_760_000_000, ["x"]))
    (d / "b.revlog").write_bytes(synthetic.revlog_v2())
    (d / "c.hoot").write_bytes(synthetic.fake_hoot())
    (d / "e.csv").write_bytes(b"time_s,voltage\n0,12\n1,12\n2,6\n3,12\n4,12\n")
    env.add_local(d, include_csv=True)
    env.step()
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out"))
    assert res.ok, res.error
    return res.archives[0]["path"]


def rebuild(src, dst, mutate):
    """Copy a package member by member, letting `mutate(name, data)` return [(name, data, attrs)]."""
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, "w") as zout:
        for info in zin.infolist():
            for name, data, mode in mutate(info.filename, zin.read(info)):
                zi = zipfile.ZipInfo(name)
                zi.external_attr = (mode or 0o100644) << 16
                zout.writestr(zi, data)
    return dst


def test_verify_accepts_a_good_package(package):
    rep = verify_package(package)
    assert rep["ok"] and rep["files_checked"] == 9 and not rep["errors"]


def test_tampered_bytes_are_detected(package, tmp_path):
    def flip(name, data):
        if name.endswith("voltage.wpilog"):
            data = data[:-1] + bytes([data[-1] ^ 1])
        return [(name, data, None)]
    bad = rebuild(package, tmp_path / "bad.zip", flip)
    rep = verify_package(bad)
    assert not rep["ok"] and any("SHA-256 mismatch" in e for e in rep["errors"])


@pytest.mark.parametrize("evil", [
    f"{ROOT}/../evil.txt", f"/{ROOT}/abs.txt", f"{ROOT}\\win.txt", f"C:/{ROOT}/x.txt", f"{ROOT}/logs/CON.txt",
    f"{ROOT}/./dot.txt", "outside.txt", f"{ROOT}/logs/a b.txt",
])
def test_unsafe_member_names_are_rejected(package, tmp_path, evil):
    def add(name, data):
        out = [(name, data, None)]
        if name.endswith("README.txt"):
            out.append((evil, b"payload", None))
        return out
    bad = rebuild(package, tmp_path / "bad.zip", add)
    rep = verify_package(bad)
    assert not rep["ok"] and any("unsafe member" in e for e in rep["errors"])
    with pytest.raises(HandoffError):
        extract_package(bad, tmp_path / "dest")
    assert not (tmp_path / "evil.txt").exists() and not (tmp_path / "dest" / ROOT).exists()


def test_symlink_entries_are_rejected(package, tmp_path):
    def add(name, data):
        out = [(name, data, None)]
        if name.endswith("README.txt"):
            out.append((f"{ROOT}/logs/link", b"/etc/passwd", stat.S_IFLNK | 0o777))
        return out
    rep = verify_package(rebuild(package, tmp_path / "bad.zip", add))
    assert any("symbolic link" in e for e in rep["errors"])


def test_duplicate_and_case_colliding_members(package, tmp_path):
    def dup(name, data):
        out = [(name, data, None)]
        if name.endswith("README.txt"):
            out.append((name.replace("README.txt", "readme.TXT"), data, None))
        return out
    rep = verify_package(rebuild(package, tmp_path / "bad.zip", dup))
    assert any("case-insensitive" in e for e in rep["errors"])


def test_unlisted_files_and_lying_manifest(package, tmp_path):
    def extra(name, data):
        out = [(name, data, None)]
        if name.endswith("README.txt"):
            out.append((f"{ROOT}/logs/source-001/smuggled.wpilog", b"WPILOG", None))
        return out
    rep = verify_package(rebuild(package, tmp_path / "bad1.zip", extra))
    assert any("unexpected file" in e for e in rep["errors"])

    def lie(name, data):
        if name.endswith("manifest.json"):
            m = json.loads(data)
            m["captures"][0]["size_bytes"] += 1
            data = json.dumps(m).encode()
        return [(name, data, None)]
    rep = verify_package(rebuild(package, tmp_path / "bad2.zip", lie))
    assert any("size mismatch" in e for e in rep["errors"])


def test_not_a_zip(tmp_path):
    p = tmp_path / "x.zip"
    p.write_bytes(b"not a zip")
    assert not verify_package(p)["ok"]


def test_extract_is_safe_readonly_and_never_overwrites(package, tmp_path):
    dest = tmp_path / "dest"
    res = extract_package(package, dest)
    root = dest / ROOT
    manifest = json.loads((root / "manifest.json").read_text())
    for c in manifest["captures"]:
        p = root / c["archive_path"]
        assert hashlib.sha256(p.read_bytes()).hexdigest() == c["sha256"]
        assert not os.access(p, os.W_OK) or getattr(os, "geteuid", lambda: 1)() == 0  # root ignores permission bits
        assert not (p.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH))
    assert res["files"] == 10
    with pytest.raises(HandoffError):
        extract_package(package, dest)  # existing destination is never overwritten
    assert not [x for x in os.listdir(dest) if x.startswith(".pitrelay-extract-")]


def test_handoff_plan_routes(package):
    manifest = verify_package(package)["manifest"]
    plan = {p["archive_path"].rsplit("/", 1)[1]: p for p in build_plan(manifest)}
    assert plan["voltage.wpilog"]["operation"] == "log.inspect" and plan["voltage.wpilog"]["format_argument"] is None
    assert plan["a.dslog"]["format_argument"] == "dslog_v4"
    assert plan["a.dsevents"]["format_argument"] == "dsevents_v4"
    assert plan["b.revlog"]["format_argument"] == "rev_native"
    assert plan["e.csv"]["operation"] == "log.import_csv"
    assert plan["c.hoot"]["operation"] is None
    text = plan_text(build_plan(manifest))
    assert "dslog_v4" in text and "no engine route" in text
