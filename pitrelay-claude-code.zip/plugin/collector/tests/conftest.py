"""Shared fixtures: deterministic clock, temporary store, simulated sources."""

from __future__ import annotations

import os
import struct
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from pitrelay_collector.collector import Collector  # noqa: E402
from pitrelay_collector.config import CollectorConfig, ConfigManager, SourceConfig  # noqa: E402
from pitrelay_collector.secrets import MemorySecrets  # noqa: E402
from pitrelay_collector.store import Store  # noqa: E402
from pitrelay_collector.util import FakeClock  # noqa: E402


class Env:
    """A collector wired to a temporary store and a fake clock."""

    def __init__(self, base: Path, **cfg_kw):
        self.base = base
        self.store_dir = base / "store"
        self.clock = FakeClock()
        self.store = Store(self.store_dir, self.clock).open_owner()
        self.cm = ConfigManager(self.store_dir)
        defaults = dict(collection_enabled=True, bandwidth_limit_bps=None, active_window_s=60, complete_after_s=600,
                        chunk_bytes=64 * 1024, max_bytes_per_cycle=16 * 1024 * 1024, quota_bytes=1024 * 1024 * 1024,
                        min_free_bytes=0, backoff_initial_s=5, backoff_max_s=300)
        defaults.update(cfg_kw)
        self.cm.save(CollectorConfig(**defaults))
        self.secrets = MemorySecrets()
        self.collector = Collector(self.store, self.cm, clock=self.clock, secrets=self.secrets, jitter=False)

    def add_local(self, directory: Path, alias="ds", sid=None, **kw) -> str:
        sid = sid or f"src-{alias}"
        kw.setdefault("poll_interval_s", 10)

        def add(cfg):
            cfg.sources.append(SourceConfig(id=sid, alias=alias, kind="local", directories=[str(directory)], **kw))
        self.cm.update(add)
        self.store.sync_sources(self.cm.load().sources)
        return sid

    def add_sftp(self, server, alias="robot", dirs=("/home/lvuser/logs",), trusted=True, auth="blank_password", **kw) -> str:
        from pitrelay_collector.sources import key_info
        sid = f"src-{alias}"
        kw.setdefault("poll_interval_s", 10)
        keys = []
        if trusted:
            k = key_info(server.host_key)
            keys = [{"type": k["type"], "fingerprint": k["fingerprint"], "key_b64": k["key_b64"]}]

        def add(cfg):
            cfg.sources.append(SourceConfig(id=sid, alias=alias, kind="sftp", hosts=["127.0.0.1"], port=server.port,
                                            username="lvuser", auth=auth, directories=list(dirs),
                                            trusted_host_keys=keys, **kw))
        self.cm.update(add)
        self.store.sync_sources(self.cm.load().sources)
        return sid

    def step(self, n=1, dt=10.0):
        for _ in range(n):
            self.clock.advance(dt)
            self.collector.tick(force=True)

    def caps(self, **kw):
        return self.store.captures(**kw)

    def data(self, cap) -> bytes:
        return (self.store_dir / cap["data_file"]).read_bytes()

    def events(self, kind=None):
        evs = list(reversed(self.store.events(limit=1000)))
        return [e for e in evs if kind is None or e["kind"] == kind]

    def close(self):
        self.collector.stop(timeout=1)
        self.store.close()


@pytest.fixture
def env(tmp_path):
    e = Env(tmp_path)
    yield e
    e.close()


@pytest.fixture
def make_env(tmp_path):
    made = []

    def make(**kw):
        e = Env(tmp_path / f"env{len(made)}", **kw)
        made.append(e)
        return e
    yield make
    for e in made:
        e.close()


@pytest.fixture
def robot(tmp_path):
    from sftp_server import FakeRobotSFTP
    root = tmp_path / "robotfs"
    (root / "home" / "lvuser" / "logs").mkdir(parents=True)
    srv = FakeRobotSFTP(root).start()
    srv.logs = root / "home" / "lvuser" / "logs"
    yield srv
    srv.stop()


def decode_wpilog_doubles(data: bytes, entry_name: str) -> list[tuple[int, float]]:
    """Independent minimal WPILOG reader (spec 1.0) used only by tests as an oracle."""
    assert data[:6] == b"WPILOG"
    extra = struct.unpack_from("<I", data, 8)[0]
    pos = 12 + extra
    ids = {}
    out = []
    while pos < len(data):
        b = data[pos]
        il, sl, tl = (b & 3) + 1, ((b >> 2) & 3) + 1, ((b >> 4) & 7) + 1
        eid = int.from_bytes(data[pos + 1:pos + 1 + il], "little")
        size = int.from_bytes(data[pos + 1 + il:pos + 1 + il + sl], "little")
        ts = int.from_bytes(data[pos + 1 + il + sl:pos + 1 + il + sl + tl], "little")
        payload = data[pos + 1 + il + sl + tl:pos + 1 + il + sl + tl + size]
        pos += 1 + il + sl + tl + size
        if eid == 0 and payload[0] == 0:
            target = struct.unpack_from("<I", payload, 1)[0]
            nl = struct.unpack_from("<I", payload, 5)[0]
            name = payload[9:9 + nl].decode()
            tl2 = struct.unpack_from("<I", payload, 9 + nl)[0]
            ids[target] = (name, payload[13 + nl:13 + nl + tl2].decode())
        elif eid in ids and ids[eid] == (entry_name, "double"):
            out.append((ts, struct.unpack("<d", payload)[0]))
    return out


def snapshot_tree(root: Path) -> dict:
    """Content, permissions and times of every file and folder under root (to prove nothing was modified)."""
    snap = {}
    for dirpath, dirs, files in os.walk(root):
        for d in dirs:
            p = Path(dirpath) / d
            st = p.lstat()
            snap[str(p.relative_to(root)) + "/"] = ("<dir>", st.st_mode, st.st_uid, st.st_gid, st.st_mtime_ns)
        for f in files:
            p = Path(dirpath) / f
            st = p.lstat()
            snap[str(p.relative_to(root))] = (p.read_bytes() if not p.is_symlink() else b"<link>", st.st_size,
                                              st.st_mtime_ns, st.st_mode, st.st_uid, st.st_gid)
    st = Path(root).lstat()
    snap["."] = ("<root>", st.st_mode, st.st_mtime_ns)
    return snap
