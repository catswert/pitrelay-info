"""A local, in-process SFTP server that stands in for a robot during tests.

It serves a temporary directory read-only, records every request it receives,
and can inject faults: refuse connections (robot off), drop the connection
after N bytes have been read, deny specific paths, or present a different host
key. No real robot or network beyond 127.0.0.1 is involved.
"""

from __future__ import annotations

import os
import socket
import threading

import paramiko
from paramiko.sftp import CMD_NAME, CMD_REALPATH

MUTATING_FLAGS = os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND


class ServerLog:
    def __init__(self):
        self.lock = threading.Lock()
        self.ops: list[tuple] = []

    def add(self, *op):
        with self.lock:
            self.ops.append(op)

    def kinds(self) -> set:
        with self.lock:
            return {op[0] for op in self.ops}

    def of(self, kind) -> list:
        with self.lock:
            return [op for op in self.ops if op[0] == kind]


class _Auth(paramiko.ServerInterface):
    def __init__(self, fake):
        self.fake = fake

    def get_allowed_auths(self, username):
        return "password"

    def check_auth_none(self, username):
        self.fake.log.add("auth_none", username)
        return paramiko.AUTH_FAILED

    def check_auth_password(self, username, password):
        self.fake.log.add("auth_password", username)
        ok = username == self.fake.username and password == self.fake.password
        return paramiko.AUTH_SUCCESSFUL if ok else paramiko.AUTH_FAILED

    def check_channel_request(self, kind, chanid):
        self.fake.log.add("channel", kind)
        return paramiko.OPEN_SUCCEEDED if kind == "session" else paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED

    def check_channel_exec_request(self, channel, command):
        self.fake.log.add("exec", command)
        return False

    def check_channel_shell_request(self, channel):
        self.fake.log.add("shell")
        return False

    def check_channel_pty_request(self, *args):
        self.fake.log.add("pty")
        return False


class _Handle(paramiko.SFTPHandle):
    def __init__(self, fake, path, flags):
        super().__init__(flags)
        self.fake = fake
        self.path = path
        self.readfile = open(path, "rb")

    def read(self, offset, length):
        fake = self.fake
        with fake.lock:
            if fake.drop_after_bytes is not None and fake.bytes_served >= fake.drop_after_bytes:
                fake.drop_after_bytes = None
                fake.kill_connections_soon()
                return paramiko.SFTP_FAILURE
            if fake.drop_after_bytes is not None:
                length = min(length, max(1, fake.drop_after_bytes - fake.bytes_served))
        data = super().read(offset, length)
        if isinstance(data, bytes):
            with fake.lock:
                fake.bytes_served += len(data)
            fake.log.add("read", self.path, offset, len(data))
        return data

    def stat(self):
        return paramiko.SFTPAttributes.from_stat(os.fstat(self.readfile.fileno()))

    def write(self, offset, data):
        self.fake.log.add("MUTATION", "write", self.path)
        return paramiko.SFTP_PERMISSION_DENIED

    def chattr(self, attr):
        self.fake.log.add("MUTATION", "fchattr", self.path)
        return paramiko.SFTP_PERMISSION_DENIED


class _SFTP(paramiko.SFTPServerInterface):
    def __init__(self, server, *args, fake=None, **kwargs):
        super().__init__(server, *args, **kwargs)
        self.fake = fake

    def _real(self, path):
        path = "/" + path.lstrip("/")
        real = os.path.realpath(os.path.join(self.fake.root, path.lstrip("/")))
        root = os.path.realpath(self.fake.root)
        if real != root and not real.startswith(root + os.sep):
            return None
        return real

    def _denied(self, path):
        return any(path == d or path.startswith(d.rstrip("/") + "/") for d in self.fake.deny)

    def canonicalize(self, path):
        self.fake.log.add("realpath", path)
        if self._denied(path):
            return paramiko.SFTP_PERMISSION_DENIED
        real = self._real(path)
        if real is None or not os.path.exists(real):
            return paramiko.SFTP_NO_SUCH_FILE
        rel = os.path.relpath(real, os.path.realpath(self.fake.root))
        return "/" if rel == "." else "/" + rel.replace(os.sep, "/")

    def list_folder(self, path):
        self.fake.log.add("list", path)
        if self._denied(path):
            return paramiko.SFTP_PERMISSION_DENIED
        real = self._real(path)
        if real is None or not os.path.isdir(real):
            return paramiko.SFTP_NO_SUCH_FILE
        out = []
        for name in sorted(os.listdir(real)):
            attr = paramiko.SFTPAttributes.from_stat(os.lstat(os.path.join(real, name)))
            attr.filename = name
            out.append(attr)
        return out

    def stat(self, path):
        real = self._real(path)
        if real is None or not os.path.exists(real):
            return paramiko.SFTP_NO_SUCH_FILE
        return paramiko.SFTPAttributes.from_stat(os.stat(real))

    def lstat(self, path):
        self.fake.log.add("lstat", path)
        if self._denied(path):
            return paramiko.SFTP_PERMISSION_DENIED
        real = self._real(path)
        if real is None or not os.path.lexists(real):
            return paramiko.SFTP_NO_SUCH_FILE
        return paramiko.SFTPAttributes.from_stat(os.lstat(real))

    def open(self, path, flags, attr):
        if flags & MUTATING_FLAGS:
            self.fake.log.add("MUTATION", "open-for-write", path)
            return paramiko.SFTP_PERMISSION_DENIED
        self.fake.log.add("open", path)
        if self._denied(path):
            return paramiko.SFTP_PERMISSION_DENIED
        real = self._real(path)
        if real is None or not os.path.isfile(real):
            return paramiko.SFTP_NO_SUCH_FILE
        return _Handle(self.fake, real, flags)

    def _mutation(self, kind, *args):
        self.fake.log.add("MUTATION", kind, *args)
        return paramiko.SFTP_PERMISSION_DENIED

    def remove(self, path):
        return self._mutation("remove", path)

    def rename(self, oldpath, newpath):
        return self._mutation("rename", oldpath, newpath)

    def posix_rename(self, oldpath, newpath):
        return self._mutation("posix_rename", oldpath, newpath)

    def mkdir(self, path, attr):
        return self._mutation("mkdir", path)

    def rmdir(self, path):
        return self._mutation("rmdir", path)

    def chattr(self, path, attr):
        return self._mutation("chattr", path)

    def symlink(self, target_path, path):
        return self._mutation("symlink", path)


class _FaithfulSFTPServer(paramiko.SFTPServer):
    """paramiko's server ignores error codes from canonicalize(); OpenSSH returns a status."""

    def _process(self, t, request_number, msg):
        if t == CMD_REALPATH:
            path = msg.get_text()
            result = self.server.canonicalize(path)
            if isinstance(result, int):
                self._send_status(request_number, result)
            else:
                self._response(request_number, CMD_NAME, 1, result, "", paramiko.SFTPAttributes())
            return
        return super()._process(t, request_number, msg)


class FakeRobotSFTP:
    def __init__(self, root, username="lvuser", password="", host_key=None, port=0):
        self.root = str(root)
        self.username = username
        self.password = password
        self.host_key = host_key or paramiko.RSAKey.generate(2048)
        self.log = ServerLog()
        self.lock = threading.Lock()
        self.deny: set[str] = set()
        self.drop_after_bytes: int | None = None
        self.bytes_served = 0
        self._port = port
        self._sock = None
        self._thread = None
        self._transports: list = []
        self._running = False

    @property
    def port(self) -> int:
        return self._port

    def start(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind(("127.0.0.1", self._port))
        self._port = self._sock.getsockname()[1]
        self._sock.listen(8)
        self._sock.settimeout(0.1)  # lets the accept loop notice stop() promptly
        self._running = True
        self._thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._thread.start()
        return self

    def _accept_loop(self):
        sock = self._sock
        while self._running:
            try:
                conn, _ = sock.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            if not self._running:
                conn.close()
                return
            conn.settimeout(None)
            t = paramiko.Transport(conn)
            t.add_server_key(self.host_key)
            t.set_subsystem_handler("sftp", _FaithfulSFTPServer, _SFTP, fake=self)
            try:
                t.start_server(server=_Auth(self))
            except Exception:
                t.close()
                continue
            with self.lock:
                self._transports.append(t)

    def kill_connections_soon(self):
        """Drop every live connection (simulates a radio/tether loss)."""
        def kill():
            with self.lock:
                ts, self._transports = list(self._transports), []
            for t in ts:
                t.close()
        threading.Timer(0.01, kill).start()

    def kill_connections(self):
        with self.lock:
            ts, self._transports = list(self._transports), []
        for t in ts:
            t.close()

    def stop(self):
        """Robot powered off: refuse new connections and drop existing ones."""
        self._running = False
        if self._thread is not None:
            self._thread.join(2)
            self._thread = None
        if self._sock is not None:
            try:
                self._sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._sock.close()
            self._sock = None
        self.kill_connections()

    def restart(self, host_key=None):
        """Robot powered back on (optionally re-imaged with a new host key), same port."""
        if host_key is not None:
            self.host_key = host_key
        return self.start()

    def mutations(self) -> list:
        return self.log.of("MUTATION")
