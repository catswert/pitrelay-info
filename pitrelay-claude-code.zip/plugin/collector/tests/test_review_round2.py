"""Regression tests for the second independent review (each defect was reproduced before it was fixed)."""

import errno
import hashlib
import json
import os
import subprocess
import sys
import threading
import time
import zipfile
from pathlib import Path

import pytest

from conftest import Env
from pitrelay_collector import cli, projectscan, sources, synthetic
from pitrelay_collector.app import App
from pitrelay_collector.autostart import Autostart
from pitrelay_collector.collector import Collector
from pitrelay_collector.config import ConfigManager, SourceConfig
from pitrelay_collector.export import ExportOptions, export_package
from pitrelay_collector.package import verify_package
from pitrelay_collector.secrets import MemorySecrets
from pitrelay_collector.sources import SourceUnreachable, key_info
from pitrelay_collector.status import build_status
from pitrelay_collector.store import Store, StoreError

ESC = "\x1b"


@pytest.fixture
def src(tmp_path):
    d = tmp_path / "source"
    d.mkdir()
    return d


def _export(env, tmp_path, **kw):
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", **kw))
    assert res.ok, res.error
    return res.archives[0]["path"]


def _count_reads(monkeypatch, after_n, action):
    """Patch local reads: run `action` once after `after_n` reads; return the read log."""
    orig_open = sources.LocalFS.open
    log = {"reads": 0, "after": 0, "fired": False}

    def patched(self, path):
        r = orig_open(self, path)
        orig = r.read_at

        def read_at(off, n):
            log["reads"] += 1
            if log["fired"]:
                log["after"] += 1
            data = orig(off, n)
            if log["reads"] == after_n and not log["fired"]:
                log["fired"] = True
                action()
            return data
        r.read_at = read_at
        return r
    monkeypatch.setattr(sources.LocalFS, "open", patched)
    return log


# --- pause and disable stop a transfer that is already running ----------------------------


def test_pause_stops_a_transfer_in_progress(env, src, monkeypatch):
    data = os.urandom(2 * 1024 * 1024)
    (src / "big.hoot").write_bytes(data)
    env.add_local(src)
    log = _count_reads(monkeypatch, 3, env.collector.pause)
    env.step()
    cap = env.caps()[0]
    assert cap["committed_size"] == 2 * 64 * 1024  # the chunk being read when pause arrived is committed, nothing after
    assert log["after"] <= 1  # at most the verify re-read of that chunk's head
    assert env.data(cap) == data[:cap["committed_size"]]
    env.step()
    assert env.caps()[0]["committed_size"] == 2 * 64 * 1024  # still paused
    env.collector.resume()
    env.step()
    assert env.data(env.caps()[0]) == data


def test_pause_from_another_process_stops_a_transfer(env, src, monkeypatch):
    (src / "big.hoot").write_bytes(os.urandom(2 * 1024 * 1024))
    env.add_local(src)
    other = Store(env.store_dir).open_reader()  # what `pitrelay-collector pause` does from its own process

    def cli_pause():
        other.conn().execute("INSERT INTO meta(key, value) VALUES('paused', '1') "
                             "ON CONFLICT(key) DO UPDATE SET value=excluded.value")
    log = _count_reads(monkeypatch, 3, cli_pause)
    env.step()
    other.close()
    assert env.caps()[0]["committed_size"] < 2 * 1024 * 1024 and log["after"] <= 1


def test_disable_stops_a_transfer_in_progress(env, src, monkeypatch):
    (src / "big.hoot").write_bytes(os.urandom(2 * 1024 * 1024))
    env.add_local(src)
    log = _count_reads(monkeypatch, 3, lambda: env.collector.set_enabled(False))
    env.step()
    assert env.caps()[0]["committed_size"] < 2 * 1024 * 1024 and log["after"] <= 1


# --- storage-full status is cleared when storage allows ------------------------------------


def test_blocked_state_clears_after_restart_and_for_cli_status(tmp_path, src):
    e = Env(tmp_path / "e", min_free_bytes=1 << 60)  # impossible free-space floor: blocked at once
    e.add_local(src)
    (src / "a.hoot").write_bytes(os.urandom(5000))
    e.step()
    assert e.collector.quota_blocked and e.store.meta_get("quota_blocked")
    assert build_status(e.store, e.cm.load(), None, running_elsewhere=True)["overall"] == "blocked"
    e.cm.update(lambda c: setattr(c, "min_free_bytes", 0))
    # Restart: a new collector instance on the same store.
    e.collector = Collector(e.store, e.cm, clock=e.clock, secrets=e.secrets, jitter=False)
    assert e.collector.quota_blocked  # restored from the catalog...
    e.step()
    assert e.collector.quota_blocked is None and not e.store.meta_get("quota_blocked")  # ...and cleared with an event
    assert e.events("quota_resumed")
    assert build_status(e.store, e.cm.load(), None, running_elsewhere=True)["overall"] == "collecting"
    e.close()


def test_blocked_state_clears_while_the_source_is_offline(tmp_path, src):
    e = Env(tmp_path / "e", quota_bytes=16 * 1024 * 1024, chunk_bytes=1024 * 1024)
    e.add_local(src)
    (src / "a.hoot").write_bytes(os.urandom(17 * 1024 * 1024))
    e.step(2)  # the first poll fills the 16 MiB quota; the next one is refused
    assert build_status(e.store, e.cm.load(), e.collector)["overall"] == "blocked"
    os.rename(src, src.with_name("unplugged"))  # source goes offline
    e.cm.update(lambda c: setattr(c, "quota_bytes", 1024 ** 3))
    e.step()
    st = build_status(e.store, e.cm.load(), e.collector)
    assert st["overall"] == "disconnected" and st["storage"]["blocked"] is None
    assert not [a for a in st["alerts"] if "quota" in (a["message"] or "")]
    e.close()


# --- configuration edits made from another process -------------------------------------------


def test_sources_added_by_another_process_reach_the_catalog_and_exports(env, src, tmp_path):
    env.add_local(src, alias="dsA")
    second = tmp_path / "second"
    second.mkdir()
    (second / "two.wpilog").write_bytes(synthetic.counter_wpilog(50))
    other = ConfigManager(env.store_dir)  # the CLI's own ConfigManager: no in-process listeners fire
    time.sleep(0.01)
    other.update(lambda c: c.sources.append(SourceConfig(id="src-b", alias="dsB", kind="local", directories=[str(second)])))
    os.utime(env.cm.path, (time.time() + 5, time.time() + 5))  # make sure the mtime differs on coarse filesystems
    env.step()
    assert {s["alias"] for s in env.store.known_sources()} == {"dsA", "dsB"}
    m = verify_package(_export(env, tmp_path))["manifest"]
    keys = {s["source_key"]: s["alias"] for s in m["sources"]}
    assert {keys[c["source_key"]] for c in m["captures"]} == {"dsB"}


def test_export_describes_a_source_missing_from_the_catalog(env, src, tmp_path):
    env.add_local(src)
    (src / "a.wpilog").write_bytes(synthetic.counter_wpilog(50))
    env.step()
    with env.store.write() as w:
        w.execute("DELETE FROM sources")  # e.g. a store written before the source was synced
    m = verify_package(_export(env, tmp_path))["manifest"]
    assert m["sources"][0]["alias"] == "ds" and m["captures"][0]["source_key"] == m["sources"][0]["source_key"]


def test_trust_from_the_cli_takes_effect_without_waiting_for_backoff(env, robot):
    (robot.logs / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    env.add_sftp(robot, trusted=False)
    env.step()
    assert env.store.get_source_state("src-robot")["state"] == "host_key_untrusted"
    k = key_info(robot.host_key)

    def trust(c):  # exactly what `pitrelay-collector trust-host` writes, from another process
        c.source_by_id("src-robot").trusted_host_keys = [{"type": k["type"], "fingerprint": k["fingerprint"],
                                                          "key_b64": k["key_b64"]}]
    ConfigManager(env.store_dir).update(trust)
    os.utime(env.cm.path, (time.time() + 5, time.time() + 5))
    env.step(n=1, dt=10)  # far less than the 300 s backoff
    assert env.store.get_source_state("src-robot")["state"] == "connected"
    assert len(env.caps()) == 1


def test_all_sources_disabled_is_not_reported_as_disconnected(env, src):
    env.add_local(src, enabled=False)
    env.step(2)
    st = build_status(env.store, env.cm.load(), env.collector)
    assert st["overall"] == "sources_disabled" and "disabled" in st["overall_help"]


# --- integrity reporting ------------------------------------------------------------------------


def test_every_committed_chunk_counts_its_checks(env, src, tmp_path):
    (src / "a.hoot").write_bytes(os.urandom(300 * 1024))
    env.add_local(src)
    env.step()
    cap = env.caps()[0]
    n = len(env.store.segments(cap["id"]))
    assert n == 5
    counts = cap["checks"]["counts"]
    assert counts["post_chunk_head:match"] == n and counts["segment_sha256:recorded"] == n
    m = verify_package(_export(env, tmp_path))["manifest"]
    assert m["captures"][0]["acquisition"]["consistency_checks"]["performed"]["post_chunk_head:match"] == n


def test_reader_refuses_an_unsupported_store_version(env, src, tmp_path):
    env.store.meta_set("schema_version", "2")
    with pytest.raises(StoreError, match="not supported"):
        Store(env.store_dir).open_reader()
    assert cli.main(["status", "--store", str(env.store_dir)]) == 1
    assert cli.main(["export", "--store", str(env.store_dir), "--out", str(tmp_path / "o")]) == 1
    assert not (tmp_path / "o").exists() or not list((tmp_path / "o").glob("*.zip"))
    env.store.meta_set("schema_version", "1")


def test_authorized_folder_that_now_resolves_somewhere_too_broad_is_refused(env, tmp_path):
    real = tmp_path / "real_logs"
    real.mkdir()
    (real / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    link = tmp_path / "usb_logs"
    link.symlink_to(real)
    env.add_local(link)
    env.step()
    assert len(env.caps()) == 1
    link.unlink()
    link.symlink_to(env.store_dir)  # re-pointed after configuration (e.g. a remounted drive)
    env.step()
    st = list(env.store.get_source_state("src-ds")["dirs"].values())[0]
    assert st["status"].startswith("refused:") and "store" in st["status"]
    assert len(env.caps()) == 1 and env.events("folder_refused")
    assert env.caps()[0]["presence"] == "present"  # an unresolvable authorization never marks files missing


# --- observations ---------------------------------------------------------------------------------


def test_observations_accept_the_documented_capture_id_form(env, src, tmp_path):
    (src / "a.wpilog").write_bytes(synthetic.counter_wpilog(50))
    env.add_local(src)
    env.step()
    obs = tmp_path / "obs.json"
    obs.write_text(json.dumps({"observations": [
        {"author": "Driver", "text": "stall", "related_capture_ids": ["cap-000001", 1, "x", "cap-99"]}, "not an object"]}))
    rc = cli.main(["export", "--store", str(env.store_dir), "--out", str(tmp_path / "o"), "--observations", str(obs)])
    assert rc == 0
    z = next((tmp_path / "o").glob("*.zip"))
    with zipfile.ZipFile(z) as zf:
        o = json.loads(zf.read("pitrelay-collection/observations.json"))
    assert o["observations"][0]["related_capture_ids"] == ["cap-000001", "cap-000001"]


# --- extraction never overwrites --------------------------------------------------------------------


def test_extract_refuses_a_non_empty_destination(env, src, tmp_path, capsys):
    (src / "a.wpilog").write_bytes(synthetic.counter_wpilog(50))
    env.add_local(src)
    env.step()
    pkg = _export(env, tmp_path)
    dest = tmp_path / "handoff"
    dest.mkdir()
    (dest / "HANDOFF.txt").write_text("MY OWN NOTES")
    assert cli.main(["extract", pkg, str(dest)]) == 1
    assert (dest / "HANDOFF.txt").read_text() == "MY OWN NOTES" and not (dest / "pitrelay-collection").exists()
    fresh = tmp_path / "fresh"
    assert cli.main(["extract", pkg, str(fresh)]) == 0
    assert (fresh / "HANDOFF.txt").exists() and (fresh / "pitrelay-collection" / "manifest.json").exists()


# --- untrusted text never reaches the terminal raw -----------------------------------------------------


def test_verify_output_neutralizes_terminal_controls(env, src, tmp_path, capsys):
    (src / "a.wpilog").write_bytes(synthetic.counter_wpilog(50))
    env.add_local(src)
    env.step()
    pkg = Path(_export(env, tmp_path))
    evil = tmp_path / "evil.zip"
    with zipfile.ZipFile(pkg) as zin, zipfile.ZipFile(evil, "w") as zout:
        for info in zin.infolist():
            data = zin.read(info)
            if info.filename.endswith("/manifest.json"):
                m = json.loads(data)
                m["package_files"].append({"archive_path": "zzz\r\x1b[2K\x1b[1AOK: all good", "size_bytes": 1, "sha256": "0" * 64})
                data = json.dumps(m).encode()
            zout.writestr(info, data)
    capsys.readouterr()
    assert cli.main(["verify", str(evil)]) == 1
    out = capsys.readouterr().out
    assert "VERIFICATION FAILED" in out and ESC not in out and "\r" not in out


def test_remote_error_text_is_neutralized_before_storage(env, tmp_path, capsys):
    def connect(*a, **k):
        raise SourceUnreachable("SSH negotiation with 10.0.0.2 failed: Error reading SSH protocol banner\x1b]0;OWNED\x07")
    env.collector.connect = connect
    env.cm.update(lambda c: c.sources.append(SourceConfig(id="src-r", alias="r", kind="sftp", hosts=["10.0.0.2"],
                                                          username="lvuser", directories=["/home/lvuser/logs"])))
    env.step()
    assert ESC not in env.store.get_source_state("src-r")["last_error"]
    assert all(ESC not in e["message"] for e in env.events())
    capsys.readouterr()
    cli.main(["status", "--store", str(env.store_dir)])
    assert ESC not in capsys.readouterr().out


# --- credentials in selected project source ------------------------------------------------------------


def test_credentials_in_json_yaml_and_constants_are_excluded(tmp_path):
    proj = tmp_path / "robot"
    (proj / "src/main/deploy").mkdir(parents=True)
    (proj / "src/main/java/frc/robot").mkdir(parents=True)
    (proj / "src/main/deploy/config.json").write_text('{"wifi":{"password":"hunter2hunter2"},"tba":{"apiKey":"AbCdEf1234567890"}}')
    (proj / "src/main/deploy/vision.yaml").write_text("camera: front\npassword: hunter2hunter2\n")
    (proj / "src/main/java/frc/robot/Constants.java").write_text('class C { static final String ROBOT_PASSWORD = "abcdef12"; }')
    (proj / "src/main/java/frc/robot/Tba.java").write_text('class T { String kTbaAuthKey = "abcdefgh1234"; }')
    (proj / "src/main/java/frc/robot/Robot.java").write_text("class Robot { void go() { if (password == null) {} } }")
    included, excluded = projectscan.select_source_files(proj)
    assert [i["rel"] for i in included] == ["src/main/java/frc/robot/Robot.java"]
    assert len(excluded) == 4 and all("credential" in x["reason"] for x in excluded)


def test_project_links_are_not_followed(tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "private.java").write_text("class P {}")
    proj = tmp_path / "robot"
    proj.mkdir()
    (proj / "Robot.java").write_text("class Robot {}")
    (proj / "shared").symlink_to(outside, target_is_directory=True)
    included, excluded = projectscan.select_source_files(proj)
    assert [i["rel"] for i in included] == ["Robot.java"]
    assert excluded == [{"rel": "shared/", "reason": "symbolic link or junction (not followed)"}]


# --- launching the UI ------------------------------------------------------------------------------------


def test_run_under_pythonw_has_no_console_and_does_not_crash(tmp_path, monkeypatch):
    monkeypatch.setattr(sys, "stdout", None)
    monkeypatch.setattr(sys, "stderr", None)
    monkeypatch.setattr(App, "wait", lambda self: None)
    monkeypatch.setattr("pitrelay_collector.app.KeyringSecrets", MemorySecrets, raising=False)
    import pitrelay_collector.secrets as secrets_mod
    monkeypatch.setattr(secrets_mod, "KeyringSecrets", MemorySecrets)
    assert cli.main(["run", "--store", str(tmp_path / "store"), "--no-browser", "--port", "0"]) == 0


def test_browser_gets_a_single_use_launch_code_not_the_token(tmp_path, monkeypatch):
    import http.client
    opened = []
    monkeypatch.setattr("webbrowser.open", lambda url, *a, **k: opened.append(url) or True)
    app = App(tmp_path / "store", secrets=MemorySecrets(), autostart=Autostart(system="Linux", home=tmp_path / "h")).open()

    def exchange(code, origin=None):
        c = http.client.HTTPConnection("127.0.0.1", app.ui.port, timeout=10)
        headers = {"Host": f"127.0.0.1:{app.ui.port}", "Content-Type": "application/json"}
        if origin:
            headers["Origin"] = origin
        c.request("POST", "/api/launch", body=json.dumps({"code": code}), headers=headers)
        r = c.getresponse()
        body = json.loads(r.read() or b"{}")
        c.close()
        return r.status, body
    try:
        app.start(ui=True, port=0, open_browser=True)
        assert len(opened) == 1 and "#launch=" in opened[0] and app.ui.token not in opened[0]
        code = opened[0].split("#launch=")[1]
        assert exchange(code, origin="http://evil.example")[0] == 403  # another site cannot exchange it
        status, body = exchange(code)
        assert status == 200 and body["token"] == app.ui.token
        assert exchange(code)[0] == 403  # single use: a copy read from the command line afterwards is worthless
        # `open-ui` from another process asks the running collector for a fresh code over the authenticated API.
        assert cli.main(["open-ui", "--store", str(tmp_path / "store")]) == 0
        assert len(opened) == 2 and "#launch=" in opened[1] and app.ui.token not in opened[1]
        assert exchange(opened[1].split("#launch=")[1])[0] == 200
    finally:
        app.shutdown()
    assert not app.ui_file.exists()


# --- deletion waits for exports running in any process ------------------------------------------------------


def test_deletion_waits_for_an_export_in_another_process(env, src):
    (src / "a.hoot").write_bytes(os.urandom(5000))
    env.add_local(src)
    env.step()
    holder = subprocess.Popen(
        [sys.executable, "-c",
         "import fcntl, sys, time; f = open(sys.argv[1], 'a+b'); fcntl.flock(f.fileno(), fcntl.LOCK_SH); "
         "print('locked', flush=True); time.sleep(1.5)", str(env.store_dir / "exports.lock")],
        stdout=subprocess.PIPE, text=True) if os.name == "posix" else None
    if holder is None:
        pytest.skip("POSIX flock helper")
    assert holder.stdout.readline().strip() == "locked"
    t0 = time.monotonic()
    env.store.delete_captures([env.caps()[0]["id"]], "test")
    waited = time.monotonic() - t0
    holder.wait()
    assert waited >= 1.0  # blocked until the other process's export released its shared lock


def test_concurrent_exports_share_the_lock(env, src, tmp_path):
    (src / "a.hoot").write_bytes(os.urandom(5000))
    env.add_local(src)
    env.step()
    other = Store(env.store_dir).open_reader()
    started = threading.Event()
    release = threading.Event()

    def hold():
        with other.export_guard():
            started.set()
            release.wait(5)
    t = threading.Thread(target=hold)
    t.start()
    started.wait(5)
    t0 = time.monotonic()
    _export(env, tmp_path)  # a second export is not blocked by the first
    assert time.monotonic() - t0 < 4
    release.set()
    t.join()
    other.close()


def test_only_path_redirecting_reparse_points_count_as_links():
    from types import SimpleNamespace as NS
    from pitrelay_collector.sources import is_link_like, is_online_only
    assert is_link_like(NS(st_file_attributes=0x400, st_reparse_tag=0xA000000C), False, False)  # symbolic link
    assert is_link_like(NS(st_file_attributes=0x400, st_reparse_tag=0xA0000003), False, False)  # junction / mount point
    assert not is_link_like(NS(st_file_attributes=0x400, st_reparse_tag=0x9000601A), False, False)  # OneDrive placeholder
    assert is_link_like(NS(st_file_attributes=0x400), False, False)  # unknown tag: not followed
    assert is_online_only(NS(st_file_attributes=0x400 | 0x400000)) and not is_online_only(NS(st_file_attributes=0x400))


# --- gaps found by the test-quality review (each test fails against the mutant it describes) -----------------


def test_file_rewritten_during_a_transfer_is_never_mixed(env, src, monkeypatch):
    old, new = os.urandom(300_000), os.urandom(300_000)
    f = src / "a.hoot"
    f.write_bytes(old)
    env.add_local(src)
    _count_reads(monkeypatch, 3, lambda: f.write_bytes(new))  # rewritten in place while chunk 2 is read
    env.step()
    cap = env.caps()[0]
    assert cap["committed_size"] == 64 * 1024 and env.data(cap) == old[:64 * 1024]
    assert (env.store_dir / cap["data_file"]).stat().st_size == 64 * 1024  # the mixed chunk was rolled back
    assert cap["flags"].get("inconsistent_transfer") and cap["status"] == "uncertain"
    assert cap["checks"]["counts"].get("post_chunk_head:mismatch") == 1 and env.events("changed_during_transfer")


def test_same_size_rewrite_caught_before_transfer_is_recorded_as_replacement(env, src, monkeypatch):
    f = src / "a.hoot"
    first = os.urandom(100_000)
    f.write_bytes(first)
    env.add_local(src)
    env.step()
    grown = first + os.urandom(100_000)
    f.write_bytes(grown)
    st = f.stat()
    rewritten = os.urandom(len(grown))

    def rewrite_keeping_size_and_time():
        f.write_bytes(rewritten)
        os.utime(f, ns=(st.st_atime_ns, st.st_mtime_ns))
    _count_reads(monkeypatch, 1, rewrite_keeping_size_and_time)  # after the prefix re-check, before the transfer
    env.step()
    cap = env.store.get_capture(env.caps()[0]["id"])
    assert cap["checks"]["counts"].get("pre_transfer_head:mismatch") == 1 and cap["committed_size"] == 100_000
    monkeypatch.undo()
    env.step()  # same size and time as listed, yet the change is noticed
    caps = env.store.captures(include_deleted=True)
    old_cap = [c for c in caps if c["id"] == cap["id"]][0]
    fresh = [c for c in caps if c["presence"] == "present"][0]
    assert old_cap["presence"] == "replaced" and env.data(old_cap) == first
    assert fresh["predecessor_id"] == cap["id"] and env.data(fresh) == rewritten


def test_disk_full_in_the_middle_of_a_chunk_leaves_only_committed_bytes(make_env, src, monkeypatch):
    from pitrelay_collector import collector as collector_mod
    env = make_env(chunk_bytes=1024 * 1024)  # a chunk spans several 256 KiB writes, as in production
    data = os.urandom(3 * 1024 * 1024)
    (src / "a.hoot").write_bytes(data)
    env.add_local(src)
    real_open = open
    budget = {"left": 1024 * 1024 + 100_000}

    class FillingFile:
        def __init__(self, fh):
            self.fh = fh

        def write(self, b):
            if budget["left"] < len(b):  # the device fills part-way through this write
                self.fh.write(b[:max(0, budget["left"])])
                budget["left"] = 0
                raise OSError(errno.ENOSPC, "No space left on device")
            budget["left"] -= len(b)
            return self.fh.write(b)

        def __getattr__(self, name):
            return getattr(self.fh, name)

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return self.fh.__exit__(*a)

    monkeypatch.setattr(collector_mod, "open", lambda p, mode="r", *a, **k: FillingFile(real_open(p, mode, *a, **k))
                        if mode == "r+b" else real_open(p, mode, *a, **k), raising=False)
    env.step()
    cap = env.caps()[0]
    assert cap["committed_size"] == 1024 * 1024
    assert (env.store_dir / cap["data_file"]).stat().st_size == cap["committed_size"]
    monkeypatch.undo()
    env.step()
    assert env.data(env.caps()[0]) == data


def test_wrong_or_missing_robot_password_is_an_auth_failure_not_an_outage(env, tmp_path):
    from sftp_server import FakeRobotSFTP
    root = tmp_path / "robotfs"
    (root / "home/lvuser/logs").mkdir(parents=True)
    (root / "home/lvuser/logs/a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    srv = FakeRobotSFTP(root, password="team2658").start()
    try:
        env.add_sftp(srv, auth="password")
        env.step()  # no password stored yet
        st = env.store.get_source_state("src-robot")
        assert st["state"] == "auth_failed" and "No password is stored" in st["last_error"]
        env.secrets.set("src-robot", "password", "wrong")
        env.step(n=1, dt=400)
        st = env.store.get_source_state("src-robot")
        assert st["state"] == "auth_failed" and st["pending_host_key"] is None
        assert any(e["level"] == "error" and e["kind"] == "auth_failed" for e in env.events())
        assert srv.log.of("read") == []
        env.secrets.set("src-robot", "password", "team2658")
        env.step(n=1, dt=400)
        assert env.store.get_source_state("src-robot")["state"] == "connected" and len(env.caps()) == 1
    finally:
        srv.stop()


def test_blank_password_source_against_a_robot_that_needs_a_password(env, tmp_path):
    from sftp_server import FakeRobotSFTP
    root = tmp_path / "robotfs"
    (root / "home/lvuser/logs").mkdir(parents=True)
    srv = FakeRobotSFTP(root, password="team2658").start()
    try:
        env.add_sftp(srv)
        env.step()
        assert env.store.get_source_state("src-robot")["state"] == "auth_failed"
    finally:
        srv.stop()


def test_generated_collision_names_never_collide_again(env, src, tmp_path):
    for name in ("v__c3.wpilog", "v.wpilog", "V.wpilog"):
        (src / name).write_bytes(synthetic.counter_wpilog(10 + len(name)))
        env.add_local(src) if name == "v__c3.wpilog" else None
        env.step()
    assert [c["id"] for c in env.caps()] == [1, 2, 3]
    m = verify_package(_export(env, tmp_path))["manifest"]
    names = [c["archive_path"] for c in m["captures"]]
    assert len({n.casefold() for n in names}) == 3, names


def test_pause_inside_a_production_size_chunk_stops_within_one_read_block(make_env, src, monkeypatch):
    env = make_env(chunk_bytes=4 * 1024 * 1024)  # the default: 16 reads of 256 KiB per chunk
    data = os.urandom(8 * 1024 * 1024)
    (src / "big.hoot").write_bytes(data)
    env.add_local(src)
    log = _count_reads(monkeypatch, 3, env.collector.pause)
    env.step()
    cap = env.caps()[0]
    assert cap["committed_size"] == 3 * 256 * 1024 and log["after"] <= 1
    assert env.data(cap) == data[:cap["committed_size"]]


def test_hostile_ssh_banner_never_reaches_the_terminal_raw(tmp_path):
    """A device answering on a robot address controls the SSH banner that paramiko quotes in its own log."""
    import socket
    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(5)
    port = srv.getsockname()[1]

    def serve():
        for _ in range(3):
            try:
                c, _ = srv.accept()
            except OSError:
                return
            c.sendall(b"SSH-\x1b]0;OWNED\x07-x\r\n")
            c.close()
    threading.Thread(target=serve, daemon=True).start()
    store = tmp_path / "store"
    code = (
        "import sys, time\n"
        "from pitrelay_collector import cli\n"
        f"cli.main(['init', '--store', {str(store)!r}])\n"
        f"cli.main(['source', 'add-sftp', '--store', {str(store)!r}, '--alias', 'robot', '--host', '127.0.0.1', "
        f"'--port', '{port}', '--dir', '/home/lvuser/logs'])\n"
        f"cli.main(['enable', '--store', {str(store)!r}])\n"
        f"cli.main(['trust-host', '--store', {str(store)!r}, '--source', 'robot', '--fingerprint', 'SHA256:x'])\n"
        "from pitrelay_collector.app import App, setup_logging\n"
        "from pitrelay_collector.secrets import MemorySecrets\n"
        f"setup_logging(__import__('pathlib').Path({str(store)!r}))\n"
        f"a = App(__import__('pathlib').Path({str(store)!r}), secrets=MemorySecrets()).open().start(ui=False)\n"
        "time.sleep(3)\n"
        "a.shutdown()\n")
    done = subprocess.run([sys.executable, "-c", code], capture_output=True, timeout=120)
    srv.close()
    out = done.stdout + done.stderr
    assert b"\x1b" not in out and b"\x07" not in out, out[-2000:]
    log = (store / "diagnostics" / "collector.log").read_bytes()
    assert b"\x1b" not in log


def test_a_restart_retries_a_backed_off_source_once(env, robot):
    (robot.logs / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    env.add_sftp(robot, trusted=False)
    env.step()
    assert env.store.get_source_state("src-robot")["state"] == "host_key_untrusted"
    k = key_info(robot.host_key)
    ConfigManager(env.store_dir).update(lambda c: setattr(c.source_by_id("src-robot"), "trusted_host_keys",
                                        [{"type": k["type"], "fingerprint": k["fingerprint"], "key_b64": k["key_b64"]}]))
    os.utime(env.cm.path, (time.time() + 5, time.time() + 5))
    # The collector restarts before it ever sees the new key (e.g. launch at login after a reboot).
    env.collector = Collector(env.store, env.cm, clock=env.clock, secrets=env.secrets, jitter=False)
    env.step(n=1, dt=10)
    assert env.store.get_source_state("src-robot")["state"] == "connected"


def test_verify_accepts_an_extracted_folder_and_detects_changes(env, src, tmp_path, capsys):
    (src / "a.wpilog").write_bytes(synthetic.counter_wpilog(50))
    env.add_local(src)
    env.step()
    pkg = _export(env, tmp_path)
    dest = tmp_path / "handoff"
    assert cli.main(["extract", pkg, str(dest)]) == 0
    capsys.readouterr()
    assert cli.main(["verify", str(dest)]) == 0
    assert "note: extracted folder" in capsys.readouterr().out
    assert cli.main(["verify", str(dest / "pitrelay-collection")]) == 0
    log = next((dest / "pitrelay-collection" / "logs").rglob("*.wpilog"))
    log.chmod(0o644)
    log.write_bytes(log.read_bytes()[:-1] + b"X")
    assert cli.main(["verify", str(dest)]) == 1
    assert "SHA-256 mismatch" in capsys.readouterr().out
    log.write_bytes(synthetic.counter_wpilog(50))
    (dest / "pitrelay-collection" / "extra.txt").write_text("planted")
    assert cli.main(["verify", str(dest)]) == 1
    assert "unexpected file" in capsys.readouterr().out
    (dest / "pitrelay-collection" / "extra.txt").unlink()
    (dest / "pitrelay-collection" / "link").symlink_to("/etc/passwd")
    assert cli.main(["verify", str(dest)]) == 1
    assert "link not allowed" in capsys.readouterr().out


# --- final review round -------------------------------------------------------------------------------------


def test_deletion_interrupted_by_a_full_disk_is_consistent_and_finished_later(env, src, tmp_path, monkeypatch):
    import sqlite3
    (src / "a.hoot").write_bytes(os.urandom(5000))
    (src / "b.hoot").write_bytes(os.urandom(5000))
    env.add_local(src)
    env.step()
    a = [c for c in env.caps() if c["path"].endswith("a.hoot")][0]
    real_write = env.store.write
    calls = {"n": 0}

    def failing_second_write():
        calls["n"] += 1
        if calls["n"] == 2:  # the transaction that drops the segments: SQLITE_FULL
            raise sqlite3.OperationalError("database or disk is full")
        return real_write()
    monkeypatch.setattr(env.store, "write", failing_second_write)
    with pytest.raises(sqlite3.OperationalError):
        env.store.delete_captures([a["id"]], "making room")
    monkeypatch.undo()
    assert env.store.get_capture(a["id"])["deleted_at"] is not None  # the user's deletion stands
    m = verify_package(_export(env, tmp_path))["manifest"]  # exports keep working meanwhile
    assert [c["original_filename"] for c in m["captures"]] == ["b.hoot"]
    env.store.close()  # restart: the half-finished deletion is completed
    env.store = Store(env.store_dir, env.clock).open_owner()
    env.collector.store = env.store
    gone = env.store.get_capture(a["id"])
    assert env.store.segments(a["id"]) == [] and gone["flags"]["deleted_sha256"] == hashlib.sha256((src / "a.hoot").read_bytes()).hexdigest()
    assert not list(env.store_dir.rglob("*.deleting"))
    assert env.store.usage_bytes == env.store._committed_total()


def test_a_failed_first_step_leaves_the_capture_untouched(env, src, monkeypatch):
    import sqlite3
    (src / "a.hoot").write_bytes(os.urandom(5000))
    env.add_local(src)
    env.step()
    cap = env.caps()[0]

    def full():
        raise sqlite3.OperationalError("database or disk is full")
    monkeypatch.setattr(env.store, "write", full)
    with pytest.raises(sqlite3.OperationalError):
        env.store.delete_captures([cap["id"]], "x")
    monkeypatch.undo()
    assert env.store.get_capture(cap["id"])["deleted_at"] is None and env.store.data_path(cap).exists()


def test_a_commit_racing_the_deletion_cannot_change_what_was_deleted(make_env, src, monkeypatch):
    from pitrelay_collector import store as store_mod
    env = make_env(chunk_bytes=64 * 1024, max_bytes_per_cycle=64 * 1024)
    data = os.urandom(300_000)
    (src / "a.hoot").write_bytes(data)
    env.add_local(src)
    env.step()
    cid = env.caps()[0]["id"]
    real_hash = store_mod._sha256_stream

    def hash_while_collecting(f, length, block=1024 * 1024):
        env.step()  # the collector tries to commit the next chunk while the deletion is hashing
        return real_hash(f, length, block)
    monkeypatch.setattr(store_mod, "_sha256_stream", hash_while_collecting)
    env.store.delete_captures([cid], "race")
    monkeypatch.undo()
    c = env.store.get_capture(cid)
    assert c["committed_size"] == 64 * 1024
    assert c["flags"]["deleted_sha256"] == hashlib.sha256(data[:64 * 1024]).hexdigest()
    assert env.store.usage_bytes == env.store._committed_total()


@pytest.mark.parametrize("value", ['"Fr1;Pit-2026!"', '"ab,cd-team-9999"', '"{abc}defgh"', "'a1;b2c3d4e5f6g7'"])
def test_quoted_secrets_with_punctuation_are_excluded(tmp_path, value):
    proj = tmp_path / "robot"
    proj.mkdir()
    (proj / "Constants.java").write_text(f"class C {{ static final String password = {value}; }}")
    (proj / "net.yaml").write_text(f"password: {value}\n")
    included, excluded = projectscan.select_source_files(proj)
    assert included == [] and len(excluded) == 2


def test_credential_scan_is_linear_on_long_word_runs():
    t0 = time.monotonic()
    projectscan._credential_hit("A" * 1_000_000)
    projectscan._credential_hit("x" + "password" * 125_000)
    assert time.monotonic() - t0 < 5  # the previous pattern needed hours for this


def test_a_capture_whose_file_goes_online_only_stays_present_and_is_not_recollected(env, src, monkeypatch):
    data = os.urandom(50_000)
    (src / "a.hoot").write_bytes(data)
    env.add_local(src)
    env.step()
    real = sources.LocalFS.listdir
    reads = {"n": 0}

    def placeholder_listdir(self, path):
        # A cloud placeholder whose listed size and time changed (edited elsewhere while not on this disk).
        return [sources.Entry(e.path, e.name, "online_only", e.size + 1000, e.mtime + 5, e.file_id) if e.name == "a.hoot"
                else e for e in real(self, path)]
    real_open = sources.LocalFS.open

    def counting_open(self, path):
        if path.endswith("a.hoot"):
            reads["n"] += 1  # reading a placeholder would start a cloud download
        return real_open(self, path)
    monkeypatch.setattr(sources.LocalFS, "listdir", placeholder_listdir)
    monkeypatch.setattr(sources.LocalFS, "open", counting_open)
    (src / "new.hoot").write_bytes(os.urandom(100))
    env.step(2)
    a = [c for c in env.caps() if c["path"].endswith("a.hoot")]
    assert len(a) == 1 and a[0]["presence"] == "present" and not env.events("capture_missing")
    assert reads["n"] == 0
    monkeypatch.undo()
    env.step(2)  # hydrated again: same bytes, nothing collected twice
    assert len([c for c in env.store.captures(include_deleted=True) if c["path"].endswith("a.hoot")]) == 1
    assert env.data(a[0]) == data


def test_handoff_refuses_extracted_files_that_no_longer_match_the_manifest(env, src, tmp_path):
    from pitrelay_collector.handoff import HandoffError, handoff_to_engine
    (src / "voltage.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    env.add_local(src)
    env.step()
    pkg = _export(env, tmp_path)
    dest = tmp_path / "hand"
    assert cli.main(["extract", pkg, str(dest)]) == 0
    log = next((dest / "pitrelay-collection" / "logs").rglob("voltage.wpilog"))
    log.chmod(0o644)
    data = bytearray(log.read_bytes())
    data[-1] ^= 0xFF
    log.write_bytes(bytes(data))
    with pytest.raises(HandoffError, match="no longer match"):  # checked before any engine is started
        handoff_to_engine(dest / "pitrelay-collection", "java-not-needed", tmp_path / "no.jar", tmp_path / "st", tmp_path / "o")
    assert cli.main(["handoff", str(dest / "pitrelay-collection"), "--engine-jar", str(tmp_path / "no.jar"),
                     "--state", str(tmp_path / "st"), "--out", str(tmp_path / "o")]) == 1


@pytest.mark.parametrize("argv", [["init"], ["enable"], ["disable"], ["pause"], ["status"], ["source", "list"],
                                  ["source", "add-local", "--alias", "x", "--dir", "/srv/logs"], ["export"],
                                  ["delete-captures", "--id", "1", "--yes"]])
def test_every_store_command_refuses_a_store_from_another_version(tmp_path, argv):
    import sqlite3
    store = tmp_path / "store"
    assert cli.main(["init", "--store", str(store)]) == 0
    c = sqlite3.connect(store / "state.sqlite3")
    c.execute("UPDATE meta SET value='2' WHERE key='schema_version'")
    c.commit()
    c.close()
    before = (store / "config.json").read_bytes()
    assert cli.main(argv + ["--store", str(store)]) == 1
    assert (store / "config.json").read_bytes() == before
    c = sqlite3.connect(store / "state.sqlite3")
    assert c.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0] == "2"
    c.close()


def test_split_limit_counts_source_code_and_warns_when_a_zip_is_still_larger(env, src, tmp_path):
    (src / "a.hoot").write_bytes(os.urandom(1_000_000))
    (src / "b.hoot").write_bytes(os.urandom(100_000))
    env.add_local(src)
    env.step()
    proj = tmp_path / "robot"
    proj.mkdir()
    (proj / "Big.java").write_text("// " + "x" * 600_000)
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", source_project_dir=proj,
                                                                  max_archive_bytes=1024 * 1024))
    assert res.ok, res.error
    sizes = {Path(a["path"]).name: a["size_bytes"] for a in res.archives}
    over = [n for n, sz in sizes.items() if sz > 1024 * 1024]
    assert len(res.archives) >= 2  # the source code is counted in part 1's budget
    for n in over:  # anything still over the limit is reported, never silent
        assert any(n in w for w in res.warnings)


def test_status_shows_where_a_linked_folder_leads(env, tmp_path, capsys):
    real = tmp_path / "real_logs"
    real.mkdir()
    (real / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    (tmp_path / "linked").symlink_to(real)
    env.add_local(tmp_path / "linked")
    env.step()
    capsys.readouterr()
    cli.main(["status", "--store", str(env.store_dir)])
    out = capsys.readouterr().out
    assert f"{tmp_path / 'linked'} -> {real}: ok (1 files)" in out


def test_bandwidth_limit_is_enforced(make_env, src):
    env = make_env(bandwidth_limit_bps=1024 * 1024, chunk_bytes=1024 * 1024, max_bytes_per_cycle=64 * 1024 * 1024)
    data = os.urandom(8 * 1024 * 1024)
    (src / "big.hoot").write_bytes(data)
    env.add_local(src)
    t0 = env.clock.monotonic()
    env.step(dt=0)
    elapsed = env.clock.monotonic() - t0
    assert env.data(env.caps()[0]) == data
    assert elapsed >= 7.5  # 8 MiB at 1 MiB/s (the first second's burst allowance aside)
    env.cm.update(lambda c: setattr(c, "bandwidth_limit_bps", 4 * 1024 * 1024))
    (src / "big2.hoot").write_bytes(os.urandom(8 * 1024 * 1024))
    t0 = env.clock.monotonic()
    env.step(dt=0)
    assert 1.5 <= env.clock.monotonic() - t0 < 4  # a higher limit is honored on the next poll
