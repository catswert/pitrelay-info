"""Format identification: every collected extension, by content, with honest support levels."""

import struct

import pytest

from pitrelay_collector import compat, formats, synthetic


def analyze(tmp_path, name, data, **kw):
    p = tmp_path / "blob"
    p.write_bytes(data)
    return formats.analyze_file(p, len(data), name, **kw)


def test_wpilog_voltage_fixture_structure(tmp_path):
    data = synthetic.voltage_fixture_wpilog()
    r = analyze(tmp_path, "v.wpilog", data)
    assert r["detected_format"] == "wpilog" and r["format_version"] == "1.0"
    assert r["structure"]["records"] == 8 and r["structure"]["data_records"] == 6
    assert r["structure"]["trailing_incomplete_bytes"] == 0
    assert formats.structure_complete(r) is True
    assert r["original_clock"]["first_data_timestamp_us"] == 0
    assert r["original_clock"]["last_data_timestamp_us"] == 4_000_000
    assert {"name": synthetic.VOLTAGE_ENTRY, "type": "double"} in r["details"]["entries"]
    assert "SYNTHETIC" in r["details"]["extra_header"]
    route = compat.pitrelay_route(r, len(data))
    assert route["operation"] == "log.inspect" and route["format_argument"] is None


def test_wpilog_incomplete_final_record(tmp_path):
    data = synthetic.voltage_fixture_wpilog()
    r = analyze(tmp_path, "v.wpilog", data[:-5])
    assert r["structure"]["trailing_incomplete_bytes"] == 9  # a 14-byte final record lost 5 bytes
    assert formats.structure_complete(r) is False
    assert any("final record incomplete" in i for i in r["structure"]["issues"])


def test_wpilog_corrupt_size_claim_is_bounded(tmp_path):
    bad = synthetic.wpilog_header("") + bytes([0b00001100, 1]) + (0xFFFFFFFF).to_bytes(4, "little") + b"\x00"
    r = analyze(tmp_path, "bad.wpilog", bad)
    assert r["structure"]["records"] == 0
    assert r["structure"]["trailing_incomplete_bytes"] == len(bad) - 12


def test_wpilog_large_payload_is_skipped_not_buffered(tmp_path):
    big = synthetic.build_wpilog([(1, "/big", "raw", "")], [(1, 5, b"x" * (3 * 1024 * 1024)), (1, 6, b"y")])
    r = analyze(tmp_path, "big.wpilog", big)
    assert r["structure"]["data_records"] == 2 and r["structure"]["trailing_incomplete_bytes"] == 0
    assert r["details"]["max_record_payload_bytes"] == 3 * 1024 * 1024


def test_advantagekit_hint_from_extra_header_only(tmp_path):
    data = synthetic.build_wpilog([(1, "/RealOutputs/x", "double", "")], [], extra_header="AdvantageKit")
    assert "AdvantageKit" in analyze(tmp_path, "akit_1.wpilog", data)["producer_hint"]
    # A filename alone never establishes the producer.
    plain = synthetic.build_wpilog([(1, "/x", "double", "")], [], extra_header="")
    assert analyze(tmp_path, "akit_2.wpilog", plain)["producer_hint"] is None


def test_wpilog_unsupported_version(tmp_path):
    data = b"WPILOG" + struct.pack("<HI", 0x0200, 0)
    r = analyze(tmp_path, "x.wpilog", data)
    assert r["format_version"] == "2.0" and r["structure"]["checked"] is False
    assert compat.pitrelay_route(r, len(data))["operation"] is None


def test_wpilog_extension_without_signature(tmp_path):
    r = analyze(tmp_path, "fake.wpilog", b"not a log at all")
    assert r["detected_format"] == "unknown" and r["extension_consistent"] is False


def test_dslog_v4_and_dsevents_v4(tmp_path):
    for pd in (0, 25, 33):
        data = synthetic.dslog_v4(1_760_000_000, 50, pd_type=pd)
        r = analyze(tmp_path, "a.dslog", data)
        assert r["label"] == "NI Driver Station dslog v4" and r["structure"]["records"] == 50
        assert r["structure"]["trailing_incomplete_bytes"] == 0
        assert r["original_clock"]["raw_labview_seconds"] == 1_760_000_000 + synthetic.LABVIEW_EPOCH_OFFSET
        assert "not robot time" in r["original_clock"]["note"]
        assert compat.pitrelay_route(r, len(data))["format_argument"] == "dslog_v4"
    ev = synthetic.dsevents_v4(1_760_000_000, ["Info: one", "Warning: two"])
    r = analyze(tmp_path, "a.dsevents", ev)
    assert r["structure"]["records"] == 2 and formats.structure_complete(r)
    assert compat.pitrelay_route(r, len(ev))["format_argument"] == "dsevents_v4"
    assert analyze(tmp_path, "a.dsevents", ev[:-3])["structure"]["trailing_incomplete_bytes"] > 0


def test_ds_versions_are_distinguished_by_content(tmp_path):
    v3 = synthetic.dslog_v4(1_760_000_000, 5, version=3)
    r = analyze(tmp_path, "old.dslog", v3)
    assert r["label"].startswith("legacy NI Driver Station dslog v3")
    assert compat.pitrelay_route(r, len(v3))["operation"] is None
    r = analyze(tmp_path, "new.dslog", b"\x00\x00\x00\x07" + bytes(40))
    assert r["detected_format"] == "unknown" and r["extension_consistent"] is False
    # A newer Driver Station's WPILOG with a .dslog name is identified as WPILOG.
    r = analyze(tmp_path, "renamed.dslog", synthetic.voltage_fixture_wpilog())
    assert r["detected_format"] == "wpilog" and r["extension_consistent"] is False
    # A dslog named .dsevents, and a dsevents named .dslog, are identified by their record structure and routed to
    # the adapter that matches (the engine itself would accept either adapter and report "partial").
    log = synthetic.dslog_v4(1_760_000_000, 10)
    r = analyze(tmp_path, "x.dsevents", log)
    assert r["detected_format"] == "dslog" and r["extension_consistent"] is False and not r["structure"]["stopped_early"]
    assert any("dslog structure although the extension is .dsevents" in e for e in r["evidence"])
    assert compat.pitrelay_route(r, len(log))["format_argument"] == "dslog_v4"
    ev = synthetic.dsevents_v4(1_760_000_000, ["Info: one", "Warning: two"])
    r = analyze(tmp_path, "y.dslog", ev)
    assert r["detected_format"] == "dsevents" and r["extension_consistent"] is False and r["structure"]["records"] == 2
    assert compat.pitrelay_route(r, len(ev))["format_argument"] == "dsevents_v4"
    for pd_type in (0, 25, 33):
        assert formats.ds_content_format(synthetic.dslog_v4(1_760_000_000, 20, pd_type=pd_type)) == "dslog"
    assert formats.ds_content_format(ev) == "dsevents"
    assert formats.ds_content_format(log[:40]) is None  # too short to decide
    # A .dsevents whose records are not events at all still stops the walk and gets no engine route.
    junk = log[:20] + bytes([0x7F] * 64)
    r = analyze(tmp_path, "z.dsevents", junk)
    assert r["structure"]["stopped_early"] and compat.pitrelay_route(r, len(junk))["operation"] is None


def test_revlog_versions(tmp_path):
    r2 = analyze(tmp_path, "a.revlog", synthetic.revlog_v2())
    assert r2["label"] == "REVLOG v2.0" and r2["structure"]["records"] == 4
    route2 = compat.pitrelay_route(r2, 100)
    assert route2["format_argument"] == "rev_native" and any("v2" in x for x in route2["limitations"])
    r1 = analyze(tmp_path, "b.revlog", synthetic.revlog_v1())
    assert r1["format_version"] == "1" and r1["structure"]["records"] == 3
    assert not any("v2" in x for x in compat.pitrelay_route(r1, 100)["limitations"])
    r = analyze(tmp_path, "c.revlog", synthetic.revlog_v2()[:-4])
    assert r["structure"]["trailing_incomplete_bytes"] > 0


def test_hoot_is_collected_but_not_claimed(tmp_path):
    r = analyze(tmp_path, "x.hoot", synthetic.fake_hoot(compliancy=7))
    assert r["detected_format"] == "hoot" and r["format_version"] is None
    assert r["details"]["byte_at_offset_70"] == 7 and "not a CTRE specification" in r["details"]["byte_at_offset_70_note"]
    route = compat.pitrelay_route(r, 256)
    assert route["operation"] is None and any("conversion unavailable" in x for x in route["limitations"])


def test_csv_and_text(tmp_path):
    r = analyze(tmp_path, "x.csv", "Timestamp,Key,Value\n0,a,1\n".encode())
    assert r["detected_format"] == "csv" and r["details"]["header_columns"] == ["Timestamp", "Key", "Value"]
    assert compat.pitrelay_route(r, 30)["operation"] == "log.import_csv"
    assert analyze(tmp_path, "x.csv", b"\xff\xfe\x00bin")["extension_consistent"] is False
    assert analyze(tmp_path, "FRC_UserProgram.log", b"hello\n")["detected_format"] == "text"
    assert analyze(tmp_path, "x.bin", bytes(range(256)))["detected_format"] == "unknown"
    assert analyze(tmp_path, "empty.wpilog", b"")["detected_format"] == "empty"


def test_oversize_is_flagged_without_reading(tmp_path):
    r = analyze(tmp_path, "v.wpilog", synthetic.voltage_fixture_wpilog())
    route = compat.pitrelay_route(r, 65 * 1024 * 1024)
    assert any("64 MiB" in x for x in route["limitations"])


@pytest.mark.parametrize("n", [400_001])
def test_index_budget_warning(tmp_path, n):
    info = {"detected_format": "wpilog", "format_version": "1.0", "structure": {"records": n, "data_records": n},
            "details": {}}
    lim = compat.pitrelay_route(info, 1000)["limitations"]
    assert any("400000 records" in x for x in lim) and any("200000 samples" in x for x in lim)
