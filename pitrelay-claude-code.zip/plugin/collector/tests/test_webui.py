"""Local web UI: access control, cross-site/DNS-rebinding defenses and the main API flows."""

import http.client
import json
import time

import pytest

from pitrelay_collector import synthetic
from pitrelay_collector.app import App
from pitrelay_collector.autostart import Autostart
from pitrelay_collector.config import CollectorConfig, ConfigManager, SourceConfig
from pitrelay_collector.secrets import MemorySecrets


class Client:
    def __init__(self, ui, token=None):
        self.port = ui.port
        self.token = token

    def req(self, method, path, body=None, headers=None, host=None, auth=True):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        h = {"Host": host or f"127.0.0.1:{self.port}"}
        if auth and self.token:
            h["Authorization"] = f"Bearer {self.token}"
        if method == "POST":
            h["Content-Type"] = "application/json"
        h.update(headers or {})
        c.request(method, path, body=json.dumps(body) if body is not None else None, headers=h)
        r = c.getresponse()
        data = r.read()
        c.close()
        return r, data

    def json(self, method, path, body=None, **kw):
        r, data = self.req(method, path, body, **kw)
        return r.status, json.loads(data or b"{}")


@pytest.fixture
def app(tmp_path):
    src = tmp_path / "ds"
    src.mkdir()
    (src / "voltage.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    store = tmp_path / "store"
    store.mkdir()
    cfg = CollectorConfig(collection_enabled=True, bandwidth_limit_bps=None)
    cfg.sources.append(SourceConfig(id="src-ds", alias="ds", kind="local", directories=[str(src)], poll_interval_s=5))
    ConfigManager(store).save(cfg)
    a = App(store, secrets=MemorySecrets(), autostart=Autostart(system="Linux", home=tmp_path / "home")).open()
    a.start(ui=True, port=0)
    for _ in range(100):
        if a.store.captures():
            break
        time.sleep(0.05)
    yield a
    a.shutdown()


@pytest.fixture
def client(app):
    return Client(app.ui, app.ui.token)


def test_requires_session_token(app):
    c = Client(app.ui)
    r, body = c.req("GET", "/api/status")
    assert r.status == 401
    c.token = "wrong"
    assert c.req("GET", "/api/status")[0].status == 401
    assert c.req("POST", "/api/control", {"action": "pause"})[0].status == 401
    assert not app.collector.is_paused()
    # The sign-in link carries the token only in the fragment, which browsers never send to a server.
    assert app.ui.login_url == f"http://127.0.0.1:{app.ui.port}/#token={app.ui.token}"


def test_no_cookie_is_issued_or_accepted(app):
    """Cookies are shared by every port on 127.0.0.1, so they must not carry the credential."""
    c = Client(app.ui)
    for path in ("/", "/static/app.js", "/login?token=" + app.ui.token):
        r, _ = c.req("GET", path)
        assert r.getheader("Set-Cookie") is None
    r, _ = c.req("GET", "/api/status", headers={"Cookie": f"pitrelay_session={app.ui.token}"})
    assert r.status == 401


def test_page_and_script_contain_no_secret(app):
    c = Client(app.ui)
    for path in ("/", "/static/app.js", "/static/style.css"):
        r, data = c.req("GET", path)
        assert r.status == 200 and app.ui.token.encode() not in data


def test_dns_rebinding_host_is_refused(client):
    r, _ = client.req("GET", "/api/status", host=f"attacker.example:{client.port}")
    assert r.status == 403
    r, _ = client.req("POST", "/api/control", {"action": "pause"}, host="evil.example")
    assert r.status == 403


def test_cross_origin_changes_are_refused(app, client):
    status, _ = client.json("POST", "/api/control", {"action": "pause"}, headers={"Origin": "http://evil.example"})
    assert status == 403
    status, _ = client.json("POST", "/api/control", {"action": "pause"}, headers={"Origin": "http://127.0.0.1:1"})
    assert status == 403  # another local port is another origin
    assert not app.collector.is_paused()


def test_index_has_strict_csp(client):
    r, data = client.req("GET", "/")
    assert r.status == 200 and b"/static/app.js" in data
    assert "script-src 'self'" in r.getheader("Content-Security-Policy")
    assert r.getheader("X-Content-Type-Options") == "nosniff"


def test_status_controls_and_events(app, client):
    status, st = client.json("GET", "/api/status")
    assert status == 200 and st["overall"] == "collecting" and st["captures"]["total"] == 1
    assert st["autostart"]["enabled"] is False  # never enabled implicitly
    assert client.json("POST", "/api/control", {"action": "pause"})[0] == 200
    assert client.json("GET", "/api/status")[1]["overall"] == "paused"
    client.json("POST", "/api/control", {"action": "resume"})
    client.json("POST", "/api/control", {"action": "disable"})
    assert client.json("GET", "/api/status")[1]["overall"] == "disabled"
    assert client.json("POST", "/api/control", {"action": "bogus"})[0] == 400


def test_sources_and_secrets_never_leak(app, client, tmp_path):
    status, cfg = client.json("POST", "/api/sources", {"source": {
        "kind": "sftp", "alias": "robot", "role": "robot", "hosts": ["172.22.11.2", "roborio-2658-frc.local"],
        "port": 22, "username": "lvuser", "auth": "password", "directories": ["/home/lvuser/logs"],
        "trusted_host_keys": [{"type": "ssh-rsa", "key_b64": "AAAA", "fingerprint": "SHA256:forged"}]}})
    assert status == 200, cfg
    robot = [s for s in cfg["sources"] if s["alias"] == "robot"][0]
    assert robot["trusted_host_keys"] == []  # keys cannot be injected through the source form
    assert client.json("POST", "/api/secret", {"source_id": robot["id"], "name": "password", "value": "s3cret-pw"})[0] == 200
    for path in ("/api/config", "/api/status"):
        r, data = client.req("GET", path)
        assert b"s3cret-pw" not in data and b"key_b64" not in data
    assert app.secrets.get(robot["id"], "password") == "s3cret-pw"
    assert b"s3cret-pw" not in (app.root / "config.json").read_bytes()
    assert json.loads(client.req("GET", "/api/config")[1])["sources"][1]["has_password"] is True
    status, body = client.json("POST", "/api/sources", {"source": {"kind": "local", "alias": "root", "directories": ["/"]}})
    assert status == 400 and "too broad" in body["error"]


def test_export_download_and_delete(app, client, tmp_path):
    status, body = client.json("POST", "/api/export", {"observations": [{"author": "t", "text": "synthetic"}]})
    job = body["job"]
    for _ in range(100):
        st, j = client.json("GET", f"/api/export/{job}")
        if j["state"] != "running":
            break
        time.sleep(0.05)
    assert j["ok"], j
    path = j["archives"][0]["path"]
    status, t = client.json("POST", "/api/download-ticket", {"path": path})
    assert status == 200 and t["url"].startswith("/download?ticket=")
    r, data = client.req("GET", t["url"], auth=False)  # a browser navigation carries no Authorization header
    assert r.status == 200 and data[:2] == b"PK" and len(data) == j["archives"][0]["size_bytes"]
    assert client.req("GET", t["url"])[0].status == 403  # single use
    assert client.json("POST", "/api/download-ticket", {"path": "/etc/passwd"})[0] == 404
    assert client.req("GET", "/download?path=" + path)[0].status == 403  # paths alone never authorize a download
    caps = client.json("GET", "/api/captures")[1]["captures"]
    assert client.json("POST", "/api/delete-captures", {"ids": [caps[0]["id"]], "confirm": "yes"})[0] == 400
    assert client.json("POST", "/api/delete-captures", {"ids": [caps[0]["id"]], "confirm": "DELETE"})[1]["deleted"] == [caps[0]["id"]]


def test_autostart_requires_explicit_confirmation(app, client, tmp_path):
    status, body = client.json("POST", "/api/autostart", {"enable": True})
    assert status == 400 and not (tmp_path / "home/.config/autostart/pitrelay-collector.desktop").exists()
    status, body = client.json("POST", "/api/autostart", {"enable": True, "confirm": True})
    assert status == 200 and body["enabled"]
    assert client.json("POST", "/api/autostart", {"enable": False})[1]["enabled"] is False


def test_saved_source_id_is_returned_for_follow_up_requests(app, client):
    status, cfg = client.json("POST", "/api/sources", {"source": {
        "kind": "sftp", "alias": "coproc ", "role": "coprocessor", "hosts": ["10.26.58.11"], "port": 22,
        "username": "pi", "auth": "password", "directories": ["/home/pi/logs"]}})
    assert status == 200
    saved = [s for s in cfg["sources"] if s["id"] == cfg["saved_id"]][0]
    assert saved["alias"] == "coproc"  # trimmed by the server; the UI uses saved_id, not the typed alias
    assert client.json("POST", "/api/secret", {"source_id": cfg["saved_id"], "name": "password", "value": "pw"})[0] == 200
    assert app.secrets.get(cfg["saved_id"], "password") == "pw"


def test_static_types_do_not_depend_on_the_platform_registry(app, monkeypatch):
    import mimetypes
    monkeypatch.setattr(mimetypes, "guess_type", lambda *a, **k: ("text/plain", None))  # a bad Windows registry mapping
    c = Client(app.ui)
    assert c.req("GET", "/static/app.js")[0].getheader("Content-Type").startswith("text/javascript")
    assert c.req("GET", "/static/style.css")[0].getheader("Content-Type").startswith("text/css")
