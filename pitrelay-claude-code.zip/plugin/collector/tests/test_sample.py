"""The shipped sample package stays valid and keeps exercising the parts of the schema it documents."""

import hashlib
import json
import zipfile
from pathlib import Path

from pitrelay_collector.package import verify_package

SAMPLE = Path(__file__).resolve().parents[1] / "samples" / "pitrelay-collection-sample.zip"


def test_sample_verifies_and_matches_its_sidecar():
    rep = verify_package(SAMPLE)
    assert rep["ok"], rep["errors"]
    digest, name = (SAMPLE.parent / (SAMPLE.name + ".sha256")).read_text().split()
    assert name == SAMPLE.name and hashlib.sha256(SAMPLE.read_bytes()).hexdigest() == digest


def test_sample_shows_the_documented_cases():
    with zipfile.ZipFile(SAMPLE) as z:
        m = json.loads(z.read("pitrelay-collection/manifest.json"))
    assert m["schema"] == "pitrelay-collection" and m["schema_version"].split(".")[0] == "1"
    assert "SYNTHETIC" in m["package"]["label"] and m["package"]["private_not_anonymized"] is True
    statuses = {c["acquisition"]["status"] for c in m["captures"]}
    assert {"complete", "active", "partial"} <= statuses
    assert any(c["acquisition"]["unrecovered_gap_bytes"] > 0 for c in m["captures"])
    assert any(len(c["name_history"]) > 1 for c in m["captures"])  # a rename followed while growing
    assert {"deleted_by_user"} <= {o["kind"] for o in m["omissions"]}
    assert m["source_code"]["included"] and any(x["relative_path"] == ".env" for x in m["source_code"]["excluded"])
    formats = {c["format"]["detected_format"] for c in m["captures"]}
    assert {"wpilog", "dslog", "dsevents", "revlog", "hoot", "csv"} <= formats
