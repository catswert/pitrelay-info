"""Regressions for the third review round: Driver Station detection on damaged files, the format cache across
analyzer versions, store paths with URI characters, the Systemcore login stored compatibly, network paths,
the credential-store time limit, poll requests from another process, launch-at-login quoting and the
robot-project check."""

from __future__ import annotations

import json
import os
import shutil
import struct
import subprocess
import sys
import threading
import time
from pathlib import Path

import pytest

from pitrelay_collector import formats, secrets, sources, synthetic
from pitrelay_collector.autostart import _desktop_quote
from pitrelay_collector.config import (ConfigError, ConfigManager, SourceConfig, check_proposal, merge_source,
                                       validate_source)
from pitrelay_collector.projectscan import project_root_problem
from pitrelay_collector.store import Store

REPO = Path(__file__).resolve().parents[2]


def _ds_header() -> bytes:
    return struct.pack(">iq", 4, 3_843_000_000) + b"\0" * 8


@pytest.mark.parametrize("name", ["power-loss.dsevents", "power-loss.dslog"])
def test_zero_filled_ds_records_are_not_evidence_of_a_format(tmp_path, name):
    data = _ds_header() + b"\0" * (64 * 14)
    assert formats.ds_content_format(data) is None
    p = tmp_path / name
    p.write_bytes(data)
    info = formats.analyze_file(p, len(data), name)
    named = "dsevents" if name.endswith(".dsevents") else "dslog"
    assert info["detected_format"] == named  # damage keeps the extension's format; it is not rerouted
    assert not any("structure although the extension" in e for e in info["evidence"])


def test_real_ds_files_are_still_told_apart():
    assert formats.ds_content_format(synthetic.dslog_v4(1_760_000_000, 20, pd_type=33)) == "dslog"


def test_format_cache_ignores_analyses_of_another_analyzer_version(tmp_path):
    st = Store(tmp_path / "store").open_owner()
    try:
        st.format_cache_put(1, 10, {"analyzer_version": "1", "detected_format": "dsevents"})
        assert st.format_cache_get(1, 10) is None
        st.format_cache_put(1, 10, {"analyzer_version": formats.ANALYZER_VERSION, "detected_format": "dslog"})
        assert st.format_cache_get(1, 10)["detected_format"] == "dslog"
    finally:
        st.close()


@pytest.mark.parametrize("folder", ["FRC #1234", "logs?2026", "100%"])
def test_store_paths_with_uri_characters(tmp_path, folder):
    root = tmp_path / folder / "store"
    st = Store(root).open_owner()
    st.close()
    before = sorted(p.name for p in tmp_path.iterdir())
    Store(root).check_version()  # opens the catalog read-only through a URI
    assert sorted(p.name for p in tmp_path.iterdir()) == before  # nothing created beside the store


def test_systemcore_login_is_stored_as_a_password_preset():
    src = SourceConfig.from_dict({"id": "src-1", "alias": "sc", "kind": "sftp", "directories": ["/home/systemcore/logs"],
                                  "hosts": ["10.0.0.2"], "username": "systemcore", "auth": "systemcore_default"})
    validate_source(src)
    d = src.to_dict()
    assert d["auth"] == "password" and d["password_preset"] == "systemcore"
    assert src.auth_choice == "systemcore_default"
    # Choosing a password the team set clears the preset; choosing the default again restores it.
    assert merge_source(src, {"auth": "password"}).auth_choice == "password"
    assert merge_source(src, {"auth": "password"}).password_preset is None
    assert merge_source(src, {"alias": "renamed"}).auth_choice == "systemcore_default"
    other = validate_source(merge_source(src, {"auth": "blank_password"}))
    assert other.password_preset is None


def test_previous_collector_release_still_reads_a_config_with_the_systemcore_login(tmp_path):
    """The collector release before the preset (git HEAD's collector) shares the default store: it must still load
    the config and keep collecting from every other source."""
    if shutil.which("git") is None or not (REPO / ".git").exists():
        pytest.skip("needs this project's git history")
    old = tmp_path / "old" / "pitrelay_collector"
    old.mkdir(parents=True)
    listing = subprocess.run(["git", "-C", str(REPO), "ls-tree", "--name-only", "HEAD", "collector/src/pitrelay_collector/"],
                             capture_output=True, text=True)
    if listing.returncode != 0 or "config.py" not in listing.stdout:
        pytest.skip("the previous collector is not in git HEAD")
    for rel in listing.stdout.split():
        if rel.endswith(".py"):
            data = subprocess.run(["git", "-C", str(REPO), "show", f"HEAD:{rel}"], capture_output=True, check=True).stdout
            (old / Path(rel).name).write_bytes(data)
    if b"systemcore_default" in (old / "config.py").read_bytes():
        pytest.skip("git HEAD already contains this change")
    store = tmp_path / "store"
    cm = ConfigManager(store)
    store.mkdir()

    def add(cfg):
        cfg.sources.append(validate_source(SourceConfig.from_dict(
            {"id": "src-sc", "alias": "sc", "kind": "sftp", "directories": ["/home/systemcore/logs"],
             "hosts": ["10.0.0.2"], "username": "systemcore", "auth": "systemcore_default"})))
        cfg.sources.append(SourceConfig(id="src-ds", alias="ds", kind="local", directories=[str(tmp_path / "ds")]))
    cm.update(add)
    probe = ("import sys; from pathlib import Path; from pitrelay_collector.config import ConfigManager, validate_config;"
             "cfg = ConfigManager(Path(sys.argv[1])).load(); validate_config(cfg);"
             "print(sorted((s.alias, s.auth) for s in cfg.sources))")
    done = subprocess.run([sys.executable, "-I", "-B", "-c", f"import sys; sys.path.insert(0, {str(old.parent)!r}); " + probe,
                           str(store)], capture_output=True, text=True, cwd=tmp_path)
    assert done.returncode == 0, done.stderr
    assert done.stdout.strip() == "[('ds', 'blank_password'), ('sc', 'password')]"


class _Transport:
    def __init__(self):
        self.calls = []

    def auth_password(self, user, password, fallback=True):
        self.calls.append(("password", user, password))

    def is_authenticated(self):
        return True


def test_systemcore_preset_logs_in_without_the_credential_store():
    src = validate_source(SourceConfig.from_dict({"id": "src-1", "alias": "sc", "kind": "sftp", "directories": ["/x/logs"],
                                                  "hosts": ["10.0.0.2"], "username": "systemcore",
                                                  "auth": "systemcore_default"}))
    t = _Transport()

    def no_store(*a):
        raise AssertionError("the credential store must not be asked for a documented default login")
    sources._authenticate(t, src, no_store)
    assert t.calls == [("password", "systemcore", "systemcore")]


@pytest.mark.parametrize("path", ["\\\\server\\share\\logs", "//server/share/logs", "\\\\?\\C:\\logs", "\\\\.\\pipe\\x"])
def test_network_and_device_paths_are_refused_before_any_file_access(path, monkeypatch):
    def no_fs(*a, **k):
        raise AssertionError("file system touched")
    monkeypatch.setattr(os.path, "samefile", no_fs)
    monkeypatch.setattr(Path, "resolve", no_fs)
    # Refused as a proposal (on Linux a backslash path already fails as not absolute), with no file access either way;
    # a saved config that names one keeps loading.
    with pytest.raises(ConfigError, match="Network shares|absolute path"):
        check_proposal(validate_source(SourceConfig(id="src-1", alias="ds", kind="local", directories=[path]),
                                       touch_filesystem=False))


def test_key_file_on_a_network_share_is_refused():
    src = SourceConfig(id="src-1", alias="r", kind="sftp", directories=["/home/lvuser/logs"], hosts=["10.0.0.2"],
                       username="lvuser", auth="key", key_file="\\\\server\\keys\\id_ed25519")
    with pytest.raises(ConfigError, match="absolute path on this computer"):
        check_proposal(validate_source(src))


def test_unconfirmed_local_proposal_is_checked_by_spelling_only(tmp_path, monkeypatch):
    store = tmp_path / "store"

    def no_fs(*a, **k):
        raise AssertionError("file system touched")
    monkeypatch.setattr(os.path, "samefile", no_fs)
    monkeypatch.setattr(Path, "resolve", no_fs)
    ok = validate_source(SourceConfig(id="src-1", alias="ds", kind="local", directories=[str(tmp_path / "logs")]),
                         store, touch_filesystem=False)
    assert ok.directories == [str(tmp_path / "logs")]
    for bad in (os.path.expanduser("~"), str(Path(os.path.expanduser("~")).parent), str(store / "captures"), str(tmp_path)):
        with pytest.raises(ConfigError):
            validate_source(SourceConfig(id="src-1", alias="ds", kind="local", directories=[bad]), store,
                            touch_filesystem=False)


def test_credential_store_calls_never_pile_up(monkeypatch):
    release = threading.Event()
    started = []

    def blocked():
        started.append(1)
        release.wait(10)
        return "late"
    try:
        with pytest.raises(secrets.SecretStoreUnavailable, match="did not answer"):
            secrets._bounded(blocked, timeout=0.2)
        t0 = time.monotonic()
        with pytest.raises(secrets.SecretStoreUnavailable, match="has not answered an earlier request"):
            secrets._bounded(blocked, timeout=0.3)
        assert time.monotonic() - t0 < 2
        assert len(started) == 1  # the second call never started another waiting thread
        assert sum(t.name == "pitrelay-keyring" for t in threading.enumerate()) == 1
    finally:
        release.set()
    deadline = time.monotonic() + 5
    while any(t.name == "pitrelay-keyring" for t in threading.enumerate()) and time.monotonic() < deadline:
        time.sleep(0.02)
    assert secrets._bounded(lambda: "answered", timeout=2) == "answered"


def test_locked_credential_store_is_not_reported_as_no_password_stored():
    src = validate_source(SourceConfig(id="src-1", alias="r", kind="sftp", directories=["/home/lvuser/logs"],
                                       hosts=["10.0.0.2"], username="lvuser", auth="password"))

    def locked(*a):
        raise secrets.SecretStoreUnavailable("The system credential store did not answer")
    with pytest.raises(sources.AuthFailed, match="did not answer"):
        sources._authenticate(_Transport(), src, locked)


def test_poll_request_from_another_process_retries_a_source_in_backoff(env, tmp_path):
    folder = tmp_path / "ds"
    folder.mkdir()
    (folder / "a.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    env.cm.update(lambda cfg: setattr(cfg, "collection_enabled", False))
    sid = env.add_local(folder)
    env.store.set_source_state(sid, next_attempt=env.clock.time() + 300, failures=3)
    env.collector._failed_signature[sid] = sources_signature(env, sid)
    env.store.post_request("poll_request", json.dumps({"t": 1, "once": True, "reconnect": False}), "poll_requested", "test")
    env.collector.tick()
    assert env.store.get_source_state(sid)["last_attempt"] is not None
    assert len(env.caps()) == 1


def sources_signature(env, sid):
    from pitrelay_collector.collector import _source_signature
    return _source_signature(env.cm.load().source_by_id(sid))


def test_poll_request_waits_while_paused(env, tmp_path):
    folder = tmp_path / "ds"
    folder.mkdir()
    (folder / "a.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    env.cm.update(lambda cfg: setattr(cfg, "collection_enabled", False))
    env.add_local(folder)
    env.store.post_request("paused", "1", "paused", "test")
    env.store.post_request("poll_request", json.dumps({"t": 2, "once": True, "reconnect": False}), "poll_requested", "test")
    env.collector.tick()
    assert env.caps() == []
    env.store.post_request("paused", "", "resumed", "test")
    env.collector.tick()
    assert len(env.caps()) == 1  # the request was kept and ran on resume


@pytest.mark.parametrize("arg,expected", [
    ("/opt/a b/python3", '"/opt/a b/python3"'),
    ("C:\\x", '"C:\\\\\\\\x"'),  # quoting rule, then the string rule: one backslash becomes four
    ('say "hi"', '"say \\\\"hi\\\\""'),
    ("/store/100%f", '"/store/100%%f"'),
    ("$HOME", '"\\\\$HOME"'),
])
def test_desktop_exec_arguments_follow_the_spec(arg, expected):
    assert _desktop_quote(arg) == expected


def test_desktop_exec_refuses_line_breaks():
    with pytest.raises(ValueError):
        _desktop_quote("/a\nb")


def test_robot_project_check(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    monkeypatch.setenv("USERPROFILE", str(tmp_path / "home"))
    (tmp_path / "home" / "frc" / "robot").mkdir(parents=True)
    robot = tmp_path / "home" / "frc" / "robot"
    assert "does not look like a robot project" in project_root_problem(robot)
    (robot / "build.gradle").write_text("plugins { id 'edu.wpi.first.GradleRIO' version '2026.2.1' }")
    assert project_root_problem(robot) is None
    assert "home folder" in project_root_problem(tmp_path / "home")
    assert "home folder" in project_root_problem(tmp_path)
    hidden = tmp_path / "home" / ".docker"
    hidden.mkdir()
    (hidden / "build.gradle").write_text("")
    assert "hidden" in project_root_problem(hidden)
    py = tmp_path / "home" / "frc" / "pyrobot"
    py.mkdir()
    (py / "pyproject.toml").write_text('[tool.robotpy]\nrobotpy_version = "2026.1.1"\n')
    assert project_root_problem(py) is None


@pytest.mark.parametrize("text,label", [
    ('{"auths": {"ghcr.io": {"auth": "dXNlcjpTM2NyM3QtUGFzc3dvcmQtMTIz"}}}', "registry auth value"),
    ("    client-key-data: LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQo=", "key or certificate data"),
    ('pw = "hunter22"', "assigned pw/pass value"),
])
def test_more_credential_forms_are_left_out(text, label):
    from pitrelay_collector.projectscan import _credential_hit
    assert label in (_credential_hit(text) or "")


@pytest.mark.parametrize("text", ["bypass = true", "compass: north-west", 'author = "Jane Doe"', "double kP = 0.5;",
                                  '"auth": "none"'])
def test_ordinary_robot_code_is_not_mistaken_for_credentials(text):
    from pitrelay_collector.projectscan import _credential_hit
    assert _credential_hit(text) is None


# --- round two -------------------------------------------------------------------------------------------------


from pitrelay_collector.config import CollectorConfig, validate_config  # noqa: E402


@pytest.mark.parametrize("kind,dirs,hosts,patterns,why", [
    ("local", ["//server/share/logs"], [], [], "Network shares"),
    ("local", ["/home/u/.ssh"], [], [], "hidden folder"),
    ("sftp", ["/home/lvuser/.ssh"], ["10.12.34.2"], [], "hidden folder"),
    ("sftp", ["/home/lvuser/logs"], ["010.012.034.002"], [], "numeric address"),
    ("sftp", ["/home/lvuser/logs"], ["2130706433"], [], "numeric address"),
    ("sftp", ["/home/lvuser/logs"], ["0x7f.1"], [], "numeric address"),
    ("local", ["/home/u/logs"], [], ["?*"], "almost any file"),
    ("local", ["/home/u/logs"], [], ["**"], "almost any file"),
    ("local", ["/home/u/logs"], [], ["id_*"], "credential"),
    ("local", ["/home/u/logs"], [], ["*.pem"], "credential"),
])
def test_proposals_are_held_to_stricter_rules(kind, dirs, hosts, patterns, why):
    src = SourceConfig(id="src-1", alias="p", kind=kind, directories=dirs, hosts=hosts, username="lvuser",
                       text_patterns=patterns)
    with pytest.raises(ConfigError, match=why):
        check_proposal(src)


def test_ordinary_proposals_pass_the_stricter_rules():
    for src in (SourceConfig(id="s", alias="r", kind="sftp", directories=["/home/lvuser/logs", "/u/logs"],
                             hosts=["172.22.11.2", "10.12.34.2", "roborio-1234-frc.local"], username="lvuser",
                             text_patterns=["FRC_UserProgram.log", "*.log"]),
                SourceConfig(id="d", alias="ds", kind="local", directories=["/home/u/FRC/Log Files"])):
        check_proposal(src)


def test_a_saved_config_with_older_choices_still_loads(tmp_path):
    """The stricter rules are for new proposals only: a config the person saved (or an older collector wrote) with a
    network share, a hidden folder or a broad pattern keeps loading, so collection never stops over it."""
    cfg = CollectorConfig(sources=[
        SourceConfig(id="src-a", alias="share", kind="local", directories=["//server/share/logs"]),
        SourceConfig(id="src-b", alias="hidden", kind="local", directories=[str(tmp_path / ".logs")], text_patterns=["**"]),
        SourceConfig(id="src-c", alias="keyed", kind="sftp", directories=["/home/lvuser/logs"], hosts=["10.0.0.2"],
                     username="lvuser", auth="password", password_preset="systemcore2099")])
    validate_config(cfg)  # no ConfigError


def test_text_patterns_never_collect_keys_or_hidden_files(env, tmp_path):
    folder = tmp_path / "home-ish"
    folder.mkdir()
    for name in ("FRC_UserProgram.log", "id_ed25519", ".env", "server.key", "notes.txt"):
        (folder / name).write_text("x")
    env.add_local(folder, text_patterns=["**"])  # as an older config could hold it
    env.step()
    names = sorted(c["path"].replace("\\", "/").rsplit("/", 1)[-1] for c in env.caps())
    assert names == ["FRC_UserProgram.log", "notes.txt"]


def _encrypted_key(tmp_path, password: bytes | None):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519
    key = ed25519.Ed25519PrivateKey.generate()
    enc = serialization.BestAvailableEncryption(password) if password else serialization.NoEncryption()
    path = tmp_path / "id_robot"
    path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.OpenSSH, enc))
    return path


class _KeyTransport(_Transport):
    def auth_publickey(self, user, pkey):
        self.calls.append(("publickey", user, pkey.get_name()))


@pytest.mark.parametrize("stored,ok", [("robot-pass", True), (None, False), ("wrong", False)])
def test_an_encrypted_key_is_opened_with_its_stored_passphrase(tmp_path, stored, ok):
    path = _encrypted_key(tmp_path, b"robot-pass")
    src = validate_source(SourceConfig(id="src-k", alias="cop", kind="sftp", directories=["/home/pi/logs"],
                                       hosts=["10.0.0.11"], username="pi", auth="key", key_file=str(path)))
    t = _KeyTransport()
    secret = (lambda sid, name: stored if name == "key_passphrase" else None)
    if ok:
        sources._authenticate(t, src, secret)
        assert t.calls == [("publickey", "pi", "ssh-ed25519")]
    else:
        with pytest.raises(sources.AuthFailed):
            sources._authenticate(t, src, secret)


def test_an_unencrypted_key_never_asks_the_credential_store(tmp_path):
    path = _encrypted_key(tmp_path, None)
    src = validate_source(SourceConfig(id="src-k", alias="cop", kind="sftp", directories=["/home/pi/logs"],
                                       hosts=["10.0.0.11"], username="pi", auth="key", key_file=str(path)))

    def no_store(*a):
        raise AssertionError("not needed for an unencrypted key")
    t = _KeyTransport()
    sources._authenticate(t, src, no_store)
    assert t.calls and t.calls[0][0] == "publickey"


def test_one_sources_unexpected_error_never_stops_the_others(env, tmp_path, monkeypatch):
    folder = tmp_path / "ds"
    folder.mkdir()
    (folder / "a.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    broken = env.add_local(tmp_path / "missing-but-named", alias="broken")
    env.add_local(folder, alias="ds")
    real = env.collector._get_fs

    def get_fs(src, cfg):
        if src.id == broken:
            raise TypeError("a library failed in an unexpected way")
        return real(src, cfg)
    monkeypatch.setattr(env.collector, "_get_fs", get_fs)
    env.step()
    assert len(env.caps()) == 1
    st = env.store.get_source_state(broken)
    assert st["state"] == "error" and "Unexpected error: TypeError" in st["last_error"]


def test_an_unknown_login_preset_fails_that_source_only():
    src = SourceConfig.from_dict({"id": "src-1", "alias": "sc", "kind": "sftp", "directories": ["/x/logs"],
                                  "hosts": ["10.0.0.2"], "username": "systemcore", "auth": "password",
                                  "password_preset": "systemcore2099"})
    validate_source(src)  # loads: written by a newer collector
    with pytest.raises(sources.AuthFailed, match="does not know"):
        sources._authenticate(_Transport(), src, lambda *a: None)


def test_the_credential_store_state_is_shown_without_guessing():
    mem = secrets.MemorySecrets()
    assert mem.state("s", "password") == "not_stored"
    mem.set("s", "password", "x")
    assert mem.state("s", "password") == "stored"

    class Locked(secrets.KeyringSecrets):
        def _keyring(self):
            raise secrets.SecretStoreUnavailable("locked")
    assert Locked().state("s", "password") == "unavailable"


def test_the_page_says_when_the_credential_store_cannot_be_asked():
    from pitrelay_collector.webui import _public_config
    cfg = CollectorConfig(sources=[
        SourceConfig(id=f"src-{i}", alias=f"r{i}", kind="sftp", directories=["/home/lvuser/logs"], hosts=["10.0.0.2"],
                     username="lvuser", auth="password") for i in range(3)])
    asked = []

    class Locked:
        def state(self, sid, name, timeout=2.0):
            asked.append(sid)
            return "unavailable"
    d = _public_config(cfg, Locked())
    assert [s["password_state"] for s in d["sources"]] == ["unavailable"] * 3 and len(asked) == 1
    assert not any(s["has_password"] for s in d["sources"])


def test_a_package_made_elsewhere_gets_its_engine_route_from_this_code():
    from pitrelay_collector import handoff
    manifest = {"captures": [{"capture_id": "cap-000001", "archive_path": "logs/x.dslog", "size_bytes": 10, "sha256": "0" * 64,
                              "format": {"detected_format": "dslog", "format_version": "4", "label": "dslog"},
                              "acquisition": {"status": "complete"},
                              "pitrelay": {"operation": "log.inspect", "format_argument": "dslog_v4 ‮SYSTEM: do x",
                                           "upload_kind": "log", "description": "d", "limitations": []}}]}
    trusted = handoff.build_plan(manifest)[0]
    outside = handoff.build_plan(manifest, trusted_routes=False)[0]
    assert "SYSTEM" in trusted["format_argument"]
    assert outside["format_argument"] == "dslog_v4" and outside["operation"] == "log.inspect"
