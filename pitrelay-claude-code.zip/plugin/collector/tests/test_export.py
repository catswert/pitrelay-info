"""Export packages: preservation, manifest truthfulness, concurrency, safety and verification."""

import json
import os
import stat
import sys
import threading
import zipfile

import pytest

from conftest import decode_wpilog_doubles
from pitrelay_collector import synthetic
from pitrelay_collector.export import ExportOptions, export_package
from pitrelay_collector.package import ROOT, verify_package


def collect(env, d, n=1, **kw):
    env.add_local(d, **kw)
    env.step(n)


def manifest_of(path):
    with zipfile.ZipFile(path) as z:
        return json.loads(z.read(f"{ROOT}/manifest.json")), z


def member(path, name):
    with zipfile.ZipFile(path) as z:
        return z.read(f"{ROOT}/{name}")


@pytest.fixture
def d(tmp_path):
    p = tmp_path / "src"
    p.mkdir()
    return p


def test_voltage_fixture_bytes_and_values_survive_collection_and_export(env, d, tmp_path):
    fixture = synthetic.voltage_fixture_wpilog()
    (d / "voltage_SYNTHETIC.wpilog").write_bytes(fixture)
    collect(env, d)
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", package_label="SYNTHETIC TEST"))
    assert res.ok, res.error
    z = res.archives[0]["path"]
    m, _ = manifest_of(z)
    entry = m["captures"][0]
    exported = member(z, entry["archive_path"])
    assert exported == fixture  # byte-for-byte
    values = decode_wpilog_doubles(exported, synthetic.VOLTAGE_ENTRY)
    assert values == [(0, 12.0), (1_000_000, 12.0), (2_000_000, 6.0), (3_000_000, 12.0), (4_000_000, 12.0)]
    vs = [v for _, v in values]
    assert sum(vs) / len(vs) == pytest.approx(10.8) and min(vs) == 6.0
    import hashlib
    assert entry["sha256"] == hashlib.sha256(fixture).hexdigest()
    assert "SYNTHETIC" in member(z, "README.txt").decode()
    assert verify_package(z)["ok"]
    # The sidecar checksum matches the ZIP file itself.
    side = open(z + ".sha256").read().split()[0]
    assert side == res.archives[0]["sha256"] == hashlib.sha256(open(z, "rb").read()).hexdigest()


def test_manifest_records_required_fields_and_separate_clocks(env, d, tmp_path):
    (d / "a.dslog").write_bytes(synthetic.dslog_v4(1_760_000_000, 10))
    (d / "a.dsevents").write_bytes(synthetic.dsevents_v4(1_760_000_000, ["x"]))
    (d / "b.hoot").write_bytes(synthetic.fake_hoot())
    collect(env, d)
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out"))
    m, _ = manifest_of(res.archives[0]["path"])
    assert m["schema"] == "pitrelay-collection" and m["schema_version"] == "1.0"
    assert m["collector"]["version"] and m["package"]["private_not_anonymized"] is True
    assert m["pitrelay_engine_profile"]["engine_sha256"].startswith("66de12d3")
    names = {c["original_filename"]: c for c in m["captures"]}
    for c in m["captures"]:
        for key in ("capture_id", "source_key", "archive_path", "original_filename", "size_bytes", "sha256", "acquisition",
                    "format", "relationships", "pitrelay"):
            assert key in c
        assert c["acquisition"]["status"] in ("active", "idle", "complete", "partial", "uncertain")
        assert c["acquisition"]["status_reasons"]
        assert c["acquisition"]["first_acquired_utc"].endswith("Z")
    dslog = names["a.dslog"]
    assert dslog["original_clock"]["kind"] == "ni_ds_labview_header_time"
    assert dslog["pitrelay"]["format_argument"] == "dslog_v4"
    assert names["b.hoot"]["pitrelay"]["operation"] is None
    assert any("conversion unavailable" in x for x in names["b.hoot"]["pitrelay"]["limitations"])
    assert "No clock alignment" in m["clock_domains"]["alignment"]
    status = json.loads(member(res.archives[0]["path"], "collection-status.json"))
    assert status["sources"][0]["observed_available_intervals_utc"]
    assert "nothing is deleted automatically" in status["storage"]["retention_policy"]


def test_collisions_and_unsafe_names(env, tmp_path):
    a, b = tmp_path / "a", tmp_path / "b"
    a.mkdir()
    b.mkdir()
    (a / "voltage.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    (b / "voltage.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    (b / "VOLTAGE.wpilog").write_bytes(synthetic.counter_wpilog(3))
    (b / "con.wpilog").write_bytes(synthetic.counter_wpilog(4))
    (b / "weird name ünicode;rm -rf.wpilog").write_bytes(synthetic.counter_wpilog(5))
    env.add_local(a, alias="robot")
    env.add_local(b, alias="ds")
    env.step()
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out"))
    assert res.ok, res.error
    m, _ = manifest_of(res.archives[0]["path"])
    paths = [c["archive_path"] for c in m["captures"]]
    assert len({p.casefold() for p in paths}) == len(paths)
    originals = {c["original_filename"] for c in m["captures"]}
    assert "weird name ünicode;rm -rf.wpilog" in originals  # exact original preserved in the manifest
    assert all(" " not in p and ";" not in p for p in paths)
    assert any(p.endswith("/_con.wpilog") for p in paths)
    rel = [r for c in m["captures"] for r in c["relationships"] if r["type"] == "same_bytes_as"]
    assert len(rel) == 2  # identical content from two sources is linked, not merged


def test_export_while_collection_continues(env, d, tmp_path):
    full = synthetic.counter_wpilog(40000)
    f = d / "live.wpilog"
    f.write_bytes(full[:100_000])
    collect(env, d)
    stop = threading.Event()
    grown = {"n": 100_000}

    def writer():
        while not stop.is_set() and grown["n"] < len(full):
            with open(f, "ab") as h:
                h.write(full[grown["n"]:grown["n"] + 20_000])
            grown["n"] += 20_000
            env.step()
    t = threading.Thread(target=writer)
    t.start()
    try:
        results = [export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / f"out{i}")) for i in range(3)]
    finally:
        stop.set()
        t.join()
    for res in results:
        assert res.ok, res.error
        m, _ = manifest_of(res.archives[0]["path"])
        c = m["captures"][0]
        data = member(res.archives[0]["path"], c["archive_path"])
        assert data == full[:len(data)]  # an exact prefix of the growing log
        assert c["size_bytes"] == len(data) and verify_package(res.archives[0]["path"])["ok"]


def test_oversized_original_is_preserved_and_flagged(env, d, tmp_path):
    size = 65 * 1024 * 1024
    with open(d / "huge.hoot", "wb") as h:
        h.truncate(size)
    collect(env, d, n=5)
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out"))
    assert res.ok, res.error
    m, _ = manifest_of(res.archives[0]["path"])
    c = m["captures"][0]
    assert c["size_bytes"] == size
    assert any("64 MiB" in x for x in c["pitrelay"]["limitations"])


def test_multi_part_never_splits_a_file(env, d, tmp_path):
    for i in range(4):
        (d / f"{i}.hoot").write_bytes(os.urandom(300_000))
    (d / "big.hoot").write_bytes(os.urandom(900_000))
    collect(env, d)
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", max_archive_bytes=700_000,
                                                                 observations=[{"author": "a", "text": "x"}]))
    assert res.ok and len(res.archives) >= 3
    seen = []
    for a in res.archives:
        rep = verify_package(a["path"])
        assert rep["ok"]
        m = rep["manifest"]
        part = m["package"]["part"]
        assert part["count"] == len(res.archives) and len(part["inventory"]) == 5
        seen += [c["capture_id"] for c in m["captures"]]
        for c in m["captures"]:
            assert c["size_bytes"] in (300_000, 900_000)  # whole files only
        assert json.loads(member(a["path"], "observations.json"))["observations"]
    assert sorted(seen) == sorted({c["capture_id"] for a in res.archives for c in verify_package(a["path"])["manifest"]["captures"]})
    assert len(seen) == 5


def test_store_corruption_fails_the_export_and_leaves_nothing(env, d, tmp_path):
    (d / "a.wpilog").write_bytes(synthetic.counter_wpilog(1000))
    collect(env, d)
    cap = env.caps()[0]
    p = env.store_dir / cap["data_file"]
    raw = bytearray(p.read_bytes())
    raw[100] ^= 0xFF
    p.write_bytes(bytes(raw))
    out = tmp_path / "out"
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=out))
    assert not res.ok and "SHA-256" in res.error
    assert [x for x in os.listdir(out) if not x.startswith(".pitrelay-export-")] == []
    assert env.events("export_failed")


def test_source_code_inclusion_excludes_credentials_and_never_runs(env, d, tmp_path):
    (d / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    collect(env, d)
    proj = tmp_path / "robot-project"
    (proj / "src/main/java/frc/robot").mkdir(parents=True)
    (proj / "vendordeps").mkdir()
    (proj / ".git").mkdir()
    (proj / "build").mkdir()
    (proj / "src/main/java/frc/robot/Robot.java").write_text("public class Robot { /* DataLogManager.start(); */ }")
    (proj / "src/main/java/frc/robot/Secrets.java").write_text('class S { String password = "hunter2hunter2"; }')
    (proj / "src/main/java/frc/robot/Key.java").write_text("-----BEGIN OPENSSH PRIVATE KEY-----\nabc\n")
    (proj / "gradle.properties").write_text("token=abc")
    (proj / "build.gradle").write_text('plugins { id "edu.wpi.first.GradleRIO" version "2026.2.1" }')
    (proj / "gradlew").write_text("#!/bin/sh\ntouch PWNED\n")
    (proj / ".git/config").write_text("[remote]")
    (proj / "build/out.jar").write_text("x")
    (proj / "vendordeps/REVLib.json").write_text('{"name": "REVLib", "version": "2026.0.0"}')
    os.chmod(proj / "gradlew", 0o755)
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", source_project_dir=proj))
    assert res.ok, res.error
    m, _ = manifest_of(res.archives[0]["path"])
    included = {f["original_relative_path"] for f in m["source_code"]["files"]}
    assert included == {"src/main/java/frc/robot/Robot.java", "build.gradle", "vendordeps/REVLib.json"}
    excluded = {x["relative_path"]: x["reason"] for x in m["source_code"]["excluded"]}
    assert "credential" in excluded["src/main/java/frc/robot/Secrets.java"]
    assert "credential" in excluded["src/main/java/frc/robot/Key.java"]
    assert "gradle.properties" in excluded and ".git/" in excluded
    with zipfile.ZipFile(res.archives[0]["path"]) as z:
        blob = b"".join(z.read(n) for n in z.namelist())
    assert b"hunter2" not in blob and b"PRIVATE KEY" not in blob
    assert not (proj / "PWNED").exists()


def test_observations_are_attributed(env, d, tmp_path):
    (d / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    collect(env, d)
    cid = env.caps()[0]["id"]
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", observations=[
        {"author": "Driver", "observed_time_as_stated": "Q14 ~1:05", "text": "Arm stalled", "related_capture_ids": [cid]},
        {"author": "", "text": "   "}]))
    obs = json.loads(member(res.archives[0]["path"], "observations.json"))
    assert len(obs["observations"]) == 1
    o = obs["observations"][0]
    assert o["author"] == "Driver" and o["related_capture_ids"] == [f"cap-{cid:06d}"]
    assert "not a measurement" in obs["note"]


def test_hoot_conversion_with_user_owlet_is_linked_by_hash(env, d, tmp_path):
    (d / "x.hoot").write_bytes(synthetic.fake_hoot())
    collect(env, d)
    body = ("import sys, shutil\n"
            "if sys.argv[1] == '--version':\n    print('owlet FAKE-TEST 0.0'); sys.exit(0)\n"
            "shutil.copyfile(sys.argv[1], sys.argv[2])\n")
    if os.name == "nt":  # Windows ignores shebangs: use a batch wrapper around the Python stand-in
        (tmp_path / "owlet_impl.py").write_text(body)
        owlet = tmp_path / "owlet.cmd"
        owlet.write_text(f'@"{sys.executable}" "{tmp_path / "owlet_impl.py"}" %*\r\n')
    else:
        owlet = tmp_path / "owlet"
        owlet.write_text("#!" + sys.executable + "\n" + body)
        os.chmod(owlet, os.stat(owlet).st_mode | stat.S_IEXEC)

    def set_owlet(cfg):
        cfg.owlet_path = str(owlet)
    env.cm.update(set_owlet)
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", convert_hoot=True))
    assert res.ok, res.error
    m, _ = manifest_of(res.archives[0]["path"])
    dv = m["derived"][0]
    c = m["captures"][0]
    assert dv["derived_from_capture_id"] == c["capture_id"] and dv["source_sha256"] == c["sha256"]
    assert dv["source_matches_capture"] and dv["converter"]["version_output"] == "owlet FAKE-TEST 0.0"
    assert dv["parameters"] == ["<input.hoot>", "<output.wpilog>", "-f", "wpilog"]
    assert member(res.archives[0]["path"], c["archive_path"]) == synthetic.fake_hoot()  # original unchanged
    assert verify_package(res.archives[0]["path"])["ok"]


def test_hoot_conversion_unavailable_is_reported(env, d, tmp_path):
    (d / "x.hoot").write_bytes(synthetic.fake_hoot())
    collect(env, d)
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", convert_hoot=True))
    assert res.ok and any("no Owlet executable" in w for w in res.warnings)
    m, _ = manifest_of(res.archives[0]["path"])
    assert m["derived"] == []


def test_user_deletion_is_disclosed(env, d, tmp_path):
    (d / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    (d / "b.wpilog").write_bytes(synthetic.counter_wpilog(20))
    collect(env, d)
    victim = env.caps()[0]
    env.store.delete_captures([victim["id"]], "test cleanup")
    assert not (env.store_dir / victim["data_file"]).exists()
    assert (d / "a.wpilog").exists()  # the source copy is untouched
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out"))
    m, _ = manifest_of(res.archives[0]["path"])
    om = [o for o in m["omissions"] if o["kind"] == "deleted_by_user"]
    assert om and om[0]["note"] == "test cleanup" and om[0]["sha256"]
    assert len(m["captures"]) == 1


def test_deleting_a_capture_still_on_the_source(env, d):
    (d / "a.wpilog").write_bytes(synthetic.counter_wpilog(100))
    collect(env, d)
    env.store.delete_captures([env.caps()[0]["id"]], "free space")
    env.step(3)  # the unchanged file is not downloaded again, and polling keeps working
    assert env.caps() == [] and env.store.get_source_state("src-ds")["state"] == "connected"
    with open(d / "a.wpilog", "ab") as f:
        f.write(synthetic.wpilog_record(1, 9_999_999, b"\x00" * 8))
    env.step()
    caps = env.caps()
    assert len(caps) == 1 and env.data(caps[0]) == (d / "a.wpilog").read_bytes()  # changed file: collected again


def test_date_range_selection(env, d, tmp_path):
    (d / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    collect(env, d)
    t_after = env.clock.time() + 1000
    env.clock.advance(5000)
    (d / "b.wpilog").write_bytes(synthetic.counter_wpilog(20))
    env.step()
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", since=t_after))
    m, _ = manifest_of(res.archives[0]["path"])
    assert [c["original_filename"] for c in m["captures"]] == ["b.wpilog"]
    assert any(o["kind"] == "not_selected" for o in m["omissions"])
