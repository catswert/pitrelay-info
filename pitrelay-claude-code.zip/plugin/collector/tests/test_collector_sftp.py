"""Read-only SFTP collection against a local fake robot (real SSH/SFTP protocol, 127.0.0.1 only)."""

import os
import time

import paramiko

from pitrelay_collector import synthetic


def state(env, sid="src-robot"):
    return env.store.get_source_state(sid)


def test_unknown_host_key_blocks_before_any_login(env, robot):
    (robot.logs / "FRC_1.wpilog").write_bytes(synthetic.counter_wpilog(100))
    env.add_sftp(robot, trusted=False)
    env.step()
    st = state(env)
    assert st["state"] == "host_key_untrusted"
    assert st["pending_host_key"]["fingerprint"].startswith("SHA256:")
    assert not robot.log.of("auth_password") and not robot.log.of("auth_none")  # no credentials offered
    assert env.caps() == []
    env.collector.trust_host_key("src-robot", st["pending_host_key"]["fingerprint"])
    env.step()
    assert state(env)["state"] == "connected"
    assert env.data(env.caps()[0]) == synthetic.counter_wpilog(100)


def test_trust_requires_the_presented_fingerprint(env, robot):
    env.add_sftp(robot, trusted=False)
    env.step()
    try:
        env.collector.trust_host_key("src-robot", "SHA256:not-the-key")
        raised = False
    except ValueError:
        raised = True
    assert raised and env.cm.load().sources[0].trusted_host_keys == []


def test_changed_host_key_is_refused(env, robot):
    (robot.logs / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    env.add_sftp(robot)
    env.step()
    assert state(env)["state"] == "connected"
    robot.stop()
    robot.restart(host_key=paramiko.RSAKey.generate(2048))
    reads_before = len(robot.log.of("read"))
    auth_before = len(robot.log.of("auth_password")) + len(robot.log.of("auth_none"))
    # The first poll after the reboot may still use the old, now-dead transport and report
    # "disconnected" (as with a real robot); the next attempt reconnects and sees the new key.
    for _ in range(3):
        env.step(n=1, dt=400)
        if state(env)["state"] != "disconnected":
            break
    st = state(env)
    assert st["state"] == "host_key_mismatch"
    assert "REMOTE HOST IDENTITY CHANGED" in st["last_error"]
    assert len(robot.log.of("read")) == reads_before
    assert len(robot.log.of("auth_password")) + len(robot.log.of("auth_none")) == auth_before
    assert any(e["level"] == "error" and e["kind"] == "host_key_mismatch" for e in env.events())


def test_disconnect_backoff_and_reconnect(env, robot):
    (robot.logs / "a.wpilog").write_bytes(synthetic.counter_wpilog(10))
    env.add_sftp(robot)
    env.step()
    robot.stop()
    env.step()
    st = state(env)
    assert st["state"] == "disconnected" and st["failures"] == 1
    first_retry = st["next_attempt"] - env.clock.time()
    env.step(n=1, dt=6)
    second = state(env)
    assert second["failures"] == 2
    assert second["next_attempt"] - env.clock.time() > first_retry  # backoff grows
    (robot.logs / "b.wpilog").write_bytes(synthetic.counter_wpilog(20))  # written while "offline"
    robot.restart()
    env.step(n=1, dt=400)
    assert state(env)["state"] == "connected" and state(env)["failures"] == 0
    assert len(env.caps()) == 2
    avail = env.store.availability("src-robot")
    assert len(avail) == 2 and avail[0]["end"] is not None  # the offline interval is a recorded gap


def test_drop_mid_transfer_then_resume(env, robot):
    data = synthetic.counter_wpilog(30000)
    (robot.logs / "big.wpilog").write_bytes(data)
    env.add_sftp(robot)
    robot.drop_after_bytes = 150_000
    env.step()
    time.sleep(0.1)
    cap = env.caps()[0]
    assert 0 < cap["committed_size"] < len(data)
    assert state(env)["state"] == "disconnected"
    env.step(n=1, dt=400)
    cap = env.caps()[0]
    assert env.data(cap) == data and len(env.caps()) == 1


def test_permission_denied_file_and_folder(env, robot):
    (robot.logs / "ok.wpilog").write_bytes(synthetic.counter_wpilog(10))
    (robot.logs / "locked.wpilog").write_bytes(synthetic.counter_wpilog(11))
    (robot.logs / "private").mkdir()
    (robot.logs / "private" / "x.hoot").write_bytes(b"h" * 100)
    robot.deny = {"/home/lvuser/logs/locked.wpilog", "/home/lvuser/logs/private"}
    env.add_sftp(robot)
    env.step()
    caps = {os.path.basename(c["path"]): c for c in env.caps()}
    assert env.data(caps["ok.wpilog"]) == synthetic.counter_wpilog(10)
    assert caps["locked.wpilog"]["committed_size"] == 0 and caps["locked.wpilog"]["error"] == "permission denied at source"
    assert "x.hoot" not in caps
    assert state(env)["state"] == "connected"
    assert list(state(env)["dirs"].values())[0]["subdir_errors"] == 1
    assert env.events("permission_denied")
    robot.deny = set()
    env.step()
    caps = {os.path.basename(c["path"]): c for c in env.caps()}
    assert env.data(caps["locked.wpilog"]) == synthetic.counter_wpilog(11) and caps["locked.wpilog"]["error"] is None
    assert "x.hoot" in caps


def test_remote_rename_while_growing_and_missing_usb_folder(env, robot):
    full = synthetic.counter_wpilog(5000)
    (robot.logs / "FRC_TBD_77.wpilog").write_bytes(full[:30_000])
    env.add_sftp(robot, dirs=("/home/lvuser/logs", "/u/logs"))
    env.step()
    os.rename(robot.logs / "FRC_TBD_77.wpilog", robot.logs / "FRC_20261023_093000.wpilog")
    with open(robot.logs / "FRC_20261023_093000.wpilog", "ab") as f:
        f.write(full[30_000:])
    env.step()
    caps = env.caps()
    assert len(caps) == 1 and env.data(caps[0]) == full
    assert caps[0]["path"] == "/home/lvuser/logs/FRC_20261023_093000.wpilog"
    assert state(env)["dirs"]["/u/logs"]["status"] == "not_found"


def test_no_remote_mutation_and_no_commands(env, robot):
    for i in range(3):
        (robot.logs / f"{i}.wpilog").write_bytes(synthetic.counter_wpilog(500 + i))
    env.add_sftp(robot)
    env.step(4)
    os.rename(robot.logs / "0.wpilog", robot.logs / "zero.wpilog")
    env.step(2)
    assert robot.mutations() == []
    assert robot.log.of("exec") == [] and robot.log.of("shell") == [] and robot.log.of("pty") == []
    assert robot.log.kinds() <= {"auth_none", "auth_password", "channel", "realpath", "list", "lstat", "open", "read"}
