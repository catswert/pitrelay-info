"""Launch-at-login (opt-in), CLI flows, robot-project inspection and config validation."""

import json
import plistlib
import zipfile

import pytest

from pitrelay_collector import cli, synthetic
from pitrelay_collector.autostart import LABEL, WIN_VALUE, Autostart, default_store_path, launch_command
from pitrelay_collector.config import ConfigError, ConfigManager, SourceConfig, validate_source
from pitrelay_collector.projectscan import inspect_project


class FakeRegistry:
    def __init__(self):
        self.values = {}

    def get(self, name):
        return self.values.get(name)

    def set(self, name, value):
        self.values[name] = value

    def delete(self, name):
        self.values.pop(name, None)


def test_windows_run_key(tmp_path):
    reg = FakeRegistry()
    a = Autostart(system="Windows", home=tmp_path, registry=reg, python=r"C:\Py\python.exe")
    assert a.status()["enabled"] is False
    st = a.enable(tmp_path / "My Store")
    assert st["enabled"] and "pitrelay_collector run --store" in reg.values[WIN_VALUE]
    assert '"' in reg.values[WIN_VALUE]  # the path with a space is quoted
    assert st["verified_on_this_platform"] is False
    assert a.disable()["enabled"] is False and WIN_VALUE not in reg.values


def test_macos_launch_agent(tmp_path):
    a = Autostart(system="Darwin", home=tmp_path, python="/usr/bin/python3")
    st = a.enable(tmp_path / "store")
    data = plistlib.loads(a.mac_path.read_bytes())
    assert data["Label"] == LABEL and data["RunAtLoad"] is True and data["KeepAlive"] is False
    assert data["ProgramArguments"][-3:] == ["--store", str((tmp_path / "store").resolve()), "--no-browser"]
    assert st["enabled"] and "next login" in st["mechanism"]
    assert a.disable()["enabled"] is False and not a.mac_path.exists()


def test_linux_desktop_entry_quoting(tmp_path):
    a = Autostart(system="Linux", home=tmp_path, python="/opt/py/bin/python3")
    a.enable(tmp_path / 'we"ird $tore')
    text = a.linux_path.read_text()
    assert 'Exec="/opt/py/bin/python3" "-m" "pitrelay_collector" "run" "--store"' in text
    assert '\\"' in text and "\\$" in text
    a.disable()
    assert not a.linux_path.exists()


def test_launch_command_and_default_store():
    cmd = launch_command("/s", python="/x/python3", system="Linux")
    assert cmd == ["/x/python3", "-m", "pitrelay_collector", "run", "--store", "/s", "--no-browser"]
    assert default_store_path("Darwin").parts[-3:] == ("Library", "Application Support", "PitRelayCollector")
    assert "PitRelayCollector" in str(default_store_path("Windows"))


def test_cli_init_never_enables_collection_or_autostart(tmp_path, capsys, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    store = tmp_path / "store"
    assert cli.main(["--store", str(store), "init"]) == 0
    cfg = ConfigManager(store).load()
    assert cfg.collection_enabled is False
    assert not (tmp_path / "home/.config/autostart").exists()
    assert "OFF" in capsys.readouterr().out
    # --store is accepted after the command too (the launch-at-login command line uses that form).
    assert cli.main(["status", "--store", str(store)]) == 0
    assert "STOPPED" in capsys.readouterr().out


def test_cli_collect_export_verify_extract(tmp_path, capsys):
    from conftest import Env
    d = tmp_path / "src"
    d.mkdir()
    (d / "voltage.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    env = Env(tmp_path / "e")
    env.add_local(d)
    env.step()
    env.close()
    store = str(env.store_dir)
    obs = tmp_path / "obs.json"
    obs.write_text(json.dumps([{"author": "cli", "text": "synthetic note"}]))
    assert cli.main(["--store", store, "export", "--out", str(tmp_path / "out"), "--observations", str(obs),
                     "--label", "SYNTHETIC"]) == 0
    out = capsys.readouterr().out
    zpath = out.split("Exported and verified: ")[1].split("\n")[0].strip()
    assert cli.main(["verify", zpath]) == 0 and "OK:" in capsys.readouterr().out
    assert cli.main(["extract", zpath, str(tmp_path / "x")]) == 0
    text = capsys.readouterr().out
    assert "log.inspect" in text and (tmp_path / "x" / "handoff-plan.json").exists()
    with zipfile.ZipFile(zpath, "a") as z:  # tamper: append an unlisted member
        z.writestr("pitrelay-collection/logs/extra.wpilog", b"x")
    assert cli.main(["verify", zpath]) == 1


def test_cli_source_validation_errors(tmp_path, capsys):
    store = str(tmp_path / "s")
    assert cli.main(["--store", store, "source", "add-local", "--alias", "x", "--dir", "/"]) == 2
    assert cli.main(["--store", store, "source", "add-sftp", "--alias", "r", "--host", "bad host!", "--dir", "/home/lvuser/logs"]) == 2
    assert cli.main(["--store", store, "source", "add-sftp", "--alias", "r", "--host", "10.26.58.2", "--dir", "relative"]) == 2
    assert cli.main(["--store", store, "source", "add-sftp", "--alias", "r", "--host", "10.26.58.2", "--dir", "/home/lvuser/logs"]) == 0
    assert cli.main(["--store", store, "source", "add-local", "--alias", "R", "--dir", str(tmp_path)]) == 2  # duplicate alias


def test_validate_source_rules(tmp_path):
    s = SourceConfig(id="a", alias="ok", kind="sftp", directories=["/home/lvuser/logs/../logs/"], hosts=["roborio-2658-frc.local"],
                     username="lvuser")
    validate_source(s)
    assert s.directories == ["/home/lvuser/logs"]
    with pytest.raises(ConfigError):
        validate_source(SourceConfig(id="b", alias="x", kind="sftp", directories=["/"], hosts=["1.2.3.4"], username="u"))
    with pytest.raises(ConfigError):
        validate_source(SourceConfig(id="c", alias="x", kind="local", directories=[str(tmp_path)], text_patterns=["*"]))
    with pytest.raises(ConfigError):
        validate_source(SourceConfig(id="d", alias="x", kind="sftp", directories=["/l"], hosts=["h"], username="u", auth="key"))


def write_project(root, gradle_version, vendordeps, robot_java):
    (root / "src/main/java/frc/robot").mkdir(parents=True)
    (root / "vendordeps").mkdir()
    (root / "build.gradle").write_text(f'plugins {{\n  id "edu.wpi.first.GradleRIO" version "{gradle_version}"\n}}\n')
    for name, ver in vendordeps:
        (root / "vendordeps" / f"{name}.json").write_text(json.dumps({"name": name, "version": ver}))
    (root / "src/main/java/frc/robot/Robot.java").write_text(robot_java)


def test_projectscan_2025_ctre_without_start(tmp_path):
    write_project(tmp_path, "2025.3.2", [("CTRE-Phoenix (v6)", "25.4.0"), ("REVLib", "2025.0.3")],
                  "class Robot { void init() { } }")
    r = inspect_project(tmp_path)
    assert r["facts"]["season"] == 2025 and r["profile"]["controller"].startswith("roborio")
    topics = {g["topic"]: g for g in r["guidance"]}
    assert topics["wpilib_datalog"]["level"] == "action"
    assert "DataLogManager.start();" in topics["wpilib_datalog"]["proposed_snippet_not_applied"]
    assert "only during an FRC match" in topics["ctre_signal_logger"]["text"]
    assert "2025" in topics["ctre_signal_logger"]["documentation"]
    assert "rev_status_logger" in topics and "does not assert" in topics["rev_status_logger"]["text"]


def test_projectscan_2026_with_logging_and_paths(tmp_path):
    write_project(tmp_path, "2026.2.1", [("CTRE-Phoenix (v6)", "26.1.0"), ("AdvantageKit", "26.0.2")],
                  'class Robot { Robot() { DataLogManager.start(); DriverStation.startDataLog(DataLogManager.getLog());'
                  ' SignalLogger.setPath("/media/sda1/ctre-logs/"); SignalLogger.start(); Logger.start(); } }')
    r = inspect_project(tmp_path)
    topics = {g["topic"]: g for g in r["guidance"]}
    assert r["profile"]["wpilib_datalog"] and r["profile"]["advantagekit"]
    assert "/media/sda1/ctre-logs/" in topics["ctre_paths"]["text"]
    assert "/U/logs" in topics["advantagekit"]["text"]
    assert "ds_datalog" not in topics
    assert "2026" in topics["ctre_signal_logger"]["documentation"] or "main" in topics["ctre_signal_logger"]["documentation"]


def test_projectscan_2027_systemcore(tmp_path):
    write_project(tmp_path, "2027.0.0-alpha-7", [], "class Robot { }")
    r = inspect_project(tmp_path)
    topics = {g["topic"]: g for g in r["guidance"]}
    assert r["profile"]["controller"] == "systemcore"
    assert "/home/systemcore/logs" in topics["controller"]["text"]
    assert "FIRSTDriverStation" in topics["driver_station"]["text"]
