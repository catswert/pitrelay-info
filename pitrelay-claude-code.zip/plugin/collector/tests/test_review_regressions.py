"""Regression tests for defects found by independent review (each reproduced before it was fixed)."""

import errno
import hashlib
import os
import threading
from pathlib import Path

import pytest

from conftest import Env
from pitrelay_collector import export as export_mod
from pitrelay_collector import sources, synthetic
from pitrelay_collector.config import SourceConfig
from pitrelay_collector.export import ExportOptions, export_package
from pitrelay_collector.package import verify_package
from pitrelay_collector.store import Store


@pytest.fixture
def src(tmp_path):
    d = tmp_path / "source"
    d.mkdir()
    return d


def test_shrink_below_observed_size_is_a_new_version_not_complete(make_env, src):
    env = make_env(chunk_bytes=64 * 1024, max_bytes_per_cycle=64 * 1024)
    big, small = synthetic.counter_wpilog(9000), synthetic.counter_wpilog(4500)
    assert big.startswith(small) and 64 * 1024 < len(small) < len(big)
    env.add_local(src)
    f = src / "a.wpilog"
    f.write_bytes(big)
    env.step()  # observed len(big), committed 64 KiB (budget)
    f.write_bytes(small)  # truncated while still longer than what was captured
    env.step(80)
    caps = env.caps()
    old = caps[0]
    assert old["presence"] == "replaced" and old["status"] == "partial"
    assert old["max_observed_size"] - old["committed_size"] == len(big) - 64 * 1024
    assert env.data(caps[1]) == small and caps[1]["predecessor_id"] == old["id"]


def test_slow_poll_on_same_connection_is_not_a_reconnection(env, src):
    env.add_local(src)
    (src / "a.wpilog").write_bytes(synthetic.counter_wpilog(2000))
    env.step(7)
    (src / "b.wpilog").write_bytes(synthetic.counter_wpilog(10))
    env.step(n=1, dt=40)  # one slow poll, same session
    a = [c for c in env.caps() if c["path"].endswith("a.wpilog")][0]
    assert a["reconnects_since_change"] == 0 and a["status"] != "complete"


def test_growth_after_complete_clears_was_complete(env, src):
    env.add_local(src)
    f = src / "a.wpilog"
    f.write_bytes(synthetic.counter_wpilog(2000))
    env.step(70)
    assert env.caps()[0]["status"] == "complete"
    f.write_bytes(synthetic.counter_wpilog(4000))
    env.step()
    f.write_bytes(synthetic.counter_wpilog(4100))
    env.step()
    f.unlink()
    env.step()
    c = env.store.captures(include_deleted=True)[0]
    assert c["presence"] == "missing" and c["status"] == "uncertain"


def test_local_store_damage_is_isolated_to_one_capture(env, src):
    full = synthetic.counter_wpilog(6000)
    env.add_local(src)
    (src / "a.wpilog").write_bytes(full[:20000])
    (src / "b.wpilog").write_bytes(full[:20000])
    env.step()
    a = [c for c in env.caps() if c["path"].endswith("a.wpilog")][0]
    os.unlink(env.store.data_path(a))  # damage one capture's local copy
    (src / "a.wpilog").write_bytes(full[:30000])
    (src / "b.wpilog").write_bytes(full)
    env.step(3)
    assert env.store.get_source_state("src-ds")["state"] == "connected"
    b = [c for c in env.caps() if c["path"].endswith("b.wpilog")][0]
    assert env.data(b) == full
    damaged = env.store.get_capture(a["id"])
    assert damaged["presence"] == "detached" and damaged["error"].startswith("store integrity")
    fresh = [c for c in env.caps() if c["path"].endswith("a.wpilog") and c["presence"] == "present"][0]
    assert env.data(fresh) == full[:30000] and fresh["predecessor_id"] == a["id"]
    assert env.events("store_damaged")


def test_truncated_local_copy_is_damage_not_a_source_replacement(env, src):
    full = synthetic.counter_wpilog(6000)
    env.add_local(src)
    (src / "a.wpilog").write_bytes(full[:40000])
    env.step()
    a = env.caps()[0]
    with open(env.store.data_path(a), "r+b") as fh:
        fh.truncate(30000)
    (src / "a.wpilog").write_bytes(full[:50000])
    env.step()
    assert not env.events("capture_replaced")
    assert env.store.get_capture(a["id"])["presence"] == "detached"


def test_integrity_error_survives_and_export_omits_the_damaged_capture(tmp_path, src):
    full = synthetic.counter_wpilog(40000)
    env = Env(tmp_path / "e")
    env.add_local(src)
    f = src / "a.hoot"
    f.write_bytes(full[:300000])
    env.step()
    a = env.caps()[0]
    with open(env.store.data_path(a), "r+b") as fh:  # corrupt a byte inside the last committed segment
        fh.seek(280000)
        b = fh.read(1)
        fh.seek(280000)
        fh.write(bytes([b[0] ^ 0xFF]))
    env.store.close()
    env.store = Store(env.store_dir, env.clock).open_owner()
    env.collector.store = env.store
    assert env.store.get_capture(a["id"])["error"].startswith("store integrity")
    f.write_bytes(full[:350000])
    env.step()
    damaged = env.store.get_capture(a["id"])
    assert damaged["error"].startswith("store integrity") and damaged["committed_size"] == a["committed_size"]
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out"))
    assert res.ok, res.error
    m = verify_package(res.archives[0]["path"])["manifest"]
    assert any(o["kind"] == "store_integrity_failure" for o in m["omissions"])
    assert [c["size_bytes"] for c in m["captures"]] == [350000]  # the source copy was collected again
    env.close()


def test_failed_capture_creation_does_not_block_later_files(env, src, monkeypatch):
    env.add_local(src)
    (src / "a.hoot").write_bytes(os.urandom(5000))
    env.step()
    real_open = open
    state = {"fail": True}

    def failing_open(path, mode="r", *a, **kw):
        if state["fail"] and mode == "wb" and str(path).endswith(".bin"):
            raise OSError(errno.ENOSPC, "No space left on device")
        return real_open(path, mode, *a, **kw)
    monkeypatch.setattr("pitrelay_collector.store.open", failing_open, raising=False)
    (src / "b.hoot").write_bytes(os.urandom(5000))
    env.step()
    assert len(env.caps()) == 1  # no catalog row without its data file
    assert env.store.get_source_state("src-ds")["state"] == "connected"
    assert env.events("store_write_failed")
    state["fail"] = False
    (src / "c.hoot").write_bytes(os.urandom(5000))
    env.step(2)
    got = {os.path.basename(c["path"]): env.data(c) for c in env.caps()}
    assert got["b.hoot"] == (src / "b.hoot").read_bytes() and got["c.hoot"] == (src / "c.hoot").read_bytes()


class _FakeSftp:
    kind, host, alive = "sftp", "fake", True

    def __init__(self, root, fail):
        self.root, self.fail = root, fail

    def realpath(self, p):
        if p in self.fail:
            raise OSError("Failure")  # paramiko's generic SFTP failure has no errno
        return p

    def listdir(self, p):
        out = []
        for de in os.scandir(str(self.root) + p):
            st = de.stat()
            out.append(sources.Entry(p + "/" + de.name, de.name, "dir" if de.is_dir() else "file", st.st_size, st.st_mtime))
        return out

    def open(self, p):
        return sources._LocalReader(str(self.root) + p)

    def close(self):
        pass


def test_transient_resolve_failure_is_not_deauthorization(env, tmp_path):
    root = tmp_path / "robot"
    (root / "A").mkdir(parents=True)
    (root / "B").mkdir()
    (root / "A" / "a.wpilog").write_bytes(synthetic.counter_wpilog(1000))
    (root / "B" / "b.wpilog").write_bytes(synthetic.counter_wpilog(1000))
    fail = set()
    env.collector.connect = lambda *a, **k: _FakeSftp(root, fail)

    def add(cfg):
        cfg.sources.append(SourceConfig(id="src-r", alias="r", kind="sftp", directories=["/A", "/B"], hosts=["127.0.0.1"],
                                        username="lvuser"))
    env.cm.update(add)
    env.step()
    fail.add("/B")
    env.step()
    fail.clear()
    env.step()
    b = [c for c in env.caps() if c["path"] == "/B/b.wpilog"]
    assert len(b) == 1 and b[0]["presence"] == "present" and not env.events("capture_missing")


def test_deletion_during_a_transfer_is_respected(env, src, monkeypatch):
    env.add_local(src)
    f = src / "a.hoot"
    f.write_bytes(os.urandom(100_000))
    env.step()
    cid = env.caps()[0]["id"]
    f.write_bytes(f.read_bytes() + os.urandom(200_000))
    orig_open = sources.LocalFS.open
    state = {}

    def patched(self, path):
        r = orig_open(self, path)
        orig = r.read_at

        def read_at(off, n):
            if off >= 100_000 and "done" not in state:
                state["done"] = True
                env.store.delete_captures([cid], "user deletion racing the collector")
            return orig(off, n)
        r.read_at = read_at
        return r
    monkeypatch.setattr(sources.LocalFS, "open", patched)
    env.step()
    c = env.store.get_capture(cid)
    assert c["deleted_at"] is not None and c["committed_size"] == 100_000
    assert env.store.segments(cid) == []
    assert env.store.usage_bytes == env.store._committed_total()


def test_concurrent_exports_never_overwrite_each_other(env, src, tmp_path):
    for i in range(3):
        (src / f"f{i}.hoot").write_bytes(os.urandom(2_000_000))
    env.add_local(src)
    env.step()
    out = tmp_path / "out"
    out.mkdir()
    results = []

    def run():
        results.append(export_package(env.store, env.cm.load(), ExportOptions(out_dir=out), clock_now=env.clock.time()))
    ts = [threading.Thread(target=run) for _ in range(2)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    paths = [a["path"] for r in results for a in r.archives]
    assert all(r.ok for r in results) and len(set(paths)) == 2
    for r in results:
        a = r.archives[0]
        assert hashlib.sha256(Path(a["path"]).read_bytes()).hexdigest() == a["sha256"]
        assert Path(a["path"] + ".sha256").read_text().split()[0] == a["sha256"]


def test_multi_part_export_is_all_or_nothing(env, src, tmp_path, monkeypatch):
    for i in range(3):
        (src / f"{i}.hoot").write_bytes(os.urandom(300_000))
    env.add_local(src)
    env.step()
    real_replace = os.replace
    calls = {"n": 0}

    def flaky_replace(a, b):
        if str(b).endswith(".zip"):
            calls["n"] += 1
            if calls["n"] == 2:
                raise OSError(errno.EIO, "simulated failure renaming part 2")
        return real_replace(a, b)
    monkeypatch.setattr(export_mod.os, "replace", flaky_replace)
    out = tmp_path / "out"
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=out, max_archive_bytes=350_000))
    assert not res.ok
    assert not [p for p in os.listdir(out) if not p.startswith(".pitrelay-export-")]


def test_deletion_of_a_file_in_use_is_refused_cleanly(env, src, monkeypatch):
    (src / "a.hoot").write_bytes(os.urandom(1000))
    env.add_local(src)
    env.step()
    cap = env.caps()[0]

    def in_use(self, target):
        raise PermissionError(errno.EACCES, "file is in use")  # what Windows reports for an open file
    monkeypatch.setattr(Path, "rename", in_use)
    with pytest.raises(Exception):
        env.store.delete_captures([cap["id"]], "x")
    monkeypatch.undo()
    c = env.store.get_capture(cap["id"])
    assert c["deleted_at"] is None and env.store.data_path(c).exists()
    assert env.store.usage_bytes == env.store._committed_total()
