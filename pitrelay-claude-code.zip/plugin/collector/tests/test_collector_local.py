"""Continuous collection from a simulated local source (deterministic clock)."""

import errno
import os

import pytest

from conftest import snapshot_tree
from pitrelay_collector import collector as collector_mod
from pitrelay_collector import synthetic
from pitrelay_collector.lock import StoreLocked
from pitrelay_collector.store import Store


@pytest.fixture
def src_dir(tmp_path):
    d = tmp_path / "source"
    d.mkdir()
    return d


def test_every_supported_extension_is_collected_and_others_are_not(env, src_dir):
    files = {
        "a.wpilog": synthetic.voltage_fixture_wpilog(), "b.revlog": synthetic.revlog_v2(), "c.hoot": synthetic.fake_hoot(),
        "d.dslog": synthetic.dslog_v4(1_760_000_000, 10), "d.dsevents": synthetic.dsevents_v4(1_760_000_000, ["x"]),
        "e.csv": b"t,v\n0,1\n", "FRC_UserProgram.log": b"console\n", "notes.txt": b"unrelated\n", "photo.jpg": b"\xff\xd8",
    }
    for name, data in files.items():
        (src_dir / name).write_bytes(data)
    env.add_local(src_dir, include_csv=True, text_patterns=["FRC_UserProgram.log"])
    env.step()
    got = {os.path.basename(c["path"]): env.data(c) for c in env.caps()}
    assert set(got) == {"a.wpilog", "b.revlog", "c.hoot", "d.dslog", "d.dsevents", "e.csv", "FRC_UserProgram.log"}
    for name, data in got.items():
        assert data == files[name], name


def test_csv_and_text_are_opt_in(env, src_dir):
    (src_dir / "e.csv").write_bytes(b"t,v\n")
    (src_dir / "FRC_UserProgram.log").write_bytes(b"x")
    env.add_local(src_dir)
    env.step()
    assert env.caps() == []


def test_growth_is_fetched_incrementally(env, src_dir):
    full = synthetic.counter_wpilog(6000)
    f = src_dir / "FRC_TBD_1.wpilog"
    env.add_local(src_dir)
    sizes = [10_000, 30_000, 60_000, len(full)]
    for n in sizes:
        f.write_bytes(full[:n])
        env.step()
    cap = env.caps()[0]
    assert env.data(cap) == full
    segs = env.store.segments(cap["id"])
    assert segs[0]["offset"] == 0
    # Every byte was transferred exactly once: segment lengths add up to the file size.
    assert sum(s["length"] for s in segs) == len(full)
    assert [s["offset"] for s in segs if s["offset"] in sizes[:-1]] == sizes[:-1]


def test_rename_while_growing_follows_the_same_recording(env, src_dir):
    full = synthetic.counter_wpilog(5000)
    env.add_local(src_dir)
    (src_dir / "FRC_TBD_abc.wpilog").write_bytes(full[:20_000])
    env.step()
    os.rename(src_dir / "FRC_TBD_abc.wpilog", src_dir / "FRC_20261023_081500.wpilog")
    with open(src_dir / "FRC_20261023_081500.wpilog", "ab") as f:
        f.write(full[20_000:])
    env.step()
    caps = env.caps()
    assert len(caps) == 1
    assert env.data(caps[0]) == full
    assert [os.path.basename(n["path"]) for n in caps[0]["names"]] == ["FRC_TBD_abc.wpilog", "FRC_20261023_081500.wpilog"]
    assert env.events("capture_renamed")


def test_rotation_keeps_both_versions(env, src_dir):
    env.add_local(src_dir, text_patterns=["console.log", "console.log.1"])
    old = b"old line\n" * 50
    (src_dir / "console.log").write_bytes(old)
    env.step()
    os.rename(src_dir / "console.log", src_dir / "console.log.1")
    (src_dir / "console.log").write_bytes(b"new line\n" * 40)
    env.step()
    by_path = {os.path.basename(c["path"]): c for c in env.caps()}
    assert env.data(by_path["console.log.1"]) == old and by_path["console.log.1"]["presence"] == "present"
    assert env.data(by_path["console.log"]) == b"new line\n" * 40
    assert by_path["console.log"]["predecessor_id"] == by_path["console.log.1"]["id"]


def test_truncation_and_replacement_never_overwrite_history(env, src_dir):
    env.add_local(src_dir)
    a = synthetic.counter_wpilog(2000)
    b = synthetic.counter_wpilog(2000, start_us=7)  # same size, different bytes
    f = src_dir / "x.wpilog"
    f.write_bytes(a)
    env.step()
    f.write_bytes(b)
    os.utime(f, (1, 1))  # the mtime changes; the size does not
    env.step()
    with open(f, "r+b") as h:
        h.truncate(100)
    env.step()
    caps = env.caps()
    assert [env.data(c) for c in caps] == [a, b, b[:100]]
    assert [c["presence"] for c in caps] == ["replaced", "replaced", "present"]
    assert caps[1]["predecessor_id"] == caps[0]["id"] and caps[2]["predecessor_id"] == caps[1]["id"]
    assert caps[0]["status"] == "uncertain"
    assert any("prefix_recheck:mismatch" in k for k in caps[0]["checks"]["counts"])


def test_unrelated_file_with_same_prefix_is_not_mistaken_for_a_rename(env, src_dir):
    env.add_local(src_dir)
    small = synthetic.counter_wpilog(2000)
    (src_dir / "x.wpilog").write_bytes(small)
    env.step()
    (src_dir / "x.wpilog").write_bytes(synthetic.counter_wpilog(2000, start_us=3))
    env.step()  # x.wpilog replaced; the old capture disappears from its path in this poll
    (src_dir / "big.wpilog").write_bytes(synthetic.counter_wpilog(20000))  # begins with the old bytes
    env.step()
    big = [c for c in env.caps() if c["path"].endswith("big.wpilog")][0]
    assert len(big["names"]) == 1 and big["predecessor_id"] is None


def test_deleted_before_transfer_reports_exact_gap(make_env, tmp_path):
    env = make_env(chunk_bytes=64 * 1024, max_bytes_per_cycle=64 * 1024)
    d = tmp_path / "s"
    d.mkdir()
    env.add_local(d)
    data = synthetic.counter_wpilog(20000)
    (d / "big.wpilog").write_bytes(data)
    env.step()
    os.remove(d / "big.wpilog")
    env.step()
    cap = env.caps()[0]
    assert cap["presence"] == "missing" and cap["status"] == "partial"
    assert cap["committed_size"] == 64 * 1024
    assert env.data(cap) == data[:64 * 1024]
    assert f"before {len(data) - 64 * 1024} observed bytes" in cap["status_reasons"][0]


def test_status_is_not_complete_after_a_brief_pause(env, src_dir):
    env.add_local(src_dir)
    (src_dir / "a.wpilog").write_bytes(synthetic.counter_wpilog(100))
    env.step()
    assert env.caps()[0]["status"] == "active"
    env.step(6)  # 60 s unchanged: past the active window, far from the completion period
    assert env.caps()[0]["status"] == "idle"
    env.step(54)  # 600 s of continuous connected observation
    cap = env.caps()[0]
    assert cap["status"] == "complete"
    assert any("cannot see whether the writer closed" in r for r in cap["status_reasons"])


def test_unobserved_time_does_not_count_toward_complete(env, src_dir):
    env.add_local(src_dir)
    (src_dir / "a.wpilog").write_bytes(synthetic.counter_wpilog(100))
    env.step()
    env.step(n=3, dt=3600)  # polls far apart: no continuous observation accrues
    cap = env.caps()[0]
    assert cap["quiet_s"] == 0 and cap["status"] != "complete"


def test_complete_after_reconnect_with_newer_recording(env, src_dir):
    env.add_local(src_dir)
    (src_dir / "FRC_1.wpilog").write_bytes(synthetic.counter_wpilog(100))
    env.step(7)
    away = src_dir.with_name("source-offline")
    os.rename(src_dir, away)  # the source becomes unreachable (e.g. robot powered off)
    env.step()
    assert env.store.get_source_state("src-ds")["state"] == "disconnected"
    os.rename(away, src_dir)
    (src_dir / "FRC_2.wpilog").write_bytes(synthetic.counter_wpilog(50))  # it came back with a new recording
    env.step(n=1, dt=400)
    first = [c for c in env.caps() if c["path"].endswith("FRC_1.wpilog")][0]
    assert first["reconnects_since_change"] == 1
    assert first["status"] == "complete"
    assert "newer recording" in first["status_reasons"][0]


def test_slow_poll_without_reconnect_does_not_complete(env, src_dir):
    env.add_local(src_dir)
    (src_dir / "FRC_1.wpilog").write_bytes(synthetic.counter_wpilog(100))
    env.step(7)
    (src_dir / "FRC_2.wpilog").write_bytes(synthetic.counter_wpilog(50))
    env.step(n=1, dt=3600)  # a long gap on the same connection is unobserved time, not a reconnection
    first = [c for c in env.caps() if c["path"].endswith("FRC_1.wpilog")][0]
    assert first["status"] == "idle" and first["reconnects_since_change"] == 0


def test_incomplete_final_record_is_partial_not_complete(env, src_dir):
    env.add_local(src_dir)
    (src_dir / "a.wpilog").write_bytes(synthetic.voltage_fixture_wpilog()[:-5])
    env.step(61)
    cap = env.caps()[0]
    assert cap["status"] == "partial" and "final record is incomplete" in cap["status_reasons"][0]


def test_same_filename_on_two_sources_stays_separate(env, tmp_path):
    a, b = tmp_path / "robot", tmp_path / "ds"
    a.mkdir()
    b.mkdir()
    (a / "voltage.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    (b / "voltage.wpilog").write_bytes(synthetic.counter_wpilog(10))
    env.add_local(a, alias="robot")
    env.add_local(b, alias="ds")
    env.step()
    caps = env.caps()
    assert len(caps) == 2 and {c["source_id"] for c in caps} == {"src-robot", "src-ds"}
    assert {env.data(c) for c in caps} == {synthetic.voltage_fixture_wpilog(), synthetic.counter_wpilog(10)}


def test_links_are_not_followed(env, tmp_path, src_dir):
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "secret.wpilog").write_bytes(synthetic.counter_wpilog(5))
    try:
        os.symlink(outside / "secret.wpilog", src_dir / "link.wpilog")
        os.symlink(outside, src_dir / "linkdir", target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip("creating symbolic links is not permitted here (e.g. Windows without Developer Mode)")
    (src_dir / "real.wpilog").write_bytes(synthetic.counter_wpilog(5))
    env.add_local(src_dir)
    env.step()
    assert [os.path.basename(c["path"]) for c in env.caps()] == ["real.wpilog"]
    st = env.store.get_source_state("src-ds")
    assert list(st["dirs"].values())[0]["links_skipped"] == 2


def test_depth_limit(env, src_dir):
    (src_dir / "a" / "b" / "c").mkdir(parents=True)
    (src_dir / "a" / "one.hoot").write_bytes(b"1" * 100)
    (src_dir / "a" / "b" / "c" / "three.hoot").write_bytes(b"3" * 100)
    (src_dir / "a" / "b" / "two.hoot").write_bytes(b"2" * 100)  # exactly one level past the limit
    (src_dir / "zero.hoot").write_bytes(b"0" * 100)
    env.add_local(src_dir, recursive_depth=1)
    env.step()
    assert sorted(os.path.basename(c["path"]) for c in env.caps()) == ["one.hoot", "zero.hoot"]


def test_depth_zero_lists_only_the_folder_itself(env, src_dir):
    (src_dir / "a").mkdir()
    (src_dir / "top.hoot").write_bytes(b"t" * 100)
    (src_dir / "a" / "one.hoot").write_bytes(b"1" * 100)
    env.add_local(src_dir, recursive_depth=0)
    env.step()
    assert [os.path.basename(c["path"]) for c in env.caps()] == ["top.hoot"]


def test_missing_folder_is_disconnected_then_recovers(env, tmp_path):
    d = tmp_path / "share"
    env.add_local(d)
    env.step()
    st = env.store.get_source_state("src-ds")
    assert st["state"] == "disconnected"
    d.mkdir()
    (d / "a.wpilog").write_bytes(synthetic.counter_wpilog(5))
    env.step(n=1, dt=400)  # past the backoff
    assert env.store.get_source_state("src-ds")["state"] == "connected"
    assert len(env.caps()) == 1


def test_unavailable_folder_does_not_mark_files_missing(env, tmp_path):
    d = tmp_path / "usb"
    d.mkdir()
    (d / "a.wpilog").write_bytes(synthetic.counter_wpilog(5))
    other = tmp_path / "internal"
    other.mkdir()

    def add(cfg):
        from pitrelay_collector.config import SourceConfig
        cfg.sources.append(SourceConfig(id="src-r", alias="r", kind="local", directories=[str(d), str(other)], poll_interval_s=10))
    env.cm.update(add)
    env.step()
    os.rename(d, tmp_path / "usb-unplugged")
    env.step()
    assert env.caps()[0]["presence"] == "present"  # the folder is unavailable, not the file gone


def test_pause_disable_and_no_reads_while_paused(env, src_dir):
    env.add_local(src_dir)
    env.collector.pause()
    (src_dir / "a.wpilog").write_bytes(synthetic.counter_wpilog(5))
    env.step(3)
    assert env.caps() == []
    env.collector.resume()
    env.step()
    assert len(env.caps()) == 1
    env.collector.set_enabled(False)
    (src_dir / "b.wpilog").write_bytes(synthetic.counter_wpilog(5))
    env.step(3)
    assert len(env.caps()) == 1
    kinds = [e["kind"] for e in env.events()]
    assert "paused" in kinds and "resumed" in kinds and "disabled" in kinds


def test_restart_recovery_and_no_duplicate_download(tmp_path, monkeypatch):
    from conftest import Env
    d = tmp_path / "s"
    d.mkdir()
    data = synthetic.counter_wpilog(20000)
    (d / "a.wpilog").write_bytes(data)
    env = Env(tmp_path / "e")
    env.add_local(d)
    calls = {"n": 0}
    real_commit = env.store.commit_segment

    def crash_on_third(*a, **kw):
        calls["n"] += 1
        if calls["n"] == 3:
            raise KeyboardInterrupt("simulated power loss after fsync, before commit")
        return real_commit(*a, **kw)
    monkeypatch.setattr(env.store, "commit_segment", crash_on_third)
    with pytest.raises(KeyboardInterrupt):
        env.step()
    path = env.store_dir / env.caps()[0]["data_file"]
    assert path.stat().st_size > 2 * 64 * 1024  # uncommitted bytes are on disk
    # Simulate the process dying: release the OS lock without a clean shutdown.
    env.store.lock.release()
    for _, c in env.store._conns:
        c.close()
    env.store._conns.clear()
    store2 = Store(env.store_dir, env.clock).open_owner()
    try:
        cap = store2.captures()[0]
        assert path.stat().st_size == cap["committed_size"] == 2 * 64 * 1024
        kinds = [e["kind"] for e in store2.events()]
        assert "recovered_uncommitted" in kinds and "unclean_shutdown" in kinds
        from pitrelay_collector.collector import Collector
        from pitrelay_collector.secrets import MemorySecrets
        col = Collector(store2, env.cm, clock=env.clock, secrets=MemorySecrets(), jitter=False)
        reads = []
        real_open = collector_mod.LocalFS.open

        def counting_open(self, p):
            r = real_open(self, p)
            orig = r.read_at
            r.read_at = lambda off, n: (reads.append((off, n)), orig(off, n))[1]
            return r
        monkeypatch.setattr(collector_mod.LocalFS, "open", counting_open)
        env.clock.advance(10)
        col.tick(force=True)
        caps = store2.captures()
        assert len(caps) == 1  # no duplicate capture after restart
        assert (env.store_dir / caps[0]["data_file"]).read_bytes() == data
        committed = 2 * 64 * 1024
        chunks = -(-(len(data) - committed) // (64 * 1024))
        # Every read counts: only the missing bytes, plus one 4 KiB head check before the transfer and one per chunk.
        assert sum(n for _, n in reads) <= (len(data) - committed) + 4096 * (chunks + 1)
        assert not [(off, n) for off, n in reads if off < committed and off + n > 4096]  # nothing already committed re-read
        env.clock.advance(10)
        reads.clear()
        col.tick(force=True)
        assert len(store2.captures()) == 1 and sum(n for _, n in reads) == 0  # unchanged file: nothing re-read
    finally:
        store2.close()


def test_single_owner_per_store(env):
    with pytest.raises(StoreLocked):
        Store(env.store_dir, env.clock).open_owner()


def test_quota_stops_transfers_without_deleting(make_env, tmp_path):
    env = make_env(quota_bytes=16 * 1024 * 1024 + 100_000, chunk_bytes=64 * 1024)
    d = tmp_path / "s"
    d.mkdir()
    env.add_local(d)
    blob = os.urandom(16 * 1024 * 1024)
    (d / "a.hoot").write_bytes(blob)
    env.step()
    (d / "b.hoot").write_bytes(os.urandom(500_000))
    env.step()
    caps = {os.path.basename(c["path"]): c for c in env.caps()}
    assert env.data(caps["a.hoot"]) == blob  # nothing already collected was deleted
    assert caps["b.hoot"]["committed_size"] == 100_000  # stopped exactly at the quota
    assert env.events("quota_blocked")
    assert env.collector.quota_blocked
    env.step()
    assert caps["b.hoot"]["committed_size"] == env.store.get_capture(caps["b.hoot"]["id"])["committed_size"]

    def raise_quota(cfg):
        cfg.quota_bytes = 64 * 1024 * 1024
    env.cm.update(raise_quota)
    env.step()
    assert env.data(env.store.get_capture(caps["b.hoot"]["id"])) == (d / "b.hoot").read_bytes()
    assert env.events("quota_resumed")


def test_disk_full_is_reported_and_state_stays_consistent(env, src_dir, monkeypatch):
    data = synthetic.counter_wpilog(20000)
    (src_dir / "a.wpilog").write_bytes(data)
    env.add_local(src_dir)
    real_open = open
    budget = {"left": 100_000}

    class FullFile:
        def __init__(self, f):
            self.f = f

        def write(self, b):
            if budget["left"] <= 0:
                raise OSError(errno.ENOSPC, "No space left on device")
            budget["left"] -= len(b)
            return self.f.write(b)

        def __getattr__(self, name):
            return getattr(self.f, name)

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return self.f.__exit__(*a)

    def fake_open(path, mode="r", *a, **kw):
        f = real_open(path, mode, *a, **kw)
        return FullFile(f) if mode == "r+b" else f
    monkeypatch.setattr(collector_mod, "open", fake_open, raising=False)
    env.step()
    cap = env.caps()[0]
    path = env.store_dir / cap["data_file"]
    assert path.stat().st_size == cap["committed_size"] < len(data)  # no uncommitted bytes survive
    assert env.events("store_write_failed")
    assert env.store.get_source_state("src-ds")["state"] == "connected"  # the source was fine
    monkeypatch.undo()
    env.step()
    assert env.data(env.caps()[0]) == data


def test_connection_failure_mid_transfer_resumes(env, src_dir, monkeypatch):
    data = synthetic.counter_wpilog(20000)
    (src_dir / "a.wpilog").write_bytes(data)
    env.add_local(src_dir)
    real_open = collector_mod.LocalFS.open
    state = {"served": 0, "fail": True}

    def flaky_open(self, p):
        r = real_open(self, p)
        orig = r.read_at

        def read_at(off, n):
            if state["fail"] and state["served"] > 150_000:
                raise ConnectionResetError(errno.ECONNRESET, "link dropped")
            out = orig(off, n)
            state["served"] += len(out)
            return out
        r.read_at = read_at
        return r
    monkeypatch.setattr(collector_mod.LocalFS, "open", flaky_open)
    env.step()
    cap = env.caps()[0]
    assert 0 < cap["committed_size"] < len(data)
    assert (env.store_dir / cap["data_file"]).stat().st_size == cap["committed_size"]  # the partial chunk was rolled back
    assert env.store.get_source_state("src-ds")["state"] == "disconnected"
    state["fail"] = False
    env.step(n=1, dt=400)
    assert env.data(env.caps()[0]) == data
    assert len(env.caps()) == 1


def test_collection_never_modifies_the_source(env, src_dir):
    for i in range(3):
        (src_dir / f"{i}.wpilog").write_bytes(synthetic.counter_wpilog(1000 + i))
    (src_dir / "sub").mkdir()
    (src_dir / "sub" / "x.dslog").write_bytes(synthetic.dslog_v4(1_760_000_000, 20))
    before = snapshot_tree(src_dir)
    env.add_local(src_dir)
    env.step(5)
    assert snapshot_tree(src_dir) == before
