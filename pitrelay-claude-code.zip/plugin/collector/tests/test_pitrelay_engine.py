"""End-to-end handoff to a real PitRelay engine (runs only when one is supplied).

Set PITRELAY_ENGINE_JAR=/path/to/pitrelay.jar (and have Java 17+ on PATH). Without it these
tests are SKIPPED, never counted as passing.
"""

import os
import shutil
from pathlib import Path

import pytest

from pitrelay_collector import compat, synthetic
from pitrelay_collector.export import ExportOptions, export_package
from pitrelay_collector.handoff import EngineSession, extract_package, handoff_to_engine, statistics

JAR = os.environ.get("PITRELAY_ENGINE_JAR")
JAVA = shutil.which("java")
pytestmark = pytest.mark.skipif(not (JAR and Path(JAR).is_file() and JAVA),
                                 reason="PitRelay engine not supplied (set PITRELAY_ENGINE_JAR) or Java missing")


@pytest.fixture
def handed_off(env, tmp_path):
    d = tmp_path / "src"
    d.mkdir()
    (d / "voltage_SYNTHETIC.wpilog").write_bytes(synthetic.voltage_fixture_wpilog())
    (d / "2026_10_23 08_00_00 Thu.dslog").write_bytes(synthetic.dslog_v4(1_761_206_400, 100))
    (d / "2026_10_23 08_00_00 Thu.dsevents").write_bytes(synthetic.dsevents_v4(1_761_206_400, ["Info: synthetic"]))
    (d / "synthetic.revlog").write_bytes(synthetic.revlog_v2())
    (d / "voltage.csv").write_bytes(b"time_s,voltage\n0,12\n1,12\n2,6\n3,12\n4,12\n")
    (d / "x.hoot").write_bytes(synthetic.fake_hoot())
    env.add_local(d, include_csv=True)
    env.step()
    res = export_package(env.store, env.cm.load(), ExportOptions(out_dir=tmp_path / "out", package_label="SYNTHETIC"))
    assert res.ok, res.error
    ex = extract_package(res.archives[0]["path"], tmp_path / "handoff")
    state = tmp_path / "pitrelay-state"
    state.mkdir()
    csv_path = [c["archive_path"] for c in ex["manifest"]["captures"] if c["archive_path"].endswith(".csv")][0]
    receipt = handoff_to_engine(Path(ex["extracted_to"]), JAVA, Path(JAR), state, tmp_path / "handoff", csv_mappings={
        csv_path: {"timestamp_column": "time_s", "value_column": "voltage", "time_unit": "s",
                   "clock": "synthetic_csv_relative", "sampling_policy": "periodic", "unit": "V"}})
    return receipt, state, tmp_path


def by_name(receipt, suffix):
    return [f for f in receipt["files"] if f["archive_path"].endswith(suffix)][0]


def test_engine_accepts_each_routed_format(handed_off):
    receipt, _, tmp = handed_off
    assert receipt["engine"]["server_info"]["name"] == "pitrelay"
    assert (tmp / "handoff" / "handoff-receipt.json").exists()
    w = by_name(receipt, "voltage_SYNTHETIC.wpilog")["original"]
    assert w["upload"]["artifact_id"].startswith("artifact-")  # issued by the engine, not by the collector
    assert w["inspect"]["status"] == "ok" and w["inspect"]["integrity"] == "complete"
    assert w["inspect"]["sample_count"] == 6 and w["inspect"]["last_observation_us"] == 4_000_000
    assert by_name(receipt, ".dslog")["original"]["inspect"]["status"] == "ok"
    assert by_name(receipt, ".dsevents")["original"]["inspect"]["status"] == "ok"
    assert by_name(receipt, ".csv")["original"]["import_csv"]["status"] == "ok"
    assert by_name(receipt, ".hoot")["result"]["status"] == "not_supplied"


def test_engine_statistics_match_the_fixture(handed_off):
    receipt, state, tmp = handed_off
    aid = by_name(receipt, "voltage_SYNTHETIC.wpilog")["original"]["upload"]["artifact_id"]
    eng = EngineSession(JAVA, Path(JAR), state, tmp / "stats-stderr.log")
    try:
        eng.start()
        r = statistics(eng, aid, synthetic.VOLTAGE_ENTRY, 0, 5_000_000)
    finally:
        eng.close()
    assert r["status"] == "ok"
    res = r["result"]
    assert res["count"] == 5 and res["mean"] == pytest.approx(10.8) and res["min"] == 6.0 and res["max"] == 12.0
    assert res["interval_convention"] == "[start_us,end_us)"
    assert res["source"]["unit"] == "V"  # declared in the synthetic fixture's metadata


def test_known_engine_gap_revlog_v2_record_ids(handed_off):
    """Documents an observed v11 engine limitation; if this starts failing, the engine changed."""
    receipt, _, _ = handed_off
    ins = by_name(receipt, "synthetic.revlog")["original"]["inspect"]
    if Path(JAR).is_file() and compat.ENGINE_PROFILE["engine_sha256"] == __import__("hashlib").sha256(Path(JAR).read_bytes()).hexdigest():
        assert ins["status"] == "partial"
        assert any("record ID 3" in i.get("reason", "") for i in ins.get("issues", []))
