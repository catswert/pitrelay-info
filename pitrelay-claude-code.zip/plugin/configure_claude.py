"""Prepare a local Claude Code plugin marketplace from a verified PitRelay package.

This is the Claude Code counterpart of PitRelay's setup/configure_local.py. It
never edits Claude Code settings, never installs Java and never runs anything
from the package. The programs it starts are the Java you select (to read its
version and properties), the Python you select (to read its version and, with
the collector, to create a private virtual environment and install the
collector's two dependencies from PyPI or a wheelhouse you name, wheels only).

    python3 configure_claude.py --package <extracted-package> --manifest-sha256 <trusted-sha256>
        --accept-license <license-sha256> --java <absolute-java> --state <new-dir> --output <new-dir>
        [--python <python3.10+>] [--without-collector | --wheelhouse <dir>] [--collector-store <dir>]
        [--reuse-state] [--without-host-notes]
        [--workspace <dir> --workspace-disclosure accepted-v1 [--grants project_read,...]]

    python3 configure_claude.py verify --output <prepared-marketplace> [--manifest-sha256 <trusted-sha256>]
        [--receipt-sha256 <kept-receipt-sha256>]
    python3 configure_claude.py show-disclosure --package <extracted-package> --manifest-sha256 <trusted-sha256>
    python3 configure_claude.py wheelhouse --dest <new-dir> [--platform <tag> --python-version <x.y>]
    python3 configure_claude.py pin-overlay

What it does:
1. Checks package-manifest.json against the SHA-256 you retained from the release
   receipt, then every packaged file's size and SHA-256, the engine's entry point,
   and the license hash you acknowledge.
2. Copies the package files unchanged into a new local marketplace
   (<output>/pitrelay), keeps the original plugin.json and manifest under
   provenance/, and adds the reviewed files of this project: the host (host/: one
   local MCP server that runs the unmodified engine, relays its tools, applies the
   documented v11 compatibility fixes and runs PitRelay Collector), the overlay
   (host skills, commands, CLAUDE_CODE.md) and Claude Code metadata
   (.claude-plugin/plugin.json, .mcp.json, host/launch.json).
3. Creates the separate state directory (engine state and, with the collector,
   its Python environment), or keeps an earlier one with --reuse-state. The
   collector store is separate again (by default the standalone PitRelay
   Collector's store) and may already exist. Neither is Claude Code's per-plugin
   data directory, which `claude plugin uninstall` deletes: PitRelay state and
   collected logs must never disappear with the plugin.
4. Publishes the marketplace with a no-replace rename and writes a receipt
   (prepared-installation.json) listing every file and hash, and the identity of
   the collector's Python environment (its launcher and install records).

verify runs the Java and Python named in the receipt (to read their version) only
when --receipt-sha256 matches, and never from inside the marketplace or the state;
otherwise it names them for you to check.

Installing is a separate step you choose to run:
    claude plugin marketplace add <output>
    claude plugin install pitrelay@pitrelay-local

Python 3.10+ standard library only.
"""
from __future__ import annotations

import argparse
import ast
import ctypes
import hashlib
import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import uuid
import zipfile
from email.parser import BytesHeaderParser
from pathlib import Path

GENERATOR = "pitrelay-claude-plugin"
GENERATOR_VERSION = "2.0.0"
MARKETPLACE = "pitrelay-local"
PLUGIN = "pitrelay"
# Claude Code names tools mcp__plugin_<plugin>_<server>__<tool> without shortening them, and the model API
# limits tool names to 64 characters. With the short server key "pr" the prefix is 25 characters, which leaves
# 39 for PitRelay's own names (the longest in v11, pitrelay_report_package_submission_info, is exactly 39).
SERVER = "pr"
TOOL_PREFIX = f"mcp__plugin_{PLUGIN}_{SERVER}__"
MAX_TOOL_NAME = 64
LICENSE = "docs/release/PITRELAY_LICENSE.md"
INJECTION_VARIABLES = ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "CLASSPATH")
GRANTS = ("project_read", "propose", "apply", "execute", "restore", "persist_notebook")
MAX_MANIFEST_BYTES = 1024 * 1024
MAX_METADATA_BYTES = 64 * 1024
HERE = Path(__file__).resolve().parent
OVERLAY = HERE / "overlay"
HOST = HERE / "host"
COLLECTOR_PACKAGE = HERE / "collector" / "src" / "pitrelay_collector"

def components() -> tuple:
    """What this project adds to the plugin, by plugin path, from these folders. Python caches are skipped;
    host/launch.json is generated at setup."""
    return (("", OVERLAY), ("host/", HOST), ("host/pitrelay_collector/", COLLECTOR_PACKAGE))


SKIPPED_SOURCE_NAMES = ("__pycache__", "launch.json")
# The collector's dependencies (collector/pyproject.toml), installed as wheels into <state>/python.
COLLECTOR_REQUIREMENTS = ("paramiko>=3.4", "keyring>=24")
# Overlay files that only work with the collector; --without-collector leaves them out of the plugin.
COLLECTOR_ONLY_OVERLAY = ("skills/pitrelay-collect/", "commands/collect.md")
# The reviewed files: exactly these files, with exactly these bytes, are added to the plugin. Anything else is refused,
# so nobody can slip a hook, an agent or changed host code into a teammate's plugin by dropping a file into the project.
# After reviewing a change, refresh this table with: python3 configure_claude.py pin-overlay
OVERLAY_INVENTORY = {
    "CLAUDE_CODE.md": "91ee0d53ad2d33d717ee87f4f1f9ac7c5b3ac6246340bd6b24ef7371019b9ca2",
    "commands/checkup.md": "1d0e20c35f835127e30d33401e204073f75f1a812a740d1847c68732baf27bd7",
    "commands/collect.md": "f5c1a426b179a31a2077fb288bccaaf3ac664e47709b343c8e3e7d3d54f11777",
    "commands/diagnose.md": "4a534687fc0ad11dabd06f64eaed5594898a4ed9a7c39cc43e999fe52773527e",
    "commands/import-collection.md": "e8f8260cd6d54123eb9e8cdee533335e03999f38554863bcdd971f2993314440",
    "commands/start.md": "c301113a578dae027b3dfabb38e11ec1c1ed88feb42954c9741ded2189817dfe",
    "host/collector.py": "63c41fbf8a643d73d4e39fab8df003db8c9f895df4d2718520e46022c342f930",
    "host/gateway.py": "bc32c60909abc953ee359efeb03fadc7d7a8640081c75b726b07104efa644390",
    "host/pitrelay_collector/__init__.py": "63b4b5fd8045dd0e5527db1b1835d40400d57d48ec9f5d253f862175adccf6df",
    "host/pitrelay_collector/__main__.py": "935a1c1166b0c1ea35a82256345000bf2c73ded718d77773bc27a71ecce28f7d",
    "host/pitrelay_collector/app.py": "80e538cf12278c794214a48eb0df2c3b1f2245209c5c67a782b9b0925dc42550",
    "host/pitrelay_collector/autostart.py": "495eb5d5d3d7f4c603f0a712d3334dd261eb91cc565624eb2e2297edeffbfb40",
    "host/pitrelay_collector/cli.py": "c648048c15ec222b342fb948063e491a77e45c9d809ebc1e4370c2ad139ed218",
    "host/pitrelay_collector/collector.py": "9568f01d84118e78325a8a31c198c2303a3b55e6990d0c76a26305f1c33bccec",
    "host/pitrelay_collector/compat.py": "826687e769568c665fa4b9c9a75e06c792016744f24e1a90dda2ed21343df385",
    "host/pitrelay_collector/config.py": "0ed8b94a46586aef490d04e6cd2f14a8e1517e7dba8f5ce4a334b04e56a3e8f6",
    "host/pitrelay_collector/export.py": "0ac949b04948d1a0d80d6b83f72d109fafd43c952c7c7543b4b4b3b5ea774926",
    "host/pitrelay_collector/formats.py": "8c54e5595f2b5ea0ff1dc8b88c26801b14426d9dd59f974b2e9a0864cb21b76d",
    "host/pitrelay_collector/handoff.py": "4cb3ca5d591734df4c097ef5e8255604dcd230e9a15a035ab5554438fb852583",
    "host/pitrelay_collector/lock.py": "fdb54018a3d542270b9e9a4b7c60bb6487bdfab88e5ecd7cf138f1603dcecfb8",
    "host/pitrelay_collector/package.py": "6c9b1de9e7526bc0746bad9b5d075874cfe06f49fcbc656ae68508064518aa0d",
    "host/pitrelay_collector/projectscan.py": "f780f75e8ba58afbaa57c29f7e27a3d35ea6c8c891234ff10ee22dfd0e59a0ba",
    "host/pitrelay_collector/secrets.py": "34d41c6433f28c5a4dc59252adec359cb15fd1a2e3192ef4ef95074751e45dc2",
    "host/pitrelay_collector/sources.py": "f541b16b292e42700e3d5a80966c43db06b8be7e41c1b9480a6302ea8fe1a797",
    "host/pitrelay_collector/static/app.js": "65083e6d6a3a3743e99462560d11db771230137c2cc7382eca63b5faeee66d6e",
    "host/pitrelay_collector/static/index.html": "b6b20a79ccce4552557d14ac889a11fdf93072e347bafcd843333c48be9f850e",
    "host/pitrelay_collector/static/style.css": "ea2522f0da326670013d6fac31e8f8e8bfd56605ceb005199d13f33ca2ee4270",
    "host/pitrelay_collector/status.py": "fb1f55ac673d72f092f5126f7e6f42c058853b9689f52635e4840722a4734660",
    "host/pitrelay_collector/store.py": "8de1f01ad935cb729a2a10a99b2a5856becf6346d8feb639c4421a15bb4ffdf4",
    "host/pitrelay_collector/synthetic.py": "16f0d67086d3df06ea6066889645f3e9530ce089fd0b139ce44866a6f1a6bbad",
    "host/pitrelay_collector/util.py": "c08b76a331ee28483b43a7eec1248e24e44728b0e54081eb94f126e57b78708d",
    "host/pitrelay_collector/webui.py": "db5def86d00a7aad7d3115633a24104ef1edb84e894cbe377b7d445e5b22a31e",
    "host/pitrelay_host/__init__.py": "7dcec4b764dee240645a6ff8c90db56410a9b343368b3802a48fe6fc3c285ee4",
    "host/pitrelay_host/collector_tools.py": "21ab01f5713be52ed36f6931b0afad89a8a2c373bd882024858cf9dabaeda399",
    "host/pitrelay_host/compat.py": "ff92a707c319ff7df56340550747e0dbe77d06c5b1a479c3867952ea5dde65d3",
    "host/pitrelay_host/engine.py": "9dbc092662f33722dd3172c0585fdd0054e3346058f2e9dc11c0e936ff818fa5",
    "host/pitrelay_host/main.py": "aa9c5e7a210ec6912a1abe7f3ef21dbbb9d5abe0f1fa0cf4ccf7ad63dcc98545",
    "host/pitrelay_host/relay.py": "5bf1fcaf9ed9d7e34c5cc89cd7144ae50fcd1a74b75e64c0d9a3499f3ebd980a",
    "skills/pitrelay-claude-host/SKILL.md": "5172d645ba758450b4df8c5294348d9857982e3aa804ef079892382f68c85d70",
    "skills/pitrelay-collect/SKILL.md": "724729b00e66d2af91d4c5f0c2aa2134d8fd3145e57e22141806b786c9bbde6b",
    "skills/pitrelay-collector-intake/SKILL.md": "302172bfaabe95144a35eb8f7a503945dd3a4671158f8a5663e5a90045a149c1",
}
# Package paths that Claude Code would load as live components (hooks run shell commands at session start,
# agents and commands carry their own tool permissions). A PitRelay package never contains them.
RESERVED_PACKAGE_PATHS = ("hooks/", "agents/", "commands/", "output-styles/", "outputStyles/", "monitors/", "bin/",
                          ".claude-plugin/", ".claude/", "provenance/", "host/")
RESERVED_PACKAGE_FILES = (".mcp.json", ".lsp.json", "settings.json", "SKILL.md", "CLAUDE_CODE.md", "hooks.json")
# Skill front-matter keys that would widen what a skill may do without asking.
FORBIDDEN_SKILL_KEYS = ("allowed-tools", "hooks", "context", "agent", "model")
# The Workspace Access disclosure is PitRelay's own text. It is read from the verified package at setup time
# (parsed, never executed), so it always matches the package version and is not copied into this repository.
DISCLOSURE_SOURCE = "setup/package_local.py"
DISCLOSURE_ACK = "accepted-v1"
_PATH_RE = re.compile(r"[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)*")
_HEX64 = re.compile(r"[0-9a-f]{64}")
_VERSION_RE = re.compile(r"[0-9A-Za-z][0-9A-Za-z.+-]{0,39}")
_CASE_INSENSITIVE = sys.platform in ("darwin", "win32")  # default APFS and NTFS


class SetupError(ValueError):
    pass


# --- small helpers -----------------------------------------------------------------------


def valid_hash(value) -> bool:
    return isinstance(value, str) and _HEX64.fullmatch(value) is not None


def given_hash(value: str, option: str) -> str:
    """A SHA-256 typed or pasted by the person, in lowercase; any other value is refused as a format error."""
    normalized = value.strip().lower() if isinstance(value, str) else ""
    if not valid_hash(normalized):
        raise SetupError(f"{option} must be a SHA-256: 64 hex characters (got {str(value)[:80]!r})")
    return normalized


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def is_link(path: Path) -> bool:
    """Symlink, junction or any other reparse point (Windows)."""
    try:
        st = os.lstat(path)
    except (FileNotFoundError, NotADirectoryError):
        return False
    if stat.S_ISLNK(st.st_mode):
        return True
    if getattr(path, "is_junction", None) and path.is_junction():
        return True
    return bool(getattr(st, "st_file_attributes", 0) & 0x400)  # FILE_ATTRIBUTE_REPARSE_POINT


def no_links(path: Path, role: str) -> None:
    """Refuse a path that is, or passes through, a link: what is verified must be what runs."""
    path = Path(os.path.abspath(path))
    for node in (path, *path.parents):
        if is_link(node):
            raise SetupError(f"{role} path passes through a link or junction ({node}); use the real path "
                             f"{os.path.realpath(path)} instead")


def canonical(path: Path) -> Path:
    """Resolve what exists (Windows 8.3 names, subst drives, case); keep the not-yet-created tail as written."""
    return Path(os.path.realpath(path))


def _same(a: Path, b: Path) -> bool:
    try:
        return os.path.samefile(a, b)  # identity, whatever the spelling
    except OSError:
        sa, sb = os.path.normcase(str(a)), os.path.normcase(str(b))
        return sa.casefold() == sb.casefold() if _CASE_INSENSITIVE else sa == sb


def within(child: Path, parent: Path) -> bool:
    """`child` is `parent` or lies inside it, compared by file identity where the folders exist."""
    child, parent = canonical(child), canonical(parent)
    return any(_same(node, parent) for node in (child, *child.parents))


def lies_in(path: Path, folder: Path) -> bool:
    """`path` as written (its links not followed) is `folder` or lies inside it."""
    path = Path(os.path.abspath(path))
    return any(_same(node, folder) for node in (path, *path.parents))


def disjoint(named: dict[str, Path]) -> None:
    items = list(named.items())
    for i, (a, pa) in enumerate(items):
        for b, pb in items[i + 1:]:
            if within(pa, pb) or within(pb, pa):
                raise SetupError(f"{a} and {b} must be separate, non-overlapping folders ({pa} / {pb})")


def claude_plugin_dirs() -> list[Path]:
    """Claude Code's plugin folders (cache, data): uninstalling or cleanup deletes what is inside them."""
    roots = [Path.home() / ".claude"]
    if os.environ.get("CLAUDE_CONFIG_DIR"):
        roots.append(Path(os.environ["CLAUDE_CONFIG_DIR"]))
    return [r / "plugins" for r in roots]


def unique_object(pairs):
    out = {}
    for k, v in pairs:
        if k in out:
            raise SetupError(f"Duplicate JSON field: {k}")
        out[k] = v
    return out


def write_json_new(path: Path, value) -> None:
    with open(path, "x", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def copy_new(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with open(source, "rb") as src, open(target, "xb") as dst:
        shutil.copyfileobj(src, dst, 1024 * 1024)


def tree_files(folder: Path) -> tuple[dict[str, Path], set[str]]:
    """Every regular file and directory under folder; links and special files are refused."""
    files: dict[str, Path] = {}
    dirs: set[str] = set()
    pending = [folder]
    while pending:
        current = pending.pop()
        with os.scandir(current) as it:
            entries = sorted(it, key=lambda e: e.name)
        for e in entries:
            p = Path(e.path)
            rel = p.relative_to(folder).as_posix()
            if is_link(p):
                raise SetupError(f"A link is not allowed here: {rel}")
            mode = os.lstat(p).st_mode
            if stat.S_ISDIR(mode):
                dirs.add(rel)
                pending.append(p)
            elif stat.S_ISREG(mode):
                files[rel] = p
            else:
                raise SetupError(f"A special file is not allowed here: {rel}")
    return files, dirs


def rename_noreplace(source: Path, destination: Path) -> None:
    """Publish atomically, refusing an existing destination in the OS call itself."""
    if sys.platform == "win32":
        os.rename(source, destination)  # never replaces on Windows
        return
    if sys.platform not in ("linux", "darwin"):
        raise SetupError("Exclusive rename is unavailable on this platform")
    libc = ctypes.CDLL(None, use_errno=True)
    if sys.platform == "linux":
        fn = getattr(libc, "renameat2", None)
        if fn is None:
            raise SetupError("renameat2 is unavailable; cannot publish without risking replacement")
        fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        args = [-100, os.fsencode(source), -100, os.fsencode(destination), 1]  # AT_FDCWD, RENAME_NOREPLACE
    else:
        fn = getattr(libc, "renamex_np", None)
        if fn is None:
            raise SetupError("renamex_np is unavailable; cannot publish without risking replacement")
        fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_uint]
        args = [os.fsencode(source), os.fsencode(destination), 4]  # RENAME_EXCL
    fn.restype = ctypes.c_int
    if fn(*args) != 0:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err), str(source), None, str(destination))


# --- package verification ------------------------------------------------------------------


def read_manifest(package: Path, manifest_sha256: str) -> tuple[dict, bytes]:
    if not valid_hash(manifest_sha256):
        raise SetupError("--manifest-sha256 must be 64 lowercase hex characters from your retained release receipt")
    path = package / "package-manifest.json"
    if is_link(path) or not path.is_file():
        raise SetupError("package-manifest.json is missing (is --package the extracted package folder?)")
    with open(path, "rb") as f:
        raw = f.read(MAX_MANIFEST_BYTES + 1)
    if len(raw) > MAX_MANIFEST_BYTES:
        raise SetupError("package-manifest.json is larger than 1 MiB")
    if hashlib.sha256(raw).hexdigest() != manifest_sha256:
        raise SetupError("package-manifest.json does not match the SHA-256 you supplied; do not use this package")
    return parse_manifest(raw), raw


def parse_manifest(raw: bytes) -> dict:
    try:
        manifest = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object)
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise SetupError(f"package-manifest.json is not valid JSON: {e}") from None
    validate_manifest(manifest)
    return manifest


def validate_manifest(m) -> None:
    if not isinstance(m, dict):
        raise SetupError("Package manifest must be a JSON object")
    need = {"schema_version": "1.0", "workflow_contract": "2", "entry_point": "org.pitrelay.Main"}
    for key, expected in need.items():
        if m.get(key) != expected:
            raise SetupError(f"Unsupported package: manifest {key} is {m.get(key)!r}, expected {expected!r}")
    if not isinstance(m.get("version"), str) or not _VERSION_RE.fullmatch(m["version"]):
        raise SetupError("Package manifest version is missing or malformed")
    if not valid_hash(m.get("engine_sha256")):
        raise SetupError("Package manifest has no valid engine_sha256")
    rows = m.get("files")
    if not isinstance(rows, list) or not rows:
        raise SetupError("Package manifest has no file inventory")
    paths = []
    for row in rows:
        if not isinstance(row, dict) or set(row) != {"path", "byte_size", "sha256"}:
            raise SetupError("Malformed file record in package manifest")
        p = row["path"]
        if not isinstance(p, str) or not _PATH_RE.fullmatch(p) or any(part in (".", "..") for part in p.split("/")):
            raise SetupError(f"Package file path is not a canonical relative path: {p!r}")
        if not isinstance(row["byte_size"], int) or isinstance(row["byte_size"], bool) or row["byte_size"] < 0 \
                or not valid_hash(row["sha256"]):
            raise SetupError(f"Package file size or hash is malformed: {p}")
        folded = p.casefold()  # APFS and NTFS are case-insensitive: Hooks/ is hooks/ there
        if folded.startswith(tuple(r.casefold() for r in RESERVED_PACKAGE_PATHS)) or \
                folded in {r.casefold() for r in RESERVED_PACKAGE_FILES}:
            raise SetupError(f"Package lists {p}, a location Claude Code would load as a live plugin component; "
                             "a PitRelay package never contains one")
        paths.append(p)
    if paths != sorted(set(paths)):
        raise SetupError("Package file inventory must be sorted and free of duplicates")
    folded = [p.casefold() for p in paths]
    if len(set(folded)) != len(folded):
        raise SetupError("Package file paths collide on case-insensitive filesystems")
    if "package-manifest.json" in paths:
        raise SetupError("The manifest must not list itself")
    required = {"engine/pitrelay.jar", LICENSE, "plugin.json"}
    missing = required - set(paths)
    if missing:
        raise SetupError(f"Package is missing required files: {sorted(missing)}")
    if not any(p.startswith("skills/") and p.endswith("/SKILL.md") for p in paths):
        raise SetupError("Package contains no skills")
    engine = next(r for r in rows if r["path"] == "engine/pitrelay.jar")
    if engine["byte_size"] == 0 or engine["sha256"] != m["engine_sha256"]:
        raise SetupError("Engine identity in the inventory differs from engine_sha256")


def verify_tree(package: Path, manifest: dict) -> None:
    files, dirs = tree_files(package)
    expected = {r["path"] for r in manifest["files"]} | {"package-manifest.json"}
    extra, missing = sorted(set(files) - expected), sorted(expected - set(files))
    if extra or missing:
        hint = (" The unexpected files are Python caches, created by running the package's setup scripts without -B; "
                 "delete those __pycache__ folders and run again." if extra and all("__pycache__/" in x for x in extra) else "")
        raise SetupError(f"Package files differ from its manifest; missing={missing[:10]} unexpected={extra[:10]}.{hint}")
    implied = {"/".join(p.split("/")[:i]) for p in expected for i in range(1, len(p.split("/")))}
    if dirs != implied:
        raise SetupError(f"Package has unexpected folders: {sorted(dirs - implied)[:10]}")
    for row in manifest["files"]:
        p = files[row["path"]]
        if p.stat().st_size != row["byte_size"] or digest(p) != row["sha256"]:
            raise SetupError(f"Package file bytes differ from the manifest: {row['path']}; do not use this package")


_FRONT_MATTER_KEY = re.compile(r"([A-Za-z0-9_][A-Za-z0-9_.-]*):(?:[ \t]|$)")


def check_skill_front_matter(rel: str, data: bytes) -> None:
    """Package skills may describe themselves but not grant themselves tools, hooks or another model.

    Claude Code reads the front matter as YAML, which can spell a key in many ways (a flow mapping, a '?' key, a quoted
    or escaped key, an anchor, alias or tag, an indented root mapping). Only the plain form is accepted: unindented
    'key: value' lines with a bare key, each optionally followed by indented lines continuing its value, so every
    top-level key Claude Code sees is one this check sees."""
    text = data.decode("utf-8", errors="replace").lstrip("\ufeff").lstrip()
    if not text.startswith("---"):
        return

    def refuse(number: int, why: str):
        raise SetupError(f"Skill {rel} front matter line {number}: {why}. Claude Code reads it as YAML, where this form "
                         "could hide a key that would change what it may do without asking; PitRelay skills use plain "
                         "'key: value' lines only")
    lines = text.splitlines()
    if lines[0].rstrip() != "---":
        refuse(1, "the opening line is not exactly '---'")
    keys_seen = False
    for number, line in enumerate(lines[1:], start=2):
        if line.startswith(("---", "...")):
            if line.rstrip() != "---":
                refuse(number, f"{line[:40]!r} is not a plain closing '---'")
            return
        if not line.strip() or line.startswith("#"):
            continue
        if line[0] in " \t":
            if not keys_seen:
                refuse(number, "an indented line before the first key")
            continue  # continues the value of the key above
        m = _FRONT_MATTER_KEY.match(line)
        if not m:
            refuse(number, f"{line[:40]!r} is not a plain 'key: value' line")
        keys_seen = True
        key = m[1].lower()
        if key in FORBIDDEN_SKILL_KEYS:
            raise SetupError(f"Skill {rel} declares '{key}', which would change what it may do without asking; "
                             "PitRelay skills never do")
    refuse(len(lines), "the front matter has no closing '---' line")


def verify_engine(jar: Path) -> None:
    try:
        with zipfile.ZipFile(jar) as z:
            names = z.namelist()
            if "org/pitrelay/Main.class" not in names:
                raise SetupError("Engine jar lacks the org.pitrelay.Main entry point")
            if names.count("META-INF/MANIFEST.MF") != 1 or z.getinfo("META-INF/MANIFEST.MF").file_size > 65536:
                raise SetupError("Engine jar needs exactly one bounded manifest")
            main = z.read("META-INF/MANIFEST.MF").decode("utf-8").replace("\r\n", "\n").split("\n\n", 1)[0]
    except zipfile.BadZipFile:
        raise SetupError("Engine jar is not a valid archive") from None
    attrs = {}
    for line in main.replace("\n ", "").splitlines():
        if ": " in line:
            k, v = line.split(": ", 1)
            attrs[k.lower()] = v
    if attrs.get("main-class") != "org.pitrelay.Main" or "class-path" in attrs:
        raise SetupError("Engine manifest must select org.pitrelay.Main and carry no external Class-Path")


def workspace_disclosure_text(package: Path, manifest: dict) -> str:
    """PitRelay's WORKSPACE_DISCLOSURE string from the verified package, read with ast (never executed)."""
    if DISCLOSURE_SOURCE not in {r["path"] for r in manifest["files"]}:
        raise SetupError(f"This package has no {DISCLOSURE_SOURCE}, so its Workspace Access disclosure cannot be shown; "
                         "use Standard Access")
    try:
        tree = ast.parse((package / DISCLOSURE_SOURCE).read_text(encoding="utf-8"))
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "WORKSPACE_DISCLOSURE"
                                                    for t in node.targets):
                text = ast.literal_eval(node.value)
                if isinstance(text, str) and text.strip():
                    return text
    except (OSError, SyntaxError, ValueError) as e:
        raise SetupError(f"Could not read the Workspace Access disclosure from {DISCLOSURE_SOURCE}: {e}") from None
    raise SetupError(f"{DISCLOSURE_SOURCE} defines no WORKSPACE_DISCLOSURE text; use Standard Access")


def author_from(plugin_json: Path) -> dict:
    """Author of the package, read from the verified copy (never from the source folder after verification)."""
    try:
        with open(plugin_json, "rb") as f:
            raw = f.read(MAX_METADATA_BYTES + 1)
        meta = json.loads(raw[:MAX_METADATA_BYTES].decode("utf-8"), object_pairs_hook=unique_object)
    except (OSError, ValueError):
        return {"name": "PitRelay"}
    author = meta.get("author") if isinstance(meta, dict) else None
    if isinstance(author, dict) and isinstance(author.get("name"), str) and author["name"].strip():
        return {k: author[k][:200] for k in ("name", "email", "url") if isinstance(author.get(k), str)}
    return {"name": "PitRelay"}


# --- the Java runtime ----------------------------------------------------------------------------


UTF8_LOCALES = ("C.UTF-8", "C.utf8", "en_US.UTF-8")
_LINUX_LIKE = os.name == "posix" and sys.platform != "darwin"


def java_properties(java: Path, cwd: Path, extra_env: dict | None = None) -> tuple[dict, str]:
    """Run `java -XshowSettings:properties -version` and return (properties, raw output).

    The output is forced to UTF-8 (a Windows JDK otherwise writes piped output in the ANSI code page) and, on
    Linux, the probe runs under a UTF-8 locale unless one is given, so a JDK under a non-ASCII path reports its
    real java.home.
    """
    env = {k: v for k, v in os.environ.items() if k.upper() not in INJECTION_VARIABLES}
    if _LINUX_LIKE:
        env["LC_ALL"] = UTF8_LOCALES[0]
    env.update(extra_env or {})
    flags = ["-Dstdout.encoding=UTF-8", "-Dstderr.encoding=UTF-8", "-Dsun.stdout.encoding=UTF-8",
             "-Dsun.stderr.encoding=UTF-8"]
    try:
        done = subprocess.run([str(java), *flags, "-XshowSettings:properties", "-version"], cwd=cwd, env=env, shell=False,
                              capture_output=True, timeout=60)
    except (OSError, subprocess.SubprocessError) as e:
        raise SetupError(f"Could not run the selected Java: {e}") from None
    out = (done.stdout + done.stderr).decode("utf-8", errors="replace")
    props = {}
    for line in out.splitlines():
        m = re.match(r"^    ([A-Za-z0-9_.]+) = (.*)$", line)
        if m:
            props[m[1]] = m[2]
    if done.returncode != 0:
        raise SetupError("The selected Java failed to report its properties: " + out[-2048:])
    return props, out


def link_chain(path: Path) -> list[Path]:
    """The path as given, then as each link in it spells it, resolved one link at a time from the left."""
    chain = [Path(os.path.abspath(path))]
    for _ in range(40):  # as the operating system limits a chain of links
        parts = chain[-1].parts
        for i in range(1, len(parts) + 1):
            node = Path(*parts[:i])
            if os.path.islink(node):
                chain.append(Path(os.path.normpath(node.parent / os.readlink(node))).joinpath(*parts[i:]))
                break
        else:
            break
    return chain


def names_version(path: Path, version: str | None) -> bool:
    """`path` spells the runtime's full version (21.0.4 in Cellar/openjdk@21/21.0.4 or java-21-openjdk-21.0.4.0.7-1):
    a folder that an update to another version removes. A version without a minor part (21) names nothing here."""
    if not version or not re.fullmatch(r"\d+\.\d+[0-9A-Za-z.+_-]*", version):
        return False
    return re.search(rf"(?<![0-9]){re.escape(version)}(?![0-9])", str(path)) is not None


def select_runtime(java_given: Path, cwd: Path, avoid=()) -> dict:
    """Find the real Java runtime behind the selected file (launcher stubs and version-manager shims included).

    `launcher` is that runtime's own launcher; `executable`, the path that is pinned, starts it. When the launcher lies
    in a folder named for the runtime's full version (Homebrew's Cellar, Fedora's java-21-openjdk-21.0.4..., SDKMAN),
    which an update removes, a path that leads to it through links only is pinned by the shallowest spelling in its
    chain of links that does not name the version, provided neither it nor any link after it lies in one of the `avoid`
    folders (whoever controls those could switch the Java). Otherwise the launcher itself is pinned, as a link such as
    Debian's /usr/bin/java (alternatives) could later lead to another installed Java. verify reports a pinned link that
    leads elsewhere, and fails unless that is a native launcher of the same major version reporting a new version."""
    props, out = java_properties(java_given, cwd)
    m = re.search(r'(?:openjdk|java) version "(\d+)(?:[.\-"]|$)', out)
    if not m or int(m[1]) < 17:
        raise SetupError("An existing Java 17 or later is required; the selected Java said: " + out[-2048:])
    home = props.get("java.home")
    launcher_name = "java.exe" if os.name == "nt" else "java"
    real = Path(os.path.realpath(Path(home) / "bin" / launcher_name)) if home else None
    selected = Path(os.path.realpath(java_given))
    if real is None or not real.is_file():
        # java.home could not be turned back into a path (an unusual layout or encoding): if the selected file is
        # itself a Java launcher, use it as it is rather than refusing a working runtime.
        if selected.name.lower() == launcher_name and selected.is_file():
            real = selected
        else:
            raise SetupError(f"Could not find the launcher of the runtime the selected Java reported (java.home {home!r}); "
                             "select that runtime's bin/java directly")
    full_version = props.get("java.version")
    pinned = real
    if real != selected:
        # The selected file was a stub or shim (asdf, jenv, /usr/bin/java on macOS): pin the runtime it chose,
        # so Claude Code never re-selects a different Java from the project folder it happens to start in.
        props, out = java_properties(real, cwd)
    else:
        chain = link_chain(java_given)
        # Without a link, the path as resolved is kept (Windows: no subst drive or short name).
        if len(chain) > 1 and names_version(real, full_version):
            pinned = next((p for i, p in enumerate(chain) if not names_version(p, full_version)
                           and Path(os.path.realpath(p)) == real
                           and not any(lies_in(q, folder) for q in chain[i:] for folder in avoid)), real)
    warning = None
    if names_version(pinned, full_version) and not names_version(Path(os.path.abspath(java_given)), full_version):
        warning = (f"The Java is pinned by {pinned}, a folder named for version {full_version}: a JDK update that removes "
                   "this folder will require preparing again.")
    return {"executable": pinned, "launcher": real, "major": int(m[1]), "java_home": props.get("java.home", home),
            "vendor": props.get("java.vendor"), "version": props.get("java.runtime.version") or props.get("java.version"),
            "sun_jnu_encoding": props.get("sun.jnu.encoding"), "version_output": out[-2048:], "warning": warning}


def native_windows_code_page():
    if os.name != "nt":
        return None
    try:
        fn = ctypes.WinDLL("kernel32", use_last_error=True).GetACP
        fn.argtypes = []
        fn.restype = ctypes.c_uint
        cp = fn()
    except (AttributeError, OSError) as e:
        raise SetupError("Cannot read the Windows launcher code page (GetACP)") from e
    if not cp:
        raise SetupError("GetACP returned no code page")
    return cp


def launcher_preflight(values: dict[str, str], classpath: str, java: Path, cwd: Path) -> tuple[dict, dict]:
    """The Java launcher must receive these strings exactly (PitRelay's own rules, plus POSIX locales).

    Returns (report, extra environment for the server).
    """
    if os.pathsep in classpath:
        raise SetupError(f"The engine path {classpath!r} contains {os.pathsep!r}, which Java would split; "
                         "choose an output folder without it")
    env: dict[str, str] = {}
    cp = native_windows_code_page()
    if cp is not None:
        enc = f"cp{cp}"
        for role, value in values.items():
            try:
                ok = value.encode(enc, errors="strict").decode(enc, errors="strict") == value
            except (UnicodeError, LookupError):
                ok = False
            if not ok:
                raise SetupError(f"WINDOWS_JAVA_PATH_ENCODING: the {role} cannot be passed exactly through code page {cp}; "
                                 "choose a path using only characters of that code page")
        return {"native_windows_code_page": cp, "encoding_check": "representable_in_native_code_page"}, env
    non_ascii = sorted(role for role, value in values.items() if not value.isascii())
    if sys.platform == "darwin":  # macOS Java always uses UTF-8 for file names
        return {"native_windows_code_page": None, "encoding_check": "macos_utf8"}, env
    # Linux and other POSIX: the JVM decodes file names with the locale Claude Code happens to run under. Under a
    # POSIX locale (common over ssh and in containers) any non-ASCII name, in the configured paths or in files
    # inside the workspace, cannot be opened. Pin a UTF-8 locale for the server, checking that this Java honors it.
    for locale_name in UTF8_LOCALES:
        props, _ = java_properties(java, cwd, {"LC_ALL": locale_name})
        if (props.get("sun.jnu.encoding") or "").upper().replace("-", "") == "UTF8":
            env["LC_ALL"] = locale_name
            return {"native_windows_code_page": None, "encoding_check": f"utf8_file_names_with_LC_ALL={locale_name}",
                    "non_ascii": non_ascii}, env
    if non_ascii:
        raise SetupError(f"The {', '.join(non_ascii)} contain non-ASCII characters and this Java cannot be given a "
                         "UTF-8 locale for file names; choose paths with ASCII characters only")
    return {"native_windows_code_page": None, "encoding_check": "no_utf8_locale_available",
            "warning": "No UTF-8 locale is available to this Java: files with non-ASCII names inside the workspace "
                       "cannot be read when Claude Code runs under a non-UTF-8 locale"}, env


# --- the Python runtime --------------------------------------------------------------------------

# sys.version is the full build string (version, build date, compiler): a rebuild or a distribution's backported fix
# changes it, other bytes put in the interpreter's place do not.
_PYTHON_PROBE = ("import json, os, sys, sysconfig; print(json.dumps({'executable': sys.executable, "
                 "'version': list(sys.version_info[:3]), 'implementation': sys.implementation.name, 'prefix': sys.prefix, "
                 "'base_prefix': sys.base_prefix, 'base_executable': getattr(sys, '_base_executable', sys.executable), "
                 "'gil_disabled': bool(sysconfig.get_config_var('Py_GIL_DISABLED')), 'sys_version': sys.version}))")
# pip settings that would install somewhere else or refuse wheels; index, proxy and certificate settings are kept,
# because schools and clubs often need them.
PIP_OVERRIDES = {"PIP_USER": "0", "PIP_TARGET": "", "PIP_PREFIX": "", "PIP_ROOT": "", "PIP_NO_BINARY": "",
                 "PIP_ONLY_BINARY": "", "PIP_REQUIRE_HASHES": ""}
# The versions the collector was tested with. Setup installs exactly these where they apply (other platforms add their
# own small dependencies); if they cannot be installed here, it installs the newest compatible versions instead and
# records that in the receipt.
COLLECTOR_TESTED_VERSIONS = ("bcrypt==5.0.0", "cffi==2.1.1", "cryptography==50.0.2", "invoke==3.0.3",
                             "jaraco.classes==3.4.0", "jaraco.context==6.1.2", "jaraco.functools==4.6.0", "jeepney==0.9.0",
                             "keyring==25.7.0", "more-itertools==11.2.1", "paramiko==5.1.0", "PyNaCl==1.6.2",
                             "SecretStorage==3.5.0")


def _python_env() -> dict:
    # -I already ignores PYTHON* variables; dropping them also keeps them out of pip and venv child processes.
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith("PYTHON")}
    env.update(PIP_OVERRIDES)
    return env


def python_info(python: Path, cwd: Path) -> dict:
    try:
        done = subprocess.run([str(python), "-I", "-B", "-c", _PYTHON_PROBE], cwd=cwd, env=_python_env(), shell=False,
                              capture_output=True, timeout=60)
    except (OSError, subprocess.SubprocessError) as e:
        raise SetupError(f"Could not run the selected Python: {e}") from None
    out = done.stdout.decode("utf-8", "replace").strip()
    if done.returncode != 0 or not out:
        raise SetupError("The selected Python failed to report itself: " + (done.stderr or b"").decode("utf-8", "replace")[-1024:])
    try:
        info = json.loads(out.splitlines()[-1])
    except ValueError:
        raise SetupError("The selected Python reported itself in an unexpected form") from None
    if not isinstance(info, dict) or not isinstance(info.get("version"), list):
        raise SetupError("The selected Python reported itself in an unexpected form")
    return info


_UNVERSIONED_PYTHON = ("python", "python3", "python.exe", "python3.exe")


def select_python(python_given: Path, cwd: Path) -> dict:
    """The base interpreter for the host, pinned so that Claude Code always starts the same Python.

    A virtual environment is resolved to its base interpreter. A shim (a pyenv or asdf script, a mise binary: its probe
    reports another interpreter than the file the selected path and its links lead to) is resolved to the interpreter it
    ran, so the Python never depends on the folder Claude Code starts in. An unversioned name (python3) becomes its
    versioned sibling (python3.12) when that is the same file, because the unversioned name can later be moved to
    another minor version, which the collector's environment cannot follow. Otherwise the selected path is kept rather
    than resolved: a versioned name survives patch updates (a Homebrew upgrade removes the resolved Cellar path)."""
    def store_alias(path) -> bool:
        return "windowsapps" in str(path).lower() or "windowsapps" in os.path.realpath(path).lower()
    if store_alias(python_given):
        raise SetupError("The selected Python is the Microsoft Store app alias, which changes path when it updates; install "
                         "Python from python.org and select it instead")
    selected = Path(os.path.abspath(python_given))
    info = python_info(selected, cwd)
    if tuple(info["version"]) < (3, 10):
        raise SetupError(f"Python 3.10 or later is required; the selected Python is {'.'.join(map(str, info['version']))}")
    if info.get("implementation") != "cpython" or info.get("gil_disabled"):
        raise SetupError("Select a standard CPython 3.10 or later (not a free-threaded build or another implementation): "
                         "the collector's dependencies are built for it")
    reasons = []
    warning = None
    probed = Path(os.path.abspath(info["executable"])) if info.get("executable") else None
    if info["prefix"] != info["base_prefix"]:
        env = Path(info["prefix"])
        reference = Path(os.path.abspath(info["base_executable"]))
        if lies_in(reference, env):
            reference = selected  # Python 3.10 reports the environment's own interpreter; its link leads to the base
        # Python 3.11+ reports the base fully resolved (a Homebrew Cellar path, which an upgrade removes). It is pinned by
        # the name in the folder the environment was made from (pyvenv.cfg 'home') or in the base prefix, where that is
        # the same file.
        name = "python.exe" if os.name == "nt" else f"python{info['version'][0]}.{info['version'][1]}"
        folders = [f for f in (pyvenv_home(env), Path(info["base_prefix"]) / ("" if os.name == "nt" else "bin")) if f]
        # Python 3.10 records the folder of the environment it was made from, which can itself be an environment.
        base = next((f / name for f in folders if (f / name).is_file() and not lies_in(f / name, env)
                     and not (f.parent / "pyvenv.cfg").is_file() and _same(f / name, reference)), None)
        if base is None:
            base = Path(os.path.realpath(reference))
            warning = (f"The Python is pinned by its resolved path {base}: the virtual environment {env} names no other "
                       "path to its base interpreter. If an update removes that path, the plugin stops working until you "
                       "prepare again; select the base interpreter by a stable name with --python to avoid this.")
        reasons.append(f"{selected} is in a virtual environment; its base interpreter {base} is pinned")
    elif probed is not None and not _same(probed, selected):
        base = probed
        reasons.append(f"{selected} is a shim that started another interpreter; that interpreter, {base}, is pinned")
    else:
        base = selected
    if base.name.lower() in _UNVERSIONED_PYTHON:
        versioned = f"python{info['version'][0]}.{info['version'][1]}" + (".exe" if base.suffix.lower() == ".exe" else "")
        for candidate in (base.with_name(versioned), probed):
            if candidate is not None and re.fullmatch(r"python\d+\.\d+(\.exe)?", candidate.name, re.I) \
                    and candidate.is_file() and _same(candidate, base):
                reasons.append(f"{base} is an unversioned name; its versioned name {candidate}, the same file, is pinned")
                base = candidate
                break
    if store_alias(base):
        raise SetupError("The selected Python starts the Microsoft Store app alias, which changes path when it updates; "
                         "install Python from python.org and select it instead")
    if not base.is_file():
        raise SetupError(f"Could not find the interpreter behind the selected Python ({base}); select it directly")
    if base != selected:
        before = info["version"]
        info = python_info(base, cwd)
        if info["prefix"] != info["base_prefix"] or info["version"] != before or not info.get("executable") \
                or not _same(Path(os.path.abspath(info["executable"])), base):
            raise SetupError("Could not find a base interpreter behind the selected Python; select it directly")
    return {"executable": base, "resolved": Path(os.path.realpath(base)), "version": ".".join(map(str, info["version"])),
            "implementation": info.get("implementation"), "sys_version": info.get("sys_version"),
            "pinned": "; ".join(reasons) or None, "warning": warning}


def pyvenv_home(env: Path) -> Path | None:
    """The folder a virtual environment was made from (the first 'home' in its pyvenv.cfg, as Python reads it)."""
    try:
        lines = (env / "pyvenv.cfg").read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError):
        return None
    for line in lines:
        key, sep, value = line.partition("=")
        if sep and key.strip().lower() == "home":
            return Path(value.strip()) if os.path.isabs(value.strip()) else None
    return None


def create_python_env(base: Path, target: Path, wheelhouse: Path | None, cwd: Path) -> dict:
    """A private virtual environment with the collector's dependencies, installed as wheels (no build scripts run)."""
    env = _python_env()

    def run(cmd: list[str], what: str, timeout: float, check: bool = True) -> tuple[int, str]:
        try:
            done = subprocess.run(cmd, cwd=cwd, env=env, shell=False, capture_output=True, timeout=timeout)
        except (OSError, subprocess.SubprocessError) as e:
            raise SetupError(f"{what} failed: {e}") from None
        output = (done.stdout + done.stderr).decode("utf-8", "replace")
        if done.returncode != 0 and check:
            hint = (" On Debian or Ubuntu, install the python3-venv package for this Python first."
                    if "ensurepip" in output else
                    " Without internet access, prepare a wheelhouse elsewhere ('configure_claude.py wheelhouse') and pass "
                    "--wheelhouse." if "pip" in cmd else "")
            raise SetupError(f"{what} failed (exit code {done.returncode}).{hint} Its last output: {output[-1500:]}")
        return done.returncode, done.stdout.decode("utf-8", "replace")

    run([str(base), "-I", "-B", "-m", "venv", str(target)], "Creating the collector's Python environment", 600)
    py = venv_python(target)
    source = ["--no-index", "--find-links", str(wheelhouse)] if wheelhouse is not None else []
    pip = [str(py), "-I", "-m", "pip", "install", "--disable-pip-version-check", "--no-input", "--only-binary", ":all:",
           *source]
    what = ("Installing the collector's dependencies (" + ", ".join(COLLECTOR_REQUIREMENTS) + ")"
            + (f" from {wheelhouse}" if wheelhouse is not None else " from PyPI"))
    constraints = target / "tested-versions.txt"
    constraints.write_text("\n".join(COLLECTOR_TESTED_VERSIONS) + "\n", encoding="utf-8")
    code, _ = run([*pip, "-c", str(constraints), *COLLECTOR_REQUIREMENTS], what, 1800, check=False)
    tested = code == 0
    if not tested:
        run([*pip, *COLLECTOR_REQUIREMENTS], what, 1800)
    constraints.unlink()
    run([str(py), "-I", "-B", "-c", "import paramiko, keyring"], "Checking the collector's Python environment", 120)
    return {"python": str(py), "tested_versions": tested}


def site_packages(env_dir: Path, version: str) -> Path:
    """The one site-packages folder of a virtual environment made by this Python version (x.y or x.y.z)."""
    if os.name == "nt":
        return env_dir / "Lib" / "site-packages"
    m = re.fullmatch(r"(\d+)\.(\d+)(?:\.\d+)?", str(version))
    if not m:
        raise SetupError(f"Malformed Python version {version!r}")
    return env_dir / "lib" / f"python{m[1]}.{m[2]}" / "site-packages"


def installed_distributions(env_dir: Path, version: str) -> dict:
    """Name -> version of every distribution in the environment, read from its metadata (nothing is executed)."""
    out = {}
    sp = site_packages(env_dir, version)
    for meta in sorted(sp.glob("*.dist-info/METADATA")) if sp.is_dir() else []:
        name = version = None
        for line in meta.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("Name: "):
                name = line[6:].strip()
            elif line.startswith("Version: "):
                version = line[9:].strip()
            elif not line:
                break
        if name and version:
            out[name] = version
    return dict(sorted(out.items()))


NT_LAUNCHERS = ("python.exe", "pythonw.exe")  # the copies of venv's launcher on Windows (pythonw: background collection)


def install_records(env_dir: Path, version: str) -> dict[str, str]:
    """SHA-256 of every install record (*.dist-info/RECORD) in the environment, for the receipt: anchored by the
    receipt hash, they are what verify trusts to say which files belong in the environment."""
    sp = site_packages(env_dir, version)
    return {f"{r.parent.name}/RECORD": digest(r) for r in sorted(sp.glob("*.dist-info/RECORD"))} if sp.is_dir() else {}


def env_launchers(env_dir: Path) -> dict:
    """What starts the collector's environment (.mcp.json's command), for the receipt: on POSIX venv's link to the base
    interpreter, on Windows (where venv copies a small launcher that reads pyvenv.cfg) the launchers' SHA-256."""
    if os.name == "nt":
        return {f"Scripts/{n}": {"sha256": digest(env_dir / "Scripts" / n)} for n in NT_LAUNCHERS
                if (env_dir / "Scripts" / n).is_file()}
    return {"bin/python": {"link_to": os.path.realpath(venv_python(env_dir))}}


def native_executable(path: Path) -> bool:
    """A compiled program (ELF, Mach-O or PE), not a script that could wrap one."""
    try:
        with open(path, "rb") as f:
            head = f.read(4)
    except OSError:
        return False
    return head == b"\x7fELF" or head[:2] == b"MZ" or head in (b"\xfe\xed\xfa\xce", b"\xfe\xed\xfa\xcf",
                                                                b"\xce\xfa\xed\xfe", b"\xcf\xfa\xed\xfe",
                                                                b"\xca\xfe\xba\xbe")


def record_row_path(sp: Path, row_path: str) -> str:
    """The file an install record row names, as the record spells it (never case-folded: on Windows normcase would
    lowercase it, and the keys of the receipt would no longer match)."""
    return os.path.normpath(os.path.join(sp, row_path))


def env_key(path: str, env_dir: Path) -> str:
    """The receipt's key of a file in the environment: its path inside it, as spelled, with '/' separators."""
    return Path(os.path.relpath(path, env_dir)).as_posix()


def unhashed_files(env_dir: Path, version: str) -> dict[str, str]:
    """SHA-256 of the files in the environment that no install record hashes, for the receipt: those the records list
    without a hash (pip's cached bytecode) and venv's own files (pyvenv.cfg, activate scripts)."""
    import csv
    out: dict[str, str] = {}
    sp = site_packages(env_dir, version)
    for record in sorted(sp.glob("*.dist-info/RECORD")) if sp.is_dir() else []:
        for row in csv.reader(record.read_text(encoding="utf-8").splitlines()):
            if row and (len(row) < 2 or not row[1]):
                full = Path(record_row_path(sp, row[0]))
                if full.is_file() and not is_link(full) and full != record:
                    out[env_key(str(full), env_dir)] = digest(full)
    for dirpath, _, files in os.walk(env_dir):
        for f in files:
            full = Path(dirpath) / f
            rel = Path(os.path.relpath(full, env_dir)).as_posix()
            if _venv_own_file(rel, {}) and not is_link(full):
                out[rel] = digest(full)
    return dict(sorted(out.items()))


def _venv_own_file(rel: str, launchers: dict) -> bool:
    """A file venv writes itself, which no install record lists: its configuration, activate scripts and launchers."""
    if rel in ("pyvenv.cfg", ".gitignore"):
        return True
    folder, _, name = rel.partition("/")
    if folder.lower() != ("scripts" if os.name == "nt" else "bin") or "/" in name:
        return False
    return name.lower().startswith(("activate", "deactivate")) or (os.name == "nt" and f"Scripts/{name}" in launchers)


def check_python_env(env_dir: Path, base: Path, version: str, installed: dict, records: dict | None,
                     launchers: dict | None, unhashed: dict | None = None) -> list[str]:
    """The collector's environment, checked from outside it (it is never run for this).

    It must be made from the recorded Python and start it (bin/python a link to it; on Windows the launchers recorded at
    setup), be isolated from the system's packages, and hold the install records recorded at setup, every file they
    list unchanged, and nothing else anywhere in it except what venv itself writes: a planted .pth file, sitecustomize,
    cached bytecode, or a dist-packages, local or lib64 folder that site.py would add, would run inside the host."""
    import base64
    import csv
    py = venv_python(env_dir)
    if not os.path.lexists(py):
        return [f"the collector's Python environment is missing ({env_dir}); prepare again"]
    problems = []
    try:
        lines = (env_dir / "pyvenv.cfg").read_text(encoding="utf-8").splitlines()
        pairs = [(k.strip().lower(), v.strip()) for k, v in (ln.split("=", 1) for ln in lines if "=" in ln)]
        cfg = dict(pairs)
    except OSError as e:
        return [f"the collector's Python environment has no readable pyvenv.cfg: {e}"]
    if len(cfg) != len(pairs):  # Python uses the first 'home' line, a dict the last: never let them differ
        problems.append("the collector's Python environment has a pyvenv.cfg with a repeated setting")
    if not isinstance(unhashed, dict):
        problems.append("the receipt records no hashes of the collector's Python environment's own files; prepare again")
        unhashed = {}
    if not _same(Path(cfg.get("home", "")), base.parent) and not _same(Path(cfg.get("home", "")), Path(os.path.realpath(base)).parent):
        problems.append("the collector's Python environment was not made from the recorded Python")
    if cfg.get("include-system-site-packages", "false").lower() != "false":
        problems.append("the collector's Python environment includes the system's packages")
    real_base = Path(os.path.realpath(base))
    if not isinstance(launchers, dict) or not launchers:
        problems.append("the receipt records no launcher of the collector's Python environment; prepare again")
        launchers = {}
    if os.name == "nt":
        for rel, rec in launchers.items():
            p = env_dir / rel
            if not (isinstance(rec, dict) and p.is_file() and not is_link(p) and digest(p) == rec.get("sha256")):
                problems.append(f"the collector's Python launcher {rel} is missing or changed since setup")
    elif not is_link(py):
        problems.append("the collector's Python environment starts bin/python, which is a file instead of venv's link to "
                        "the recorded Python, so it could run anything")
    elif Path(os.path.realpath(py)) != real_base:
        problems.append("the collector's Python environment runs a different interpreter than the recorded one")
    try:
        sp = site_packages(env_dir, version)
    except SetupError as e:
        return problems + [str(e)]
    if not sp.is_dir():
        return problems + [f"the collector's Python environment has no site-packages folder for Python {version}"]
    if not isinstance(records, dict):
        problems.append("the receipt records no install records of the collector's Python environment; prepare again")
        records = {}
    present = {f"{r.parent.name}/RECORD": r for r in sp.glob("*.dist-info/RECORD")}
    claimed: set[str] = set()
    untrusted: set[str] = set()  # listed only by a record that is not the one recorded at setup: reported with it
    for name in sorted(set(present) | set(records)):
        record = present.get(name)
        if record is None:
            problems.append(f"install record missing from the collector's Python environment: {name}")
            continue
        try:
            rows = [row for row in csv.reader(record.read_text(encoding="utf-8").splitlines()) if row]
        except (OSError, csv.Error) as e:
            problems.append(f"unreadable install record {record.parent.name}: {e}")
            continue
        # As spelled for reading and for the receipt's keys; case-folded (Windows) only to compare and claim.
        targets = [record_row_path(sp, row[0]) for row in rows]
        why = ("that setup did not make" if name not in records else
               "changed since setup" if digest(record) != records[name] else None)
        if why:
            problems.append(f"install record {why}, in the collector's Python environment: {name} (the {len(rows)} "
                            "files it lists are not trusted)")
            untrusted.update(os.path.normcase(t) for t in targets)
            continue
        for row, target in zip(rows, targets):
            claimed.add(os.path.normcase(target))
            if len(row) < 2 or not row[1]:
                # Listed without a hash (cached bytecode): its hash was recorded at setup instead, by the same key.
                rel = env_key(target, env_dir)
                if os.path.isfile(target) and os.path.normcase(target) != os.path.normcase(str(record)) and (
                        unhashed.get(rel) != digest(Path(target))):
                    problems.append(f"collector dependency file differs from the one installed at setup: {rel}")
                continue
            algo, _, expected = row[1].partition("=")
            try:
                data = Path(target).read_bytes()
            except OSError:
                problems.append(f"collector dependency file missing: {row[0]} ({record.parent.name})")
                continue
            try:
                actual = base64.urlsafe_b64encode(hashlib.new(algo, data).digest()).rstrip(b"=").decode()
            except ValueError:
                problems.append(f"unknown hash in install record {record.parent.name}: {algo}")
                continue
            if actual != expected:
                problems.append(f"collector dependency file differs from its install record: {row[0]}")
    # The whole environment, not only site-packages: Debian's site.py also reads dist-packages folders (and local/),
    # Fedora's lib64, Windows' the environment's own top folder. os.walk does not follow links; each one is reported.
    known = claimed | untrusted
    for dirpath, dirnames, files in os.walk(env_dir):
        dirnames.sort()
        for d in list(dirnames):
            full = os.path.join(dirpath, d)
            rel = Path(os.path.relpath(full, env_dir)).as_posix()
            if is_link(Path(full)):
                dirnames.remove(d)
                if not (os.name != "nt" and rel == "lib64" and os.readlink(full) == "lib"):  # venv's own lib64 -> lib
                    problems.append(f"link in the collector's Python environment: {rel}")
            elif d.lower() == "dist-packages" or rel.lower() in ("local", "lib64"):
                problems.append(f"folder in the collector's Python environment that Python would load packages from, "
                                f"which setup never makes: {rel}")
        for f in sorted(files):
            full = os.path.join(dirpath, f)
            rel = Path(os.path.relpath(full, env_dir)).as_posix()
            if is_link(Path(full)):
                if not (os.name != "nt" and rel.count("/") == 1 and rel.startswith("bin/")
                        and Path(os.path.realpath(full)) == real_base):  # bin/python3, python3.x: venv's links
                    problems.append(f"link in the collector's Python environment: {rel}")
                continue
            if f in OS_METADATA or f.startswith("._"):
                continue  # Finder and Explorer metadata: never loaded by Python
            if _venv_own_file(rel, launchers):
                if not (os.name == "nt" and rel in launchers) and unhashed.get(rel) != digest(Path(full)):
                    problems.append(f"file of the collector's Python environment changed since setup: {rel}")
                continue
            if os.path.normcase(os.path.normpath(full)) in known:
                continue
            inside = Path(os.path.relpath(full, sp)).as_posix() if within(Path(full), sp) else None
            problems.append("file in the collector's Python environment that no install record claims: "
                            + (f"{inside} (in site-packages)" if inside else rel))
    if installed_distributions(env_dir, version) != installed:
        problems.append("the packages in the collector's Python environment differ from those recorded at setup")
    return problems[:50]


# --- generation ----------------------------------------------------------------------------------


def engine_args(state: Path, workspace: Path | None, grants: list[str], plugin_root: Path) -> list[str]:
    """The engine's command line after the Java executable, exactly as host/pitrelay_host/engine.py builds it."""
    args = ["-Xmx384m", f"-Duser.home={state / 'jvm-home'}", f"-Djava.io.tmpdir={state / 'tmp'}",
            "-cp", str(plugin_root / "engine" / "pitrelay.jar"), "org.pitrelay.Main",
            "--state", str(state / "engine"), "--mode", "mcp"]
    if workspace is not None:
        args += ["--experience", "workspace", "--workspace", str(workspace), "--grants", ",".join(grants),
                 "--workspace-disclosure", "accepted-v1"]
    return args


# Claude Code starts the host (one local stdio MCP server); the host starts the engine from host/launch.json. Both
# name the verified marketplace folder directly (not ${CLAUDE_PLUGIN_ROOT}, which may point at Claude Code's cached copy
# of an earlier generation, since the cache is keyed by version).
LAUNCH_SCHEMA = "1.0"
RECEIPT_SCHEMA = "2.0"


def gateway_args(plugin_root: Path) -> list[str]:
    return ["-I", "-B", "-X", "utf8", str(plugin_root / "host" / "gateway.py")]


def mcp_config(python_command: str, extra_env: dict[str, str], plugin_root: Path) -> dict:
    return {"mcpServers": {SERVER: {"command": python_command, "args": gateway_args(plugin_root),
                                    "env": server_env(extra_env)}}}


def host_file_hashes() -> dict[str, str]:
    """The host files (pinned in OVERLAY_INVENTORY) that the host checks against itself when it starts."""
    return {rel: sha for rel, sha in sorted(OVERLAY_INVENTORY.items()) if rel.startswith("host/")}


def launch_spec(java: Path, state: Path, workspace: Path | None, grants: list[str], extra_env: dict[str, str],
                collector: bool, engine_sha256: str, host_notes: bool = True, collector_store: Path | None = None,
                plugin_root: Path | None = None) -> dict:
    return {"schema_version": LAUNCH_SCHEMA, "java": str(java), "state": str(state),
            "plugin_root": str(plugin_root) if plugin_root is not None else None,
            "workspace": str(workspace) if workspace is not None else None, "workspace_grants": list(grants),
            "lc_all": extra_env.get("LC_ALL") if extra_env.get("LC_ALL") in UTF8_LOCALES else None,
            "collector": bool(collector), "collector_store": str(collector_store) if collector and collector_store else None,
            "host_notes": bool(host_notes), "tool_name_prefix": TOOL_PREFIX, "engine_sha256": engine_sha256,
            "host_files": host_file_hashes()}


def plugin_version(package_version: str, install_id: str) -> str:
    """Unique per preparation, so Claude Code never keeps serving a cached copy of an earlier one (semver-valid)."""
    return f"{package_version}{'.' if '-' in package_version else '-'}claude.{install_id}"


def default_collector_store() -> Path:
    """The standalone PitRelay Collector's default store, so both share one store (and one robot connection) and a
    store survives every regeneration of this plugin. Same rules as pitrelay_collector.autostart.default_store_path."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA")
        return (Path(base) if base else Path.home() / "AppData" / "Local") / "PitRelayCollector"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "PitRelayCollector"
    xdg = os.environ.get("XDG_DATA_HOME")
    return (Path(xdg) if xdg else Path.home() / ".local" / "share") / "pitrelay-collector"


def collector_store_schema() -> str:
    m = re.search(r"^STORE_SCHEMA_VERSION = (\d+)", (COLLECTOR_PACKAGE / "store.py").read_text(encoding="utf-8"), re.M)
    if not m:
        raise SetupError("Cannot read the collector's store schema version from collector/src/pitrelay_collector/store.py")
    return m[1]


def collector_store_catalog() -> str:
    """The catalog's file name inside a store, as the collector's store.py names it."""
    m = re.search(r'self\.db_path = self\.root / "([^"]+)"', (COLLECTOR_PACKAGE / "store.py").read_text(encoding="utf-8"))
    if not m:
        raise SetupError("Cannot read the collector's catalog file name from collector/src/pitrelay_collector/store.py")
    return m[1]


def check_collector_store(store: Path) -> str:
    """'new', or 'existing' for a store of this collector version; anything else is refused."""
    import sqlite3
    if not store.exists():
        return "new"
    if not store.is_dir():
        raise SetupError(f"The collector store path is not a folder: {store}")
    db = store / collector_store_catalog()
    if not db.exists():
        if any(p.name not in ("venv", "diagnostics") for p in store.iterdir()):
            raise SetupError(f"The collector store folder {store} contains other files but no collector catalog; choose an "
                             "empty folder or an existing PitRelay Collector store")
        return "new"
    try:  # an escaped URI: a '#', '?' or '%' in the path must not end it (and open a file elsewhere for writing)
        c = read_only_sqlite(Path(db))
        try:
            row = c.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
        finally:
            c.close()
    except sqlite3.Error as e:
        raise SetupError(f"The collector store at {store} cannot be read: {e}") from None
    if row is not None and row[0] != collector_store_schema():
        raise SetupError(f"The collector store at {store} was written by another collector version (schema {row[0]}); "
                         "choose another --collector-store")
    return "existing"


_SYNCED = ("onedrive", "dropbox", "google drive", "googledrive", "icloud", "box sync")


def location_warnings(named: dict[str, Path]) -> list[str]:
    """Places where file locks and SQLite are unreliable, or where Windows path limits bite."""
    out = []
    for name, path in named.items():
        text = str(path)
        low = text.lower()
        if any(s in low for s in _SYNCED):
            out.append(f"The {name} folder is in a synced cloud folder; syncing can corrupt databases and locks there. "
                       "A local folder is safer.")
        if text.startswith("\\\\") or text.startswith("//"):
            out.append(f"The {name} folder is on a network share, where file locks are unreliable; use a local disk.")
        if re.match(r"^/mnt/[a-z]/", low):
            out.append(f"The {name} folder is a Windows drive seen from WSL; locks and databases are unreliable there.")
        if os.name == "nt" and len(text) > 120:
            out.append(f"The {name} path is long ({len(text)} characters); PitRelay adds about 130 more inside it, which "
                       "can exceed Windows' 260-character limit.")
    return out


def existing_login_item() -> dict | None:
    """A background collector of an earlier preparation registered at login (same login-item names)."""
    sys.path.insert(0, str(COLLECTOR_PACKAGE.parent))
    try:
        from pitrelay_collector.autostart import Autostart
        st = Autostart(ident="claude").status()
    except Exception:
        return None
    finally:
        sys.path.remove(str(COLLECTOR_PACKAGE.parent))
    return st if st.get("enabled") else None


def login_item_command(item: dict) -> str | None:
    """The command a login item runs, as text; None when it cannot be read."""
    command = item.get("command")
    if isinstance(command, list):
        return "\n".join(map(str, command))
    if isinstance(command, str):
        return command
    try:  # XDG autostart reports no command: it is the Exec line of the desktop file
        with open(item.get("location") or "", "rb") as f:
            return f.read(MAX_METADATA_BYTES).decode("utf-8", "replace")
    except (OSError, TypeError, ValueError):
        return None


def read_only_sqlite(db: Path):
    """Open an existing SQLite file without writing to it. A URI percent-encodes '#', '?' and '%', which would otherwise
    end the path and open (and create) another file; a network share (\\\\server\\share) has no file URI SQLite
    accepts, so it is opened by name with writes refused instead."""
    import sqlite3
    if str(db).startswith(("\\\\", "//")):
        c = sqlite3.connect(str(db), timeout=10)
        c.execute("PRAGMA query_only=ON")
        return c
    return sqlite3.connect(Path(db).as_uri() + "?mode=ro", uri=True, timeout=10)


def command_uses(command: str, folder: str) -> bool:
    needle = folder.rstrip("/\\") + os.sep
    # As written (registry, LaunchAgent), with one level of escapes removed, and as a desktop entry's Exec line writes
    # it (quoting rule and string rule both escape backslashes, '%' is doubled).
    needles = [needle, needle.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`").replace("$", "\\$")
               .replace("\\", "\\\\").replace("%", "%%")]
    texts = [command, re.sub(r"\\(.)", r"\1", command)]
    if _CASE_INSENSITIVE:
        needles, texts = [n.casefold() for n in needles], [t.casefold() for t in texts]
    return any(n in t for n in needles for t in texts)


STATE_MARKER = "pitrelay-state.json"
STATE_1X = {"engine", "jvm-home", "tmp", "host"}  # host: an earlier failed preparation may have added it


def venv_python(env_dir: Path) -> Path:
    return env_dir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def server_env(extra: dict[str, str]) -> dict[str, str]:
    # Blank (not unset: .mcp.json cannot unset) so inherited options cannot alter the engine JVM. The blanks are
    # applied last, so nothing (not even a rewritten receipt) can restore an injection variable.
    allowed = {k: v for k, v in extra.items() if k == "LC_ALL" and v in UTF8_LOCALES}
    return {**allowed, **{k: "" for k in INJECTION_VARIABLES}}


OS_METADATA = (".DS_Store", "Thumbs.db", "desktop.ini")


def overlay_bytes(path: Path) -> bytes:
    """Overlay text with line endings normalized: a Windows checkout (core.autocrlf) must not change the bytes."""
    return path.read_bytes().replace(b"\r\n", b"\n")


def component_sources() -> dict[str, Path]:
    """Every file this project adds to the plugin, by plugin path (caches, OS metadata and launch.json skipped)."""
    out: dict[str, Path] = {}
    for prefix, folder in components():
        if not folder.is_dir():
            raise SetupError(f"{folder.relative_to(HERE).as_posix()}/ not found next to this script; your copy of this "
                             "project is incomplete: get a fresh copy")
        files, _ = tree_files(folder)
        for rel, path in files.items():
            parts = rel.split("/")
            if "__pycache__" in parts or path.name in OS_METADATA or path.name.startswith("._"):
                continue  # Python caches and Finder/Explorer metadata are never shipped
            if prefix == "host/" and rel == "launch.json":
                continue  # generated at setup
            if prefix == "host/" and parts[0] == "pitrelay_collector":
                continue  # comes from the collector project itself
            out[prefix + rel] = path
    return out


def overlay_files() -> dict[str, bytes]:
    """The reviewed files (normalized bytes), refusing anything unexpected or changed."""
    data = {rel: overlay_bytes(p) for rel, p in component_sources().items()}
    unexpected = sorted(set(data) - set(OVERLAY_INVENTORY))
    missing = sorted(set(OVERLAY_INVENTORY) - set(data))
    changed = sorted(rel for rel in set(data) & set(OVERLAY_INVENTORY)
                     if hashlib.sha256(data[rel]).hexdigest() != OVERLAY_INVENTORY[rel])
    if unexpected or missing or changed:
        raise SetupError(f"The overlay, host or collector files differ from the reviewed inventory in this script: "
                         f"unexpected={unexpected[:10]} missing={missing[:10]} changed={changed[:10]}. If you did not edit "
                         "them, your copy of this project is altered or incomplete: get a fresh copy. A maintainer who "
                         "reviewed a change prints the new table with 'python3 configure_claude.py pin-overlay' and "
                         "updates OVERLAY_INVENTORY")
    return data


def overlay_inventory(collector: bool) -> dict[str, str]:
    """The reviewed files a plugin of this variant contains: without the collector, its skill and command are left out."""
    return {rel: sha for rel, sha in OVERLAY_INVENTORY.items() if collector or not rel.startswith(COLLECTOR_ONLY_OVERLAY)}


def plugin_manifest(version: str, author: dict) -> dict:
    return {
        "name": PLUGIN,
        "version": version,
        "description": "Local FRC code and telemetry investigation with the bundled PitRelay engine and PitRelay "
                       "Collector (robot and Driver Station log collection), prepared locally for Claude Code. Standard "
                       "Access unless Workspace Access was chosen at setup.",
        "author": author,
        "license": "SEE LICENSE IN docs/release/PITRELAY_LICENSE.md AND docs/release/LICENSE_INVENTORY.md",
        "keywords": ["frc", "robotics", "telemetry", "wpilog", "pitrelay"],
    }


def marketplace_manifest(version: str, author: dict) -> dict:
    return {
        "name": MARKETPLACE,
        "owner": author,
        "metadata": {"description": "PitRelay prepared locally for Claude Code; not for redistribution", "version": version},
        "plugins": [{"name": PLUGIN, "source": f"./{PLUGIN}", "version": version,
                     "description": "Bundled PitRelay engine and collector (one local stdio MCP server), PitRelay skills "
                                    "and Claude Code commands"}],
    }


def package_target(path: str) -> str:
    """Where a package file lives inside the plugin."""
    return "provenance/original-plugin.json" if path == "plugin.json" else path


GENERATED_PLUGIN_FILES = (".claude-plugin/plugin.json", ".mcp.json", "host/launch.json",
                          "provenance/original-package-manifest.json")


def overlay_digest() -> str:
    return hashlib.sha256(json.dumps(sorted(OVERLAY_INVENTORY.items())).encode()).hexdigest()


def previous_preparation(state: Path) -> dict:
    """What a reused state folder says about the preparation that used it last: its marker, and that preparation's
    receipt when it is a readable PitRelay receipt of that same preparation (None otherwise)."""
    def read_json(path: Path, limit: int):
        try:
            with open(path, "rb") as f:
                raw = f.read(limit + 1)
            return json.loads(raw.decode("utf-8")) if len(raw) <= limit else None
        except (OSError, ValueError):
            return None
    marker = read_json(state / STATE_MARKER, MAX_METADATA_BYTES)
    if not isinstance(marker, dict) or marker.get("kind") != "pitrelay_claude_code_state":
        return {}
    receipt = None
    if isinstance(marker.get("marketplace"), str) and os.path.isabs(marker["marketplace"]):
        r = read_json(Path(marker["marketplace"]) / "prepared-installation.json", 16 * MAX_MANIFEST_BYTES)
        if isinstance(r, dict) and r.get("kind") == "prepared_local_claude_code_plugin" and isinstance(
                r.get("generator"), dict) and r["generator"].get("name") == GENERATOR and \
                r.get("install_id") == marker.get("install_id"):
            receipt = r
    return {"marker": marker, "receipt": receipt}


def recorded_store(previous: dict) -> Path | None:
    """The collector store the previous preparation of a reused state used, from its receipt."""
    c = (previous.get("receipt") or {}).get("collector")
    if isinstance(c, dict) and c.get("included") is True and isinstance(c.get("store"), str) and os.path.isabs(c["store"]):
        return Path(c["store"])
    return None


def reuse_warnings(previous: dict, state: Path, workspace: Path | None) -> list[str]:
    """The engine scopes cases and artifacts to the state folder's path and to the access level and workspace: a
    reused state prepared differently keeps its files, but the engine no longer reaches the earlier ones."""
    marker = previous.get("marker") or {}
    before = marker if "experience" in marker else (previous.get("receipt") or {})  # older markers: the receipt
    out = []

    def access(experience, folder) -> str:
        return f"Workspace Access on {folder}" if experience == "workspace" else "Standard Access"
    experience = before.get("experience")
    folder = before.get("workspace")
    if experience == "workspace" and not (isinstance(folder, str) and os.path.isabs(folder)):
        experience = None  # unreadable: say nothing
    if experience in ("standard", "workspace") and (
            (experience == "workspace") != (workspace is not None)
            or (workspace is not None and not _same(Path(folder), workspace))):
        out.append(f"The cases and artifacts in this state folder were made with {access(experience, folder)}; this "
                   f"preparation uses {access('workspace' if workspace else 'standard', workspace)}. PitRelay's engine "
                   "scopes them to the access level and workspace, so it cannot reach them here. They stay in the state "
                   f"folder and are reachable again from an installation prepared with {access(experience, folder)} on "
                   "it; supply the evidence again here if you need it.")
    if isinstance(before.get("state"), str) and os.path.isabs(before["state"]) and not _same(Path(before["state"]), state):
        out.append(f"This state folder was prepared at {before['state']}. Moved, it keeps its files, but PitRelay's "
                   "engine scopes cases and artifacts to the state folder's path, so it cannot reach the earlier ones here.")
    return out


def prepare(package: Path, manifest_sha256: str, java: Path, state: Path, output: Path, accept_license: str,
            workspace: Path | None = None, workspace_disclosure: str | None = None, grants: str | None = None,
            python: Path | None = None, collector: bool = True, wheelhouse: Path | None = None,
            host_notes: bool = True, collector_store: Path | None = None, reuse_state: bool = False,
            python_env_factory=None) -> dict:
    # --- access selection (Standard by default; Workspace only with the explicit disclosure) ---
    if workspace is None and (workspace_disclosure is not None or grants is not None):
        raise SetupError("--workspace-disclosure and --grants apply only together with --workspace")
    granted: list[str] = []
    if workspace is not None:
        if workspace_disclosure is not None and workspace_disclosure != DISCLOSURE_ACK:
            raise SetupError(f"--workspace-disclosure must be {DISCLOSURE_ACK}")
        granted = sorted(set((grants or "project_read").split(",")))
        unknown = [g for g in granted if g not in GRANTS]
        if unknown or not granted:
            raise SetupError(f"Unknown Workspace Access grant(s) {unknown}; choose from {', '.join(GRANTS)}")

    if not collector and (wheelhouse is not None or collector_store is not None):
        raise SetupError("--wheelhouse and --collector-store apply to the collector; not with --without-collector")
    python = Path(sys.executable) if python is None else python
    # A reused state keeps the collector store its previous preparation used, unless another one is chosen.
    previous = previous_preparation(Path(state)) if reuse_state and Path(state).is_absolute() else {}
    store_before = recorded_store(previous) if collector else None
    store_given = collector_store is not None
    if collector and collector_store is None:
        collector_store = store_before or default_collector_store()

    # --- paths ---
    for value, role in ((package, "package"), (java, "Java"), (python, "Python"), (state, "state"), (output, "output"),
                        *(((workspace, "workspace"),) if workspace is not None else ()),
                        *(((wheelhouse, "wheelhouse"),) if wheelhouse is not None else ()),
                        *(((collector_store, "collector store"),) if collector else ())):
        if not Path(value).is_absolute():
            raise SetupError(f"The {role} path must be absolute: {value}")
    for value, role in ((package, "package"), (state, "state"), (output, "output"),
                        *(((workspace, "workspace"),) if workspace is not None else ()),
                        *(((collector_store, "collector store"),) if collector else ())):
        no_links(value, role)
    package, state, output = (Path(os.path.abspath(p)) for p in (package, state, output))
    java_given = Path(os.path.abspath(java))
    python_given = Path(os.path.abspath(python))
    if collector:
        collector_store = Path(os.path.abspath(collector_store))
    if wheelhouse is not None:
        wheelhouse = Path(os.path.abspath(wheelhouse))
        if not wheelhouse.is_dir():
            raise SetupError(f"The wheelhouse folder does not exist: {wheelhouse}")
    if workspace is not None:
        workspace = Path(os.path.abspath(workspace))
        if not workspace.is_dir():
            raise SetupError(f"The workspace folder does not exist: {workspace}")
    named = {"package": package, "state": state, "output": output}
    if workspace is not None:
        named["workspace"] = workspace
    disjoint(named)
    for name, folder in named.items():
        if name != "package" and any(within(folder, d) for d in claude_plugin_dirs()):
            raise SetupError(f"The {name} folder is inside Claude Code's plugin folders, which Claude Code deletes "
                             "when plugins are uninstalled or cleaned up; choose a folder outside them")
    if collector:
        for name in ("package", "state", "output", *(("workspace",) if workspace is not None else ())):
            if within(collector_store, named[name]) or within(named[name], collector_store):
                raise SetupError(f"The collector store and the {name} folder must not overlap ({collector_store})")
        if any(within(collector_store, d) for d in claude_plugin_dirs()):
            raise SetupError("The collector store is inside Claude Code's plugin folders; choose a folder outside them")

    # --- package integrity ---
    if not package.is_dir():
        raise SetupError(f"The package folder does not exist: {package}")
    manifest, manifest_bytes = read_manifest(package, manifest_sha256)
    verify_tree(package, manifest)
    verify_engine(package / "engine/pitrelay.jar")
    for row in manifest["files"]:
        if row["path"].startswith("skills/") and row["path"].endswith("/SKILL.md"):
            check_skill_front_matter(row["path"], (package / row["path"]).read_bytes())
    with zipfile.ZipFile(package / "engine/pitrelay.jar") as z:
        if any(n.startswith("games/") and not n.endswith("/") for n in z.namelist()):
            raise SetupError("The engine bundles seasonal game resources, which PitRelay's release rules forbid")
    if not valid_hash(accept_license) or digest(package / LICENSE) != accept_license:
        raise SetupError(f"Read {LICENSE} and acknowledge its exact SHA-256 with --accept-license")
    disclosure = None
    if workspace is not None:
        disclosure = workspace_disclosure_text(package, manifest)
        if workspace_disclosure != DISCLOSURE_ACK:
            raise SetupError(f"Workspace Access requires --workspace-disclosure {DISCLOSURE_ACK} after reading "
                             f"PitRelay's disclosure: {disclosure}")

    # --- Java, Python and destinations ---
    if not Path(os.path.realpath(java_given)).is_file():
        raise SetupError(f"The Java executable was not found: {java_given}")
    if output.exists():
        raise SetupError("--output must be a new path; an existing marketplace is never reused or overwritten")
    adopted = None
    if state.exists():
        if not reuse_state:
            raise SetupError("--state must be a new path, or add --reuse-state to keep an earlier installation's state "
                             "(PitRelay cases and artifacts) after closing every Claude Code session that uses it")
        if not state.is_dir():
            raise SetupError(f"The state path is not a folder: {state}")
        marker = state / STATE_MARKER
        names = {p.name for p in state.iterdir() if p.name not in OS_METADATA and not p.name.startswith("._")}
        if marker.is_file():
            adopted = "2.x"
        elif names and names <= STATE_1X:
            adopted = "1.x"
        else:
            raise SetupError(f"{state} is not a PitRelay for Claude Code state folder; --reuse-state accepts only one")
    elif reuse_state:
        raise SetupError(f"--reuse-state: the state folder does not exist: {state}")
    for d in (output.parent, state.parent):
        for node in (d, *d.parents):
            if node.exists() and not node.is_dir():
                raise SetupError(f"A parent of the output or state path is not a folder: {node}")
    probe_cwd = Path(os.path.realpath(state.parent if state.parent.is_dir() else Path.home()))
    for name, folder in named.items():
        if within(java_given, folder):
            raise SetupError(f"Select an independently installed Java, not one inside the {name} folder")
        if within(python_given, folder):
            raise SetupError(f"Select an independently installed Python, not one inside the {name} folder")
    runtime = select_runtime(java_given, probe_cwd, avoid=named.values())
    java_real: Path = runtime["executable"]
    py = select_python(python_given, probe_cwd)
    python_base: Path = py["executable"]
    for name, folder in named.items():
        if within(java_real, folder):
            raise SetupError(f"Select an independently installed Java, not one inside the {name} folder")
        if within(python_base, folder) or within(py["resolved"], folder) or any(
                lies_in(q, folder) for q in link_chain(python_base)):
            raise SetupError(f"Select an independently installed Python, not one inside the {name} folder or reached "
                             "through it")
    if not native_executable(Path(os.path.realpath(python_base))):
        raise SetupError(f"The selected Python {python_base} is a script, not an interpreter; select the interpreter it "
                         "starts (Claude Code must start the same Python every time, and verify accepts only that)")
    store_kind = check_collector_store(collector_store) if collector else None
    install_id = "g" + uuid.uuid4().hex[:8]
    plugin_root = output / PLUGIN
    env_dir = state / f"python-{install_id}"
    server_python = venv_python(env_dir) if collector else python_base
    # Claude Code expands ${...} in .mcp.json, so a literal path containing it would silently change.
    for role, value in (("Java", str(java_real)), ("Python", str(server_python)), ("state", str(state)),
                        ("output", str(output)), *((("workspace", str(workspace)),) if workspace is not None else ())):
        if "${" in value:
            raise SetupError(f"The {role} path contains '${{', which Claude Code would expand as a variable: {value}")
    real_args = engine_args(state, workspace, granted, plugin_root)
    preflight, extra_env = launcher_preflight(
        {"Java executable": str(java_real), **{f"argument {i}": a for i, a in enumerate(real_args)}},
        str(plugin_root / "engine" / "pitrelay.jar"), java_real, probe_cwd)
    launch = launch_spec(java_real, state, workspace, granted, extra_env, collector, manifest["engine_sha256"], host_notes,
                         collector_store, plugin_root)
    variant = overlay_inventory(collector)
    overlay = {rel: data for rel, data in overlay_files().items() if rel in variant}
    clash = sorted(set(overlay) & ({package_target(r["path"]) for r in manifest["files"]} | set(GENERATED_PLUGIN_FILES)))
    if clash:
        raise SetupError(f"Overlay files would replace package files: {clash}")
    warnings = location_warnings({"state": state, "output": output,
                                  **({"collector store": collector_store} if collector else {})})
    warnings += [w for w in (runtime["warning"], py["warning"]) if w]
    if adopted is not None:
        warnings += reuse_warnings(previous, state, workspace)
    if store_given and store_before is not None and not _same(collector_store, store_before):
        warnings.append(f"The earlier preparation of this state used the collector store {store_before}; this one uses "
                        f"{collector_store}. The sources, trusted host keys and logs in {store_before} are not seen here; "
                        "pass that folder with --collector-store to keep using it.")
    if collector and os.name != "nt" and python_base.name in _UNVERSIONED_PYTHON:
        warnings.append(f"The Python is pinned by its unversioned name {python_base} (no versioned python3.x beside it is "
                        "the same file). If that name later points at another Python version, the collector stops "
                        "working until you prepare again; select a versioned name with --python to avoid this.")
    login_item = existing_login_item() if collector or adopted is not None else None
    if login_item and collector:
        warnings.append("A background collector from an earlier preparation starts at login (" + str(login_item.get(
            "location")) + "). It runs that installation's copy; turn background collection on again in this one "
            "(collector_background), which replaces it, or turn it off on the old installation's collector page.")

    # --- stage everything, then publish with one no-replace rename ---
    no_links(output.parent, "output parent")
    output.parent.mkdir(parents=True, exist_ok=True)
    stage = output.parent / f".{output.name}.prepare-{uuid.uuid4().hex}"
    stage.mkdir()
    plugin = stage / PLUGIN
    state_created = env_created = False
    subs_created: list[str] = []
    old_marker = (state / STATE_MARKER).read_bytes() if (state / STATE_MARKER).is_file() else None
    version = plugin_version(manifest["version"], install_id)
    try:
        for row in manifest["files"]:
            copy_new(package / row["path"], plugin / package_target(row["path"]))
        (plugin / "provenance").mkdir(exist_ok=True)
        with open(plugin / "provenance/original-package-manifest.json", "xb") as f:
            f.write(manifest_bytes)
        for rel, content in sorted(overlay.items()):
            (plugin / rel).parent.mkdir(parents=True, exist_ok=True)
            with open(plugin / rel, "xb") as f:
                f.write(content)
        # Recheck every copy before anything is derived from it or becomes usable.
        for row in manifest["files"]:
            if digest(plugin / package_target(row["path"])) != row["sha256"]:
                raise SetupError(f"Copied file changed during preparation: {row['path']}")
        for rel in overlay:
            if digest(plugin / rel) != OVERLAY_INVENTORY[rel]:
                raise SetupError(f"Copied overlay file changed during preparation: {rel}")
        author = author_from(plugin / "provenance/original-plugin.json")
        (plugin / ".claude-plugin").mkdir()
        write_json_new(plugin / ".claude-plugin/plugin.json", plugin_manifest(version, author))
        write_json_new(plugin / ".mcp.json", mcp_config(str(server_python), extra_env, plugin_root))
        write_json_new(plugin / "host/launch.json", launch)
        (stage / ".claude-plugin").mkdir()
        write_json_new(stage / ".claude-plugin/marketplace.json", marketplace_manifest(version, author))
        if digest(package / "package-manifest.json") != manifest_sha256:
            raise SetupError("The source manifest changed during preparation")
        # State is separate from the plugin. A state created by this run is removed again if anything below fails;
        # a reused one keeps everything it had (only this run's new Python environment is removed).
        no_links(state, "state")
        if adopted is None:
            state.mkdir(parents=True, exist_ok=False)
            state_created = True
            if os.name == "posix":
                os.chmod(state, 0o700)
        for sub in ("jvm-home", "tmp", "host"):
            if not (state / sub).is_dir():
                (state / sub).mkdir()  # a file in the way is refused
                subs_created.append(sub)  # removed again if this run fails, so a 1.x state stays recognizable
        python_env = None
        installed: dict = {}
        if collector:
            env_created = True
            python_env = (python_env_factory or create_python_env)(python_base, env_dir, wheelhouse, probe_cwd)
            if Path(python_env["python"]) != server_python or not server_python.is_file():
                raise SetupError("The collector's Python environment is not where it was expected")
            installed = installed_distributions(env_dir, py["version"])
            env_identity = {"launcher": env_launchers(env_dir), "install_records": install_records(env_dir, py["version"]),
                            "unhashed_files": unhashed_files(env_dir, py["version"])}
            # The same check verify makes, so a preparation that passes here also passes verify right away.
            env_problems = check_python_env(env_dir, python_base, py["version"], installed,
                                            env_identity["install_records"], env_identity["launcher"],
                                            env_identity["unhashed_files"])
            if env_problems:
                raise SetupError("The collector's new Python environment does not pass the check verify makes: "
                                 + "; ".join(env_problems[:5]))
        tmp_marker = state / f".{STATE_MARKER}.{install_id}"
        tmp_marker.write_text(json.dumps({"kind": "pitrelay_claude_code_state", "generator": GENERATOR,
                                          "generator_version": GENERATOR_VERSION, "install_id": install_id,
                                          "marketplace": str(output), "state": str(state),
                                          "experience": "workspace" if workspace is not None else "standard",
                                          "workspace": str(workspace) if workspace is not None else None},
                                         indent=2) + "\n", encoding="utf-8")
        os.replace(tmp_marker, state / STATE_MARKER)
        # Earlier preparations' environments: the installed plugin (until the switch) and a background collector
        # registered at login (until it is turned on again here) still start them, so they are listed with that caveat,
        # and one that the login item starts is not listed at all.
        old_envs = sorted(str(p) for p in state.glob("python*") if p.is_dir() and p != env_dir)
        in_use = []
        if old_envs and login_item:
            command = login_item_command(login_item)
            in_use = [e for e in old_envs if command is None or command_uses(command, e)]
            old_envs = [e for e in old_envs if e not in in_use]
        older_note = " ".join(filter(None, (
            "Delete these only after you have switched Claude Code to this marketplace and, if background collection was "
            "on, turned it on again here: until then the installed plugin and its login item still start them."
            if old_envs else None,
            f"Not listed, because the background collector registered at login may still start it: {', '.join(in_use)}. "
            "Turn background collection on again in this installation first." if in_use else None)))
        files, _ = tree_files(stage)
        receipt = {
            "schema_version": RECEIPT_SCHEMA, "kind": "prepared_local_claude_code_plugin", "installed": False,
            "generator": {"name": GENERATOR, "version": GENERATOR_VERSION, "script_sha256": digest(Path(__file__).resolve()),
                          "overlay_sha256": overlay_digest()},
            "install_id": install_id, "plugin_version": version,
            "source_package_version": manifest["version"], "source_manifest_sha256": manifest_sha256,
            "engine_sha256": manifest["engine_sha256"], "license_acknowledged_sha256": accept_license,
            "experience": "workspace" if workspace is not None else "standard",
            "workspace": str(workspace) if workspace is not None else None, "workspace_grants": granted,
            "workspace_disclosure": disclosure, "workspace_disclosure_acknowledgement": DISCLOSURE_ACK if disclosure else None,
            "runtime": {k: v for k, v in runtime.items() if k not in ("executable", "launcher", "warning")},
            "java_executable": str(java_real), "java_selected": str(java_given), "java_launcher": str(runtime["launcher"]),
            "java_executable_sha256": digest(java_real), "launcher_preflight": preflight,
            "server_env_extra": extra_env,
            "python": {"selected": str(python_given), "executable": str(python_base), "resolved": str(py["resolved"]),
                       "version": py["version"], "sys_version": py["sys_version"], "implementation": py["implementation"],
                       "executable_sha256": digest(python_base), "pinned": py["pinned"]},
            "server_command": str(server_python),
            "engine_state": str(state / "engine"), "state_reused": adopted,
            "host_notes": bool(host_notes),
            "collector": {"included": collector, "store": str(collector_store) if collector else None,
                          "store_was": store_kind,
                          "python_environment": str(env_dir) if collector else None,
                          "requirements": list(COLLECTOR_REQUIREMENTS) if collector else [],
                          "installed": installed,
                          "tested_versions": python_env.get("tested_versions") if python_env else None,
                          "wheelhouse": str(wheelhouse) if wheelhouse is not None else None,
                          # What the receipt hash anchors of the environment: what .mcp.json starts there, and
                          # the install records that say which files belong in it.
                          "launcher": env_identity["launcher"] if collector else None,
                          "install_records": env_identity["install_records"] if collector else None,
                          "unhashed_files": env_identity["unhashed_files"] if collector else None},
            "launch": launch, "warnings": warnings,
            "state": str(state), "output": str(output), "marketplace": MARKETPLACE, "plugin": PLUGIN,
            "mcp_server": SERVER, "tool_name_prefix": TOOL_PREFIX,
            "overlay_files": sorted(overlay),
            "relocation": "Prepare again after moving the output, state, Java, Python or workspace (add --reuse-state to "
                          "keep the state); the marketplace is loaded in place from the output folder. A moved state folder "
                          "or workspace keeps its files, but PitRelay's engine no longer reaches the earlier cases and "
                          "artifacts: they are scoped to the state folder's path and to the workspace (and access level) "
                          "they were made with",
            "uninstall": "claude plugin uninstall pitrelay@pitrelay-local removes the plugin; the separate state folder and "
                         "the collector store are kept and must be reviewed and deleted deliberately. Turn background "
                         "collection off first. Claude Code also keeps a copy of the plugin (engine included) in its "
                         "plugins/cache/pitrelay-local folder; delete that too",
            "files": [{"path": rel, "byte_size": p.stat().st_size, "sha256": digest(p)} for rel, p in sorted(files.items())],
        }
        write_json_new(stage / "prepared-installation.json", receipt)
        rename_noreplace(stage, output)
    except BaseException as e:
        # Never leave a hidden copy of the engine behind, nor what this run added to the state folder.
        shutil.rmtree(stage, ignore_errors=True)
        if state_created:
            shutil.rmtree(state, ignore_errors=True)
        else:
            if env_created:
                shutil.rmtree(env_dir, ignore_errors=True)
            for sub in reversed(subs_created):  # only while still empty: nothing has used them yet
                try:
                    os.rmdir(state / sub)
                except OSError:
                    pass
            try:  # a reused state keeps the marker of the preparation that is still in use
                if old_marker is not None:
                    (state / STATE_MARKER).write_bytes(old_marker)
                elif adopted is not None:
                    (state / STATE_MARKER).unlink(missing_ok=True)
            except OSError:
                pass
        if not isinstance(e, Exception):
            raise
        note = ("The incomplete preparation" + (" and the new state folder were" if state_created else
                                                " was" + (" (and its new Python environment)" if env_created else ""))
                + " removed.")
        if isinstance(e, SetupError):
            raise SetupError(f"{e} {note}") from e
        raise SetupError(f"Preparation failed ({e.__class__.__name__}: {e}). {note}") from e
    return {"result": "PASS", "installed": False, "marketplace_root": str(output), "plugin": str(output / PLUGIN),
            "plugin_version": version, "state": str(state), "state_reused": adopted,
            "experience": receipt["experience"], "workspace": receipt["workspace"],
            "workspace_grants": granted, "engine_sha256": manifest["engine_sha256"], "runtime_major": runtime["major"],
            "java": str(java_real), "python": str(server_python), "collector": collector,
            "collector_store": str(collector_store) if collector else None,
            **({"collector_store_note": "the collector store of this state's previous preparation (pass "
                                        "--collector-store to choose another)"}
               if collector and not store_given and store_before is not None else {}),
            "collector_dependencies": installed,
            "collector_dependencies_tested_versions": python_env.get("tested_versions") if python_env else None,
            **({"java_pinned": f"{java_real} is pinned: it leads through links to the runtime's own launcher "
                               f"{runtime['launcher']}, so an update that installs the runtime in a new folder keeps "
                               "working. If the link is switched to another Java (alternatives, a version manager), the "
                               "engine runs that one; 'verify --receipt-sha256' reports it, and fails when the major "
                               "version changed"} if java_real != runtime["launcher"] else {}),
            **({"python_pinned": py["pinned"]} if py["pinned"] else {}),
            "warnings": warnings,
            **({"older_python_environments": old_envs} if old_envs else {}),
            **({"older_python_environments_note": older_note} if older_note else {}),
            "receipt": str(output / "prepared-installation.json"),
            "receipt_sha256": digest(output / "prepared-installation.json"),
            "keep": "Keep receipt_sha256 somewhere else (e.g. your notes) to detect later changes with "
                    "'configure_claude.py verify --receipt-sha256 ...'",
            "next_steps": [f"claude plugin validate {output / PLUGIN}",
                           f"claude plugin marketplace add {output}",
                           f"claude plugin install {PLUGIN}@{MARKETPLACE}",
                           "Start a new Claude Code session, run /pitrelay:start and check the reported access level"
                           + (", then /pitrelay:collect to set up log collection" if collector else "")]}


# --- verification of a prepared marketplace ---------------------------------------------------------


def verify_output(output: Path, manifest_sha256: str | None = None, receipt_sha256: str | None = None) -> dict:
    """Re-check a prepared marketplace: every file, and every claim, against the files themselves.

    Without --manifest-sha256 or --receipt-sha256 the check is anchored only by the receipt inside the folder,
    which detects accidental change but not deliberate tampering by someone who can also rewrite the receipt. A
    receipt that differs from the --receipt-sha256 you kept stops the check before anything else is read or run.
    """
    # A hash as Windows prints it (uppercase) or pasted with spaces is the same hash; anything else is a typing error,
    # never evidence that the folder changed.
    manifest_sha256, receipt_sha256 = (None if value is None else given_hash(value, option) for value, option in
                                       ((manifest_sha256, "--manifest-sha256"), (receipt_sha256, "--receipt-sha256")))
    output = Path(os.path.abspath(output))
    no_links(output, "output")
    problems: list[str] = []
    receipt_path = output / "prepared-installation.json"
    try:
        receipt_bytes = receipt_path.read_bytes()
    except OSError as e:
        return {"result": "FAIL", "problems": [f"receipt missing or malformed: {e}"], "problem_count": 1}
    if receipt_sha256 is not None and hashlib.sha256(receipt_bytes).hexdigest() != receipt_sha256:
        return {"result": "FAIL", "problem_count": 1, "problems": [
            "the receipt differs from the receipt SHA-256 you kept: the folder was changed after setup, or the hash "
            "belongs to another preparation. Nothing else was checked and no program it names was run; do not use this "
            "marketplace, prepare again"]}
    try:
        receipt = json.loads(receipt_bytes.decode("utf-8"), object_pairs_hook=unique_object)
        if receipt.get("kind") != "prepared_local_claude_code_plugin":
            raise SetupError("not a prepared PitRelay Claude Code marketplace")
        listed = {}
        for r in receipt["files"]:
            if not (isinstance(r, dict) and isinstance(r.get("path"), str) and isinstance(r.get("byte_size"), int)
                    and valid_hash(r.get("sha256"))):
                raise SetupError(f"malformed file row {r!r:.120}")
            listed[r["path"]] = r
        generator = receipt.get("generator") if isinstance(receipt.get("generator"), dict) else {}
        if receipt.get("schema_version") != RECEIPT_SCHEMA or str(generator.get("version", "")).split(".")[0] != \
                GENERATOR_VERSION.split(".")[0]:
            return {"result": "FAIL", "problem_count": 1, "problems": [
                f"prepared by {generator.get('name', 'an unknown generator')} {generator.get('version', '(unknown version)')} "
                f"(receipt schema {receipt.get('schema_version')}); verify it with that version of configure_claude.py, or "
                f"prepare it again with this version ({GENERATOR_VERSION})"]}
        state, plugin_name = Path(receipt["state"]), receipt["plugin"]
        if plugin_name != PLUGIN:
            raise SetupError(f"unexpected plugin name {plugin_name!r}")
        install_id = receipt["install_id"]
        if not isinstance(install_id, str) or not re.fullmatch(r"g[0-9a-f]{8}", install_id):
            raise SetupError("malformed install id")
        grants = list(receipt["workspace_grants"])
        workspace = Path(receipt["workspace"]) if receipt.get("workspace") else None
        java = Path(receipt["java_executable"])
        python_rec = receipt["python"]
        python = Path(python_rec["executable"])
        collector_rec = receipt["collector"]
        collector = collector_rec["included"] is True
        if not isinstance(collector_rec["installed"], dict):
            raise SetupError("malformed collector record")
        collector_store = Path(collector_rec["store"]) if collector else None
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as e:
        return {"result": "FAIL", "problems": [f"receipt missing or malformed: {e}"], "problem_count": 1}
    same_overlay = generator.get("overlay_sha256") == overlay_digest()
    files, _ = tree_files(output)
    files.pop("prepared-installation.json", None)
    problems += [f"unexpected file {p}" for p in sorted(set(files) - set(listed))]
    problems += [f"missing file {p}" for p in sorted(set(listed) - set(files))]
    for rel in sorted(set(files) & set(listed)):
        if files[rel].stat().st_size != listed[rel]["byte_size"] or digest(files[rel]) != listed[rel]["sha256"]:
            problems.append(f"changed file {rel}")
    plugin = output / plugin_name
    # Everything below is derived from the anchored package manifest, the overlay pinned in this script and the
    # generator's own rules, never from the receipt: whoever can rewrite the folder can rewrite the receipt too.
    engine_sha = None
    manifest = None
    try:
        raw = (plugin / "provenance/original-package-manifest.json").read_bytes()
        if hashlib.sha256(raw).hexdigest() != receipt.get("source_manifest_sha256"):
            problems.append("provenance manifest differs from the receipt's source_manifest_sha256")
        if manifest_sha256 is not None and hashlib.sha256(raw).hexdigest() != manifest_sha256:
            problems.append("provenance manifest differs from the trusted manifest SHA-256 you supplied")
        manifest = parse_manifest(raw)
        for row in manifest["files"]:
            target = plugin / package_target(row["path"])
            if not target.is_file() or digest(target) != row["sha256"]:
                problems.append(f"PitRelay file differs from its package manifest: {row['path']}")
        engine_sha = digest(plugin / "engine/pitrelay.jar") if (plugin / "engine/pitrelay.jar").is_file() else None
        if engine_sha != manifest["engine_sha256"]:
            problems.append("engine/pitrelay.jar is not the packaged engine")
    except (OSError, SetupError) as e:
        problems.append(f"provenance manifest unusable: {e}")
    variant = overlay_inventory(collector)  # without the collector, its skill and command are not in the plugin
    if not same_overlay:
        problems.append(f"prepared by {GENERATOR} {generator.get('version', 'unknown')} with a different reviewed "
                        f"overlay than this version ({GENERATOR_VERSION}); prepare it again with this version to "
                        "check it (or verify it with the generator that made it)")
    else:
        for rel, expected_sha in variant.items():
            if not (plugin / rel).is_file() or digest(plugin / rel) != expected_sha:
                problems.append(f"overlay file differs from the reviewed inventory: {rel}")
    if manifest is not None:
        overlay_paths = variant if same_overlay else receipt.get("overlay_files", [])
        expected_files = ({f"{plugin_name}/{package_target(r['path'])}" for r in manifest["files"]}
                          | {f"{plugin_name}/{rel}" for rel in overlay_paths}
                          | {f"{plugin_name}/{rel}" for rel in GENERATED_PLUGIN_FILES}
                          | {".claude-plugin/marketplace.json"})
        problems += [f"file not produced by setup: {p}" for p in sorted(set(files) - expected_files)]
        author = author_from(plugin / "provenance/original-plugin.json")
        version = plugin_version(manifest["version"], install_id)
        for rel, expected_doc in ((f"{plugin_name}/.claude-plugin/plugin.json", plugin_manifest(version, author)),
                                  (".claude-plugin/marketplace.json", marketplace_manifest(version, author))):
            try:
                if json.loads((output / rel).read_text(encoding="utf-8")) != expected_doc:
                    problems.append(f"{rel} differs from what setup writes")
            except (OSError, ValueError) as e:
                problems.append(f"{rel} unreadable: {e}")
    # What will actually be launched: Claude Code starts the host with this Python; the host starts this Java.
    extra_env = receipt.get("server_env_extra") or {}
    env_dir = state / f"python-{install_id}"
    server_python = venv_python(env_dir) if collector else python
    try:
        servers = json.loads((plugin / ".mcp.json").read_text(encoding="utf-8"))
        if servers != mcp_config(str(server_python), extra_env, plugin):
            problems.append(".mcp.json does not start exactly the host, Python and environment recorded at setup")
    except (OSError, ValueError, KeyError, TypeError) as e:
        problems.append(f".mcp.json unreadable: {e}")
    try:
        launch = json.loads((plugin / "host/launch.json").read_text(encoding="utf-8"))
        expected_launch = launch_spec(java, state, workspace, grants, extra_env, collector,
                                      manifest["engine_sha256"] if manifest else None, receipt.get("host_notes") is not False,
                                      collector_store, plugin)
        if launch != expected_launch:
            problems.append("host/launch.json does not start exactly the Java, state, access level and collector setting "
                            "recorded at setup")
    except (OSError, ValueError, KeyError, TypeError) as e:
        problems.append(f"host/launch.json unreadable: {e}")
    # The Java and Python are run (to read their version and properties) only when your kept receipt hash anchors the
    # receipt that names them, and never from inside the marketplace or the state: otherwise whoever changed the folder
    # would choose what verify starts. Without the anchor they are only compared with the hashes in the receipt and
    # named for you to check.
    anchored = receipt_sha256 is not None
    notes: list[str] = []
    not_run: list[str] = []
    inside = {}
    for role, program in (("Java", java), ("Python", python)):
        inside[role] = next((name for name, folder in (("marketplace", output), ("state", state))
                             if lies_in(program, folder) or within(program, folder)), None)  # as named, or where it leads
        if inside[role]:
            problems.append(f"the recorded {role} {program} lies inside the {inside[role]} folder, where setup never puts "
                            "it; it was not run")
    unanchored_change = ("changed since setup; it was not run, because the receipt is not anchored: verify with "
                         "--receipt-sha256 to see whether it was only updated, or prepare again")
    if not java.is_file():
        problems.append("the Java recorded at setup is missing; prepare again with the Java you want to use")
    elif inside["Java"]:
        pass  # reported above
    elif not anchored:
        if digest(java) != receipt.get("java_executable_sha256"):
            problems.append(f"the Java recorded at setup ({java}) {unanchored_change}")
        not_run.append(f"Java {java}")
    else:
        # The command must be a Java runtime's own launcher (not a wrapper script that adds options). A changed file
        # at the same path that still is, with the same major version, is an in-place update (distribution JDKs).
        launcher_was = Path(receipt["java_launcher"]) if isinstance(receipt.get("java_launcher"), str) else java
        if (digest(java) != receipt.get("java_executable_sha256") or Path(os.path.realpath(java)) != launcher_was) \
                and not native_executable(Path(os.path.realpath(java))):
            problems.append(f"the Java recorded at setup ({java}) changed and is not a native program; it was not run")
            java_checked = True
        else:
            java_checked = False
    if java.is_file() and not inside["Java"] and anchored and not java_checked:
        try:
            runtime = select_runtime(java, Path.home())
            recorded = receipt.get("runtime") if isinstance(receipt.get("runtime"), dict) else {}
            # Setup pins a link to the runtime's launcher, or the launcher itself (receipts without java_launcher).
            launcher_then = Path(receipt["java_launcher"]) if isinstance(receipt.get("java_launcher"), str) else java
            launcher_now = Path(os.path.realpath(java))
            if runtime["launcher"] != launcher_now:
                problems.append(f"the launched program {java} is not a Java runtime's own launcher")
            elif digest(java) != receipt.get("java_executable_sha256") or launcher_now != launcher_then:
                if runtime["major"] != recorded.get("major"):
                    problems.append(f"the recorded Java changed from Java {recorded.get('major')} to Java "
                                    f"{runtime['major']}; prepare again with the Java you want to use")
                elif launcher_then != java and launcher_now != launcher_then and native_executable(java) and \
                        runtime["version"] != recorded.get("version"):
                    # The link setup pinned now leads to another runtime's own launcher of the same major version: an
                    # update installed in a new folder, or a switch (alternatives, a version manager). A launcher that
                    # setup pinned itself is never expected to become a link.
                    notes.append(f"the Java {java} now leads to another runtime's launcher, {launcher_now} (was "
                                 f"{launcher_then}; {recorded.get('version')} -> {runtime['version']})")
                elif not native_executable(java) or runtime["version"] == recorded.get("version"):
                    # An update changes the version the launcher reports; a script, or other bytes reporting the same
                    # version, is something else put in its place.
                    problems.append(f"the Java recorded at setup ({java}) was changed without becoming another Java "
                                    "version; prepare again with the Java you want to use")
                else:
                    notes.append(f"the Java runtime was updated in place since setup ({recorded.get('version')} -> "
                                 f"{runtime['version']})")
        except SetupError as e:
            problems.append(f"the launched program {java} is not a working Java 17+ launcher: {str(e)[:200]}")
    if not python.is_file():
        problems.append(f"the Python recorded at setup ({python}) is missing; prepare again (--reuse-state keeps the state)")
    elif inside["Python"]:
        pass  # reported above
    elif not anchored:
        if digest(python) != python_rec.get("executable_sha256"):
            problems.append(f"the Python recorded at setup ({python}) {unanchored_change}")
        not_run.append(f"Python {python}")
    elif digest(python) != python_rec.get("executable_sha256") and not (
            native_executable(python) and native_executable(Path(os.path.realpath(python)))):
        problems.append(f"the Python recorded at setup ({python}) changed and is not a native interpreter; it was not "
                        "run; prepare again (--reuse-state keeps the state)")
    else:
        try:
            now = select_python(python, Path.home())
            if not _same(now["executable"], python):
                problems.append(f"the recorded Python {python} is not a base interpreter: it starts {now['executable']}")
            elif now["version"].split(".")[:2] != str(python_rec.get("version", "")).split(".")[:2]:
                problems.append(f"the recorded Python changed from {python_rec.get('version')} to {now['version']}; "
                                "prepare again (--reuse-state keeps the state)")
            elif digest(python) != python_rec.get("executable_sha256"):
                # A patch update or a distribution's rebuild replaces the interpreter in place: a compiled program that
                # reports another build (sys.version: version, build date, compiler), often at the same version. Other
                # bytes reporting the very same build are something else (a script in its place was refused above,
                # without running it).
                if isinstance(python_rec.get("sys_version"), str) and now["sys_version"] == python_rec["sys_version"]:
                    problems.append(f"the Python recorded at setup ({python}) changed without becoming another build (it "
                                    f"still reports {python_rec['sys_version']!r}); prepare again (--reuse-state keeps "
                                    "the state)")
                else:
                    notes.append(f"the Python interpreter was updated since setup ({python_rec.get('version')} -> "
                                 f"{now['version']}, now {str(now['sys_version'])[:120]!r})")
        except SetupError as e:
            problems.append(f"the recorded Python {python} is not a working Python 3.10+: {str(e)[:200]}")
    if not_run:
        notes.append(f"not run, because the receipt is not anchored by --receipt-sha256: {' and '.join(not_run)}; check "
                     "that these are the Java and Python you chose")
    if collector:
        problems += check_python_env(env_dir, python, str(python_rec.get("version")), collector_rec["installed"],
                                     collector_rec.get("install_records"), collector_rec.get("launcher"),
                                     collector_rec.get("unhashed_files"))
    if not (state / "jvm-home").is_dir() or not (state / "tmp").is_dir():
        problems.append(f"the state folder {state} is missing or incomplete")
    if anchored:
        anchored_by = ("your kept receipt SHA-256: every file, the launch configuration (Java, state, workspace, "
                       "grants, environment) and the collector's Python environment; the recorded Java and Python were "
                       "run to check them")
    elif manifest_sha256 is not None:
        anchored_by = ("your manifest SHA-256 for the PitRelay files; the launch configuration below comes from the "
                       "receipt in this folder, so check it, or anchor it with --receipt-sha256. The Java and Python it "
                       "names were not run")
    else:
        anchored_by = ("the receipt in this folder only (detects accidental change, not deliberate tampering); the Java "
                       "and Python it names were not run")
    result = {"result": "FAIL" if problems else "PASS", "files_verified": len(listed),
              "engine_sha256_on_disk": engine_sha, "experience": "workspace" if workspace else "standard",
              "workspace_grants": grants, "collector": collector,
              "launch": {"python": str(server_python), "java": str(java), "state": str(state),
                         "collector_store": str(collector_store) if collector else None,
                         "workspace": str(workspace) if workspace else None, "env": server_env(extra_env)},
              "anchored_by": anchored_by}
    if notes:
        result["note"] = "; ".join(notes)
    if problems:
        result.update(problems=problems[:50], problem_count=len(problems))
    return result


# --- wheelhouse for another computer ----------------------------------------------------------------
# pip download --platform/--python-version picks wheels for the target, but it evaluates the dependencies' environment
# markers (sys_platform == "win32", python_version < "3.12") for the Python running it. So the dependencies are read
# from the downloaded wheels' metadata, their markers evaluated for the target here, and what is missing is downloaded
# until nothing that applies there is missing. PEP 440 and PEP 508 are implemented only as far as needed for that.

_PEP440 = re.compile(r"v?(?:(\d+)!)?(\d+(?:\.\d+)*)(?:[-_.]?(alpha|beta|preview|pre|rc|a|b|c)[-_.]?(\d*))?"
                     r"(?:-(\d+)|[-_.]?(?:post|rev|r)[-_.]?(\d*))?(?:[-_.]?dev[-_.]?(\d*))?(?:\+[a-z0-9]+(?:[-_.][a-z0-9]+)*)?",
                     re.I)
_PRE_ORDER = {"a": 0, "alpha": 0, "b": 1, "beta": 1, "c": 2, "rc": 2, "pre": 2, "preview": 2}


def parse_version(text: str) -> tuple | None:
    """(epoch, release numbers, pre, post, dev) of a PEP 440 version (local label ignored); None if it is not one."""
    m = _PEP440.fullmatch(str(text).strip())
    if not m:
        return None
    epoch, release, pre_l, pre_n, post_a, post_b, dev = m.groups()
    post = post_a if post_a is not None else post_b
    return (int(epoch or 0), tuple(int(x) for x in release.split(".")),
            (_PRE_ORDER[pre_l.lower()], int(pre_n or 0)) if pre_l else None,
            int(post or 0) if post is not None else None, int(dev or 0) if dev is not None else None)


def _version_key(v: tuple) -> tuple:
    epoch, release, pre, post, dev = v
    release = list(release)
    while len(release) > 1 and release[-1] == 0:
        release.pop()
    pre_key = (1, *pre) if pre else ((0,) if dev is not None and post is None else (2,))  # x.dev0 < x.a0 < x
    return (epoch, tuple(release), pre_key, (0,) if post is None else (1, post), (2,) if dev is None else (1, dev))


def specifier_allows(spec: str, version: str) -> bool | None:
    """Whether `version` meets every clause of a PEP 440 specifier ('' allows any); None if either cannot be read."""
    v = parse_version(version)
    if v is None:
        return None
    for clause in filter(None, (c.strip() for c in spec.split(","))):
        m = re.fullmatch(r"(===|==|!=|~=|<=|>=|<|>)\s*(\S+)", clause)
        if not m:
            return None
        op, target = m.groups()
        if op == "===":
            ok = str(version).strip().lower() == target.lower()
        elif op in ("==", "!=") and target.endswith(".*"):
            t = parse_version(target[:-2])
            if t is None:
                return None
            padded = v[1] + (0,) * max(0, len(t[1]) - len(v[1]))
            ok = (v[0], padded[:len(t[1])]) == (t[0], t[1])
            ok = ok if op == "==" else not ok
        else:
            t = parse_version(target)
            if t is None:
                return None
            if op == "~=":
                if len(t[1]) < 2:
                    return None
                prefix = v[1] + (0,) * max(0, len(t[1]) - len(v[1]))
                ok = _version_key(v) >= _version_key(t) and prefix[:len(t[1]) - 1] == t[1][:-1] and v[0] == t[0]
            else:
                kv, kt = _version_key(v), _version_key(t)
                same_release = (v[0], _version_key(v)[1]) == (t[0], kt[1])
                ok = {"==": kv == kt, "!=": kv != kt, "<=": kv <= kt, ">=": kv >= kt,
                      # <V excludes V's pre-releases, >V its post-releases, unless V is one itself (PEP 440)
                      "<": kv < kt and not (same_release and v[2] is not None and t[2] is None),
                      ">": kv > kt and not (same_release and v[3] is not None and t[3] is None)}[op]
        if not ok:
            return False
    return True


_MARKER_VARIABLES = {"os_name", "sys_platform", "platform_machine", "platform_python_implementation", "platform_release",
                     "platform_system", "platform_version", "python_version", "python_full_version", "implementation_name",
                     "implementation_version", "extra"}
_MARKER_ALIASES = {"os.name": "os_name", "sys.platform": "sys_platform", "platform.version": "platform_version",
                   "platform.machine": "platform_machine", "platform.python_implementation": "platform_python_implementation",
                   "python_implementation": "platform_python_implementation"}
_MARKER_TOKEN = re.compile(r"\s*(?:(\()|(\))|'([^']*)'|\"([^\"]*)\"|(===|==|!=|~=|<=|>=|<|>)|(not\s+in|in|and|or)(?![\w.])"
                           r"|([A-Za-z_][A-Za-z0-9_.]*))")


def canonical_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def evaluate_marker(marker: str, env: dict) -> bool | None:
    """A PEP 508 environment marker for `env` (variable -> value, None where the target does not say): True, False,
    or None when the answer depends on a value that is not known for the target."""
    tokens, pos, text = [], 0, marker.strip()
    while pos < len(text):
        m = _MARKER_TOKEN.match(text, pos)
        if not m or m.end() == pos:
            raise SetupError(f"Cannot read the environment marker {marker!r}")
        pos = m.end()
        lp, rp, s1, s2, op, word, name = m.groups()
        if lp or rp:
            tokens.append((lp or rp, None))
        elif s1 is not None or s2 is not None:
            tokens.append(("str", s1 if s1 is not None else s2))
        elif op:
            tokens.append(("op", op))
        elif word in ("and", "or"):
            tokens.append(("bool", word))
        elif word:
            tokens.append(("op", " ".join(word.split())))  # in, not in
        else:
            tokens.append(("var", _MARKER_ALIASES.get(name, name)))
    i = 0

    def take(kind, value=None):
        nonlocal i
        if i >= len(tokens) or tokens[i][0] != kind or (value is not None and tokens[i][1] != value):
            raise SetupError(f"Cannot read the environment marker {marker!r}")
        i += 1
        return tokens[i - 1][1]

    def operand():
        if i < len(tokens) and tokens[i][0] == "var":
            name = take("var")
            if name not in _MARKER_VARIABLES:
                raise SetupError(f"Unknown variable {name!r} in the environment marker {marker!r}")
            return env.get(name), name
        return take("str"), None

    def comparison():
        if i < len(tokens) and tokens[i][0] == "(":
            take("(")
            result = disjunction()
            take(")")
            return result
        (left, lname), op, (right, rname) = operand(), take("op"), operand()
        if left is None or right is None:
            return None
        if "extra" in (lname, rname):
            left, right = canonical_name(left), canonical_name(right)
        if op in ("in", "not in"):
            return (left in right) == (op == "in")
        if op != "===" and parse_version(right) is not None:
            return specifier_allows(op + right, left) is True
        if op in ("==", "==="):
            return left == right
        if op == "!=":
            return left != right
        return {"<": left < right, "<=": left <= right, ">=": left >= right, ">": left > right}.get(op)

    def conjunction():
        values = [comparison()]
        while i < len(tokens) and tokens[i] == ("bool", "and"):
            take("bool", "and")
            values.append(comparison())
        return False if False in values else None if None in values else True

    def disjunction():
        values = [conjunction()]
        while i < len(tokens) and tokens[i] == ("bool", "or"):
            take("bool", "or")
            values.append(conjunction())
        return True if True in values else None if None in values else False

    result = disjunction()
    if i != len(tokens):
        raise SetupError(f"Cannot read the environment marker {marker!r}")
    return result


def target_environment(platform_tag: str | None, python_version: str | None, selected_version: str) -> dict:
    """The marker variables of the computer and Python a wheelhouse is for: this computer and the selected Python
    unless a platform tag or Python version is given (patch level 0 when only x.y is given; None where a tag does not
    say, such as the machine of a universal2 macOS tag)."""
    m = re.fullmatch(r"(\d+)\.(\d+)(?:\.(\d+))?", python_version or selected_version)
    if not m:
        raise SetupError(f"--python-version must look like 3.12, not {python_version!r}")
    full = f"{m[1]}.{m[2]}.{m[3] or 0}"
    env = {"python_version": f"{m[1]}.{m[2]}", "python_full_version": full, "implementation_version": full,
           "implementation_name": "cpython", "platform_python_implementation": "CPython", "platform_release": None,
           "platform_version": None}
    if not platform_tag:
        env.update(os_name=os.name, sys_platform=sys.platform, platform_system=platform.system(),
                   platform_machine=platform.machine(), platform_release=platform.release(),
                   platform_version=platform.version())
        return env
    tag = platform_tag.lower()
    linux = re.fullmatch(r"(?:manylinux\d+|manylinux_\d+_\d+|musllinux_\d+_\d+|linux)_(\w+)", tag)
    if tag.startswith("win"):
        env.update(os_name="nt", sys_platform="win32", platform_system="Windows",
                   platform_machine={"win_amd64": "AMD64", "win32": "x86", "win_arm64": "ARM64"}.get(tag))
    elif tag.startswith("macosx_"):
        arch = tag.rsplit("_", 1)[-1]
        env.update(os_name="posix", sys_platform="darwin", platform_system="Darwin",
                   platform_machine=arch if arch in ("x86_64", "arm64") else None)
    elif linux:
        env.update(os_name="posix", sys_platform="linux", platform_system="Linux", platform_machine=linux[1])
    else:
        raise SetupError(f"Unknown --platform tag {platform_tag!r}; use a win_*, macosx_*, manylinux*, musllinux* or "
                         "linux_* tag")
    return env


def wheel_metadata(wheel: Path) -> tuple[str, str, list[str]]:
    """Name, version and Requires-Dist lines of a wheel, read from its METADATA (nothing is installed or run)."""
    try:
        with zipfile.ZipFile(wheel) as z:
            names = [n for n in z.namelist() if re.fullmatch(r"[^/]+\.dist-info/METADATA", n)]
            if len(names) != 1 or z.getinfo(names[0]).file_size > MAX_MANIFEST_BYTES:
                raise SetupError(f"{wheel.name} has no single readable METADATA")
            meta = BytesHeaderParser().parsebytes(z.read(names[0]))
    except (OSError, zipfile.BadZipFile) as e:
        raise SetupError(f"{wheel.name} is not a readable wheel: {e}") from None
    if not meta["Name"] or not meta["Version"]:
        raise SetupError(f"{wheel.name} names no distribution or version")
    return str(meta["Name"]), str(meta["Version"]), [str(r) for r in meta.get_all("Requires-Dist") or []]


def parse_requirement(text: str) -> tuple[str, set[str], str, str | None]:
    """Name, extras, version specifier and marker of a PEP 508 requirement (a direct URL is refused)."""
    req, _, marker = text.partition(";")
    m = re.fullmatch(r"\s*([A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?)\s*(?:\[([^\]]*)\])?\s*\(?([^()@]*?)\)?\s*", req)
    if not m:
        raise SetupError(f"Cannot read the requirement {text!r}")
    extras = {canonical_name(e.strip()) for e in (m[2] or "").split(",") if e.strip()}
    return m[1], extras, re.sub(r"\s+", "", m[3]), marker.strip() or None


def missing_for_target(dest: Path, env: dict, roots=COLLECTOR_REQUIREMENTS) -> list[tuple[str, str]]:
    """Requirements that apply on the target (markers evaluated for `env`) but that no wheel in `dest` meets:
    [(requirement, what needs it)]. A marker whose answer is unknown for the target counts as applying."""
    wheels: dict[str, list[tuple[str, list[str]]]] = {}
    for w in sorted(dest.glob("*.whl")):
        name, version, requires = wheel_metadata(w)
        wheels.setdefault(canonical_name(name), []).append((version, requires))
    pending = [(r, "the collector") for r in roots]
    seen, missing = set(), []
    while pending:
        text, needed_by = pending.pop()
        name, extras, spec, _ = parse_requirement(text)
        key = (canonical_name(name), frozenset(extras), spec)
        if key in seen:
            continue
        seen.add(key)
        matching = [(v, reqs) for v, reqs in wheels.get(key[0], []) if specifier_allows(spec, v) is not False]
        if not matching:
            missing.append((text.partition(";")[0].strip(), needed_by))
            continue
        for version, requires in matching:
            for dep in requires:
                marker = parse_requirement(dep)[3]
                if marker is None or any(evaluate_marker(marker, {**env, "extra": e}) is not False for e in ("", *extras)):
                    pending.append((dep, f"{name} {version}" + (f" ({marker})" if marker else "")))
    return sorted(set(missing))


def _run_pip(cmd: list[str]) -> tuple[int, str]:
    try:
        done = subprocess.run(cmd, env=_python_env(), shell=False, capture_output=True, timeout=1800)
    except (OSError, subprocess.SubprocessError) as e:
        raise SetupError(f"Downloading the wheels failed: {e}") from None
    return done.returncode, (done.stdout + done.stderr).decode("utf-8", "replace")


def make_wheelhouse(dest: Path, python: Path | None = None, platform: str | None = None,
                    python_version: str | None = None, runner=None) -> dict:
    """Download the collector's dependencies as wheels into `dest`, for preparing a computer without internet access
    (for example at an event) with --wheelhouse. Nothing is installed or run from them here.

    For another platform or Python version, every dependency that applies there (its markers evaluated for the target,
    not for the Python running pip) is downloaded too, until none is missing; the result lists what that added.
    `runner` runs a pip command and returns (exit code, output); it is replaceable for tests."""
    dest = Path(os.path.abspath(dest))
    if dest.exists() and any(dest.iterdir()):
        raise SetupError(f"{dest} is not empty; choose a new folder")
    selected = select_python(Path(os.path.abspath(python or sys.executable)), Path.home())
    env = target_environment(platform, python_version, selected["version"])
    dest.mkdir(parents=True, exist_ok=True)
    constraints = dest / ".tested-versions.txt"
    constraints.write_text("\n".join(COLLECTOR_TESTED_VERSIONS) + "\n", encoding="utf-8")
    target = (["--platform", platform] if platform else []) + (["--python-version", python_version] if python_version else []) \
        + (["--implementation", "cp"] if platform or python_version else [])
    cmd = [str(selected["executable"]), "-I", "-m", "pip", "download", "--disable-pip-version-check", "--no-input",
           "--only-binary", ":all:", "--dest", str(dest), *target]
    run = runner or _run_pip
    target_name = f"{platform or 'this computer'} with Python {env['python_version']}"
    tested = True
    try:
        code, out = run([*cmd, "-c", str(constraints), *COLLECTOR_REQUIREMENTS])
        if code != 0:
            tested = False
            code, out = run([*cmd, *COLLECTOR_REQUIREMENTS])
        if code != 0:
            raise SetupError("Downloading the wheels failed: " + out[-1500:])
        first = {p.name for p in dest.glob("*.whl")}
        previous = None
        while True:
            missing = missing_for_target(dest, env)
            if not missing:
                break
            if missing == previous:
                raise SetupError(f"The wheelhouse cannot be completed for {target_name}: pip downloaded no wheel that "
                                 f"meets {', '.join(r for r, _ in missing)}")
            previous = missing
            for requirement, needed_by in missing:
                # The tested versions where they name this package, the newest compatible version otherwise.
                code, out = run([*cmd, *(["-c", str(constraints)] if tested else []), requirement])
                if code != 0 and tested:
                    code, out = run([*cmd, requirement])
                    tested = False
                if code != 0:
                    raise SetupError(f"The wheelhouse cannot be completed for {target_name}: {requirement}, needed there "
                                     f"by {needed_by}, has no wheel for it: {out[-800:]}")
    finally:
        constraints.unlink(missing_ok=True)
    wheels = sorted(p.name for p in dest.glob("*.whl"))
    return {"result": "PASS", "wheelhouse": str(dest), "wheels": wheels, "tested_versions": tested,
            "for": {"platform": platform or "this computer", "python_version": python_version or "this Python"},
            "added_for_target": sorted(set(wheels) - first),
            "checked": "every dependency that applies on the target, with its environment markers evaluated for the "
                       "target, has a wheel here",
            "use": f"configure_claude.py ... --wheelhouse {dest}"}


def show_disclosure(package: Path, manifest_sha256: str) -> str:
    """PitRelay's Workspace Access disclosure, from a package checked against your trusted manifest hash."""
    package = Path(os.path.abspath(package))
    manifest, _ = read_manifest(package, manifest_sha256)
    row = next((r for r in manifest["files"] if r["path"] == DISCLOSURE_SOURCE), None)
    if row is None or digest(package / DISCLOSURE_SOURCE) != row["sha256"]:
        raise SetupError(f"{DISCLOSURE_SOURCE} is missing or differs from the package manifest")
    return workspace_disclosure_text(package, manifest)


def pin_overlay() -> str:
    rows = [(rel, hashlib.sha256(overlay_bytes(p)).hexdigest()) for rel, p in sorted(component_sources().items())]
    lines = ["OVERLAY_INVENTORY = {"] + [f"    {rel!r}: {h!r}," for rel, h in rows] + ["}"]
    return "\n".join(lines).replace("'", '"')


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["pin-overlay"]:
        print(pin_overlay())
        return 0
    if argv[:1] == ["show-disclosure"]:
        p = argparse.ArgumentParser(prog="configure_claude.py show-disclosure",
                                    description="Print PitRelay's Workspace Access disclosure from a verified package")
        p.add_argument("--package", type=Path, required=True)
        p.add_argument("--manifest-sha256", required=True)
        a = p.parse_args(argv[1:])
        try:
            print(show_disclosure(a.package, a.manifest_sha256))
        except (OSError, SetupError) as e:
            print(f"FAIL: {e}", file=sys.stderr)
            return 1
        print(f"\nTo accept it, add: --workspace-disclosure {DISCLOSURE_ACK}")
        return 0
    if argv[:1] == ["wheelhouse"]:
        p = argparse.ArgumentParser(prog="configure_claude.py wheelhouse",
                                    description="Download the collector's dependencies as wheels for an offline setup")
        p.add_argument("--dest", type=Path, required=True, help="a new folder for the wheels")
        p.add_argument("--python", type=Path, help="the Python that runs pip (default: this one)")
        p.add_argument("--platform", help="target platform tag, e.g. win_amd64, macosx_11_0_arm64, manylinux2014_x86_64; "
                                          "the dependencies that apply only there are added")
        p.add_argument("--python-version", help="target Python version, e.g. 3.12 (default: that of --python)")
        a = p.parse_args(argv[1:])
        try:
            result = make_wheelhouse(a.dest, a.python, a.platform, a.python_version)
        except (OSError, SetupError) as e:
            result = {"result": "FAIL", "error": str(e)}
        print(json.dumps(result, indent=2))
        return 0 if result["result"] == "PASS" else 1
    if argv[:1] == ["verify"]:
        p = argparse.ArgumentParser(prog="configure_claude.py verify", description="Re-check a prepared marketplace")
        p.add_argument("--output", type=Path, required=True)
        p.add_argument("--manifest-sha256", help="the package-manifest SHA-256 from your retained release receipt")
        p.add_argument("--receipt-sha256", help="the receipt_sha256 printed when the marketplace was prepared; only with it "
                                                "does verify run the recorded Java and Python to check them")
        a = p.parse_args(argv[1:])
        try:
            result = verify_output(a.output, a.manifest_sha256, a.receipt_sha256)
        except (OSError, SetupError) as e:
            result = {"result": "FAIL", "problems": [str(e)]}
        print(json.dumps(result, indent=2))
        return 0 if result["result"] == "PASS" else 1
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    for name, helptext in (("package", "the extracted PitRelay package folder (contains package-manifest.json)"),
                           ("java", "absolute path of an existing Java 17+ (a launcher stub or shim is resolved to its runtime)"),
                           ("state", "new folder for PitRelay's private state (kept when the plugin is uninstalled)"),
                           ("output", "new folder for the generated local marketplace (must not move afterwards)")):
        p.add_argument("--" + name, type=Path, required=True, help=helptext)
    p.add_argument("--manifest-sha256", required=True, help="package-manifest.json SHA-256 from your retained release receipt")
    p.add_argument("--accept-license", required=True, help=f"SHA-256 of {LICENSE}, after reading it")
    p.add_argument("--workspace", type=Path, help="optional: folder PitRelay may read (Workspace Access)")
    p.add_argument("--workspace-disclosure", choices=(DISCLOSURE_ACK,),
                   help="acknowledge PitRelay's Workspace Access disclosure after reading it: "
                        "'configure_claude.py show-disclosure --package <pkg> --manifest-sha256 <hash>' prints it")
    p.add_argument("--grants", help=f"Workspace Access grants, comma-separated (default project_read): {', '.join(GRANTS)}. "
                                    "Standard Access already includes proposals on supplied artifacts; Workspace Access "
                                    "with project_read alone does not, so add 'propose' to keep them")
    p.add_argument("--python", type=Path, help="absolute path of Python 3.10+ for the host (default: the Python running "
                                               "this script). A virtual environment or a shim is resolved to the "
                                               "interpreter it runs, and python3 to its versioned name (python3.x)")
    p.add_argument("--without-collector", action="store_true",
                   help="leave PitRelay Collector out (no Python packages are installed; engine tools and fixes only)")
    p.add_argument("--wheelhouse", type=Path, help="install the collector's dependencies (" + ", ".join(COLLECTOR_REQUIREMENTS)
                                                   + ") from wheels in this folder instead of PyPI, e.g. offline at an event")
    p.add_argument("--collector-store", type=Path,
                   help="the collector's store (logs, sources, trusted host keys): kept across preparations and shared with "
                        "a standalone PitRelay Collector; default: the standalone collector's location for this user")
    p.add_argument("--reuse-state", action="store_true",
                   help="keep an earlier preparation's state folder (PitRelay cases and artifacts); close every Claude Code "
                        "session that uses it first")
    p.add_argument("--without-host-notes", action="store_true",
                   help="never add the host's labelled notes to engine results (engine results are relayed unchanged "
                        "either way)")
    a = p.parse_args(argv)
    try:
        result = prepare(a.package, a.manifest_sha256, a.java, a.state, a.output, a.accept_license,
                         workspace=a.workspace, workspace_disclosure=a.workspace_disclosure, grants=a.grants,
                         python=a.python, collector=not a.without_collector, wheelhouse=a.wheelhouse,
                         host_notes=not a.without_host_notes, collector_store=a.collector_store,
                         reuse_state=a.reuse_state)
    except (OSError, SetupError, subprocess.SubprocessError) as e:
        print(json.dumps({"result": "FAIL", "error": str(e)}, indent=2))
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    raise SystemExit(main())
