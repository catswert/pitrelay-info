# PitRelay for Claude Code

This turns a PitRelay package (v11, `pitrelay-0.1.0-dev`) into **one Claude Code plugin** on your own computer. It collects logs from the robot and the Driver Station and has PitRelay analyze them, without a second program:

* **PitRelay Collector is built in.** It copies log files from the robot over SSH/SFTP (read-only) and from Driver Station folders into a private store on your computer. It exports a verified ZIP package inside that store.
* **The PitRelay engine is built in.** It runs unmodified, as in PitRelay's Codex setup.
* **The collector supplies a package to the engine directly**, so the log bytes never pass through the conversation. Claude then investigates with PitRelay's own skills.
* **Fixes for the v11 engine's known problems.** The host adds clearly labelled notes where a v11 answer is known to mislead (see [Engine issues and fixes](#engine-issues-and-fixes)).

The standalone collector (with its own web page, in [`collector/`](collector/README.md)) still exists. Both use the same store, so it does not matter which one collected a log.

**License and sharing.** PitRelay's license allows private and team-internal use and modification, but restricts redistributing its protected material. So this repository contains **no PitRelay files**: only the generator, the host, the collector and the Claude-specific files (`overlay/`). See [NOTICE.md](NOTICE.md) for what that means for sharing it. Each person runs the generator against a PitRelay package they are entitled to use. Two places then hold the engine, so do not share, sync or publish either:
* the folder the generator produces;
* the copy Claude Code makes in its plugin cache when you install (`~/.claude/plugins/cache/pitrelay-local/`).

## What you get

| | |
|---|---|
| MCP server `pr` (the **host**) | One local server that Claude Code starts with your Python. It runs the PitRelay engine (`java … org.pitrelay.Main --mode mcp`, the same launch as PitRelay's Codex setup) and relays the engine's tools unchanged, as `mcp__plugin_pitrelay_pr__pitrelay_<operation>`. In v11 there are 107 in Standard Access, 105 with Workspace `project_read`, and 109 with `project_read,propose`. It adds `host_status` and, with the collector, 13 `collector_*` tools. |
| PitRelay skills (byte-identical) | `pitrelay-investigate`, `pitrelay-improve`, `pitrelay-verify-recover`, `pitrelay-navigate-explain` |
| Claude Code skills (new) | `pitrelay-collect`: collecting with the built-in collector. `pitrelay-collector-intake`: bringing a collector package into an investigation. `pitrelay-claude-host`: tool naming, host notes, evidence intake, and the boundary between PitRelay and Claude Code's own tools. |
| Commands (new) | `/pitrelay:start`, `/pitrelay:collect`, `/pitrelay:diagnose <symptom>`, `/pitrelay:checkup [scope]`, `/pitrelay:import-collection <zip>` |

### The collector tools

| Tool | What it does | Confirmed by the person in a dialog |
|---|---|---|
| `collector_status` | Who collects, each source's state, captures, storage, alerts, recent events, packages | |
| `collector_configure_source` | Add or change a source: a robot over SFTP, or a local folder | Adding, or reading more (folders, hosts, users, login, file kinds). Nothing is contacted before you allow it; then a robot's SSH host key is shown in a second dialog. |
| `collector_trust_host_key` | Trust the SSH host key a robot presented | Always |
| `collector_remove_source` | Remove a source (its captures are kept) | |
| `collector_control` | Automatic collection on or off; pause, resume | |
| `collector_background` | Collect also while Claude Code is closed: on, off (stops only the background collector it started), status | Turning it on |
| `collector_collect_now` | Sync now, even while automatic collection is off | |
| `collector_list_captures` | Collected recordings, filtered and paged | |
| `collector_export` | A verified package inside the store; optional time range, sources, captures, observations, robot source code | Including robot source code |
| `collector_job_status` | Wait for an export or supply job | |
| `collector_supply_to_engine` | Verify a package and supply its recordings to the engine with the right format | A ZIP from outside the store's exports |
| `collector_open_page` | Open the collector's page in your browser, for robot passwords and settings | |
| `collector_delete_captures` | Delete captures from the local store (never on the robot) | Always, naming each capture (at most 25 per call) |

The dialogs are Claude Code's MCP elicitation dialogs. They are answered by you, or by a hook or SDK program you configured, never by the model. A cancelled or declined dialog changes nothing, and a dialog is never cut short: a proposal too long to show in full is refused instead. Sessions that cannot show dialogs (`claude -p`) cancel them; use `collector_open_page` there.

**Access.** The default is PitRelay's **Standard Access**: the engine analyzes only artifacts you supply, and can return proposals (patches, instrumentation) about them. The collector supplies its recordings this way.

Optional **Workspace Access** lets PitRelay read one folder you choose:
* It is enabled only at setup, with PitRelay's disclosure acknowledged.
* Its grants replace Standard Access's: `project_read` alone (PitRelay's default) reads the folder but *loses* the proposal tools. Use `--grants project_read,propose` to keep them.

## Collecting and analyzing

Run `/pitrelay:collect` in a new Claude Code session. It walks through this:

1. **Sources.** Claude proposes sources and you confirm each in a dialog. Typical ones:
   * the roboRIO: SFTP, user `lvuser` (blank password), folders `/home/lvuser/logs` and `/u/logs`, addresses `172.22.11.2` (USB) and `10.TE.AM.2`;
   * Systemcore (2027): user `systemcore`, its documented login;
   * the Driver Station laptop's log folder, for example `C:\Users\Public\Documents\FRC\Log Files`.
2. **Host key.** Nothing is contacted before you allow a source. Then, if the robot answers, a second dialog shows its SSH host-key fingerprint to compare and trust. A different key later stops collection from it before any password is sent, until you decide whether the robot was re-imaged or another robot answers there.
3. **Collect.**
   * **Sync now** polls every source once.
   * **Automatic collection** keeps polling while a Claude Code session with this plugin is open.
   * **Background collection** starts the bundled collector now and at every login, so logs are also collected while Claude Code is closed, for example during matches.

   Only one process collects with a store at a time: one Claude Code session or the background collector. Other sessions still read status, export and supply packages, and take over when the collecting session ends.
4. **Export.** A verified ZIP package (`manifest.json` with hashes and acquisition status per recording, `collection-status.json`, optional observations and, if you agree in a dialog, the robot project's source code) is written to `<store>/exports/claude/`. The five newest are kept there, plus every package with observations or source code; copy a package elsewhere if it must be kept.
5. **Analyze.** `collector_supply_to_engine` verifies the package, streams each recording to the engine and inspects it with the format the collector identified. In a PitRelay workflow, the inspections count against the workflow's call budget; the uploads do not. Claude then follows `pitrelay-collector-intake` and `pitrelay-investigate`.

You can also ask in plain words ("get the logs from the robot and look at the brownout in the last match"); the `pitrelay-collect` skill covers the same steps.

**What cannot be analyzed** is listed per recording rather than skipped silently: files over 64 MiB, CTRE `.hoot` (PitRelay needs a configured Owlet), NI Driver Station v3 logs, and REVLOG v2 with the v11 engine, which decodes v1 only (an engine built with the fixes in `docs/PITRELAY_ENGINE_ISSUES.md` decodes REVLOG 2.x).

**The store** holds the logs, the sources and the trusted host keys. By default it is the standalone collector's location, so both share it:
* Windows: `%LOCALAPPDATA%\PitRelayCollector`
* macOS: `~/Library/Application Support/PitRelayCollector`
* Linux: `$XDG_DATA_HOME/pitrelay-collector` (default `~/.local/share/pitrelay-collector`)

Choose another with `--collector-store`. The store is never inside the plugin and survives every reinstallation.

**Passwords.** A password the team set on the robot never goes through the conversation or a tool argument. `collector_open_page` opens the collector's page in your browser, and you enter it there. It is kept in the OS credential store (Windows Credential Manager, macOS Keychain, Secret Service on Linux). The page's private link is never shown to the model.

## Engine issues and fixes

[docs/PITRELAY_ENGINE_ISSUES.md](docs/PITRELAY_ENGINE_ISSUES.md) lists what was found in the v11 engine, each with a suggested fix for the engine's source.

The v11 package contains only the compiled engine, and it is a frozen release, so the engine itself is not changed. The host works around the problems instead:
* The engine's answers are relayed **byte for byte**.
* Where a v11 answer is known to mislead, the host adds a second, labelled text item: `Host note (PitRelay for Claude Code, not the PitRelay engine; …)`. There are three:
  * `revlog_v2`: on a REVLOG v2 file nothing was decoded, so its "unknown record" issues come from the missing v2 support. Other issues the engine lists may still be real damage.
  * `ds_format`: a Driver Station file read with the wrong adapter is reported as damaged; the note names the right format. A file whose records are only zeros (cut short by a power loss) gets no such note.
  * `upload_transfer_id`: `upload_begin` returns the transfer id as `id`; the note says to pass it as `transfer_id`.
* `TRANSFER_BUSY` uploads are retried, and uploads left open by a session that ended are aborted by the next session.
* The notes are active only for the v11 engine (checked by SHA-256). `host_status` lists them, and `--without-host-notes` turns them off.

The collector also routes Driver Station files by their content rather than their extension, and marks REVLOG v2 files with their limitation.

**Fixed in the engine source.** With the PitRelay source, these issues were later fixed in the engine itself on a local branch (ENGINE-FIXES-1: REVLOG 2.x decoding, the DS adapters naming the right format, `transfer_id`, uploads outside workflow budgets, CSV time-unit statuses). That candidate is not a release. Prepared from its package, this plugin passes the same end-to-end checks; the host notes switch off by themselves because they are tied to the v11 engine. See [docs/PITRELAY_ENGINE_ISSUES.md](docs/PITRELAY_ENGINE_ISSUES.md).

## Requirements

* Claude Code (tested with 2.1.309).
* **Java 17 or later**, already installed. Nothing is installed for you.
* **Python 3.10 or later** (CPython, for example from python.org, your Linux distribution or Homebrew). The Microsoft Store Python and free-threaded builds are refused. Claude Code runs the host with this Python every time it starts the plugin, so keep it installed.
* For the collector, its two dependencies (`paramiko` for SFTP, `keyring` for the OS credential store). Setup installs them, wheels only, into a private virtual environment in the state folder: from PyPI, or offline from a folder of wheels (see below).
* The PitRelay package folder, plus the SHA-256 of its `package-manifest.json` from your **independently retained release receipt**. A hash read from the same download proves nothing.

## Set up

1. Read `docs/release/PITRELAY_LICENSE.md` in the package and compute its SHA-256. You acknowledge the license by passing that hash.
2. Choose two **new** folders that do not overlap the package or each other: one for PitRelay's state and one for the generated marketplace. Do not move the marketplace afterwards: Claude Code loads it in place, and background collection runs the collector from it.
3. Run (one line; quote paths for your shell):

   ```text
   python3 configure_claude.py --package <extracted-pitrelay-package> --manifest-sha256 <trusted-manifest-sha256>
       --accept-license <license-sha256> --java <absolute-path-to-java> --state <new-state-folder>
       --output <new-marketplace-folder>
   ```

   Options:

   | Option | Effect |
   |---|---|
   | `--python <python>` | The Python for the host (default: the one running setup). A virtual environment is resolved to its base interpreter, a pyenv or asdf shim to the interpreter it starts, and `python3` to its versioned name (`python3.12`), so a later change of the shim or link never changes the host's Python. |
   | `--collector-store <folder>` | Another store than the standalone collector's default. It may already exist; setup checks that it is a collector store. |
   | `--wheelhouse <folder>` | Install the collector's dependencies from wheels in this folder instead of PyPI |
   | `--without-collector` | Engine and host notes only; no Python packages are installed |
   | `--without-host-notes` | Relay the engine without the host's notes |
   | `--reuse-state` | Keep an existing state folder (PitRelay cases and artifacts) from an earlier preparation, 1.x included. Close every Claude Code session that uses it first. |
   | `--workspace <folder> --workspace-disclosure accepted-v1 [--grants …]` | Workspace Access (below) |

   For Workspace Access:
   1. Read PitRelay's disclosure: `python3 configure_claude.py show-disclosure --package <pkg> --manifest-sha256 <hash>`. It prints the disclosure from your verified package.
   2. Add `--workspace <folder> --workspace-disclosure accepted-v1 --grants project_read,propose` to the setup command.

   The other grants (`execute`, `apply`, `restore`, `persist_notebook`) let PitRelay run commands or change files in that folder; add them only deliberately.

   For a computer without internet access, download the wheels elsewhere first: `python3 configure_claude.py wheelhouse --dest <new-folder> [--platform win_amd64 --python-version 3.12]`. For another platform or Python version, it also downloads the dependencies that apply only there. Then pass `--wheelhouse <folder>`.

   * **Java path.** Any `java` works: `/usr/bin/java`, a version-manager shim such as asdf or jenv, or a full JDK path. The generator asks it for its real runtime (`java.home`) and pins that runtime's own launcher, so Claude Code never picks a different Java later from whatever folder it starts in. When that launcher lies in a folder named for its exact version (Homebrew's `Cellar/openjdk@21/21.0.4`, Fedora's `java-21-openjdk-21.0.4…`), which an update removes, the stable link you selected (`/opt/homebrew/opt/openjdk@21/bin/java`) is pinned instead. The path and SHA-256 are recorded.
   * **No links in the other paths.** The package, state, output, workspace and collector store paths may not pass through a link. On macOS, use `/Users/…` paths, not `/tmp` (which is a link to `/private/tmp`). None of them may be inside Claude Code's own plugin folders (`~/.claude/plugins`), which Claude Code deletes on uninstall. Setup warns about synced cloud folders, network shares and Windows drives seen from WSL, where databases and file locks are unreliable.
   * **Non-ASCII names.** On Linux, the engine always gets `LC_ALL=C.UTF-8`, after setup checks that this Java honors it. Without it, a Claude Code running under the POSIX locale (common over ssh) would start a Java that cannot open any path with non-ASCII characters (for example `Équipe`). On macOS, Java always uses UTF-8 for file names. On Windows, PitRelay's code-page check applies.

   On success, setup prints `receipt_sha256`. Keep it somewhere else (your notes); it lets `verify` detect deliberate changes later.
4. Install it. Setup prints these commands but does not run them, because installing changes your Claude Code settings:

   ```text
   claude plugin marketplace add <new-marketplace-folder>
   claude plugin install pitrelay@pitrelay-local
   ```

5. Start a **new** Claude Code session and run `/pitrelay:start`. It reports the engine's compatibility, the access level and the collector. Then run `/pitrelay:collect`. `/mcp` shows whether the `plugin:pitrelay:pr` server connected.

**Permissions.** Claude Code asks before each tool call unless you allow it. `/pitrelay:start` pre-approves its read-only calls and `/pitrelay:collect` the collector tools and the engine's analysis tools, for that command only; this was not verified in a live session. The collector's dialogs still appear when a tool is pre-approved. To stop prompts for tools you trust, add allow rules to your Claude Code permission settings, for example `mcp__plugin_pitrelay_pr__collector_status` or `mcp__plugin_pitrelay_pr__pitrelay_log_inspect`. Avoid a blanket `mcp__plugin_pitrelay_pr__*` if you granted Workspace permissions beyond `project_read` and `propose`.

## Safety boundaries

* **Read-only towards robots and Driver Stations.** The collector's source interface has no write, rename, delete or command methods. It never deploys code, actuates mechanisms or sends robot-control values.
* **Only confirmed sources.** It reads only the folders and hosts you confirmed, and contacts or opens nothing you have not allowed yet. Filesystem roots, your home folder and the store itself are refused, and links inside sources are not followed. What Claude proposes is held to stricter rules before you are even asked: no network shares, hidden folders, disguised numeric addresses, or text-file patterns that would match almost anything or key and credential files. Whatever a pattern says, hidden files and files named like keys or credentials are never collected through it. Robot source code goes into a package only from a robot project folder you confirm.
* **Pinned host identity.** An unknown or changed SSH host key stops the connection before any password is sent.
* **No secrets in the conversation, exports or logs.** Passwords live in the OS credential store.
* **Nothing is uploaded.** Packages are private and **not anonymized**. Nothing leaves this computer unless you give it to someone.
* **Collected logs are never deleted automatically.** A full store stops collection with an alert. Deleting captures is a confirmed action, and later exports list them as deleted. Exported packages are copies: the store keeps the five newest, plus every package with observations or source code, and removes older ones after a later export.
* **Background collection is off** until you turn it on in a dialog.
* **Untrusted data.** File names, log text, robot banners and imported packages are treated as data. Nothing from a package is executed, including robot source code included in it.
* **The engine is unmodified**, and its answers are relayed unchanged.

## Check, update, remove

* **Verify.** `python3 configure_claude.py verify --output <marketplace> --receipt-sha256 <kept value>` checks:
  * every file against the receipt, and the receipt against the hash you kept;
  * the PitRelay files against their own package manifest, and the engine against the packaged engine;
  * the host, collector and overlay files against the reviewed inventory;
  * that `.mcp.json` starts exactly the recorded host and Python, and `host/launch.json` exactly the recorded Java, state, access level and collector settings, never restoring an injection variable;
  * that the collector's virtual environment starts the recorded Python and holds exactly what was installed at setup (no extra or changed files, which would run inside the host);
  * that the Java, the Python and the state folder are still there;
  * with `--receipt-sha256`: that the Java it launches is a real Java runtime's own launcher, not a wrapper, and the Python the recorded base interpreter. Only then does verify run them (to ask their versions), and never a changed one that is not a compiled program. A security update of either is a note, not a failure: same path and major version, still a compiled program, and reporting another version (Java) or another build (Python, whose `sys.version` changes with a distribution's backports). Other bytes reporting the same version or build fail.

  What anchors the result:
  * `--receipt-sha256 <kept value>` anchors everything, including the launch configuration and the virtual environment. Use it to detect deliberate changes. If the receipt differs from it, verify stops at once and runs nothing.
  * `--manifest-sha256` alone anchors the PitRelay files. The launch configuration still comes from the receipt inside the folder, so verify prints it, and the Java and Python it names, for you to check; it does not run them.
  * Without either hash, verify can only detect accidental change.

  The output says which applies. The host also checks its own files against the recorded hashes each time it starts; `host_status` shows the result.
* **Upgrade or move.** Prepare a new version into a **new** output folder, with `--reuse-state` and the old state folder to keep PitRelay's cases and artifacts. They stay reachable only with the same state path, access level and workspace; setup warns when these differ. The collector store the earlier preparation used is used again (setup warns if you name another). Then switch:

  ```text
  claude plugin marketplace remove pitrelay-local
  claude plugin marketplace add <new-marketplace>
  claude plugin install pitrelay@pitrelay-local
  ```

  If background collection was on, turn it on again in the new installation; it replaces the old login item. Every preparation gets its own plugin version, so Claude Code never serves a stale cached copy.
* **Remove.**
  1. If background collection is on, turn it off first (`collector_background` `off`, or on the collector page).
  2. Run `claude plugin uninstall pitrelay@pitrelay-local`, then `claude plugin marketplace remove pitrelay-local`.
  3. Delete Claude Code's cached copy: `~/.claude/plugins/cache/pitrelay-local/` (or `$CLAUDE_CONFIG_DIR/plugins/cache/pitrelay-local/` if you set that variable). Claude Code 2.1.309 keeps it, engine included, marked orphaned, for up to 14 days.
  4. Delete the generated marketplace folder.
  5. The state folder and the collector store stay. Review them and delete them yourself when you are sure you no longer need their logs, artifacts, reports or checkpoints.

## Where it works

| Surface | Status |
|---|---|
| Claude Code CLI on Linux: host, engine, collector, skills, commands | Verified below the model: validate `--strict`, install in an isolated config, server `√ Connected`, every tool through the exact launch command, collection from a local SFTP test server, export, supply to the real v11 engine, background collection. Details in [docs/TESTING.md](docs/TESTING.md). |
| A live model session (Claude choosing the tools, dialogs in the terminal) | UNVERIFIED |
| Claude Code on Windows or macOS | UNVERIFIED. The generator includes PitRelay's Windows code-page check and macOS no-replace rename; the collector supports both. |
| Claude Code IDE extensions and the desktop app | UNVERIFIED. They use the same plugin system; whether they show MCP dialogs was not checked. |
| A real roboRIO or Systemcore, a real Driver Station, real REV or CTRE logs | UNVERIFIED (synthetic logs and a local SFTP server only) |
| claude.ai chat | Not supported: it does not run local servers. |

## Files

* `configure_claude.py`: the generator and verifier (standard library only).
* `host/`: the local MCP server Claude Code starts. `gateway.py` is the entry point; `collector.py` is the bundled collector's command line (`<python> -I -B -X utf8 <plugin>/host/collector.py status`, for example). See [docs/HOST.md](docs/HOST.md).
* `collector/`: PitRelay Collector. The generator copies its package into the plugin's `host/`; it also works standalone.
* `overlay/`: the skills, commands and `CLAUDE_CODE.md` added to the PitRelay package. The exact files and hashes of `overlay/`, `host/` and the collector package are pinned in `OVERLAY_INVENTORY` in `configure_claude.py`, so an added or changed file is refused. After reviewing a change, print the new table with `python3 configure_claude.py pin-overlay`.
* `tests/`: synthetic packages, a fake engine, the host over pipes, and `mcp_e2e.py`, which drives a prepared plugin's server exactly as Claude Code launches it.
* `tools/mutants.py`: re-runs the mutation checks (reintroduced defects; every one must make the tests fail).
* `docs/`: [HOST.md](docs/HOST.md), [PITRELAY_ENGINE_ISSUES.md](docs/PITRELAY_ENGINE_ISSUES.md), [TESTING.md](docs/TESTING.md).

The generator mirrors PitRelay's own `setup/configure_local.py`:

* **Checks.**
  * the manifest SHA-256 from your receipt, every file's size and hash, the engine entry point, and the license hash;
  * that the package contains nothing Claude Code would load as hooks, agents or commands, and no skill that grants itself tools;
  * Java 17+ and Python 3.10+;
  * new paths that do not overlap (compared by file identity, so case or 8.3-name variants are caught) and contain no links;
  * PitRelay's launcher preflight.
* **Publication.** Files are staged, re-verified and published with a no-replace rename. A failed preparation removes what it created.
* **Execution.** Nothing from the package is executed. The programs run are the Java you chose (to read its version and properties) and the Python you chose (to read its version, create the collector's virtual environment and run pip, wheels only).
