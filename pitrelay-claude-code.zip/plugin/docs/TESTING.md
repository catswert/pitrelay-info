# Testing: what was run, what could not be run, and what is unverified

Date: 2026-10-23. Linux 6.18 x86_64, Claude Code CLI 2.1.309, OpenJDK 21.0.12, CPython 3.13, 3.11 and 3.10. PitRelay package `pitrelay-0.1.0-dev-20261006-v11` (manifest SHA-256 `e842e0ca…776c`, engine `66de12d3…c5d2`). All robot, Driver Station and REV data used here is synthetic; the "robot" is a local SFTP test server.

## Commands

```bash
# Python with paramiko, keyring and pytest; the engine jar enables the tests that need the real engine
PITRELAY_ENGINE_JAR=<pkg>/engine/pitrelay.jar python3 -m pytest -q tests                  # generator, host, collector tools, notes
cd collector && PITRELAY_ENGINE_JAR=<pkg>/engine/pitrelay.jar python3 -m pytest -q tests   # the collector itself
python3 tools/mutants.py                                                                   # reintroduced defects; each must make the tests fail
python3 configure_claude.py --package <pkg> --manifest-sha256 <m> --accept-license <l> --java <java> --state <new> --output <new> [...]
python3 tests/mcp_e2e.py <output> --posix-locale --home <scratch> [--upload <file> | --register <path>] [--collector-flow <folder>] [--entry <name> --expect-mean 10.8 --expect-min 6]
python3 configure_claude.py verify --output <output> --receipt-sha256 <kept> --manifest-sha256 <m>
```

Claude Code itself was only run with `HOME` and `CLAUDE_CONFIG_DIR` pointing at new, empty folders, so no real Claude Code configuration was read or changed. Login items were only written into such a scratch `HOME`.

## 1. Tests run (PASS)

| Check | Result |
|---|---|
| `tests/` on Python 3.13, 3.11 and 3.10 | **352 passed** each. The generator (synthetic packages, real `claude plugin validate --strict`), the host over pipes with a fake engine and with the real v11 engine, the 13 collector tools against a local SFTP robot, the host notes. |
| `collector/tests` on Python 3.13, 3.11 and 3.10 | **230 passed** each, including the handoff to the real v11 engine and a check that the previous collector release still reads a config written by this one. |
| `tools/mutants.py` | **136 of 136 mutants killed** (generator, host and collector). Every mutant reintroduces one defect a review found, or removes one safeguard; the run first checks that an unmutated copy passes. |
| Real preparation from the v11 package, then `mcp_e2e.py --posix-locale` | **PASS** for every variant below. |
| `verify --receipt-sha256 … --manifest-sha256 …` on untouched outputs | **PASS** (81 files). |
| `claude plugin validate --strict`, marketplace and plugin | **PASS** |
| `claude plugin marketplace add`, `claude plugin install pitrelay@pitrelay-local` | **PASS** |
| `claude mcp list`, Claude Code started under `LC_ALL=C` | **PASS**: `plugin:pitrelay:pr … - √ Connected`. No host or engine process is left after the health check. |
| `claude plugin details` | 12 skills and commands, 1 MCP server. About 1,160 tokens always-on. |
| `claude plugin uninstall`, `claude plugin marketplace remove` | **PASS**. The state folder and the collector store were kept. |
| Background collection, real processes | **PASS**: the dialog, the login item (XDG, in a scratch `HOME`), the detached collector owning the store, "sync now" through it, `off` stopping exactly it and removing the login item, and the session taking over. |

Real preparations and `mcp_e2e.py` results:

| Variant | Tools | Checks | Notes |
|---|---|---|---|
| Standard Access with the collector, an existing collector store, then `--reuse-state` | 121 | 17 of 17 | Source added after its dialog; sync (captures from a local folder); export; supply of 4 recordings with matching hashes; REVLOG v2 note; statistics count 5, **mean 10.8**, **min 6.0**, max 12.0, unit V. |
| `--without-collector` | 108 | 14 of 14 | Upload in 48 KiB chunks with the `upload_transfer_id` note; same statistics. |
| `--without-collector --without-host-notes` | 108 | 14 of 14 | No note on the same upload. |
| Workspace `project_read,propose` with the collector, a new store, a file under `Équipe/` | 123 | 20 of 20 | `artifact.register` inside the workspace; a path outside it is `blocked`; same statistics. |

The longest full tool name is exactly 64 characters (`mcp__plugin_pitrelay_pr__pitrelay_report_package_submission_info`). The host checked its 32 files against `launch.json` at every start.

### With the ENGINE-FIXES-1 engine candidate

The engine fixes were later made in the PitRelay source (see [PITRELAY_ENGINE_ISSUES.md](PITRELAY_ENGINE_ISSUES.md)). Its candidate package `pitrelay-0.1.0-dev-20261024-engine-fixes-1` (manifest SHA-256 `e62f01a6…5723`, engine `a10fb14d…16f7`, the same license file) was prepared with this plugin:

| Check | Result |
|---|---|
| Preparation with the collector, then `verify --receipt-sha256 … --manifest-sha256 …` | **PASS** (81 files) |
| `mcp_e2e.py --posix-locale --collector-flow` | **17 of 17**, 121 tools, statistics mean 10.8 V / min 6.0. All four supplied recordings inspect `ok`, the REVLOG 2.0 file included; no host notes (inactive for this engine). |
| `--without-collector`, upload path | **14 of 14**, 108 tools, same statistics, no `upload_transfer_id` note |

The plugin's own tests that use the real engine are written for v11 (`PITRELAY_ENGINE_JAR` is the v11 jar); they were not run against the candidate.

## 2. Not run: prerequisites unavailable

| Item | Why |
|---|---|
| Windows and macOS | Not available here. This covers the Windows job object, launcher hashes and `Scripts` layout, `HKCU\…\Run` and LaunchAgent login items, process start times there, UNC paths, the code-page check, `renamex_np`/`os.rename` publication, keychain access and case-insensitive paths. |
| A real roboRIO or Systemcore, a real Driver Station, real REV or CTRE logs, a CTRE Owlet | Not available; synthetic files and a local SFTP server only. |
| Claude Code IDE extensions and the desktop app | Not available here. |
| Other PitRelay builds than v11 | Only v11 was supplied. |

## 3. Unverified (could have been attempted, but was not)

* **A live model session**: Claude choosing the tools, the skills triggering, `/pitrelay:start` and `/pitrelay:collect` end to end, and Claude Code's elicitation dialogs shown in the terminal. It would have needed this environment's own Claude credentials in a nested session, which was deliberately not done. Everything below the model was exercised: the installed plugin, its server connection, every tool through the exact launch command, and the dialogs answered by a test client.
* **Pre-approved tools** (`allowed-tools` in `/pitrelay:start` and `/pitrelay:collect`).

## Independent reviews

Two rounds of multi-agent review, each with one reviewer per area and an independent skeptic per finding who tried to refute it, reproducing where possible:

* **Round one** (host relay, collector tools, security and human control, generator, notes and documentation, collector core): 51 findings, 48 confirmed and fixed. The most important:
  * the model could make the host read any folder into a package (`source_project_dir`), or contact a robot it named, before the person agreed; both now need a dialog first, and nothing is touched before it;
  * adding an address to a robot could replace its trusted key, with trust pre-ticked; key trust is now its own dialog, never pre-ticked, with an explicit replace-or-add choice;
  * a dialog could be cut short, hiding what was being approved; long proposals are now refused instead;
  * a changed engine jar was refused once and then started anyway;
  * `verify` missed a wrapped launcher or a planted `.pth` in the collector's environment, and ran programs named by an unanchored receipt;
  * supplying a package inside a PitRelay workflow used up its call budget;
  * a Systemcore login written to the shared store stopped an older standalone collector from loading its config;
  * a REVLOG v2 note called a damaged file intact, and a zero-filled Driver Station file was routed to the wrong adapter.
* **Round two** (collector and security, host relay, generator, documentation against the code) checked those fixes and the code they changed: 28 findings, 27 confirmed and fixed, 1 refuted. The most important:
  * on Windows, every preparation with the collector would have failed its own self-check (bytecode paths compared case-folded on one side only);
  * the round-one fix for `source_project_dir` was inverted: a robot project inside the home folder was refused, a folder above it reached the dialog;
  * an encrypted private key made every collection cycle fail (paramiko 5 raises `TypeError`, and the keyword was renamed), and an unexpected error from one source stopped the sources after it;
  * `verify` accepted a script put in place of the recorded Python, or the same Java version from other bytes, as an update;
  * Java and a virtual environment's base Python were pinned by version-named paths that a routine update removes;
  * proposals could name a hidden folder (`~/.ssh`), a catch-all text pattern (`?*`), or a robot address in a disguised numeric form;
  * retention pruned a multi-part export part by part, and kept every export once Claude had written any observation;
  * the supply dialog still cut a long path short, and text from a package made elsewhere still reached Claude unescaped in one field;
  * the macOS process start time depended on the time zone, which could abort a live session's uploads;
  * documentation that promised more than the code does (cases kept across an access change, "nothing is deleted automatically", the shared store on upgrade).

The final runs on Python 3.10 found one more defect: Python 3.10 records the environment a virtual environment was made from as its `home`, and setup pinned a name in that other environment instead of the base interpreter. Setup now skips a folder that belongs to another environment, and a test covers it on every version.

Every confirmed finding is covered by a test, and the safeguards by `tools/mutants.py`.
