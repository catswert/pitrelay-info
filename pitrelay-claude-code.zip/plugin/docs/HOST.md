# The host: one local MCP server for Claude Code

The host is the `pr` MCP server of PitRelay for Claude Code. Claude Code starts it with the Python recorded at setup:

```text
<python> -I -B -X utf8 <output>/pitrelay/host/gateway.py
```

The path is the absolute path of the generated marketplace, not `${CLAUDE_PLUGIN_ROOT}`, because Claude Code may point that variable at its cached copy. `-I` keeps the user's environment and site folders out of the interpreter. `-B` keeps Python from writing caches into the verified plugin folder.

The host does three things:
1. It runs the **unmodified PitRelay engine** and relays its tools.
2. It adds **host notes** where a v11 answer is known to mislead.
3. With the collector, it runs **PitRelay Collector** in the same process and adds the `collector_*` tools.

Its configuration is `host/launch.json`, written by `configure_claude.py` and pinned in its receipt. The code is in `host/pitrelay_host/`:

| File | Role |
|---|---|
| `main.py` | Reads `launch.json`, moves the protocol to private descriptors, installs the signal handlers, starts the server |
| `relay.py` | The MCP server: protocol, engine queue, host tools, dialogs, `host_status` |
| `engine.py` | The engine process: command line, environment, line encoding |
| `compat.py` | Host notes for the v11 engine |
| `collector_tools.py` | PitRelay Collector in the host, and its 13 tools |

`host/collector.py` is the bundled collector's own command line, with the same commands as the standalone `pitrelay-collector`, defaulting to this installation's store. Background collection runs `collector.py run`.

## The engine

The host starts the engine on demand:

```text
<java> … -cp <plugin>/engine/pitrelay.jar org.pitrelay.Main --state <state>/engine --mode mcp [--workspace <folder> --grant …]
```

This is the same launch as PitRelay's Codex setup.
* **Environment.** Injection variables (`JAVA_TOOL_OPTIONS`, `_JAVA_OPTIONS`, `JDK_JAVA_OPTIONS`, `CLASSPATH`) are removed. On Linux, `LC_ALL=C.UTF-8` is pinned, after setup checked that this Java honors it.
* **Integrity.** The host checks the jar's SHA-256 against `launch.json` at start and again before every start of the engine, restarts included. A jar that differs, or cannot be read, is refused for the life of the host process: no engine is started, every engine call fails with the problem, and `host_status` reports it. At start, the host also checks its own files against the hashes in `launch.json`; `host_status` reports the result (`self_check`).
* **Logs.** Each host process writes the engine's stderr to its own `<state>/host/engine-stderr-<pid>.log`. Logs older than a week are removed.
* **Several sessions.** Each Claude Code session runs its own host and engine on the installation's state folder. The engine coordinates several processes on one state itself, with its own per-resource file locks; PitRelay's own Companion and local HTTP processes share a state the same way.
* **Restart.** If the engine stops, the next call starts it again, at most once every 10 seconds. If the first start of a session fails and no tool list is known yet, the host retries on its own, pausing 10, 20, 40, 80 and 160 seconds after each failed start, and `host_status` starts it too (or waits for a start that is running, and reports `starting` meanwhile); once it runs, the host sends `notifications/tools/list_changed`.
* **Windows.** The engine is placed in a job object, so it ends with the host. (UNVERIFIED: not run on Windows.)

## Protocol rules

The host was checked against Claude Code 2.1.309 and the v11 engine.

* **One writer.** stdout carries only JSON-RPC, one ASCII-escaped object per line. `main.py` moves the real stdin and stdout to private descriptors first. Children (the engine, a browser opened for the collector page) and stray prints then see stderr as stdout and an empty stdin.
* **Answered by the host at once:**
  * `initialize`: protocol `2025-06-18` (older versions are echoed), with the capability `tools.listChanged`. The instructions are the engine's own, plus a paragraph about host notes and the collector.
  * `ping`.
  * `tools/list`: the engine's tool list is cached in `<state>/host/engine-cache.json` (keyed by the jar's SHA-256 and the command line). A connection therefore never waits for Java. If the engine's live list differs, the host sends `notifications/tools/list_changed`.
  * unknown methods, such as Claude Code's `server/discover` probe: error `-32601`.
* **Engine queue.** Only `tools/call` for an engine tool reaches the engine. The engine handles one request at a time, so the host sends one at a time. Claude Code's own calls go before the host's background work (uploads by `collector_supply_to_engine`, reads for host notes).
* **Limits.**
  * A request over the engine's 1 MiB line limit is refused by the host with the caller's id (`REQUEST_TOO_LARGE`). The engine would answer it with an id it cannot correlate.
  * A result line over 15 MiB is replaced by an error (`RESULT_TOO_LARGE`), because Claude Code closes the connection on a line over 16 MiB.
  * Numbers that JSON cannot carry (NaN, infinities) become `null`.
* **The engine's own requests** are refused (`-32601`) and its notifications are dropped. The v11 engine sends neither.
* **Cancellation (`notifications/cancelled`).** A queued engine call is dropped. A running one finishes in the engine, and its answer is discarded, because the engine ignores cancellation. A host tool stops cooperatively and withdraws its open dialog.
* **Long calls** send `notifications/progress` at most every 10 seconds when the caller asked for progress. This keeps Claude Code's idle timer from expiring.
* **Shutdown.** Claude Code ends a stdio server with SIGINT, then SIGTERM after 100 ms, then SIGKILL after 500 ms. The host therefore stops without waiting:
  * it closes the engine's input, so the engine finishes its current request and exits;
  * it releases the collector store if this session was collecting;
  * then it exits.

  Nothing it holds needs an orderly exit: the collector store is crash-safe.
* **Interrupted uploads.** Each host process records the uploads it opened in its own `<state>/host/open-transfers-<pid>-<random>.json`, with its start time. An upload leaves the record only when the engine has closed it (finished, or aborted). Once its engine runs, a later host aborts the recorded uploads of host processes that are gone (pid not running, or running with another start time; start times are read on Linux, Windows and macOS, the last two UNVERIFIED) with `artifact.upload_abort`, and keeps any the engine did not close yet for the next time. A damaged record file never stops the cleanup of the others. When the engine itself stops, open uploads are kept in its state and can be continued with the same `transfer_id`.
* **Malformed messages.** A message the host cannot parse or handle is answered with a JSON-RPC error (`-32700`, `-32602` or `-32603`) and logged; the server keeps running.
* **Busy engine state.** An `upload_begin` that answers `blocked` `TRANSFER_BUSY` (another engine is admitting a transfer) is retried up to 8 times before the answer is relayed.
* **Tool names.** Claude Code names a plugin's tools `mcp__plugin_pitrelay_pr__<tool>`, and the model API allows 64 characters. A longer engine tool name would be listed under a deterministic shortened alias that names the original. v11 needs none; its longest name is exactly 64.

## Host notes

The engine's answers are relayed byte for byte: the text of every content item, the status and `isError` are unchanged. Where a v11 answer is known to mislead, `compat.py` appends a second text item:

```text
Host note (PitRelay for Claude Code, not the PitRelay engine; <rule>, engine issue <n>): …
```

A note is added only when all of these hold:
* the running engine is the inspected v11 build (by jar SHA-256);
* notes are on in `launch.json` (setup's `--without-host-notes` turns them off);
* the engine's own result shows the symptom;
* the host's check of the file confirms the cause.

The check reads the first 48 KiB of the artifact with the engine's own `artifact.download`, never with a `workflow_id`, so it changes no engine state. It runs on a worker thread.

| Rule | Engine issue | Added when | The note says |
|---|---|---|---|
| `revlog_v2` | 1 | A `rev_native` call answers `partial`, `no_match`, `not_applicable` or `unsupported`, and the artifact starts with a REVLOG v2 header record | v11 decodes REVLOG v1 only, so nothing was decoded and its unknown-record issues come from that; other issues may still be real damage; convert it to WPILOG with REV's tools |
| `ds_format` | 2 | A `dslog_v4` or `dsevents_v4` call answers one of those statuses, and the file's records clearly have the other format's structure (records that are all zeros never count) | The format to use |
| `upload_transfer_id` | 3 | `artifact.upload_begin` succeeds | Pass `result.id` as `transfer_id` |

What is deliberately not changed is listed in `host_status` (`compatibility.not_changed`) and in [PITRELAY_ENGINE_ISSUES.md](PITRELAY_ENGINE_ISSUES.md):
* the CSV time-unit status;
* `readOnlyHint`;
* several engines on one state.

## The collector in the host

`collector_tools.py` runs the same code as the standalone PitRelay Collector (`pitrelay_collector`, copied into `host/` at setup), in the host process. Its dependencies (`paramiko`, `keyring`) are in a private virtual environment in the state folder; the host runs on that environment's Python.

**The store** is the one named at setup (by default the standalone collector's store), outside the plugin and the state folder. One process at a time owns a store, through the collector's own lock:
* **Owner.** Normally the first Claude Code session. It collects while automatic collection is on.
* **Readers.** A second session, or every session while the background collector owns the store. A reader still reads status and captures, exports and supplies packages. Its settings changes are written to the store's files and picked up by the owner on its next cycle. Its "sync now" and pause/resume are requests the owner carries out.
* **Takeover.** The host first collects 15 seconds after Claude Code finished connecting, so a session that only connects briefly (`claude mcp list`) never collects. A reader then checks every 45 seconds whether the store became free, and takes over.

**Dialogs.** The host asks the person through Claude Code's MCP dialog (`elicitation/create`) before:
* adding a source, or widening what a source reads (folders, hosts, users, login, file kinds);
* trusting a robot's SSH host key. After the person allows a robot source, the host reads the robot's key (the SSH key exchange, no login) and shows it in a second dialog. When keys are already trusted, the person must choose between replacing them (re-imaged robot) and adding the new one (another robot of the team); nothing is pre-ticked;
* turning background collection on;
* including a robot project's source code in a package;
* supplying a ZIP from outside the store's exports;
* deleting captures (each one named; at most 25 per call).

Nothing the model proposed is contacted or opened before the person agrees. A proposal is first checked by its text alone, and refused when it names:
* a relative path, a network share or device path, a filesystem root, the home folder or a folder above it, a hidden folder, or the collector store (and, for robot source code, the PitRelay state);
* a robot address written in a form that hides the machine it reaches (octal, hex or integer, such as `010.012.034.002`);
* a text-file pattern that matches almost any file (`**`, `?*`) or keys and credential files (`id_*`, `*.pem`, `*.json`).

The files, folders and robots are touched only afterwards. Whatever a text pattern says, the collector never collects hidden files or files named like keys or credentials with it. These stricter rules apply to what Claude proposes; a configuration the person saved, or one an older collector wrote, keeps loading as before.

The answer is `accept`, `decline` or `cancel`, and only `accept` with the confirmation box ticked (and any required choice made) changes anything. The dialog is answered by the person, or by a hook or SDK program they configured, never by the model. Values from the model, robots and files are escaped (control, line-break and bidirectional characters) before they are shown. A dialog is never cut short: a proposal is bounded (at most 8 folders, 4 addresses and 10 text-file patterns of 200 characters each), and a message that would still be too long is refused. A client without dialogs gets an error that points to `collector_open_page`.

**Things that never pass through the conversation:**
* passwords and key passphrases (entered on the collector's page, kept in the OS credential store);
* the collector page's private link (`collector_open_page` opens it in the person's browser);
* the log bytes (`collector_supply_to_engine` streams them to the engine directly).

**Supplying a package** (`collector_supply_to_engine`):
1. Verify every hash in the package.
2. Check that the disk keeps at least 1 GiB free after the engine stores the recordings.
3. For each recording (up to 25 per call), upload it in 48 KiB chunks through the engine queue, then call `log.inspect` with the format the collector identified. The engine's answer is returned with the recording's acquisition status, gaps and limitations, plus any host notes.
   An upload that fails midway is aborted. One recording's failure is reported on its row and the others are kept.
4. With a `workflow_id`, the inspections are made in that PitRelay workflow. The uploads are not: the engine counts every upload call against a workflow's budget, so a match log would use it up.
5. Text from the manifest (labels, reasons, limitations) is escaped and bounded. For a package from outside the store it is untrusted text: verification covers the files' hashes, not that text.

**Background collection** (`collector_background`) starts `host/collector.py run` from the generated marketplace with the private Python, as a separate process. It also registers a per-user login item that starts the same command at every login: a value under `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` on Windows, a LaunchAgent on macOS, an XDG autostart entry on Linux. (Windows and macOS: UNVERIFIED.) It owns the store while it runs, and every Claude Code session works as a reader.
* `on` reports it as running only once that process holds the store. If another process collects with the store already, nothing is started next to it; the login item starts it at the next login.
* `off` removes the login item and stops the collector only if it is this plugin's background collector (`ident` `claude` in the store's `ui.json`). A standalone collector or another Claude Code session is left running.

**Exports** go to `<store>/exports/claude/`. The five newest packages are kept, plus every package that holds observations or source code (the store has no other copy of them) and any package a running supply reads; older ones are removed when a new export finishes.
