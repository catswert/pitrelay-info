# PitRelay v11 engine: issues, suggested engine fixes, and what this project does about them

**Scope:** `pitrelay-0.1.0-dev-20261006-v11` local package. Its `engine/pitrelay.jar` has SHA-256 `66de12d3968b0c7e360754fabb6db4661416b61129b3b2751bf19952c93ac5d2`, and all 35 package files matched `package-manifest.json`. The engine ran through `--mode cli` and `--mode mcp` with OpenJDK 21 on Linux, in Standard and Workspace Access, using fresh private state folders.

Every observation below is from **synthetic inputs**; no real robot, REV or Driver Station log was available. The re-checks of 2026-10-23 use `tests/test_host.py`, `tests/test_collector_tools.py` and the probes described there.

## What "fixed" means here

The v11 package contains only the compiled engine, not its source, and it is a frozen release. The jar is therefore never changed: patching or decompiling it would make an untraceable build, contrary to the release's integrity model.

**Real fixes belong in the engine's source.** Each section ends with a suggested change, and those changes would fix the problem in every PitRelay client (Codex, ChatGPT, Claude Code).

**PitRelay for Claude Code works around** the problems at the host layer, between Claude Code and the unmodified engine:
* The engine's answers are relayed **byte for byte**, status and `isError` included.
* Where a v11 answer is known to mislead, the host appends a second, separately labelled text item: `Host note (PitRelay for Claude Code, not the PitRelay engine; <rule>, engine issue <n>): ...`.
* The notes are active only for the jar above (by SHA-256). They can be switched off at setup with `--without-host-notes`.
* `host_status` lists the active notes.

## Fixed in the engine source (ENGINE-FIXES-1 candidate)

The PitRelay source for v11 (commit `572e1dc`) was later made available, and the issues below were fixed there on a local branch: an unreleased candidate, built and tested with synthetic files only. Each section below says what changed. The host notes stay tied to the v11 jar's SHA-256, so they switch off by themselves for a fixed engine, which no longer needs them.

| Issue | In the fixed engine |
|---|---|
| 1. REVLOG v2 | Decoded: SPARK status fields per bus, robot state, match info, logger events, dropped-frame counts. Other REVLOG versions answer `unsupported REV_VERSION`. |
| 2. Wrong DS adapter | `not_applicable` (`DS_DSLOG_CONTENT` / `DS_DSEVENTS_CONTENT`) naming the right adapter. All-zero DS records are now damage instead of 0 V cycles. |
| 3. Transfer id names | `upload_begin` also returns `transfer_id`. |
| 4. CSV time unit | A malformed unit answers `error`; `ns`, `min` and `h` stay `unsupported`. |
| 6. Upload chunks and the workflow budget | Begin, chunk and abort are not workflow calls; finish is the one recorded call; abort is never refused. |

## 1. REVLOG v2 is not decoded (medium; matters for 2027-season logs)

* **Observed.** `log.inspect` with `format: rev_native` on a REVLOG v2 file answers `status: partial`, `complete: false`, `channel_count: 0`. Its issues are `Unknown REV native record ID 3` (offset 0) and `Unknown REV native record ID 6`. `signal.*` answers `no_match` (`NATIVE_SIGNAL`, "Requested native channel is absent"). Nothing is decoded.
* **Expected.** REV's own converter (`@rev-robotics/revlog-converter` 2.0.0, BSD-3) defines these v2 record IDs: 3 (header: `REVLOG` + major + minor), 4 (bus table), 5 (firmware), 6 (frames), 7 (robot state), 8 (match info), 9 (logger events) and 10 (diagnostics). REVLib releases after 2027.0.0-alpha-8 write v2; v1 covers REVLib 2025 through 2027.0.0-alpha-8.
* **Suggested engine fix.** Decode the 2.0.0 record set. Or, until that exists, refuse v2 with an explicit code (for example `unsupported`, "REVLOG v2 is not supported by this build") instead of a `partial` result that reads like a damaged file.
* **What this project does.**
  * **Note.** The host adds a `revlog_v2` note to any `rev_native` result with status `partial`, `no_match`, `not_applicable` or `unsupported` when the artifact begins with a REVLOG v2 header record. The note says that nothing was decoded, so the "Unknown REV native record ID" issues come from the missing v2 support, while other issues the engine lists (a truncated tail, unknown header flags) may still describe real damage. It suggests converting to WPILOG with REV's tools. It reads the first bytes with the engine's own `artifact.download`, which changes no engine state when called without a `workflow_id`.
  * **Collector manifest.** The collector marks v2 files with this limitation, and their route is not marked as verified.
* **In the fixed source (ENGINE-FIXES-1).** REVLOG 2.x is decoded per REV's converter 2.0.0 layouts (read as a reference). Unlike that converter, nothing is skipped or zero-padded silently: frames whose length differs from the DBC message, other manufacturers' frames and unknown records are issues.

## 2. The wrong Driver Station adapter describes a good file as damaged (low to medium)

* **Observed.** `.dslog` and `.dsevents` v4 share the same 20-byte header, so either adapter accepts either file:
  * **dslog read with `dsevents_v4`:** `partial`. Issues include `corrupt` ("DS event relative time exceeds signed microseconds") and `truncated_tail` ("DS event text extends beyond input"). With power-distribution type 25 there were 300 `corrupt` issues for 300 records.
  * **dsevents read with `dslog_v4`:** `partial`, with "Unknown DS power-distribution block type 110". It reports `channel_count: 16` from one record, and `log.entries` lists 16 channels that do not exist.
  * **No wrong numbers.** In the cases tried, `signal.statistics` did not return wrong values: it answered `no_match`.
* **Why it matters.** "Partial / truncated / corrupt" suggests data loss in a good file. CONTRACTS.md asks that `not_applicable` and `unsupported` not be disguised as other states.
* **Suggested engine fix.** Validate the record structure before decoding:
  * dsevents: event timestamps near the header time, bounded lengths, readable text;
  * dslog: one consistent power-distribution type and record size.

  Answer a clear "content does not match dsevents_v4" (`not_applicable`) instead of decoding.
* **What this project does.**
  * **Note.** On a `partial`, `no_match`, `not_applicable` or `unsupported` result from a call with `format`/`other_format` `dslog_v4` or `dsevents_v4`, the host checks the artifact's first bytes. If the records clearly have the other structure, a `ds_format` note names the format to use. Records that are all zeros (a file cut short by a power loss) are damage, not evidence of either format, and get no note. The check is `pitrelay_collector.formats.ds_content_format`, the same code the collector uses.
  * **Collector routing.** The collector routes each Driver Station file by its record structure, not its extension, so a dsevents named `.dslog` is supplied with `dsevents_v4`. It records the contradiction in the manifest.
* **In the fixed source (ENGINE-FIXES-1).** Each adapter answers `not_applicable` (`DS_DSLOG_CONTENT` / `DS_DSEVENTS_CONTENT`) when the first records clearly have the other format's structure, and decodes as before otherwise. All-zero records are reported as damage (`truncated_tail` to the end of the file, else `corrupt`), so they no longer become 0 V cycles with every flag set.

## 3. The transfer id has two names (low)

* **Observed.** `artifact.upload_begin` returns the transfer id as `result.id`; `upload_chunk` and `upload_finish` take, and `upload_chunk` echoes, `transfer_id`.
* **Suggested engine fix.** Also return `transfer_id` from `upload_begin`. **Done in the fixed source.**
* **What this project does.** The host adds an `upload_transfer_id` note to a successful `upload_begin` that says to pass `result.id` as `transfer_id`. The engine's result itself is not changed. The collector's own uploads accept either name.

## 4. Status of an invalid CSV time unit (low)

* **Observed.** `log.import_csv` with `time_unit` other than `us`, `ms` or `s` answers `unsupported` with code `CSV_TIME_UNIT` ("CSV time unit must be us, ms or s"). That covers a typo such as `bogus` and real units such as `ns` or `sec` alike. An invalid `sampling_policy` answers `error` (`SAMPLING_POLICY`); valid ones include `periodic`, `event` and `unknown`. `clock` accepts any string.
* **Assessment.** For a real unit the engine does not implement (`ns`), `unsupported` is correct under CONTRACTS.md §1. Only a malformed value would be an `error`, and the engine's message is already actionable.
* **Suggested engine fix (optional), done in the fixed source.** Separate the two cases (`error` for a malformed value, `unsupported` for a recognized but unimplemented unit). Document a `clock` vocabulary, or record `clock` explicitly as a user assertion.
* **What this project does.** Nothing to the result. The skills tell Claude that the valid units are `us`, `ms` and `s`, and that every CSV mapping is confirmed by the person.

## 5. Documentation notes (informational)

* The project pack's `DESIGN.md` has no "automatic log collection" section, and `docs/ACCESS_MODEL.md` is in neither the pack nor the v11 package. The brief for the collector referenced both.
* A WPILOG entry's unit is read from the `unit` metadata key; `units` is ignored. This is reasonable but undocumented in the operation help (`log.entries`). The host skill mentions it.
* **Artifact ids are deterministic, but not addressed by content alone.** The same bytes uploaded with the same file name and kind get the same id. A different file name or kind gives a different id. Artifacts are immutable either way.

## 6. Items found while preparing the Claude Code plugin (low)

* **Tool-name length.**
  * **Problem.** Claude Code exposes a plugin's MCP tools as `mcp__plugin_<plugin>_<server>__<tool>` and does not shorten the result, while the model API limits tool names to 64 characters. With the server key `pr`, the longest v11 name is exactly 64 (`mcp__plugin_pitrelay_pr__pitrelay_report_package_submission_info`).
  * **Suggestion.** Keep engine tool names at 39 characters or fewer, or offer shorter aliases.
  * **What this project does.** Independently of the engine build, the host lists any longer name under a deterministic shortened alias (which names the original) and routes calls to the original. v11 needs no alias.
* **Annotations.**
  * **Observed.** Every tool except `workflow.status` reports `readOnlyHint: false`, including pure reads such as `capability.list` and `help`. The engine's own `pitrelay/annotationReason` says why: any call may record workflow admission or evidence. `signal.statistics`, for example, writes evidence artifacts even without a workflow.
  * **What this project does.** Nothing: the hints are relayed unchanged.
* **Several engine processes on one state.** *(Corrected; an earlier version of this document said nothing coordinates them.)*
  * **Observed.** Two engines started on the same `--state` both run. The engine coordinates them with its own per-resource file locks: cases, transfers, recovery and workflow sessions. In probes, concurrent case operations from two engines all succeeded and were visible to both. An `upload_begin` that races another engine's admission answers `blocked`, code `TRANSFER_BUSY` ("Another process is admitting a transfer"), and admits nothing. PitRelay's own Companion and local HTTP processes are documented to share a state the same way.
  * **What this project does.** Each Claude Code session runs its own engine on the installation's state folder. The host retries a `TRANSFER_BUSY` `upload_begin` a few times before relaying the answer. It records the transfers it opened, so the next session can abort them (`artifact.upload_abort`) if Claude Code ended the session mid-upload.

* **Upload chunks count against a workflow's call budget.**
  * **Observed.** Every `artifact.upload_begin`, `upload_chunk`, `upload_finish` and `upload_abort` made with a `workflow_id` counts as one workflow call. With 48 KiB chunks, a checkup's default budget of 80 calls covers about 3.8 MB, so an ordinary match log used up the whole budget partway through its upload, and the abort was then refused too. An artifact uploaded without a `workflow_id` can be inspected inside the workflow for one call.
  * **Suggestion.** Count an upload as one call, or exempt transfer operations from the budget.
  * **What this project does.** `collector_supply_to_engine` uploads outside the workflow and makes only the inspections in it.
  * **In the fixed source.** Begin, chunk and abort carrying `workflow_id` are not workflow calls (`result.workflow.admission` is `not_admitted`); `upload_finish` is the upload's one recorded call; an abort is never refused for workflow state.

## Confirmed working (same build)

* WPILOG auto-detection, and `integrity: truncated_tail` with an exact byte offset for a cut final record.
* `dslog_v4` and `dsevents_v4` on matching v4 files.
* `log.import_csv` with explicit mappings, and `signal.statistics` on `$derived`.
* The voltage oracle via `signal.statistics`: count 5, mean 10.8, min 6.0, max 12.0, `[start_us, end_us)`. This was checked directly, through the host relay, and through the collector's `collector_supply_to_engine`.
* `artifact.download` of a bounded head (no state change without a `workflow_id`).
* Workspace Access with `project_read`: `artifact.register` with a path relative to the workspace captures a file with the same SHA-256 as the collector's manifest. A path outside the workspace returns `blocked`.
