# Notice

This repository contains no PitRelay files: no engine, skills, documentation or setup scripts. Everything PitRelay-specific in a prepared plugin is copied, at setup time, from a PitRelay package the user supplies. That includes the Workspace Access disclosure, which is read from the package rather than stored here. The PitRelay engine is never modified, decompiled or patched.

It is nevertheless derived from PitRelay:
* `configure_claude.py` follows the approach and checks of PitRelay's own `setup/configure_local.py` and `setup/package_local.py`: manifest anchoring, inventory and hash checks, the launcher preflight, no-replace publication and receipts.
* The host (`host/`) starts the engine the way PitRelay's Codex setup does, relays its MCP tools, and its host notes describe the behavior of the v11 engine.
* The overlay skills and commands describe PitRelay's operations and refer to its skills.
* PitRelay Collector (`collector/`) produces packages for PitRelay and supplies them to its engine.

The PitRelay license (`docs/release/PITRELAY_LICENSE.md` in the package) governs PitRelay's material and restricts redistributing it. Whether this repository may be shared beyond a team is therefore the PitRelay licensor's decision. Until the licensor decides, keep it private to the team, like PitRelay itself.

The collector and the host contain no code copied from WPILib, AdvantageScope, REV or CTRE. Their published formats and documentation were read to implement compatible, read-only parsing. They are cited in `collector/docs/ROBOT_SETUP.md` and `docs/PITRELAY_ENGINE_ISSUES.md`.

A prepared plugin installs two third-party Python packages from PyPI or a wheelhouse into its own virtual environment: `paramiko` (LGPL-2.1) and `keyring` (MIT), with their dependencies. They are not part of this repository.

No license has been chosen for this repository's own code.
