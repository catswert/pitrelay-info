"""Entry point Claude Code starts (see the plugin's .mcp.json): python -I -B -X utf8 <plugin>/host/gateway.py

-I keeps the user's environment and site folders out of this interpreter; the host's own folder is added to
the import path explicitly below. -B keeps Python from writing caches into the verified plugin folder.
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from pitrelay_host.main import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main(HERE))
