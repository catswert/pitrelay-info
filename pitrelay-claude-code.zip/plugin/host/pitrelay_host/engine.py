"""The unmodified PitRelay engine as a child process that speaks MCP over stdio.

The host builds the engine's command line and environment itself, from launch.json written at setup:
* Java option injection variables (JAVA_TOOL_OPTIONS, JDK_JAVA_OPTIONS, _JAVA_OPTIONS, CLASSPATH) are removed,
  not just blanked, so nothing inherited from Claude Code's environment can alter the engine JVM;
* on Linux a UTF-8 locale checked at setup is pinned, so non-ASCII file names work under a POSIX locale;
* the engine runs in its private state folder, whatever folder Claude Code was started in.

This module only moves messages. Request ids, routing and the compatibility layer live in relay.py.
"""

from __future__ import annotations

import json
import os
import subprocess
import threading
from pathlib import Path

INJECTION_VARIABLES = ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "CLASSPATH")
STDERR_KEEP_BYTES = 1024 * 1024
MAX_LINE_BYTES = 64 * 1024 * 1024


class EngineUnavailable(RuntimeError):
    pass


def encode(msg: dict) -> bytes:
    """One JSON-RPC line. ASCII escapes keep lone surrogates and any character safe on the wire; NaN and Infinity
    (not JSON) become null."""
    try:
        text = json.dumps(msg, ensure_ascii=True, separators=(",", ":"), allow_nan=False)
    except ValueError:
        text = json.dumps(_finite(msg), ensure_ascii=True, separators=(",", ":"), allow_nan=False)
    return (text + "\n").encode("ascii")


def _finite(value):
    if isinstance(value, float) and (value != value or value in (float("inf"), float("-inf"))):
        return None
    if isinstance(value, dict):
        return {k: _finite(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_finite(v) for v in value]
    return value


def engine_argv(launch: dict, plugin_root: Path) -> list[str]:
    """The engine command line (the same as PitRelay's own setup/configure_local.py writes)."""
    root = Path(launch["state"])
    args = [launch["java"], "-Xmx384m", f"-Duser.home={root / 'jvm-home'}", f"-Djava.io.tmpdir={root / 'tmp'}",
            "-cp", str(plugin_root / "engine" / "pitrelay.jar"), "org.pitrelay.Main",
            "--state", str(root / "engine"), "--mode", "mcp"]
    if launch.get("workspace"):
        args += ["--experience", "workspace", "--workspace", launch["workspace"],
                 "--grants", ",".join(launch["workspace_grants"]), "--workspace-disclosure", "accepted-v1"]
    return args


def engine_env(launch: dict, base: dict | None = None) -> dict:
    env = {k: v for k, v in (os.environ if base is None else base).items() if k.upper() not in INJECTION_VARIABLES}
    if launch.get("lc_all"):
        env["LC_ALL"] = launch["lc_all"]
    return env


def _kill_with_host(proc: subprocess.Popen):  # pragma: no cover - Windows only, UNVERIFIED
    """Windows: put the engine in a job object that ends it when the host's handle closes (the host dies)."""
    import ctypes
    from ctypes import wintypes

    class _Basic(ctypes.Structure):
        _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                    ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                    ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                    ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]

    class _Extended(ctypes.Structure):
        _fields_ = [("BasicLimitInformation", _Basic), ("IoInfo", ctypes.c_ulonglong * 6),
                    ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                    ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateJobObjectW.restype = wintypes.HANDLE
    job = k32.CreateJobObjectW(None, None)
    info = _Extended()
    info.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    k32.SetInformationJobObject(wintypes.HANDLE(job), 9, ctypes.byref(info), ctypes.sizeof(info))
    k32.AssignProcessToJobObject(wintypes.HANDLE(job), wintypes.HANDLE(int(proc._handle)))
    return job  # kept open for the host's lifetime


class EngineProcess:
    """One engine child. `on_message(dict)` is called on the reader thread for every message; `on_exit()` once.

    When the host ends (Claude Code ends it within half a second), the engine reads end-of-input, finishes its
    current request and exits. On Windows a job object also ends it with the host.
    """

    def __init__(self, argv: list[str], env: dict, cwd: Path, stderr_path: Path, on_message, on_exit):
        self.argv, self.env, self.cwd, self.stderr_path = argv, env, Path(cwd), Path(stderr_path)
        self._on_message, self._on_exit = on_message, on_exit
        self._wlock = threading.Lock()
        self.proc: subprocess.Popen | None = None
        self.exit_code: int | None = None
        self._job = None

    def start(self) -> "EngineProcess":
        try:
            self.stderr_path.parent.mkdir(parents=True, exist_ok=True)
            if self.stderr_path.stat().st_size > STDERR_KEEP_BYTES:
                os.replace(self.stderr_path, self.stderr_path.with_suffix(".1.log"))
        except OSError:  # missing, or (Windows) still open elsewhere: keep appending
            pass
        with open(self.stderr_path, "ab") as err:
            try:
                self.proc = subprocess.Popen(self.argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err,
                                             cwd=self.cwd, env=self.env, shell=False)
            except OSError as e:
                raise EngineUnavailable(f"Could not start the PitRelay engine ({e.__class__.__name__}: {e})") from None
        if os.name == "nt":  # pragma: no cover
            try:
                self._job = _kill_with_host(self.proc)
            except Exception:
                self._job = None
        threading.Thread(target=self._read, name="pitrelay-engine-reader", daemon=True).start()
        return self

    def _read(self) -> None:
        try:
            for raw in self.proc.stdout:
                if len(raw) > MAX_LINE_BYTES:
                    continue
                try:
                    msg = json.loads(raw)
                except ValueError:
                    continue  # the engine writes only JSON-RPC to stdout; anything else is not a message
                if isinstance(msg, dict):
                    self._on_message(msg)
        except (OSError, ValueError):
            pass
        finally:
            try:
                self.exit_code = self.proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                self.exit_code = None
            self._on_exit()

    def send(self, msg: dict) -> None:
        self.send_bytes(encode(msg))

    def send_bytes(self, data: bytes) -> None:
        with self._wlock:
            if self.proc is None or self.proc.poll() is not None:
                raise EngineUnavailable("The PitRelay engine is not running")
            try:
                self.proc.stdin.write(data)
                self.proc.stdin.flush()
            except (BrokenPipeError, OSError, ValueError):
                raise EngineUnavailable("The PitRelay engine stopped while a request was being sent") from None

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def close_input(self) -> None:
        """End-of-input: the engine finishes its current request, then exits."""
        p = self.proc
        if p is None:
            return
        with self._wlock:
            try:
                p.stdin.close()
            except OSError:
                pass

    def stop(self, timeout: float = 15.0) -> None:
        p = self.proc
        if p is None:
            return
        self.close_input()
        try:
            p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            p.kill()
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass

    def stderr_tail(self, max_bytes: int = 2048) -> str:
        try:
            with open(self.stderr_path, "rb") as f:
                f.seek(max(0, f.seek(0, os.SEEK_END) - max_bytes))
                return f.read().decode("utf-8", "replace")
        except OSError:
            return ""
