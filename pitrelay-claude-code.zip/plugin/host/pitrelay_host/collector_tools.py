"""PitRelay Collector inside the host: collect, export and supply logs from Claude Code.

The collector is the same code as the standalone PitRelay Collector (pitrelay_collector, shipped in host/), run
in this process. Its store is the one named at setup (by default the standalone PitRelay Collector's store), outside
the plugin and the state folder. One process at a time owns a store (the collector's own lock): normally this
Claude Code session, while it is open. If another process owns it (a
second Claude Code session, or the background collector started at login), this session works as a reader:
status, captures, exports and supplying packages to the engine still work, and settings are changed through the
store's files, which the owner picks up on its next cycle.

The person, not the model, decides what may be read and from which robot: adding or widening a source, trusting
a robot's SSH host key and deleting captures are confirmed in Claude Code's dialog (MCP elicitation), which the
model cannot answer. Passwords never pass through tools; collector_open_page opens the collector's local page.
"""

from __future__ import annotations

import base64
import json
import os
import shutil
import sys
import threading
import time
import uuid
import zipfile
from pathlib import Path

from .relay import CallContext, HostTool, NoElicitation, text_result

WAIT_S = 40.0
FAILOVER_CHECK_S = 45.0
MIN_FREE_AFTER_SUPPLY = 1024 * 1024 * 1024
KEEP_PACKAGES = 5
KEY_PREVIEW_TIMEOUT_S = 4.0
BUSY_RETRIES = 8
RESUME_GRACE_S = 15.0
UPLOAD_CHUNK = 49152
MAX_LIST = 200
DEFAULT_LIST = 50
SUPPLY_LIMIT = 25  # recordings per supply call; the rest are listed for a follow-up call
DIALOG_LIMIT = 3500  # characters; a dialog is never cut short: a longer proposal is refused instead
# Bounds on one source proposal, so its whole scope always fits in the dialog that confirms it.
MAX_DIRECTORIES, MAX_HOSTS, MAX_PATTERNS, MAX_ITEM_CHARS = 8, 4, 10, 200
MAX_DELETE = 25  # captures per deletion dialog, each listed by name
BACKGROUND_PREVIOUS = "background_previous_collection_enabled"  # store meta: the setting before background collection


class ToolError(Exception):
    def __init__(self, code: str, message: str, **details):
        super().__init__(message)
        self.code, self.message, self.details = code, message, details


def ok(payload: dict) -> dict:
    return text_result(payload)


def fail(code: str, message: str, **details) -> dict:
    return text_result({"status": "error", "error": {"code": code, "message": message, **details}}, True)


def _schema(properties: dict, required: list[str] | None = None) -> dict:
    return {"type": "object", "properties": properties, "required": required or [], "additionalProperties": False}


def _ann(read_only: bool, destructive: bool = False, open_world: bool = False) -> dict:
    return {"readOnlyHint": read_only, "destructiveHint": destructive, "openWorldHint": open_world}


SOURCE_PROPS = {
    "id": {"type": "string", "description": "Existing source id to change; omit to add a new source"},
    "alias": {"type": "string", "description": "Short name, e.g. 'robot' or 'ds-laptop'"},
    "kind": {"type": "string", "enum": ["sftp", "local"], "description": "sftp: a robot or coprocessor over SSH/SFTP; "
             "local: a folder on this computer (e.g. the Driver Station's log folder)"},
    "role": {"type": "string", "enum": ["robot", "coprocessor", "driver_station", "vendor_tool", "other"]},
    "directories": {"type": "array", "items": {"type": "string"},
                    "description": "Log folders: absolute remote POSIX paths for sftp (e.g. /home/lvuser/logs, /u/logs), "
                                   "absolute local paths for local"},
    "hosts": {"type": "array", "items": {"type": "string"},
              "description": "sftp: robot addresses tried in order, e.g. 172.22.11.2 (USB), 10.TE.AM.2, roborio-TEAM-frc.local"},
    "port": {"type": "integer", "minimum": 1, "maximum": 65535},
    "username": {"type": "string", "description": "sftp: 'lvuser' for a roboRIO, 'systemcore' for Systemcore"},
    "auth": {"type": "string", "enum": ["blank_password", "systemcore_default", "password", "key"],
             "description": "blank_password for a roboRIO's lvuser; systemcore_default for Systemcore's documented "
                            "login; password: the person enters it in collector_open_page"},
    "key_file": {"type": "string", "description": "auth=key: path of the private key file"},
    "enabled": {"type": "boolean"},
    "poll_interval_s": {"type": "number", "minimum": 5, "maximum": 3600},
    "recursive_depth": {"type": "integer", "minimum": 0, "maximum": 5},
    "include_csv": {"type": "boolean", "description": "Also collect .csv files"},
    "text_patterns": {"type": "array", "items": {"type": "string"},
                      "description": "Specific diagnostic text files to collect by name pattern, e.g. FRC_UserProgram.log"},
}


class Job:
    def __init__(self, kind: str):
        self.id = f"{kind}-{uuid.uuid4().hex[:10]}"
        self.kind = kind
        self.state = "running"
        self.result: dict | None = None
        self.progress = "starting"
        self.started = time.time()
        self.finished: float | None = None
        self.done = threading.Event()

    def view(self) -> dict:
        out = {"job_id": self.id, "kind": self.kind, "state": self.state,
               "elapsed_s": round((self.finished or time.time()) - self.started, 1)}
        if self.state == "running":
            out["progress"] = self.progress
            out["next"] = f"Call collector_job_status with job_id {self.id} to wait for the result."
        else:
            out.update(self.result or {})
        return out


class CollectorHost:
    def __init__(self, server, launch: dict):
        self.server = server
        self.launch = launch
        self.root = Path(launch["collector_store"])
        # The bundled collector's own command line (status, open-ui, run in the background) for the person's terminal.
        self.cli_script = Path(server.plugin_root) / "host" / "collector.py"
        self.cli_command = [sys.executable, "-I", "-B", "-X", "utf8", str(self.cli_script)]
        self.app = None
        self._lock = threading.RLock()
        self.jobs: dict[str, Job] = {}
        self._in_use: set[Path] = set()  # packages a running supply job reads (never pruned meanwhile)
        self.import_error: str | None = None
        try:
            from pitrelay_collector import app as _app, config as _config, export as _export, handoff as _handoff, \
                lock as _lock_mod, package as _package, projectscan as _projectscan, status as _status, store as _store, \
                util as _util
            from pitrelay_collector.autostart import Autostart
            self.m = {"app": _app, "config": _config, "export": _export, "handoff": _handoff, "lock": _lock_mod,
                      "package": _package, "projectscan": _projectscan, "status": _status, "store": _store,
                      "util": _util}
            self.autostart = Autostart(python=sys.executable, script=str(self.cli_script), ident="claude")
        except ImportError as e:  # the collector's Python dependencies are missing from this interpreter
            self.import_error = f"{e.__class__.__name__}: {e}"
        self._stop = threading.Event()
        server.shutdown_hooks.append(self.shutdown)
        server.status_hooks.append(self.status_hook)
        if self.import_error is None:
            server.initialized_hooks.append(self._schedule_resume)

    def _schedule_resume(self) -> None:
        # Health checks (`claude mcp list`) start the server and end it within seconds; only a session that stays
        # resumes collection, so a short-lived start never takes the store from anyone. After that, a session that is
        # only reading takes over collection when the collecting process ends (another session closed).
        def loop():
            if self._stop.wait(RESUME_GRACE_S):
                return
            while not self._stop.is_set():
                self._resume_if_enabled()
                if self._stop.wait(FAILOVER_CHECK_S):
                    return
        threading.Thread(target=loop, name="pitrelay-collector-failover", daemon=True).start()

    # --- ownership ---

    def _resume_if_enabled(self) -> None:
        """Collection the person left on resumes when Claude Code starts (if no other process collects)."""
        if self.app is not None:
            return
        try:
            cm = self.m["config"].ConfigManager(self.root)
            if cm.path.exists() and cm.load().collection_enabled and not self.m["lock"].StoreLock(self.root).is_held_elsewhere():
                self.owner()
        except Exception:
            pass

    def owner(self):
        """This session's running collector, taking ownership of the store if no other process holds it."""
        with self._lock:
            if self.app is not None:
                return self.app
            if self.server.engine.status == "stopped":
                return None
            from pitrelay_collector.secrets import KeyringSecrets
            self.m["app"].setup_logging(self.root, console=False)
            app = self.m["app"].App(self.root, secrets=KeyringSecrets(), autostart=self.autostart, ident="claude-session")
            try:
                app.open()
            except self.m["lock"].StoreLocked:
                return None
            app.start(ui=False)
            self.app = app
            for folder in (self.internal_exports, self.root / "exports"):
                self.m["export"].sweep_interrupted(app.store, folder)
            return app

    def holder(self) -> dict | None:
        return self.m["lock"].StoreLock(self.root).read_holder()

    def config(self):
        return self.app.config if self.app is not None else self.m["config"].ConfigManager(self.root)

    def reader(self):
        store = self.m["store"].Store(self.root)
        try:
            return store.open_reader()
        except self.m["store"].StoreError:
            # No store yet: create it (collection stays off) so a reader view has something to read.
            self.m["store"].Store.create(self.root)
            cm = self.m["config"].ConfigManager(self.root)
            if not cm.path.exists():
                cm.save(cm.load())
            return self.m["store"].Store(self.root).open_reader()

    def shutdown(self) -> None:
        """Fast: Claude Code ends the host within half a second. The store is crash-safe, so stopping the collector
        thread at its next check is enough; an interrupted transfer resumes from committed bytes next time."""
        self._stop.set()
        app = self.app
        if app is None:
            return
        col = app.collector
        col.stop_event.set()
        col._halt.set()
        col.wake()
        if app.ui is not None:
            threading.Thread(target=app.ui.stop, daemon=True).start()
            try:  # the page ends with this session: a later open-ui or background stop must not find it
                info = json.loads(app.ui_file.read_text(encoding="utf-8"))
                if info.get("pid") == os.getpid():
                    app.ui_file.unlink()
            except (OSError, ValueError, AttributeError):
                pass
        if col._thread is not None:
            col._thread.join(0.25)
        if col._thread is None or not col._thread.is_alive():
            try:
                app.store.close()  # records the run's end and releases the store at once
            except Exception:
                pass
        self.app = None

    def status_hook(self, status: dict) -> None:
        c = status["collector"]
        c["store"] = str(self.root)
        if self.import_error:
            c["available"] = False
            c["problem"] = f"The collector's Python packages could not be loaded ({self.import_error}). Prepare the plugin " \
                           "again with configure_claude.py so its Python environment is created."
            return
        c["available"] = True
        c["this_session_collects"] = self.app is not None
        c["command_line"] = " ".join(_quote(a) for a in self.cli_command)

    # --- tool plumbing ---

    def guard(self, fn):
        def handler(arguments: dict, ctx: CallContext) -> dict:
            if self.import_error:
                return fail("COLLECTOR_UNAVAILABLE", "The collector is not available in this installation: "
                            f"{self.import_error}. Prepare the plugin again with configure_claude.py.")
            try:
                return fn(arguments, ctx)
            except ToolError as e:
                return fail(e.code, e.message, **e.details)
            except NoElicitation:
                return fail("CONFIRMATION_UNAVAILABLE",
                            "This step needs the person's confirmation in a Claude Code dialog, and this client cannot show "
                            "one (for example `claude -p`). Use collector_open_page so the person can do it on the "
                            "collector's own page, or run Claude Code interactively.")
            except (self.m["config"].ConfigError, self.m["store"].StoreError, ValueError) as e:
                return fail("REFUSED", str(e))
        return handler

    def confirm(self, ctx: CallContext, message: str, field: str, title: str) -> None:
        self.ask(ctx, message, {field: {"type": "boolean", "title": title, "default": False}}, field)

    def ask(self, ctx: CallContext, message: str, properties: dict, gate: str, required: tuple = ()) -> dict:
        """Ask in Claude Code's dialog; anything but an explicit yes for `gate` changes nothing. Returns the answers.

        The text is shown whole or not at all: what the person decides on is never cut off."""
        text = _clean(message)
        if len(text) > DIALOG_LIMIT:
            raise ToolError("TOO_LONG_TO_CONFIRM", "This request is too long to show in full in a confirmation dialog; "
                            "nothing was changed. Propose fewer or shorter folders, addresses, patterns or items.")
        answer = ctx.elicit(text, properties, [gate, *required])
        action = answer["action"]
        if action == "accept" and answer["content"].get(gate) is True and all(
                answer["content"].get(r) is not None for r in required):
            return answer["content"]
        why = {
            "accept": "The person answered no in the dialog.",
            "decline": "The dialog was declined (by the person, or automatically by a host program that answers dialogs).",
            "cancel": "The dialog was dismissed or not answered. Sessions that cannot show dialogs (for example "
                      "`claude -p`) cancel them; then use collector_open_page so the person can do this on the "
                      "collector's own page.",
            "error": f"Claude Code could not show the dialog ({(answer.get('error') or {}).get('message', 'no detail')}).",
        }[action]
        raise ToolError("NOT_CONFIRMED", why + " Nothing was changed.")

    def wait_job(self, job: Job, ctx: CallContext, wait_s: float) -> dict:
        deadline = time.monotonic() + max(0.0, min(float(wait_s), 120.0))
        last = None
        while not job.done.wait(0.5):
            if ctx.cancelled.is_set() or time.monotonic() >= deadline:
                break
            if job.progress != last:
                ctx.progress(job.progress)
                last = job.progress
        return text_result(job.view(), is_error=job.state == "failed")

    def run_job(self, kind: str, fn) -> Job:
        job = Job(kind)
        self.jobs[job.id] = job

        def run():
            try:
                job.result = fn(job)
                job.state = "succeeded" if (job.result or {}).get("ok", True) else "failed"
            except ToolError as e:
                job.result, job.state = {"ok": False, "error": {"code": e.code, "message": e.message, **e.details}}, "failed"
            except Exception as e:  # report through the job, never crash the host
                from .relay import log_exception
                log_exception(self.launch, f"collector job {job.id}")
                job.result, job.state = {"ok": False, "error": {"code": "HOST_INTERNAL_ERROR",
                                                                "message": f"{e.__class__.__name__}: {e}"}}, "failed"
            finally:
                job.finished = time.time()
                job.done.set()
        threading.Thread(target=run, name=f"pitrelay-{job.id}", daemon=True).start()
        return job

    # --- tools ---

    def status(self, arguments: dict, ctx: CallContext) -> dict:
        app = self.owner()
        util = self.m["util"]
        if app is not None:
            st = app.status()
            st["this_session_collects"] = True
        else:
            store = self.reader()
            try:
                st = self.m["status"].build_status(store, self.config().load(), None, running_elsewhere=True)
            finally:
                store.close()
            st["this_session_collects"] = False
            holder = self.holder() or {}
            st["owned_by_other_process"] = {"pid": holder.get("pid"), "since_utc": util.utc_iso(holder.get("started_unix"))}
            st["note"] = ("Another process (the background collector, a second Claude Code session or a standalone "
                          "collector) is collecting with this store. Status, captures, exports and supplying packages work "
                          "here; settings changes and 'collect now' requests are picked up by that process within seconds.")
        st["recent_events"] = st.get("recent_events", [])[:15]
        st.pop("autostart", None)
        st["background_collection"] = self.autostart.status()
        st["packages"] = self.packages()[:5]
        st["disk"] = self.disk_usage()
        cfg = self.config().load()
        if not cfg.sources:
            sug = self.m["config"].suggested_directories
            st["suggested_sources"] = {
                "robot": {"kind": "sftp", "role": "robot", "username": "lvuser", "auth": "blank_password",
                          "hosts": ["172.22.11.2 (USB)", "10.TE.AM.2 (team 1234 -> 10.12.34.2)", "roborio-TEAM-frc.local"],
                          "directories": sug(cfg.robot_profile, "robot"),
                          "systemcore": {"username": "systemcore", "auth": "systemcore_default",
                                         "directories": ["/home/systemcore/logs", "/u/logs"]}},
                "driver_station": {"kind": "local", "role": "driver_station",
                                   "directories": sug(cfg.robot_profile, "driver_station")},
            }
        return ok(st)

    @property
    def internal_exports(self) -> Path:
        """This plugin's own packages (a store shared with a standalone collector keeps its exports apart)."""
        return self.root / "exports" / "claude"

    def packages(self) -> list[dict]:
        out = []
        try:
            zips = sorted(self.internal_exports.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
        except OSError:
            return out
        for p in zips[:20]:
            try:
                out.append({"path": str(p), "size_bytes": p.stat().st_size,
                            "modified_utc": self.m["util"].utc_iso(p.stat().st_mtime)})
            except OSError:
                continue
        return out

    def disk_usage(self) -> dict:
        def size(folder: Path, limit: int = 200_000) -> int | None:
            total, n = 0, 0
            for dirpath, _, files in os_walk(folder):
                for f in files:
                    n += 1
                    if n > limit:
                        return None
                    try:
                        total += (Path(dirpath) / f).stat().st_size
                    except OSError:
                        pass
            return total
        return {"internal_packages_bytes": size(self.internal_exports),
                "engine_state_bytes": size(Path(self.launch["state"]) / "engine"),
                "note": "Captures count toward the collector's storage quota; packages and the engine's copies of supplied "
                        f"recordings do not. The {KEEP_PACKAGES} newest internal packages are kept, plus every package "
                        "with observations or source code; older ones are removed after a later export."}

    @staticmethod
    def _read_scope(src) -> dict:
        return {"kind": src.kind, "hosts": set(src.hosts), "port": src.port, "username": src.username,
                "auth": src.auth_choice,
                "key_file": src.key_file, "directories": set(src.directories), "depth": src.recursive_depth,
                "csv": src.include_csv, "text": set(src.text_patterns)}

    def _widens(self, old, new) -> bool:
        if old is None:
            return True
        a, b = self._read_scope(old), self._read_scope(new)
        for k in ("kind", "port", "username", "auth", "key_file"):
            if a[k] != b[k]:
                return True
        return (not b["hosts"] <= a["hosts"] or not b["directories"] <= a["directories"] or b["depth"] > a["depth"]
                or (b["csv"] and not a["csv"]) or not b["text"] <= a["text"])

    @staticmethod
    def _check_proposal(data: dict) -> None:
        """Bounds that keep a proposal's whole scope inside the dialog that confirms it."""
        for key, most, what in (("directories", MAX_DIRECTORIES, "folders"), ("hosts", MAX_HOSTS, "addresses"),
                                ("text_patterns", MAX_PATTERNS, "text file patterns")):
            items = data.get(key)
            if items is None:
                continue
            if not isinstance(items, list) or not all(isinstance(x, str) for x in items):
                raise ToolError("REFUSED", f"{key} must be a list of strings")
            if len(items) > most:
                raise ToolError("REFUSED", f"At most {most} {what} per source")
            if any(len(x) > MAX_ITEM_CHARS for x in items):
                raise ToolError("REFUSED", f"Each of the {what} may be at most {MAX_ITEM_CHARS} characters")
        for key in ("alias", "username", "key_file"):
            if isinstance(data.get(key), str) and len(data[key]) > MAX_ITEM_CHARS:
                raise ToolError("REFUSED", f"{key} may be at most {MAX_ITEM_CHARS} characters")

    def _auth_text(self, src) -> str:
        return {"blank_password": "blank password", "systemcore_default": "Systemcore's documented default login",
                "password": "a password the person enters on the collector page",
                "key": f"the private key file {_shown(src.key_file)}"}.get(src.auth_choice, src.auth_choice)

    def configure_source(self, arguments: dict, ctx: CallContext) -> dict:
        cfgmod = self.m["config"]
        unknown = sorted(set(arguments) - set(SOURCE_PROPS))
        if unknown:
            raise ToolError("REFUSED", f"Unknown source settings {unknown}. Passwords and passphrases are never tool "
                            "arguments; the person enters them on the collector page (collector_open_page).")
        self._check_proposal(arguments)
        data = dict(arguments)
        cm = self.config()
        current = cm.load()
        existing = current.source_by_id(data["id"]) if data.get("id") else None
        if data.get("id") and existing is None:
            raise ToolError("UNKNOWN_SOURCE", f"No source has id {data['id']!r}; omit id to add a new source")
        candidate = cfgmod.merge_source(existing, data)
        candidate.trusted_host_keys = list(existing.trusted_host_keys) if existing is not None else []
        # The text alone is checked first: nothing on this computer or the network is touched before the person agrees.
        candidate = cfgmod.validate_source(candidate, self.root, [s for s in current.sources if s.id != candidate.id],
                                           touch_filesystem=False)
        widened = self._widens(existing, candidate)
        if widened:
            cfgmod.check_proposal(candidate)  # stricter rules for what Claude proposes (hidden folders, shares, ...)
            where = (f"robot address(es) {', '.join(_shown(h) for h in candidate.hosts)} (port {candidate.port}) as user "
                     f"{_shown(candidate.username)} with {self._auth_text(candidate)}, remote folder(s) "
                     if candidate.kind == "sftp" else "local folder(s) ")
            kinds = ".wpilog, .dslog, .dsevents, .revlog and .hoot files" + (", .csv files" if candidate.include_csv else "") \
                + (f", and text files named {', '.join(_shown(t) for t in candidate.text_patterns)}"
                   if candidate.text_patterns else "")
            message = (f"{'Add' if existing is None else 'Change'} PitRelay Collector source '{_shown(candidate.alias)}' "
                       f"(values proposed by Claude).\nIt will read {kinds} from {where}"
                       f"{', '.join(_shown(d) for d in candidate.directories)} (up to {candidate.recursive_depth} folder "
                       "levels deep), copy them into this computer's private collector store, and never change or delete "
                       "anything there.")
            if candidate.kind == "sftp":
                message += ("\n\nNothing is contacted before you allow it. If the robot answers, its SSH host key is "
                            "shown next, for you to check.")
            self.ask(ctx, message, {"allow": {"type": "boolean", "title": "Allow this source", "default": False}}, "allow")
        saved = {}

        def apply(cfg):
            src = cfgmod.validate_source(cfgmod.SourceConfig.from_dict(candidate.to_dict()), self.root,
                                         [s for s in cfg.sources if s.id != candidate.id])
            cur = cfg.source_by_id(candidate.id)
            # Trusted keys change only through a host-key dialog, never through a source change.
            src.trusted_host_keys = list(cur.trusted_host_keys) if cur is not None else []
            cfg.sources = [s for s in cfg.sources if s.id != src.id] + [src]
            saved["source"] = src
        cm.update(apply)
        src = saved["source"]
        nxt, trusted = [], None
        if widened and src.kind == "sftp" and (existing is None or set(src.hosts) - set(existing.hosts)
                                               or not src.trusted_host_keys):
            key = self._preview_key(src)  # only now that the person allowed this robot; read before any login
            if key is not None and not any(k.get("key_b64") == key["key_b64"] for k in src.trusted_host_keys):
                try:
                    replace = self._key_dialog(ctx, src, key)
                except ToolError as e:
                    nxt.append(f"The robot's SSH host key was not trusted ({e.message}) The source is saved; collection "
                               "from it waits until its key is trusted with collector_trust_host_key.")
                else:
                    self._trust(src.id, key, replace, preview=True)
                    trusted = key
        if self.app is not None:
            self.app.collector.poll_now()
        src = self.config().load().source_by_id(src.id) or src
        if src.kind == "sftp" and not src.trusted_host_keys and trusted is None and not nxt:
            nxt.append("The robot's SSH host key is not trusted yet (the robot was not reachable). When it is reachable, "
                       "call collector_collect_now, then collector_trust_host_key.")
        if src.kind == "sftp" and src.auth_choice == "password":
            nxt.append("The password is entered by the person on the collector page (collector_open_page), never here.")
        if not current.collection_enabled:
            nxt.append("Automatic collection is off. collector_collect_now syncs once; collector_control 'enable' keeps "
                       "collecting while Claude Code is open; collector_background collects even when it is closed.")
        return ok({"saved": True, "source": src.public_dict() | ({"auth": src.auth_choice} if src.kind == "sftp" else {}),
                   **({"host_key_trusted": trusted["fingerprint"]} if trusted else {}), "next": nxt})

    def _preview_key(self, src) -> dict | None:
        """The host key the robot presents, read without logging in (the SSH key exchange comes first)."""
        try:
            from pitrelay_collector.sources import fetch_host_key
        except ImportError:
            return None
        for host in src.hosts[:MAX_HOSTS]:
            try:
                return fetch_host_key(host, src.port, KEY_PREVIEW_TIMEOUT_S)
            except Exception:  # unreachable now: the key is confirmed on first connection instead
                continue
        return None

    def _key_dialog(self, ctx: CallContext, src, key: dict) -> bool:
        """Ask the person to trust the SSH host key a robot presented. Returns True when it replaces the keys trusted
        before (the robot was re-imaged), False when it is added to them (another robot of the team)."""
        where = _shown(key.get("host") or ", ".join(src.hosts))
        message = (f"The robot for source '{_shown(src.alias)}' at {where} presented this SSH host key:\n\n"
                   f"{_shown(key.get('type'))} {_shown(key.get('fingerprint'))}\n\n")
        props = {"trust": {"type": "boolean", "title": "Trust this host key", "default": False}}
        required = ()
        if src.trusted_host_keys:
            before = ", ".join(_shown(k.get("fingerprint")) for k in src.trusted_host_keys[:4])
            message += (f"It differs from the key trusted before ({before}). That is expected after the robot controller "
                        "was re-imaged, or when another robot (for example a practice robot) answers at the same "
                        "address. Otherwise something else may be answering there: do not trust it.")
            props["how"] = {"type": "string", "title": "What changed", "enum": ["replace", "add"],
                            "enumNames": ["The robot was re-imaged: replace the old key",
                                          "Another robot of ours: trust both keys"]}
            required = ("how",)  # no default: the person says which
        else:
            message += "Trust it only if this is your robot."
        answer = self.ask(ctx, message, props, "trust", required)
        return answer.get("how") == "replace"

    def _trust(self, sid: str, key: dict, replace: bool, preview: bool = False) -> None:
        """Trust exactly `key`: the pending key the collector recorded, or one read just before (preview)."""
        if self.app is not None:
            self.app.collector.trust_host_key(sid, key["fingerprint"], replace=replace, key=key if preview else None)
            return
        entry = {"type": key["type"], "fingerprint": key["fingerprint"], "key_b64": key["key_b64"],
                 "trusted_at": self.m["util"].utc_iso(time.time())}

        def trust(cfg):
            s = cfg.source_by_id(sid)
            if s is None:
                raise ToolError("UNKNOWN_SOURCE", f"No source has id {sid!r}")
            kept = [] if replace else [k for k in s.trusted_host_keys if k.get("key_b64") != entry["key_b64"]]
            s.trusted_host_keys = kept + [entry]
        self.config().update(trust)
        self._event("warning", "host_key_trusted", f"User trusted host key {key['fingerprint']}"
                    + ("" if replace else " (in addition)"), source_id=sid,
                    data={"fingerprint": key["fingerprint"], "type": key["type"], "replaced_previous": replace})

    def _meta(self, key: str) -> str:
        store = self.app.store if self.app is not None else self.reader()
        try:
            return store.meta_get(key, "") or ""
        finally:
            if self.app is None:
                store.close()

    def _set_meta(self, key: str, value: str, message: str) -> None:
        store = self.app.store if self.app is not None else self.reader()
        try:
            store.post_request(key, value, key, message)
        finally:
            if self.app is None:
                store.close()

    def _event(self, level: str, kind: str, message: str, **kw) -> None:
        if self.app is not None:
            self.app.store.add_event(level, kind, message, **kw)
        else:
            store = self.reader()
            try:
                store.post_request("last_reader_event", kind, kind, message)
            finally:
                store.close()

    def remove_source(self, arguments: dict, ctx: CallContext) -> dict:
        sid = arguments.get("source_id")

        def drop(cfg):
            if cfg.source_by_id(sid) is None:
                raise ToolError("UNKNOWN_SOURCE", f"No source has id {sid!r}")
            cfg.sources = [s for s in cfg.sources if s.id != sid]
        self.config().update(drop)
        if self.app is not None:
            self.app.store.add_event("info", "source_removed", "Source removed from configuration; its captures are kept",
                                     source_id=sid)
            self.app.collector.wake()
        return ok({"removed": sid, "note": "Captures already collected from this source are kept."})

    def trust_host_key(self, arguments: dict, ctx: CallContext) -> dict:
        sid = arguments.get("source_id")
        src = self.config().load().source_by_id(sid)
        if src is None or src.kind != "sftp":
            raise ToolError("UNKNOWN_SOURCE", f"No SFTP source has id {sid!r}")
        store = self.app.store if self.app is not None else self.reader()
        try:
            state = store.get_source_state(sid) or {}
        finally:
            if self.app is None:
                store.close()
        pending = state.get("pending_host_key")
        if not pending:
            return ok({"trusted": False, "message": "No unrecognized host key is waiting for this source. The collector "
                       "records one when it reaches the robot and sees a key it does not know: make the robot reachable, "
                       "call collector_collect_now, then call this again.",
                       "trusted_host_keys": [k.get("fingerprint") for k in src.trusted_host_keys]})
        replace = self._key_dialog(ctx, src, pending)
        self._trust(sid, pending, replace)
        return ok({"trusted": True, "fingerprint": pending["fingerprint"], "type": pending.get("type"),
                   "previous_keys": ("replaced" if replace else "kept") if src.trusted_host_keys else "none",
                   "note": "Collection from this robot proceeds on the next connection (collector_collect_now)."})

    def control(self, arguments: dict, ctx: CallContext) -> dict:
        action = arguments.get("action")
        app = self.owner()
        if app is not None:
            col = app.collector
            {"enable": lambda: col.set_enabled(True), "disable": lambda: col.set_enabled(False), "pause": col.pause,
             "resume": col.resume}[action]()
        elif action in ("enable", "disable"):
            def set_enabled(cfg):
                cfg.collection_enabled = action == "enable"
            self.config().update(set_enabled)
        else:
            store = self.reader()
            try:
                store.post_request("paused", repr(time.time()) if action == "pause" else "",
                                   "paused" if action == "pause" else "resumed",
                                   f"Collection {'paused' if action == 'pause' else 'resumed'} from Claude Code")
            finally:
                store.close()
        return self.status({}, ctx)

    def collect_now(self, arguments: dict, ctx: CallContext) -> dict:
        """Poll every enabled source now (once, even if automatic collection is off), then once more after a fresh
        connection, so recordings that stopped changing can be judged complete."""
        cfg = self.config().load()
        sources = [s for s in cfg.sources if s.enabled]
        if not sources:
            raise ToolError("NO_SOURCES", "No enabled sources; add one with collector_configure_source.")
        wait = max(2.0, min(float(arguments.get("wait_s", WAIT_S)), 120.0))
        deadline = time.monotonic() + wait
        app = self.owner()
        if app is not None:
            if app.collector.is_paused():
                raise ToolError("PAUSED", "Collection is paused; resume it first (collector_control 'resume').")
            col, store = app.collector, app.store
            caps_before = len(store.captures())
            completed = 0
            for reconnect in (False, True):
                # A cycle already running when the request arrives may have passed some sources: wait for one more.
                target = col.cycles + (2 if col.in_cycle else 1)
                col.sync_once(reconnect=reconnect)
                while col.cycles < target and time.monotonic() < deadline and not ctx.cancelled.is_set():
                    ctx.progress("polling sources and transferring new bytes")
                    time.sleep(0.25)
                if col.cycles < target:
                    break
                completed += 1
            st = json.loads(self.status({}, ctx)["content"][0]["text"])
            st["poll_completed"] = completed == 2
            st["new_captures_since_request"] = len(store.captures()) - caps_before
            return ok(st)
        # Another process owns the store: ask it to poll, and watch its source states.
        store = self.reader()
        try:
            if store.meta_get("paused", ""):
                raise ToolError("PAUSED", "Collection is paused; resume it first (collector_control 'resume').")
            caps_before = len(store.captures())
            asked = time.time()
            store.post_request("poll_request", json.dumps({"t": asked, "once": True, "reconnect": False}),
                               "poll_requested", "Collection requested from Claude Code")

            def polled() -> bool:
                return all(((store.get_source_state(s.id) or {}).get("last_attempt") or 0) >= asked for s in sources)
            while not polled() and time.monotonic() < deadline and not ctx.cancelled.is_set():
                ctx.progress("waiting for the collecting process to poll")
                time.sleep(0.5)
            done = polled()
            new = len(store.captures()) - caps_before
        finally:
            store.close()
        st = json.loads(self.status({}, ctx)["content"][0]["text"])
        st["poll_completed"] = done
        st["new_captures_since_request"] = new
        if not done:
            st["poll_note"] = "The collecting process had not polled every source yet; check collector_status shortly."
        return ok(st)

    def background(self, arguments: dict, ctx: CallContext) -> dict:
        """Collection while Claude Code is closed: the bundled collector at login, and now."""
        action = arguments.get("action")
        auto = self.autostart
        if action == "status":
            return ok({"launch_at_login": auto.status(), "store_owner": self.holder(),
                       "this_session_collects": self.app is not None})
        if action == "on":
            st = auto.status()
            self.ask(ctx, "Collect robot and Driver Station logs in the background, also while Claude Code is closed?\n\n"
                          f"This starts PitRelay Collector now and at every login of this user ({_shown(st.get('mechanism'))}: "
                          f"{_shown(st.get('location'))}). It reads only the sources you confirmed, uses no internet, and "
                          "can be turned off here or on the collector page. Automatic collection is turned on too, also in "
                          "Claude Code sessions; turning background collection off restores the previous setting.",
                     {"allow": {"type": "boolean", "title": "Collect in the background", "default": False}}, "allow")
            previous = self.config().load().collection_enabled
            if self._meta(BACKGROUND_PREVIOUS) == "":  # turned on twice: keep the setting from before the first time
                self._set_meta(BACKGROUND_PREVIOUS, "1" if previous else "0", "Background collection turned on")

            def enable(cfg):
                cfg.collection_enabled = True
            self.config().update(enable)
            result = auto.enable(self.root)
            started = self._start_background()
            note = ("This session now reads status and packages from the background collector." if started["running_now"]
                    else "The background collector starts at the next login; " + started["why_not"])
            return ok({"launch_at_login": result, **started, "note": note})
        if action == "off":
            result = auto.disable()
            stopped = self._stop_background()
            previous = self._meta(BACKGROUND_PREVIOUS)
            if previous:
                if previous == "0":
                    def restore(cfg):
                        cfg.collection_enabled = False
                    self.config().update(restore)
                self._set_meta(BACKGROUND_PREVIOUS, "", "Background collection turned off")
            enabled = self.config().load().collection_enabled
            return ok({"launch_at_login": result, **stopped, "automatic_collection": "on" if enabled else "off",
                       "note": ("Automatic collection is back to its setting from before background collection: "
                                + ("on, so open Claude Code sessions keep collecting." if enabled else "off.")
                                if previous else "Collection continues in Claude Code sessions only if automatic "
                                                 "collection is on (collector_control).")})
        raise ToolError("REFUSED", "action must be on, off or status")

    def _start_background(self) -> dict:
        """Hand the store to a background collector process (no window, no browser), and confirm that this process,
        not some other one, took it."""
        import subprocess
        holder = self.holder()
        if self.app is None and holder is not None and self.m["lock"].StoreLock(self.root).is_held_elsewhere():
            return {"running_now": False, "why_not": f"another process (pid {holder.get('pid')}) collects with this store "
                    "now: another Claude Code session or a standalone collector. Nothing was started next to it."}
        with self._lock:
            app, self.app = self.app, None
        if app is not None:
            app.shutdown()  # release the store, so the background process can own it
        cmd = [*self.cli_command, "run", "--store", str(self.root), "--no-browser", "--quiet"]
        kw = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL, "close_fds": True}
        if os_name() == "nt":  # pragma: no cover
            kw["creationflags"] = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            kw["args"] = [str(Path(self.cli_command[0]).with_name("pythonw.exe")), *cmd[1:]] if \
                Path(self.cli_command[0]).with_name("pythonw.exe").exists() else cmd
        else:
            kw["start_new_session"] = True
            kw["args"] = cmd
        proc = subprocess.Popen(**kw)
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            if (self.holder() or {}).get("pid") == proc.pid:
                return {"running_now": True, "pid": proc.pid}
            if proc.poll() is not None:
                return {"running_now": False, "why_not": f"the background collector stopped at once (exit code "
                        f"{proc.returncode}); the collector page or `collector.py status` shows why."}
            time.sleep(0.2)
        return {"running_now": False, "why_not": "the background collector did not take the store within 15 seconds."}

    def _stop_background(self) -> dict:
        """Stop the background collector of this plugin (identified in its ui.json), never another collector."""
        if self.app is not None:
            return {"background_stopped": False, "why": "this session collects; nothing runs in the background"}
        try:
            info = json.loads((self.root / "ui.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            info = None
        holder = self.holder() or {}
        if not isinstance(info, dict) or info.get("ident") != "claude" or info.get("pid") != holder.get("pid"):
            if not self.m["lock"].StoreLock(self.root).is_held_elsewhere():
                return {"background_stopped": False, "why": "no collector is running with this store"}
            who = (info or {}).get("ident") if isinstance(info, dict) and info.get("pid") == holder.get("pid") else None
            return {"background_stopped": False,
                    "why": f"the process collecting with this store (pid {holder.get('pid')}"
                           + (f", {who}" if who else "") + ") was not started by this plugin's background "
                           "collection, so it was left running"}
        try:
            token = info["login_url"].split("#token=", 1)[1]
            import http.client
            conn = http.client.HTTPConnection("127.0.0.1", int(info["port"]), timeout=10)
            conn.request("POST", "/api/control", body=json.dumps({"action": "stop"}), headers={
                "Host": f"127.0.0.1:{info['port']}", "Authorization": f"Bearer {token}", "Content-Type": "application/json"})
            ok_ = conn.getresponse().status == 200
            conn.close()
        except (OSError, ValueError, KeyError, IndexError):
            ok_ = False
        lock = self.m["lock"].StoreLock(self.root)
        deadline = time.monotonic() + 15
        while ok_ and time.monotonic() < deadline:
            if not lock.is_held_elsewhere():
                return {"background_stopped": True}
            time.sleep(0.2)
        return {"background_stopped": False, "why": "the background collector did not stop when asked"}

    def list_captures(self, arguments: dict, ctx: CallContext) -> dict:
        util = self.m["util"]
        since = util.parse_iso(arguments["since"]) if arguments.get("since") else None
        until = util.parse_iso(arguments["until"]) if arguments.get("until") else None
        offset = max(0, int(arguments.get("offset", 0)))
        limit = max(1, min(int(arguments.get("limit", DEFAULT_LIST)), MAX_LIST))
        store = self.app.store if self.app is not None else self.reader()
        try:
            aliases = {s["source_id"]: s["alias"] for s in store.known_sources()}
            rows = []
            for c in store.captures(source_id=arguments.get("source_id")):
                if not self.m["export"]._overlaps(c, since, until):
                    continue
                if arguments.get("status") and c["status"] != arguments["status"]:
                    continue
                fmt = store.format_cache_get(c["id"], c["committed_size"])
                rows.append({"capture_id": f"cap-{c['id']:06d}", "source": aliases.get(c["source_id"], c["source_id"]),
                             "name": util.printable(c["path"].replace("\\", "/").rsplit("/", 1)[-1], 200),
                             "status": c["status"], "presence": c["presence"], "size_bytes": c["committed_size"],
                             "observed_bytes": c["observed_size"], "first_seen_utc": util.utc_iso(c["first_seen"]),
                             "last_acquired_utc": util.utc_iso(c["last_acquired"]),
                             "format": fmt.get("label") if fmt else None})
        finally:
            if self.app is None:
                store.close()
        page = rows[offset:offset + limit]
        return ok({"total": len(rows), "offset": offset, "returned": len(page), "captures": page,
                   "next_offset": offset + len(page) if offset + len(page) < len(rows) else None,
                   "clock_note": "Times are on this computer's clock (the collector clock), not the robot's."})

    def export(self, arguments: dict, ctx: CallContext) -> dict:
        util, exp = self.m["util"], self.m["export"]
        ids = None
        if arguments.get("capture_ids"):
            ids = [_capture_number(x) for x in arguments["capture_ids"]]
        project = arguments.get("source_project_dir")
        source_note = None
        if project is not None:
            project, source_note = self._confirm_project(ctx, str(project))
        max_mb = arguments.get("max_archive_mb")
        opts = exp.ExportOptions(
            out_dir=self.internal_exports,
            since=util.parse_iso(arguments["since"]) if arguments.get("since") else None,
            until=util.parse_iso(arguments["until"]) if arguments.get("until") else None,
            source_ids=arguments.get("source_ids") or None, capture_ids=ids,
            observations=[o for o in arguments.get("observations", []) if isinstance(o, dict)],
            source_project_dir=Path(project) if project else None,
            max_archive_bytes=int(float(max_mb) * 1024 * 1024) if max_mb else None,
            package_label=(str(arguments["label"]).strip()[:120] or None) if arguments.get("label") else None)

        def run(job: Job) -> dict:
            job.progress = "exporting and verifying"
            store_for_sweep = self.app.store if self.app is not None else None
            if store_for_sweep is not None:
                exp.sweep_interrupted(store_for_sweep, self.internal_exports)
            if self.app is not None:
                cfg = self.app.config.load()
                state = {"overall": self.m["status"].build_status(self.app.store, cfg, self.app.collector)["overall"],
                         "at_utc": util.utc_iso(time.time())}
                res = exp.export_package(self.app.store, cfg, opts, collector_state=state)
            else:
                store = self.reader()
                try:
                    res = exp.export_package(store, self.config().load(), opts,
                                             collector_state={"overall": "running_elsewhere", "at_utc": util.utc_iso(time.time())})
                finally:
                    store.close()
            out = {"ok": res.ok, "archives": res.archives, "warnings": res.warnings[:20], "error": res.error}
            if source_note:
                out["source_code"] = source_note
            if res.ok:
                out["pruned_old_packages"] = self.prune_packages()
                out["next"] = ("collector_supply_to_engine (package 'latest') supplies these recordings to PitRelay. The "
                               "package is private, not anonymized, and never uploaded. The collector store keeps the "
                               f"{KEEP_PACKAGES} newest packages (and every package with observations or source code); "
                               "older ones are removed when a new export finishes, so the person should copy a package "
                               "elsewhere if it must be kept.")
            return out
        return self.wait_job(self.run_job("export", run), ctx, arguments.get("wait_s", WAIT_S))

    def _confirm_project(self, ctx: CallContext, project: str) -> tuple[Path | None, str]:
        """The robot project folder whose source code may go into the package, after the person agreed to it.

        The model proposes the folder, so it is checked by its spelling first, then shown to the person, and only then
        read: it must look like a robot project (never a root, the home folder, a hidden folder or the store)."""
        cfgmod, p = self.m["config"], self.m["util"].printable
        path = Path(project)
        home = Path(os.path.normpath(os.path.expanduser("~")))
        spelled = Path(os.path.normpath(project)) if path.is_absolute() else None
        if spelled is None or cfgmod.is_network_path(project):
            raise ToolError("REFUSED", "source_project_dir must be the absolute path of a robot project folder on this "
                            "computer")
        def key(x) -> str:
            return os.path.normcase(str(x)).casefold()
        lowered = {key(x) for x in (spelled, *spelled.parents)}  # the folder and every folder above it
        private = [Path(os.path.normpath(self.root)), Path(os.path.normpath(self.launch["state"]))]
        if (spelled == Path(spelled.anchor) or key(spelled) in {key(x) for x in (home, *home.parents)}
                or any(part.startswith(".") for part in spelled.parts[1:])
                or any(key(x) in lowered for x in private)  # inside the store or the state
                or any(key(spelled) in {key(y) for y in (x, *x.parents)} for x in private)):  # or around them
            raise ToolError("REFUSED", "source_project_dir must be the robot project folder itself: not a drive root, the "
                            "home folder or a folder above it, a hidden folder, or a folder that is, holds or lies in the "
                            "collector store or the PitRelay state")
        try:
            self.confirm(ctx, f"Include the robot project's source code from {_shown(spelled)} (folder proposed by "
                              "Claude) in this package?\n\nOnly source and configuration files are copied; files whose "
                              "names or contents look like credentials are left out, and the package lists what was "
                              "left out. Nothing is built or run. The package stays private on this computer.",
                         "include", "Include this folder's source code")
        except (ToolError, NoElicitation) as e:
            why = e.message if isinstance(e, ToolError) else "this client cannot show the dialog."
            return None, f"Not included: the person did not agree to include source code ({why})"
        problem = self.m["projectscan"].project_root_problem(spelled)
        if problem:
            raise ToolError("REFUSED", f"source_project_dir was not used: {problem}. Nothing was exported.")
        return spelled, f"Included from {p(str(spelled), 300)}, as the person agreed"

    def prune_packages(self) -> list[str]:
        """Keep the newest KEEP_PACKAGES internal packages. All parts of one export count as one, and are kept or removed
        together: a set with the person's observations or source code is never removed (the store keeps no other copy),
        nor one a running supply reads."""
        pkg = self.m["package"]
        zips = sorted(self.internal_exports.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
        sets: dict[str, list[Path]] = {}  # newest set first
        for z in zips:
            sets.setdefault(_set_id(z, pkg) or z.name, []).append(z)
        in_use = {str(x) for x in self._in_use}
        removed = []
        for rank, parts in enumerate(sets.values()):
            if rank < KEEP_PACKAGES or any(str(z) in in_use or _holds_person_content(z, pkg) for z in parts):
                continue
            for z in parts:
                for f in (z, z.with_name(z.name + ".sha256")):
                    try:
                        f.unlink()
                        removed.append(f.name)
                    except FileNotFoundError:
                        pass
                    except OSError:  # open elsewhere (Windows): kept, tried again after the next export
                        break
        return [r for r in removed if r.endswith(".zip")]

    def job_status(self, arguments: dict, ctx: CallContext) -> dict:
        job = self.jobs.get(arguments.get("job_id"))
        if job is None:
            raise ToolError("UNKNOWN_JOB", "No such job in this Claude Code session (jobs do not survive a restart; "
                            "exports remain in the collector store, see collector_status).")
        return self.wait_job(job, ctx, arguments.get("wait_s", WAIT_S))

    def _resolve_packages(self, package: str | None) -> tuple[list[Path], bool]:
        """The package files, and whether they are this collector's own exports."""
        pkg = self.m["package"]
        if package in (None, "", "latest"):
            exports = self.internal_exports
            zips = sorted(exports.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True) if exports.is_dir() else []
            if not zips:
                raise ToolError("NO_PACKAGE", "No exported package yet; call collector_export first.")
            newest = zips[0]
            set_id = _set_id(newest, pkg)
            group = [z for z in zips if set_id is not None and _set_id(z, pkg) == set_id] or [newest]
            return sorted(group), True
        path = Path(str(package))
        if not path.is_absolute() or path.suffix.lower() != ".zip" or self.m["config"].is_network_path(str(package)):
            raise ToolError("REFUSED", "package must be 'latest' or the absolute path of a PitRelay Collector .zip package "
                            "on this computer")
        # A path outside the store is not even looked at before the person agrees (supply() asks first).
        own = [os.path.normcase(os.path.normpath(d)) for d in (self.root / "exports", self.internal_exports)]
        if os.path.normcase(os.path.normpath(path.parent)) in own:
            try:
                if path.is_file() and path.resolve().parent in ((self.root / "exports").resolve(),
                                                               self.internal_exports.resolve()):
                    return [path], True
            except OSError:
                pass
        return [path], False

    def supply(self, arguments: dict, ctx: CallContext) -> dict:
        paths, internal = self._resolve_packages(arguments.get("package"))
        wanted = {f"cap-{_capture_number(x):06d}" for x in arguments.get("capture_ids") or []}
        do_inspect = arguments.get("inspect", True) is not False
        offset = max(0, int(arguments.get("offset", 0)))
        workflow = arguments.get("workflow_id")
        if workflow is not None and not isinstance(workflow, str):
            raise ToolError("REFUSED", "workflow_id must be a string")
        self.server.engine.ensure()
        p = self.m["util"].printable
        if not internal:
            # A file outside the collector's own exports: reading it is the person's decision, as for Claude Code's Read.
            if not self.server.client_can_elicit():
                raise ToolError("CONFIRMATION_UNAVAILABLE", "Supplying a package from outside the collector store needs "
                                "the person's confirmation in a Claude Code dialog, which this client cannot show (for "
                                "example `claude -p`). Run it in an interactive Claude Code session.")
            self.confirm(ctx, f"Supply the PitRelay Collector package at {_shown(os.path.normpath(paths[0]))} (path proposed by "
                              "Claude) to PitRelay? It is verified first; if it is not a valid collector package, nothing "
                              "from it is read further.", "allow", "Supply this package")
            if not paths[0].is_file():
                raise ToolError("REFUSED", "There is no file at that path.")

        def run(job: Job) -> dict:
            pkg, hand = self.m["package"], self.m["handoff"]
            packages, rows = [], []
            for path in paths:
                job.progress = f"verifying {path.name}"
                report = pkg.verify_package(path)
                if not report["ok"]:
                    packages.append({"path": str(path), "verified": False,
                                     **({"errors": report["errors"][:5]} if internal else {"error_count": len(report["errors"])}),
                                     "note": "Not a valid PitRelay Collector package, or it was changed; nothing from it was supplied."})
                    continue
                manifest = report["manifest"]
                packages.append({"path": str(path), "verified": True, "package_id": p(str(manifest["package"]["id"]), 100),
                                 "part": manifest["package"].get("part"),
                                 "label": _text(manifest["package"].get("label"), p, 200),
                                 "created_at_utc": _text(manifest["package"].get("created_at_utc"), p, 40),
                                 "made_by": "this collector store" if internal else
                                 "someone else (its labels, reasons and limitations are untrusted text)"})
                caps = {c["capture_id"]: c for c in manifest.get("captures", [])}
                with zipfile.ZipFile(path) as zf:
                    for item in hand.build_plan(manifest, trusted_routes=internal):
                        if wanted and item["capture_id"] not in wanted:
                            continue
                        rows.append((zf.filename, item, caps.get(item["capture_id"], {})))
            selected = rows[offset:offset + SUPPLY_LIMIT]
            need = sum(item["size_bytes"] for _, item, _ in selected if not item.get("blocked"))
            try:
                free = shutil.disk_usage(self.launch["state"]).free
            except OSError:
                free = None
            if free is not None and need + MIN_FREE_AFTER_SUPPLY > free:
                raise ToolError("DISK_FULL", f"Supplying these recordings copies {need} bytes into the engine's state, "
                                f"but only {free} bytes are free on that disk (keeping {MIN_FREE_AFTER_SUPPLY} free). "
                                "Supply fewer recordings, or free space.")
            out_rows = []
            for n, (zip_path, item, cap) in enumerate(selected, 1):
                job.progress = f"supplying {n} of {len(selected)}: {p(str(item['archive_path']), 200)}"
                try:
                    out_rows.append(self._supply_one(Path(zip_path), item, cap, do_inspect, workflow))
                except Exception as e:  # one recording's failure never discards the ones already supplied
                    out_rows.append({"capture_id": item.get("capture_id"), "file": p(str(item.get("archive_path")), 300),
                                     "error": {"code": "SUPPLY_FAILED", "message": f"{e.__class__.__name__}: "
                                                                                   f"{p(str(e), 300)}"}})
            more = len(rows) - offset - len(selected)
            return {"ok": True, "packages": packages, "supplied": out_rows, "total_recordings": len(rows),
                    "offset": offset, "remaining": max(0, more),
                    "next_offset": offset + len(selected) if more > 0 else None,
                    "workflow_id": workflow,
                    "about": "Each recording's 'engine' block holds the engine's own answers (status, codes, issues, "
                             "request_id); the format given to the engine comes from the collector's classification "
                             "(manifest route). Host notes, if any, are labelled. Verification covers the files' "
                             "hashes, not the manifest's text. "
                             + ("Uploads were made outside the workflow (they would use up its call budget); the "
                                "inspections were made in the workflow given." if workflow else
                                "The engine calls were made outside any PitRelay workflow."),
                    "clock_domains": _clock_note(),
                    "next": "Use PitRelay tools (log.entries, signal.*) with each artifact_id. State each recording's "
                            "acquisition status and gaps alongside any result."}
        def run_marked(job: Job) -> dict:
            self._in_use.update(paths)
            try:
                return run(job)
            finally:
                self._in_use.difference_update(paths)
        return self.wait_job(self.run_job("supply", run_marked), ctx, arguments.get("wait_s", WAIT_S))

    def _supply_one(self, zip_path: Path, item: dict, cap: dict, do_inspect: bool, workflow: str | None) -> dict:
        p = self.m["util"].printable
        acq = cap.get("acquisition") or {}
        acquisition = {k: acq.get(k) for k in ("status", "snapshot", "unrecovered_gap_bytes", "pending_bytes_at_source",
                                               "presence_at_source", "first_seen_utc", "last_acquired_utc",
                                               "source_reported_mtime_utc") if k in acq}
        for k, v in list(acquisition.items()):
            if isinstance(v, str):
                acquisition[k] = p(v, 100)
        if isinstance(acq.get("status_reasons"), list):
            acquisition["status_reasons"] = [_text(r, p, 300) for r in acq["status_reasons"][:5]]
        row = {"capture_id": item["capture_id"], "file": p(str(item["archive_path"]), 300),
               "format": _text(item["format"], p, 60), "size_bytes": item["size_bytes"], "acquisition": acquisition,
               "limitations": [_text(x, p, 300) for x in item.get("limitations", [])[:4]]}
        targets = []
        if item.get("blocked"):
            row["not_supplied"] = _text(item["blocked"], p, 300)
        elif item["operation"] is None and not item.get("derived"):
            row["not_supplied"] = _text(item["description"], p, 300)
        elif item["operation"] is not None:
            targets.append(("original", item["archive_path"], item["upload_kind"], item["format_argument"], item["operation"],
                            item["sha256"], item["size_bytes"]))
        if item.get("derived"):
            d = item["derived"]
            targets.append(("derived", d["archive_path"], "log", None, "log.inspect", d["sha256"], d["size_bytes"]))
        for role, rel, kind, fmt, op, sha, size in targets:
            # Uploads are made outside any workflow: inside one, every 48 KiB chunk would use up a workflow call.
            entry = self._upload_member(zip_path, rel, kind, sha, size)
            if entry.get("artifact_id") and do_inspect and op == "log.inspect":
                args = {"artifact_id": entry["artifact_id"], **({"format": fmt} if fmt else {}),
                        **({"workflow_id": workflow} if workflow else {})}
                result = self.server.engine.call_tool_result("pitrelay_log_inspect", args)
                entry["inspect"] = _engine_fields(_envelope(result))
                compat = self.server.compat
                notes = compat.notes("pitrelay_log_inspect", args, result) if compat.wants_notes(
                    "pitrelay_log_inspect", args, result) else []
                if notes:
                    entry["host_notes"] = [n["text"] for n in notes]
                entry["inspect_arguments"] = args
                entry["format_chosen_by"] = "the collector's classification of the file (manifest route)"
            elif entry.get("artifact_id") and op == "log.import_csv":
                entry["next"] = ("CSV: call log.import_csv with explicit timestamp_column, value_column, time_unit (us, ms "
                                 "or s), clock, sampling_policy and unit, all confirmed by the person; never guessed.")
            row[role] = entry
        return row

    def _upload_member(self, zip_path: Path, rel: str, kind: str, sha256: str, size: int) -> dict:
        from pitrelay_collector.package import ROOT
        call = self.server.engine.call_tool
        begin_args = {"kind": kind, "filename": rel.rsplit("/", 1)[-1], "byte_size": size, "sha256": sha256}
        for attempt in range(BUSY_RETRIES + 1):
            begin = call("pitrelay_artifact_upload_begin", begin_args)
            busy = begin.get("status") == "blocked" and (begin.get("result") or {}).get("code") == "TRANSFER_BUSY"
            if not busy or attempt == BUSY_RETRIES:
                break
            time.sleep(min(0.5 * (attempt + 1), 3.0))  # another process (another session's engine) is admitting one
        if begin.get("status") != "ok":
            return {"status": begin.get("status"), "stage": "upload_begin", "engine": _engine_fields(begin)}
        res = begin["result"]
        transfer = res.get("transfer_id") or res.get("id")
        chunk = min(int(res.get("max_chunk_bytes") or UPLOAD_CHUNK), UPLOAD_CHUNK)
        offset, finished = 0, False
        try:
            with zipfile.ZipFile(zip_path) as zf, zf.open(f"{ROOT}/{rel}") as src:
                while True:
                    block = src.read(chunk)
                    if not block:
                        break
                    r = call("pitrelay_artifact_upload_chunk", {"transfer_id": transfer, "offset": offset,
                                                                "data_base64": base64.b64encode(block).decode("ascii")})
                    if r.get("status") != "ok":
                        return {"status": r.get("status"), "stage": "upload_chunk", "offset": offset,
                                "engine": _engine_fields(r)}
                    offset += len(block)
            fin = call("pitrelay_artifact_upload_finish", {"transfer_id": transfer})
            if fin.get("status") != "ok":
                return {"status": fin.get("status"), "stage": "upload_finish", "engine": _engine_fields(fin)}
            finished = True
        finally:
            if not finished:  # never leave a half-written transfer in the engine's state
                try:
                    call("pitrelay_artifact_upload_abort", {"transfer_id": transfer})
                except Exception:
                    pass  # the transfer journal lets a later session abort it
        r = fin["result"]
        matches = r.get("sha256") == sha256 and r.get("byte_size") == size
        out = {"status": "ok" if matches else "error", "artifact_id": r.get("id") if matches else None,
               "engine_sha256": r.get("sha256"), "sha256_matches_manifest": matches,
               "engine_request_id": fin.get("request_id")}
        if not matches:
            out["problem"] = "The engine reported a different hash or size than the verified package; do not use it."
        return out

    def open_page(self, arguments: dict, ctx: CallContext) -> dict:
        app = self.owner()
        how = " ".join(_quote(a) for a in [*self.cli_command, "open-ui", "--store", str(self.root)])
        if app is None:
            holder = self.holder() or {}
            try:
                info = json.loads((self.root / "ui.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                info = None
            if isinstance(info, dict) and info.get("pid") == holder.get("pid"):
                raise ToolError("COLLECTED_ELSEWHERE", "Another process owns the collector store and has its page running. "
                                f"The person can open it by running this in their own terminal: {how}")
            raise ToolError("COLLECTED_ELSEWHERE", f"Another process (pid {holder.get('pid')}) owns the collector store and "
                            "has no page open. If it is another Claude Code session, call collector_open_page there; if "
                            "it is a standalone or background collector, its own page or `open-ui` command applies.")
        app.start_ui(open_browser=False)
        # Not a child of this process: Claude Code ends the host's whole process tree on Windows.
        opened = open_url_detached(app.ui.launch_url())
        return ok({"opened_in_browser": opened,
                   "message": "The collector page is open in the person's browser." if opened else
                   "No browser could be opened from here. The person can open the page by running this in their own "
                   f"terminal (it prints a private link): {how} --print-url",
                   "use_it_for": ["entering a robot password", "adding or checking sources", "launch at login",
                                  "storage limits and bandwidth"]})

    def delete_captures(self, arguments: dict, ctx: CallContext) -> dict:
        ids = list(dict.fromkeys(_capture_number(x) for x in arguments.get("capture_ids") or []))
        if not ids:
            raise ToolError("REFUSED", "capture_ids is required")
        if len(ids) > MAX_DELETE:
            raise ToolError("REFUSED", f"At most {MAX_DELETE} captures per deletion, so the person sees each one; "
                            "split the request.")
        app = self.owner()
        if app is None:
            raise ToolError("COLLECTED_ELSEWHERE", "Captures can be deleted only by the process that owns the store.")
        known = {c["id"]: c for c in app.store.captures()}
        missing = [i for i in ids if i not in known]
        if missing:
            raise ToolError("UNKNOWN_CAPTURE", f"Unknown capture ids: {', '.join(f'cap-{i:06d}' for i in missing[:10])}")
        p = self.m["util"].printable
        names = "\n".join(f"  cap-{i:06d}  {p(known[i]['path'].replace(chr(92), '/').rsplit('/', 1)[-1], 80)}  "
                          f"({known[i]['committed_size']} bytes, {known[i]['status']})" for i in ids)
        self.confirm(ctx, f"Permanently delete these {len(ids)} capture(s) from this computer's collector store?\n{names}"
                          "\n\nThe robot and Driver Station are not touched. Later exports will list these as deleted by "
                          "the user.", "delete", "Delete permanently")
        note = p(str(arguments.get("note") or "deleted from Claude Code at the person's request"), 200)
        return ok({"deleted": [f"cap-{i:06d}" for i in app.store.delete_captures(ids, note)]})


_INVISIBLE = {0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069, 0xFEFF}


def _clean(text: str) -> str:
    """Dialog text: no control, ANSI or direction-changing characters. Values from the model or a robot are also
    escaped with util.printable before they are put into a message, so they cannot add lines of their own."""
    return "".join(ch for ch in str(text) if (ch in "\n\t" or ch.isprintable()) and ord(ch) not in _INVISIBLE)


def open_url_detached(url: str) -> bool:
    """Open the person's browser so that it does not belong to this process (and does not end with it)."""
    import os
    import subprocess
    try:
        if os.name == "nt":  # pragma: no cover - Windows only, UNVERIFIED
            os.startfile(url)  # ShellExecute: the browser is started by the shell, not as our child
            return True
        cmd = ["open", url] if sys.platform == "darwin" else ["xdg-open", url]
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True, close_fds=True)
        return True
    except (OSError, AttributeError):
        return False


def os_walk(folder: Path):
    import os
    return os.walk(folder)


def os_name() -> str:
    import os
    return os.name


def _capture_number(value) -> int:
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    s = str(value).strip()
    if s.startswith("cap-"):
        s = s[4:]
    if not s.isdigit():
        raise ToolError("REFUSED", f"Not a capture id: {value!r} (expected cap-NNNNNN or a number)")
    return int(s)


def _set_id(path: Path, pkg) -> str | None:
    try:
        with zipfile.ZipFile(path) as zf:
            manifest = json.loads(zf.read(f"{pkg.ROOT}/{pkg.MANIFEST}").decode("utf-8"))
        part = (manifest.get("package") or {}).get("part") or {}
        return part.get("set_id") or (manifest.get("package") or {}).get("id")
    except (OSError, KeyError, ValueError, zipfile.BadZipFile):
        return None


def _shown(value) -> str:
    """A value from the model or a robot as a dialog shows it: escaped (no line breaks or direction characters) and
    never shortened; ask() refuses a dialog that would be too long instead."""
    from pitrelay_collector.util import printable
    return printable(str(value), 1_000_000)


def _text(value, printable, limit: int):
    """Text from a package manifest (untrusted for a package made elsewhere): escaped and bounded; other values as is."""
    return printable(value, limit) if isinstance(value, str) else value


def _holds_person_content(path: Path, pkg) -> bool:
    """Whether a package holds observations or source code, which exist nowhere else in the store."""
    try:
        with zipfile.ZipFile(path) as zf:
            if any(n.startswith(f"{pkg.ROOT}/source/") for n in zf.namelist()):
                return True
            obs = json.loads(zf.read(f"{pkg.ROOT}/observations.json").decode("utf-8"))
    except (OSError, KeyError, ValueError, zipfile.BadZipFile):
        return False
    return bool(isinstance(obs, dict) and obs.get("observations"))


def _engine_fields(env: dict) -> dict:
    """The engine's own answer, field by field as it gave them (a bounded selection, values unchanged)."""
    res = env.get("result") if isinstance(env.get("result"), dict) else {}
    keep = ("code", "message", "format", "format_version", "integrity", "complete", "index_complete", "channel_count",
            "entry_count", "record_count", "sample_count", "first_observation_us", "last_observation_us", "issue_total")
    out = {"status": env.get("status"), "request_id": env.get("request_id"), **{k: res[k] for k in keep if k in res}}
    if res.get("issues"):
        out["issues"] = res["issues"][:3]
    return out


def _envelope(result: dict) -> dict:
    from .relay import envelope_of
    return envelope_of(result)


def _clock_note() -> str:
    return ("Collector times (first/last seen and acquired) are on this computer's clock; source_reported_mtime is the "
            "robot's or Driver Station's clock (may be unset); times inside a log are that log's own clock (WPILOG: robot "
            "FPGA microseconds). They are not aligned with each other.")


def _quote(arg: str) -> str:
    return f'"{arg}"' if (" " in arg or not arg) else arg


def install(server) -> CollectorHost:
    host = CollectorHost(server, server.launch)
    g = host.guard
    tools = [
        ("collector_status", "PitRelay Collector status: whether this session is collecting, each source's state "
         "(connected, unreachable, waiting for host-key trust), captures, storage, alerts, recent events and exported "
         "packages. Suggests typical robot and Driver Station sources when none are set.",
         _schema({}), _ann(True), host.status),
        ("collector_configure_source", "Add or change a collector source: a robot/coprocessor over SFTP (read-only) or a "
         "local folder such as the Driver Station's log folder. Adding or widening what is read is confirmed by the person "
         "in a dialog. Never put passwords here.", _schema(SOURCE_PROPS), _ann(False), host.configure_source),
        ("collector_remove_source", "Remove a source from the collector's configuration (its captures are kept).",
         _schema({"source_id": {"type": "string"}}, ["source_id"]), _ann(False, destructive=True), host.remove_source),
        ("collector_trust_host_key", "Ask the person to confirm the SSH host key a robot presented (shown in a dialog), "
         "so collection from it can start. Only the person can confirm.",
         _schema({"source_id": {"type": "string"}}, ["source_id"]), _ann(False), host.trust_host_key),
        ("collector_control", "Turn automatic collection on or off (it stays that way across sessions), or pause and "
         "resume it. It runs while Claude Code is open; collector_background keeps it running when Claude Code is closed.",
         _schema({"action": {"type": "string", "enum": ["enable", "disable", "pause", "resume"]}}, ["action"]),
         _ann(False, open_world=True), host.control),
        ("collector_background", "Collect also while Claude Code is closed: 'on' starts the bundled collector now and at "
         "every login (the person confirms in a dialog), 'off' stops it and removes the login item, 'status' reports it.",
         _schema({"action": {"type": "string", "enum": ["on", "off", "status"]}}, ["action"]),
         _ann(False, open_world=True), host.background),
        ("collector_collect_now", "Sync now: poll every enabled source (once, even if automatic collection is off), wait up "
         "to wait_s seconds for the transfers, then report status and how many new captures appeared.",
         _schema({"wait_s": {"type": "number", "minimum": 1, "maximum": 120}}), _ann(False, open_world=True), host.collect_now),
        ("collector_list_captures", "List collected recordings (capture ids, source, file name, acquisition status, size, "
         "format), optionally filtered by collector-clock time range, source or status. Paged.",
         _schema({"since": {"type": "string", "description": "ISO 8601 UTC, collector clock"},
                  "until": {"type": "string"}, "source_id": {"type": "string"},
                  "status": {"type": "string", "enum": ["active", "idle", "complete", "partial", "uncertain"]},
                  "offset": {"type": "integer", "minimum": 0}, "limit": {"type": "integer", "minimum": 1, "maximum": MAX_LIST}}),
         _ann(True), host.list_captures),
        ("collector_export", "Export collected recordings into a verified PitRelay Collector ZIP inside the collector store "
         "(private, not anonymized; never uploaded). Optionally a time range, sources, capture ids, attributed "
         "observations and the team's robot project source code (credentials excluded). Long exports continue as a job.",
         _schema({"since": {"type": "string"}, "until": {"type": "string"},
                  "source_ids": {"type": "array", "items": {"type": "string"}},
                  "capture_ids": {"type": "array", "items": {"type": ["string", "integer"]}},
                  "observations": {"type": "array", "items": {"type": "object", "properties": {
                      "author": {"type": "string"}, "observed_time_as_stated": {"type": "string"},
                      "text": {"type": "string"}, "related_capture_ids": {"type": "array", "items": {"type": "string"}}},
                      "required": ["text"]}},
                  "source_project_dir": {"type": "string", "description": "absolute path of the robot project to include"},
                  "label": {"type": "string"}, "max_archive_mb": {"type": "number", "minimum": 1},
                  "wait_s": {"type": "number", "minimum": 0, "maximum": 120}}),
         _ann(False), host.export),
        ("collector_job_status", "Wait for (up to wait_s seconds) and report a collector export or supply job.",
         _schema({"job_id": {"type": "string"}, "wait_s": {"type": "number", "minimum": 0, "maximum": 120}}, ["job_id"]),
         _ann(True), host.job_status),
        ("collector_supply_to_engine", "Verify a collector package ('latest' export, or the absolute path of a collector "
         ".zip) and supply its recordings to the PitRelay engine directly (no bytes pass through the conversation), "
         "inspecting each with the right PitRelay format. Returns each recording's artifact_id, inspection summary, "
         "acquisition status, gaps and limitations. Up to 25 recordings per call; use offset for more.",
         _schema({"package": {"type": "string", "description": "'latest' (default) or the absolute path of a collector "
                                                                ".zip; a path outside the collector's exports is confirmed "
                                                                "by the person"},
                  "capture_ids": {"type": "array", "items": {"type": ["string", "integer"]}},
                  "inspect": {"type": "boolean"}, "offset": {"type": "integer", "minimum": 0},
                  "workflow_id": {"type": "string", "description": "a PitRelay workflow to make the inspections in (the "
                                                                   "uploads are made outside it, so they use none of its "
                                                                   "calls)"},
                  "wait_s": {"type": "number", "minimum": 0, "maximum": 120}}),
         _ann(False), host.supply),
        ("collector_open_page", "Open the collector's local page in the person's browser, for what must not pass through "
         "the conversation (robot passwords) and for settings. The page's private link is never returned here.",
         _schema({}), _ann(False), host.open_page),
        ("collector_delete_captures", "Permanently delete captures from the local collector store after the person "
         "confirms in a dialog (never touches the robot). Exports list them as deleted by the user.",
         _schema({"capture_ids": {"type": "array", "items": {"type": ["string", "integer"]}}, "note": {"type": "string"}},
                 ["capture_ids"]), _ann(False, destructive=True), host.delete_captures),
    ]
    for name, description, schema, annotations, fn in tools:
        server.register(HostTool({"name": name, "description": description, "inputSchema": schema,
                                  "annotations": annotations}, g(fn)))
    return host
