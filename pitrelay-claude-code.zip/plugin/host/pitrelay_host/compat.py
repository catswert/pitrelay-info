"""Host notes for misleading results of the frozen PitRelay v11 engine.

The engine ships as a compiled jar without source and is never modified, and neither are its answers: every
engine result reaches Claude Code byte for byte, including its status. Where a v11 result is known to mislead,
the host adds a second, separately labelled text item after the engine's own ("Host note (PitRelay for Claude
Code, not the PitRelay engine) ..."). A note:
* is added only when the running engine is the inspected v11 build (by jar SHA-256) and notes are switched on
  in launch.json; any other build is relayed untouched, because it may behave differently;
* is added only when the engine's own result shows the symptom and the host's check of the file confirms the
  cause (from the first bytes of the artifact, read with the engine's own artifact.download, never with a
  workflow_id);
* corresponds to an issue in docs/PITRELAY_ENGINE_ISSUES.md.

Notes:
1. REVLOG v2 (issue 1). The v11 REV adapter decodes REVLOG v1 only. On a v2 file it answers `partial` with
   "Unknown REV native record ID 3" and "... ID 6" (or `no_match` for signals), which reads like a damaged file.
2. Driver Station format (issue 2). dslog and dsevents v4 share their header, so the wrong adapter accepts the
   file and reports `partial` (corrupt events, a truncated tail, or an unknown power-distribution block type).
   When the records clearly have the other format's structure, the note names the format to use.
3. Transfer id (issue 3). upload_begin returns the transfer id as `id`; upload_chunk and upload_finish take it as
   `transfer_id`.

Not changed on purpose (see the issues document): readOnlyHint (issue 6; the engine says every call may record
workflow state); the CSV time-unit status (issue 4; "unsupported" is right for real units the engine does not
implement, such as "ns"); several engines on one state (issue 6; the engine coordinates them with its own locks).
"""

from __future__ import annotations

import base64
import threading
from collections import OrderedDict

from pitrelay_collector.formats import ds_content_format, revlog_header_version

V11_ENGINE_SHA256 = "66de12d3968b0c7e360754fabb6db4661416b61129b3b2751bf19952c93ac5d2"
HEAD_BYTES = 49152  # one artifact.download chunk
LABEL = "Host note (PitRelay for Claude Code, not the PitRelay engine; {rule}, engine issue {issue})"
DS_FORMATS = {"dslog_v4": "dslog", "dsevents_v4": "dsevents"}
SYMPTOM_STATUSES = ("partial", "no_match", "not_applicable", "unsupported")

RULES = [
    {"rule": "revlog_v2", "engine_issue": 1,
     "what": "rev_native on a REVLOG v2 file: a note explains that the v11 adapter decodes REVLOG v1 only, so nothing "
             "was decoded and its unknown-record issues come from that, while other issues may still be real damage"},
    {"rule": "ds_format", "engine_issue": 2,
     "what": "dslog_v4/dsevents_v4 on a file whose records have the other structure: a note names the format to use"},
    {"rule": "upload_transfer_id", "engine_issue": 3,
     "what": "artifact.upload_begin: a note says to pass result.id as transfer_id"},
]
NOT_CHANGED = [
    {"engine_issue": 4, "what": "log.import_csv keeps the engine's 'unsupported' for a time_unit other than us, ms or s"},
    {"engine_issue": 6, "what": "readOnlyHint stays as the engine declares it (any call may record workflow state)"},
    {"engine_issue": 6, "what": "several engine processes may share a state folder; the engine coordinates them itself"},
]


def note(rule: str, issue: int, text: str) -> dict:
    return {"type": "text", "text": f"{LABEL.format(rule=rule, issue=issue)}: {text}"}


class Compat:
    def __init__(self, server):
        self.server = server
        self._heads: OrderedDict[str, bytes | None] = OrderedDict()
        self._lock = threading.Lock()

    @property
    def active(self) -> bool:
        return self.server.launch.get("host_notes", True) is not False and \
            self.server.engine.jar_sha256 == V11_ENGINE_SHA256

    def describe(self) -> dict:
        enabled = self.server.launch.get("host_notes", True) is not False
        return {"notes_active": self.active, "notes_enabled_at_setup": enabled,
                "applies_to_engine_sha256": V11_ENGINE_SHA256, "running_engine_sha256": self.server.engine.jar_sha256,
                "rules": RULES if self.active else [],
                "engine_results": "relayed byte for byte; notes are separate, labelled content items",
                "note": None if self.active else ("Host notes were switched off at setup." if not enabled else
                                                  "The running engine is not the inspected v11 build, so no notes are added."),
                "not_changed": NOT_CHANGED}

    # --- which results need a look ---

    @staticmethod
    def _format_pairs(args: dict) -> list[tuple[str, str]]:
        pairs = []
        for aid, fmt in (("artifact_id", "format"), ("other_artifact_id", "other_format")):
            if isinstance(args.get(aid), str) and args.get(fmt) in ("rev_native", *DS_FORMATS):
                pairs.append((args[aid], args[fmt]))
        return pairs

    def wants_notes(self, tool: str, args: dict, result: dict) -> bool:
        """Cheap test on the dispatcher thread: does this result need notes (which may need engine reads)?"""
        if not self.active:
            return False
        if tool == "pitrelay_artifact_upload_begin":
            return True
        return bool(self._format_pairs(args)) and _status(result) in SYMPTOM_STATUSES

    def head(self, artifact_id: str) -> bytes | None:
        with self._lock:
            if artifact_id in self._heads:
                self._heads.move_to_end(artifact_id)
                return self._heads[artifact_id]
        env = self.server.engine.call_tool("pitrelay_artifact_download", {"artifact_id": artifact_id, "offset": 0,
                                                                          "length": HEAD_BYTES})
        data = None
        res = env.get("result") if isinstance(env.get("result"), dict) else {}
        if env.get("status") == "ok" and isinstance(res.get("data_base64"), str):
            try:
                data = base64.b64decode(res["data_base64"], validate=True)
            except ValueError:
                data = None
        with self._lock:
            self._heads[artifact_id] = data  # an artifact's bytes never change
            while len(self._heads) > 256:
                self._heads.popitem(last=False)
        return data

    def notes(self, tool: str, args: dict, result: dict) -> list[dict]:
        """The notes for one engine result (may read artifact heads through the engine; worker thread only)."""
        if tool == "pitrelay_artifact_upload_begin":
            env = _envelope(result)
            res = env.get("result") if isinstance(env.get("result"), dict) else {}
            if env.get("status") == "ok" and isinstance(res.get("id"), str) and "transfer_id" not in res:
                return [note("upload_transfer_id", 3, f"pass this transfer's id, {res['id']}, as transfer_id to "
                                                      "artifact.upload_chunk and artifact.upload_finish.")]
            return []
        out = []
        for artifact_id, fmt in self._format_pairs(args):
            head = self.head(artifact_id)
            if not head:
                continue
            if fmt == "rev_native":
                version = revlog_header_version(head)
                if version is not None and version[0] >= 2:
                    out.append(note("revlog_v2", 1, (
                        f"{artifact_id} is a REVLOG v{version[0]}.{version[1]} file. The v11 engine's REV adapter decodes "
                        "REVLOG v1 only and does not know the v2 header and frame records (ids 3 and 6), so nothing was "
                        "decoded: the 'Unknown REV native record ID' issues come from that missing support. Other issues "
                        "the engine lists (a truncated tail, unknown header flags) may still describe real damage. Convert "
                        "the file to WPILOG with REV's own tools and supply that, or use an engine build with REVLOG v2 "
                        "support. (Checked on synthetic v2 files; no real v2 log was available.)")))
            else:
                content = ds_content_format(head)
                if content is not None and content != DS_FORMATS[fmt]:
                    other = f"{content}_v4"
                    out.append(note("ds_format", 2, (
                        f"the records of {artifact_id} have the {other} structure, not {fmt}. Both formats share the same "
                        f"20-byte header, so the {fmt} adapter accepted the file and reported what it could not read as "
                        f"damage. Call again with format \"{other}\". (Checked from the first {len(head)} bytes; tested on "
                        "synthetic files only.)")))
        return out


def _status(result: dict):
    return _envelope(result).get("status")


def _envelope(result: dict) -> dict:
    import json
    for part in result.get("content") or []:
        if isinstance(part, dict) and part.get("type") == "text":
            try:
                value = json.loads(part.get("text", ""))
            except ValueError:
                return {}
            return value if isinstance(value, dict) else {}
    return {}
