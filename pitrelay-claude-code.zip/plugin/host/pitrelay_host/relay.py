"""The MCP server Claude Code talks to: the engine's tools relayed unchanged, plus host tools.

Rules (checked against Claude Code 2.1.309 and the v11 engine):

* stdout carries only JSON-RPC, one ASCII-escaped object per line, through one writer. main.py moves the real
  stdout to a private descriptor first, so nothing else (a browser started for the collector page, a stray
  print) can write into the protocol.
* Answered here, at once: initialize (protocol 2025-06-18, the engine's instructions plus a host paragraph),
  ping, tools/list, unknown methods (-32601, including Claude Code's server/discover probe), notifications.
  The engine's tool list is cached in the state folder after its first start, so a connect never waits for Java.
* Only tools/call reaches the engine, through one queue: the engine handles one request at a time, so the host
  sends one at a time and Claude Code's own calls go before the host's background work (uploads by
  collector_supply_to_engine, reads for host notes). Requests over the engine's 1 MiB limit are refused here
  with the caller's id. Requests the engine makes are refused (-32601); its notifications are dropped (the v11
  engine sends neither).
* Engine results are relayed byte for byte (the text of every content item, status and isError unchanged).
  compat.py may append separately labelled host notes as extra content items.
* Each Claude Code session runs its own engine on the installation's state folder. The engine coordinates
  several processes on one state itself (file locks; e.g. upload_begin answers blocked TRANSFER_BUSY), as it
  does for PitRelay's own Companion and local HTTP processes.
* notifications/cancelled: a queued engine call is dropped; a running one finishes in the engine and its answer
  is discarded (the engine ignores cancellation); a host tool stops cooperatively and withdraws its dialog.
* Host tools run on worker threads and may ask the person through Claude Code's dialog (elicitation/create).
* Host tools set isError exactly when their result is an error, as the engine does for status "error".
"""

from __future__ import annotations

import calendar
import hashlib
import heapq
import itertools
import json
import os
import re
import shutil
import sys
import threading
import time
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeout
from pathlib import Path

from . import __version__
from .compat import Compat
from .engine import EngineProcess, EngineUnavailable, encode, engine_argv, engine_env

PROTOCOL = "2025-06-18"
OLDER_PROTOCOLS = ("2025-03-26", "2024-11-05")
MAX_TOOL_NAME = 64
ENGINE_MAX_REQUEST = 1024 * 1024  # the engine refuses longer request lines with an uncorrelatable id:null error
MAX_OUT_LINE = 15 * 1024 * 1024  # Claude Code closes the connection on a stdout line over 16 MiB
START_TIMEOUT_S = 120.0
INITIALIZE_WAIT_S = 5.0
TOOLS_WAIT_S = 20.0
INTERNAL_TIMEOUT_S = 180.0
RESTART_BACKOFF_S = 10.0
AUTO_START_RETRIES = 5  # own starts while no engine tool is listed (1, 2, 4, 8, 16 backoffs after each failed start)
BUSY_RETRIES = 8
LOG_KEEP_S = 7 * 86400
CLIENT, BACKGROUND = 0, 1  # engine queue priorities

HOST_INSTRUCTIONS = (
    "This server is PitRelay's unmodified engine behind a local host for Claude Code. Engine tools (pitrelay_*) are "
    "relayed unchanged; an extra content item that starts 'Host note (PitRelay for Claude Code, not the PitRelay "
    "engine' explains a known misleading v11 result and is not engine output. host_status reports the engine, the "
    "host notes and the collector."
)
COLLECTOR_INSTRUCTIONS = (
    " collector_* tools are PitRelay Collector, not the PitRelay engine: they read robots over SSH/SFTP and local "
    "log folders that the person confirmed, keep the logs in a private local store, export verified packages and "
    "supply recordings to the engine without the bytes passing through the conversation; collector_open_page serves "
    "a page on this computer only. Adding or widening sources, trusting a robot's SSH host key and deleting captures "
    "are confirmed in a Claude Code dialog, not by you; never ask for passwords in the conversation."
)


def _key(request_id) -> str:
    return json.dumps(request_id, sort_keys=True)


def text_result(payload, is_error: bool = False) -> dict:
    return {"content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False, separators=(",", ":"))}],
            "isError": bool(is_error)}


class NoElicitation(RuntimeError):
    """The client does not offer dialogs (no elicitation capability)."""


class Out:
    """Serialized writes of protocol lines to Claude Code."""

    def __init__(self, stream):
        self._s = stream
        self._lock = threading.Lock()
        self.closed = False

    def send(self, msg: dict) -> None:
        data = encode(msg)
        if len(data) > MAX_OUT_LINE and "id" in msg and "method" not in msg:
            data = encode({"jsonrpc": "2.0", "id": msg["id"], "result": text_result(
                {"status": "error", "produced_by": "pitrelay-claude-host",
                 "error": {"code": "RESULT_TOO_LARGE", "message": "The result is larger than Claude Code accepts; "
                                                                 "request a smaller page or window"}}, True)})
        with self._lock:
            if self.closed:
                return
            try:
                self._s.write(data)
                self._s.flush()
            except (BrokenPipeError, OSError, ValueError):
                self.closed = True


class CallContext:
    """What a host tool handler may use: cancellation, progress and asking the person."""

    def __init__(self, server: "HostServer", request_id, params: dict):
        self.server = server
        self.request_id = request_id
        self.cancelled = threading.Event()
        meta = params.get("_meta") if isinstance(params.get("_meta"), dict) else {}
        self.progress_token = meta.get("progressToken")
        self._progress = 0
        self._last_progress = 0.0

    def progress(self, message: str, force: bool = False) -> None:
        """A progress notification (also keeps Claude Code's idle timer from expiring on long waits)."""
        if self.progress_token is None or self.cancelled.is_set():
            return
        now = time.monotonic()
        if not force and now - self._last_progress < 10.0:
            return
        self._last_progress = now
        self._progress += 1
        self.server.out.send({"jsonrpc": "2.0", "method": "notifications/progress", "params": {
            "progressToken": self.progress_token, "progress": self._progress, "message": message[:200]}})

    def elicit(self, message: str, properties: dict, required: list[str], timeout: float = 900.0) -> dict:
        return self.server.elicit(message, properties, required, timeout, self)


class HostTool:
    def __init__(self, definition: dict, handler):
        self.definition = definition
        self.handler = handler  # handler(arguments: dict, ctx: CallContext) -> dict (a tools/call result)


class EngineRequest:
    def __init__(self, method: str, params: dict, priority: int, on_done):
        self.method, self.params, self.priority, self.on_done = method, params, priority, on_done
        self.cancelled = False
        self.data: bytes | None = None


class EngineHost:
    """The engine child: start-up, the tool list, and the one-at-a-time request queue."""

    def __init__(self, launch: dict, plugin_root: Path, server: "HostServer"):
        self.launch = launch
        self.plugin_root = Path(plugin_root)
        self.server = server
        self.state_root = Path(launch["state"])
        self.status = "starting"  # starting | ready | failed | stopped
        self.problem: str | None = None
        self.tools: list[dict] | None = None  # None until known (live or cached)
        self.tools_live = False
        self.server_info: dict = {}
        self.instructions: str = ""
        self.known = threading.Event()  # tools and instructions are known (cache or live), or start-up gave up
        self.booted = threading.Event()
        self.jar_sha256: str | None = None
        self.refused: str | None = None  # the jar is not the one setup recorded: no engine starts in this process
        self.restarts = 0
        self.orphans_done = threading.Event()  # the transfers of ended host processes were handled
        self._orphans_started = False
        self._auto_starts = 0
        self._proc: EngineProcess | None = None
        self._ids = itertools.count(1)
        self._queue: list = []
        self._seq = itertools.count()
        self._cv = threading.Condition()
        self._inflight_id = None
        self._inflight_reply: dict | None = None
        self._exited = False
        self._last_start = 0.0
        self._last_failure = 0.0  # when the last failed start ended
        self.cache_path = self.state_root / "host" / "engine-cache.json"
        # Each host process has its own engine stderr file: several sessions may run engines on one state.
        self.stderr_path = self.state_root / "host" / f"engine-stderr-{os.getpid()}.log"
        self.journal = TransferJournal(self.state_root / "host")
        prune_logs(self.state_root / "host")

    # --- cache ---

    def _argv_key(self) -> str:
        return hashlib.sha256(json.dumps(engine_argv(self.launch, self.plugin_root)).encode()).hexdigest()

    def _load_cache(self) -> None:
        try:
            cache = json.loads(self.cache_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        if isinstance(cache, dict) and cache.get("jar_sha256") == self.jar_sha256 and cache.get("argv_key") == self._argv_key() \
                and isinstance(cache.get("tools"), list):
            self.tools = cache["tools"]
            self.server_info = cache.get("server_info") or {}
            self.instructions = cache.get("instructions") or ""
            self.known.set()

    def _save_cache(self) -> None:
        try:
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.cache_path.with_name(f".{self.cache_path.name}.{uuid.uuid4().hex[:8]}")
            tmp.write_text(json.dumps({"jar_sha256": self.jar_sha256, "argv_key": self._argv_key(),
                                       "server_info": self.server_info, "instructions": self.instructions,
                                       "tools": self.tools}), encoding="utf-8")
            os.replace(tmp, self.cache_path)
        except OSError:
            pass

    # --- the dispatcher thread: start-up, then the queue ---

    def run(self) -> None:
        try:
            self._boot()
        finally:
            self.booted.set()
            self.known.set()
        while True:
            with self._cv:
                while not self._queue and self.status != "stopped":
                    delay = self._retry_delay()
                    if delay is not None and delay <= 0:
                        break
                    self._cv.wait(delay)
                if self.status == "stopped":
                    pending, self._queue = self._queue, []
                    break
                req = heapq.heappop(self._queue)[2] if self._queue else None
            if req is None:
                self._retry_start()
                continue
            if req.cancelled:
                continue
            try:
                self._ensure_running()
                # No data: the request only starts the engine (host_status, while no engine tool is listed).
                reply = self._exchange(req.data) if req.data is not None else {"jsonrpc": "2.0", "result": {}}
            except EngineUnavailable as e:
                reply = {"jsonrpc": "2.0", "error": {"code": -32603, "message": str(e)}, "_unavailable": True}
            except Exception as e:  # the dispatcher must never die: every queued call would wait forever
                log_exception(self.launch, "engine dispatcher")
                reply = {"jsonrpc": "2.0", "error": {"code": -32603, "message": f"Host error: {e.__class__.__name__}: {e}"},
                         "_unavailable": True}
            try:
                self.journal.observe(req.params, reply)
            except Exception:
                pass
            if not req.cancelled:
                try:
                    req.on_done(reply)
                except Exception:
                    log_exception(self.launch, "engine reply handling")
        for _, _, req in pending:
            if not req.cancelled:
                req.on_done({"jsonrpc": "2.0", "error": {"code": -32603, "message": "The host is shutting down"},
                             "_unavailable": True})

    def _boot(self) -> None:
        self.server.check_own_files()
        try:
            self._verify_jar()
        except EngineUnavailable as e:
            self._fail(str(e))
            return
        self._load_cache()
        try:
            self._start()
        except EngineUnavailable as e:
            self._fail(str(e))
        except Exception as e:
            log_exception(self.launch, "engine start")
            self._fail(f"The engine could not be started: {e.__class__.__name__}: {e}")
        if self.status == "ready":
            self._started()
        self.server.engine_tools_changed()

    def _fail(self, problem: str) -> None:
        with self._cv:
            self._last_failure = time.monotonic()
            if self.status != "stopped":
                self.status, self.problem = "failed", problem
            self._cv.notify_all()  # start_unlisted may wait for a running start

    def _verify_jar(self) -> None:
        """The jar about to run must be the one setup recorded (launch.json engine_sha256); checked before every start.
        A jar that differs, or cannot be read while a hash is recorded, is refused for the rest of this process."""
        expected = self.launch.get("engine_sha256")
        try:
            self.jar_sha256 = file_sha256(self.plugin_root / "engine" / "pitrelay.jar")
        except OSError as e:
            if expected:
                self._refuse(f"The engine jar cannot be read: {e}. Prepare the plugin again (configure_claude.py).")
            raise EngineUnavailable(f"The engine jar cannot be read: {e}") from None
        if expected and self.jar_sha256 != expected:
            self._refuse("engine/pitrelay.jar is not the engine recorded at setup; the plugin folder was changed. "
                         "Prepare it again (configure_claude.py).")

    def _refuse(self, problem: str) -> None:
        self.refused = problem
        self._fail(problem)
        self.tools, self.tools_live = None, False  # no tool of a jar that is not the recorded one stays listed
        raise EngineUnavailable(problem)

    def _started(self) -> None:
        """After this process's first successful start: abort the transfers of host processes that are gone."""
        if not self._orphans_started:
            self._orphans_started = True
            # Through the queue, so not on this (the dispatcher's) thread.
            threading.Thread(target=self._abort_orphans, name="pitrelay-orphans", daemon=True).start()

    def _abort_orphans(self) -> None:
        try:
            self.journal.abort_orphans(self)
        except Exception:
            log_exception(self.launch, "aborting interrupted transfers")
        finally:
            self.orphans_done.set()

    def _retry_delay(self) -> float | None:
        """Seconds until the engine is started again on its own, or None for never. Only while it failed and no tool
        list is known: Claude Code then lists no engine tool, so no engine call would start it. Counted from the end of
        the failed start, which can take START_TIMEOUT_S itself."""
        if self.status != "failed" or self.refused or self.tools is not None or self._auto_starts >= AUTO_START_RETRIES:
            return None
        return self._last_failure + RESTART_BACKOFF_S * 2 ** self._auto_starts - time.monotonic()

    def _retry_start(self) -> None:
        self._auto_starts += 1
        try:
            self._ensure_running()
        except EngineUnavailable:
            pass
        except Exception:  # the dispatcher must never die
            log_exception(self.launch, "engine start")

    def _spawn(self) -> EngineProcess:
        """Start the engine. Messages and the exit of an earlier (replaced) process are ignored."""
        (self.state_root / "tmp").mkdir(parents=True, exist_ok=True)
        box: dict = {}

        def on_message(msg: dict) -> None:
            if box.get("proc") is self._proc:
                self._on_message(msg)

        def on_exit() -> None:
            if box.get("proc") is self._proc:
                self._on_exit()

        proc = EngineProcess(engine_argv(self.launch, self.plugin_root), engine_env(self.launch), self.state_root,
                             self.stderr_path, on_message, on_exit)
        with self._cv:
            self._exited = False
            self._inflight_id, self._inflight_reply = None, None
        box["proc"] = self._proc = proc
        try:
            return proc.start()
        except EngineUnavailable:
            self._proc = None
            raise

    def _exchange(self, data: bytes, timeout: float | None = None) -> dict:
        """Send one request line and wait for its answer (or the engine's exit). Dispatcher thread only."""
        msg_id = json.loads(data)["id"]
        with self._cv:
            self._inflight_id, self._inflight_reply = msg_id, None
        try:
            self._proc.send_bytes(data)
        except EngineUnavailable:
            with self._cv:
                self._inflight_id = None
            raise
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cv:
            while self._inflight_reply is None and not self._exited:
                remaining = None if deadline is None else deadline - time.monotonic()
                if remaining is not None and remaining <= 0:
                    self._inflight_id = None
                    raise EngineUnavailable("The engine did not answer in time")
                self._cv.wait(remaining)
            reply, self._inflight_id, self._inflight_reply = self._inflight_reply, None, None
        if reply is None:
            if self.status == "stopped":
                raise EngineUnavailable("The host is shutting down")
            raise EngineUnavailable(self.problem or "The PitRelay engine stopped")
        return reply

    def _request_line(self, method: str, params: dict) -> bytes:
        return encode({"jsonrpc": "2.0", "id": next(self._ids), "method": method, "params": params})

    def _start(self) -> None:
        self._last_start = time.monotonic()
        self._verify_jar()
        self._spawn()
        try:
            init = self._exchange(self._request_line("initialize", {
                "protocolVersion": PROTOCOL, "capabilities": {},
                "clientInfo": {"name": "pitrelay-claude-host", "version": __version__}}), START_TIMEOUT_S)
            if "error" in init:
                raise EngineUnavailable(f"The engine refused initialization: {init['error']}")
            result = init.get("result") or {}
            self._proc.send({"jsonrpc": "2.0", "method": "notifications/initialized"})
            tools = self._list_tools(lambda m, p: self._exchange(self._request_line(m, p), START_TIMEOUT_S))
        except Exception:
            proc, self._proc = self._proc, None  # its exit is not reported: this error is the start's problem
            proc.stop(timeout=5)
            raise
        self.server_info = result.get("serverInfo") or {}
        self.instructions = result.get("instructions") or ""
        self.tools, self.tools_live = tools, True
        with self._cv:
            if self.status != "stopped":
                self.status, self.problem = "ready", None
            self._cv.notify_all()
        self.known.set()
        self._save_cache()

    @staticmethod
    def _list_tools(call) -> list[dict]:
        tools, cursor = [], None
        for _ in range(100):
            resp = call("tools/list", {"cursor": cursor} if cursor else {})
            if "error" in resp:
                raise EngineUnavailable(f"The engine did not list its tools: {resp['error']}")
            result = resp.get("result") or {}
            tools += [t for t in result.get("tools", []) if isinstance(t, dict) and isinstance(t.get("name"), str)]
            cursor = result.get("nextCursor")
            if not cursor:
                return tools
        raise EngineUnavailable("The engine's tool list did not end")

    def _ensure_running(self) -> None:
        if self.status == "ready" and self._proc is not None and self._proc.alive():
            return
        if self.status == "stopped":
            raise EngineUnavailable("The host is shutting down")
        if self.refused:
            raise EngineUnavailable(self.refused)
        # At most one start per RESTART_BACKOFF_S: counted from the end of a failed start, or from the start of an
        # engine that stopped.
        if self.status == "failed" and time.monotonic() - max(self._last_start, self._last_failure) < RESTART_BACKOFF_S:
            raise EngineUnavailable(self.problem or "The PitRelay engine is not running")
        with self._cv:
            if self.status == "stopped":
                raise EngineUnavailable("The host is shutting down")
            before = self.problem
            self.status = "starting"  # what host_status reports while the start runs (up to START_TIMEOUT_S)
            self.problem = "Starting the engine" + (f" again; the last problem: {before}" if before else "")
        try:
            self._start()
        except EngineUnavailable as e:
            self._fail(str(e))
            if self.refused:
                self.server.engine_tools_changed()  # the tools of the earlier start are withdrawn
            raise
        except Exception as e:  # never left "starting"
            self._fail(f"The engine could not be started: {e.__class__.__name__}: {e}")
            raise
        self.server.engine_tools_changed()
        self._started()

    # --- messages from the engine (reader thread) ---

    def _on_message(self, msg: dict) -> None:
        if "method" in msg:
            if "id" in msg and self._proc is not None:  # the v11 engine never asks the client anything
                try:
                    self._proc.send({"jsonrpc": "2.0", "id": msg["id"],
                                     "error": {"code": -32601, "message": "The host offers no client methods"}})
                except EngineUnavailable:
                    pass
            return
        with self._cv:
            if self._inflight_id is not None and (msg.get("id") == self._inflight_id
                                                  or (msg.get("id") is None and "error" in msg)):
                self._inflight_reply = msg
                self._cv.notify_all()
            # anything else answers nothing that is waiting: dropped

    def _on_exit(self) -> None:
        proc = self._proc
        if self.status != "stopped" and not self.refused:
            code = proc.exit_code if proc is not None else None
            tail = proc.stderr_tail(600).strip() if proc is not None else ""
            self.problem = (f"The PitRelay engine stopped (exit code {code}); it is restarted on the next call. The engine "
                            "keeps open upload transfers: continue each with the same transfer_id from its next offset, "
                            "or abort it." + (f" Last engine messages: {tail}" if tail else ""))
            if self.status == "ready":
                self.status = "failed"
                self.restarts += 1
        with self._cv:
            self._exited = True
            self._cv.notify_all()

    # --- API for the server and host tools ---

    def submit(self, method: str, params: dict, priority: int, on_done) -> EngineRequest:
        req = EngineRequest(method, params, priority, on_done)
        req.data = self._request_line(method, params)
        if len(req.data) > ENGINE_MAX_REQUEST:
            raise RequestTooLarge()
        with self._cv:
            if self.status == "stopped":
                raise EngineUnavailable("The host is shutting down")
            if self.refused:
                raise EngineUnavailable(self.refused)
            heapq.heappush(self._queue, (priority, next(self._seq), req))
            self._cv.notify_all()
        return req

    def start_unlisted(self, wait: float) -> None:
        """Start a failed engine whose tools are not known, through the queue, and wait at most `wait` seconds. Claude
        Code then lists no engine tool, so no engine call would start it. While a start runs, no other is queued: this
        waits for that one."""
        if self.refused or self.tools is not None:
            return
        done = threading.Event()
        req = EngineRequest("start", {}, CLIENT, lambda reply: done.set())  # no data: the queue only starts the engine
        with self._cv:
            if self.status == "starting":
                self._cv.wait_for(lambda: self.status != "starting", wait)
                return
            if self.status != "failed":
                return
            heapq.heappush(self._queue, (CLIENT, next(self._seq), req))
            self._cv.notify_all()
        if not done.wait(wait):
            req.cancelled = True

    def cancel(self, req: EngineRequest) -> None:
        req.cancelled = True

    def call(self, method: str, params: dict, timeout: float = INTERNAL_TIMEOUT_S, priority: int = BACKGROUND) -> dict:
        f: Future = Future()
        req = self.submit(method, params, priority, f.set_result)
        try:
            reply = f.result(timeout=timeout)
        except FutureTimeout:
            req.cancelled = True
            raise EngineUnavailable(f"The engine did not answer {method} within {int(timeout)} s"
                                    + ("; it is still being started" if self.status == "starting" else "")) from None
        if reply.get("_unavailable"):
            raise EngineUnavailable(reply["error"]["message"])
        return reply

    def call_tool_result(self, name: str, arguments: dict, timeout: float = INTERNAL_TIMEOUT_S) -> dict:
        """The host's own engine tool call (never with a workflow_id the person did not give); the tools/call result."""
        reply = self.call("tools/call", {"name": name, "arguments": arguments}, timeout)
        if "error" in reply:
            raise EngineUnavailable(f"The engine rejected {name}: {reply['error'].get('message')}")
        return reply.get("result") or {}

    def call_tool(self, name: str, arguments: dict, timeout: float = INTERNAL_TIMEOUT_S) -> dict:
        """The host's own engine tool call; returns the engine's JSON envelope."""
        return envelope_of(self.call_tool_result(name, arguments, timeout))

    def ensure(self, wait: float = START_TIMEOUT_S) -> None:
        """Wait for start-up. Whether the engine can answer is then decided per request: the queue restarts a stopped
        engine (at most every 10 s)."""
        if not self.booted.wait(wait):
            raise EngineUnavailable("The PitRelay engine is still starting; try again in a moment")
        if self.status == "stopped":
            raise EngineUnavailable("The host is shutting down")
        if self.refused:
            raise EngineUnavailable(self.refused)

    def stop(self) -> None:
        """Fast shutdown: end the engine's input; it finishes its current request and exits."""
        with self._cv:
            self.status = "stopped"
            self._cv.notify_all()
        proc = self._proc
        if proc is not None:
            proc.close_input()


class RequestTooLarge(ValueError):
    pass


def envelope_of(result: dict) -> dict:
    """The engine's JSON envelope from a tools/call result (the engine returns it as text content)."""
    if isinstance(result.get("structuredContent"), dict):
        return result["structuredContent"]
    for part in result.get("content") or []:
        if isinstance(part, dict) and part.get("type") == "text":
            try:
                value = json.loads(part.get("text", ""))
            except ValueError:
                break
            if isinstance(value, dict):
                return value
            break
    return {"status": "error", "error": {"code": "HOST_UNREADABLE_ENGINE_RESULT",
                                         "message": "The engine's answer was not a JSON object"}}


class HostServer:
    def __init__(self, launch: dict, plugin_root: Path, stdin=None, stdout=None):
        self.launch = launch
        self.plugin_root = Path(plugin_root)
        self.stdin = stdin if stdin is not None else sys.stdin.buffer
        self.out = Out(stdout if stdout is not None else sys.stdout.buffer)
        self.engine = EngineHost(launch, self.plugin_root, self)
        self.compat = Compat(self)
        self.pool = ThreadPoolExecutor(max_workers=8, thread_name_prefix="pitrelay-host")  # host tools, notes
        # initialize and tools/list never wait behind long host tools (dialogs, jobs)
        self.protocol_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="pitrelay-protocol")
        self.client_capabilities: dict = {}
        self.protocol = PROTOCOL
        self.initialized = threading.Event()
        self.host_tools: dict[str, HostTool] = {}
        self._aliases: dict[str, str] = {}  # listed name -> engine name (names shortened to fit 64 characters)
        self._listed: list[str] | None = None
        self._calls: dict[str, object] = {}  # client request key -> EngineRequest or CallContext
        self._my_requests: dict[str, Future] = {}
        self._ids = itertools.count(1)
        self._lock = threading.Lock()
        self.shutdown_hooks: list = []
        self.status_hooks: list = []
        self.initialized_hooks: list = []
        self.self_check: dict = {"status": "pending"}
        self._stopping = False
        self._register_status_tool()

    # --- plumbing ---

    def client_can_elicit(self) -> bool:
        return isinstance(self.client_capabilities.get("elicitation"), dict) and self.protocol >= PROTOCOL

    def elicit(self, message: str, properties: dict, required: list[str], timeout: float, ctx: CallContext) -> dict:
        """Ask through Claude Code's dialog. Returns {"action": accept|decline|cancel|error, "content": {...}}.

        Whoever answers is outside the model: the person, or an Elicitation hook or Agent SDK host they configured."""
        if not self.client_can_elicit():
            raise NoElicitation()
        rid = f"h{next(self._ids)}"
        f: Future = Future()
        with self._lock:
            self._my_requests[rid] = f
        self.out.send({"jsonrpc": "2.0", "id": rid, "method": "elicitation/create", "params": {
            "message": message, "requestedSchema": {"type": "object", "properties": properties, "required": required}}})
        deadline = time.monotonic() + timeout
        try:
            while True:
                try:
                    resp = f.result(timeout=0.5)
                    break
                except FutureTimeout:
                    if ctx.cancelled.is_set() or time.monotonic() > deadline:
                        self.out.send({"jsonrpc": "2.0", "method": "notifications/cancelled",
                                       "params": {"requestId": rid, "reason": "The tool call ended"}})
                        return {"action": "cancel", "content": {}}
        finally:
            with self._lock:
                self._my_requests.pop(rid, None)
        if "error" in resp:
            return {"action": "error", "content": {}, "error": resp["error"]}
        result = resp.get("result") or {}
        action = result.get("action")
        return {"action": action if action in ("accept", "decline", "cancel") else "error",
                "content": result.get("content") if isinstance(result.get("content"), dict) else {}}

    def check_own_files(self) -> None:
        """The host files that run must be the ones setup recorded (launch.json lists their SHA-256)."""
        expected = self.launch.get("host_files")
        if not isinstance(expected, dict):
            self.self_check = {"status": "not_recorded"}
            return
        changed = []
        for rel, sha in sorted(expected.items()):
            try:
                if file_sha256(self.plugin_root / rel) != sha:
                    changed.append(rel)
            except OSError:
                changed.append(rel)
        self.self_check = {"status": "ok" if not changed else "changed", "files_checked": len(expected),
                           **({"changed": changed[:20], "problem": "Host files differ from those recorded at setup; "
                                                                   "prepare the plugin again"} if changed else {})}

    def register(self, tool: HostTool) -> None:
        self.host_tools[tool.definition["name"]] = tool

    def reply(self, request_id, result=None, error=None) -> None:
        msg = {"jsonrpc": "2.0", "id": request_id}
        if error is not None:
            msg["error"] = error
        else:
            msg["result"] = result if result is not None else {}
        self.out.send(msg)

    def engine_tools_changed(self) -> None:
        """Tell Claude Code when the engine tools it was given differ from what is known now."""
        if self._listed is None or not self.initialized.is_set():
            return
        if [t["name"] for t in self.listed_tools(remember=False)] != self._listed:
            self.out.send({"jsonrpc": "2.0", "method": "notifications/tools/list_changed"})

    # --- the loop ---

    def serve(self) -> int:
        threading.Thread(target=self.engine.run, name="pitrelay-engine", daemon=True).start()
        try:
            for raw in self.stdin:
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    msg = json.loads(raw)
                except (ValueError, RecursionError):  # RecursionError: nested deeper than the parser allows
                    self.out.send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
                    continue
                if isinstance(msg, dict):
                    self._dispatch_safely(msg)
                else:
                    self.out.send({"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid request"}})
        finally:
            self.shutdown()
        return 0

    def shutdown(self) -> None:
        """Claude Code ends the host within half a second (SIGINT, SIGTERM, SIGKILL): stop without waiting."""
        with self._lock:
            if self._stopping:
                return
            self._stopping = True
            calls = list(self._calls.values())
        for c in calls:
            if isinstance(c, CallContext):
                c.cancelled.set()
        for hook in self.shutdown_hooks:
            try:
                hook()
            except Exception:
                pass
        self.engine.stop()
        self.out.closed = True

    def _dispatch_safely(self, msg: dict) -> None:
        """A message the host fails on is logged and, if it is a request, answered; the server keeps serving."""
        try:
            self.dispatch(msg)
        except Exception as e:
            log_exception(self.launch, "client message")
            if "id" not in msg or "method" not in msg:
                return
            try:
                with self._lock:
                    self._calls.pop(_key(msg["id"]), None)
                self.reply(msg["id"], error={"code": -32603, "message": f"Internal error: {e.__class__.__name__}"})
            except Exception:
                pass

    def dispatch(self, msg: dict) -> None:
        method = msg.get("method")
        if method is None:
            self._client_response(msg)
            return
        params = msg.get("params") if isinstance(msg.get("params"), dict) else {}
        if "id" not in msg:
            self._client_notification(method, params)
            return
        rid = msg["id"]
        if method == "initialize":
            self.protocol_pool.submit(self._initialize, rid, params)
        elif method == "ping":
            self.reply(rid, {})
        elif method == "tools/list":
            self.protocol_pool.submit(self._tools_list, rid)
        elif method == "tools/call":
            self._tools_call(rid, params)
        else:
            self.reply(rid, error={"code": -32601, "message": f"Method not found: {method}"})

    def _client_notification(self, method: str, params: dict) -> None:
        if method == "notifications/initialized":
            if not self.initialized.is_set():
                self.initialized.set()
                for hook in self.initialized_hooks:
                    hook()
        elif method == "notifications/cancelled":
            with self._lock:
                call = self._calls.pop(_key(params.get("requestId")), None)
            if isinstance(call, EngineRequest):
                self.engine.cancel(call)
            elif isinstance(call, CallContext):
                call.cancelled.set()

    def _client_response(self, msg: dict) -> None:
        rid = msg.get("id")
        with self._lock:
            f = self._my_requests.get(rid) if isinstance(rid, str) else None
        if f is not None and not f.done():
            f.set_result(msg)

    def _finish(self, rid, result=None, error=None) -> None:
        """Answer a tools/call unless it was cancelled."""
        with self._lock:
            live = self._calls.pop(_key(rid), None) is not None
        if live:
            self.reply(rid, result, error)

    # --- MCP methods ---

    def _initialize(self, rid, params: dict) -> None:
        requested = params.get("protocolVersion")
        self.protocol = requested if requested in OLDER_PROTOCOLS else PROTOCOL
        caps = params.get("capabilities")
        self.client_capabilities = caps if isinstance(caps, dict) else {}
        self.engine.known.wait(INITIALIZE_WAIT_S)
        instructions = (self.engine.instructions + "\n\n" if self.engine.instructions else "") + HOST_INSTRUCTIONS \
            + (COLLECTOR_INSTRUCTIONS if self.launch.get("collector") else "")
        engine = self.engine.server_info
        title = f"PitRelay host {__version__}" + (
            f" for engine {engine.get('name', 'pitrelay')} {engine.get('version', '')}".rstrip() if engine else "") + (
            f" (jar {self.engine.jar_sha256[:12]})" if self.engine.jar_sha256 else "")
        self.reply(rid, {"protocolVersion": self.protocol, "capabilities": {"tools": {"listChanged": True}},
                         "serverInfo": {"name": "pitrelay-claude-host", "title": title, "version": __version__},
                         "instructions": instructions})

    def listed_tools(self, remember: bool = True) -> list[dict]:
        prefix_len = len(self.launch.get("tool_name_prefix") or "")
        tools, aliases = [], {}
        for t in self.engine.tools or []:
            name = t["name"]
            if name in self.host_tools:
                continue
            if prefix_len + len(name) > MAX_TOOL_NAME:
                # Engine issue 6: Claude Code does not shorten mcp__plugin_<plugin>_<server>__<tool>, and the model API
                # rejects names over 64 characters (which would break every tool). List a shortened alias instead.
                keep = MAX_TOOL_NAME - prefix_len - 7
                alias = f"{name[:keep]}_{hashlib.sha256(name.encode()).hexdigest()[:6]}"
                aliases[alias] = name
                t = {**t, "name": alias, "description": f"{t.get('description', '')} [PitRelay tool {name}, listed as "
                                                        f"{alias} to fit Claude Code's 64-character tool-name limit]"}
            tools.append(t)
        listed = tools + [ht.definition for ht in self.host_tools.values()]
        if remember:
            self._aliases = aliases
            self._listed = [t["name"] for t in listed]
        return listed

    def _tools_list(self, rid) -> None:
        self.engine.known.wait(TOOLS_WAIT_S)
        self.reply(rid, {"tools": self.listed_tools()})

    def _tools_call(self, rid, params: dict) -> None:
        name = params.get("name")
        if not isinstance(name, str):
            self.reply(rid, error={"code": -32602, "message": "Tool name missing or not a string"})
            return
        arguments = params.get("arguments") if isinstance(params.get("arguments"), dict) else {}
        key = _key(rid)
        if name in self.host_tools:
            ctx = CallContext(self, rid, params)
            with self._lock:
                self._calls[key] = ctx
            self.pool.submit(self._run_host_tool, rid, self.host_tools[name], arguments, ctx)
            return
        engine_name = self._aliases.get(name, name)
        with self._lock:
            self._calls[key] = True
        self._forward_call(rid, engine_name, arguments, {**params, "name": engine_name})

    def _run_host_tool(self, rid, tool: HostTool, arguments: dict, ctx: CallContext) -> None:
        try:
            result = tool.handler(arguments, ctx)
        except EngineUnavailable as e:
            result = self._unavailable_result(e)
        except Exception as e:  # report, never crash the host
            log_exception(self.launch, f"host tool {tool.definition['name']}")
            result = text_result({"status": "error", "error": {"code": "HOST_INTERNAL_ERROR",
                                                               "message": f"{e.__class__.__name__}: {e}"}}, True)
        self._finish(rid, result)

    def _forward_call(self, rid, engine_name: str, arguments: dict, forwarded: dict, attempt: int = 0) -> None:
        key = _key(rid)

        def on_done(msg: dict) -> None:
            if engine_name == "pitrelay_artifact_upload_begin" and attempt < BUSY_RETRIES and _transfer_busy(msg):
                # Another session's engine was admitting a transfer at that instant; a blocked begin admitted nothing,
                # so asking again is safe. Never on the dispatcher thread: retry from a timer.
                with self._lock:
                    live = key in self._calls
                if live:
                    t = threading.Timer(min(0.25 * (attempt + 1), 2.0), self._forward_call,
                                        (rid, engine_name, arguments, forwarded, attempt + 1))
                    t.daemon = True
                    t.start()
                    return
            if msg.get("_unavailable"):
                self._finish(rid, self._unavailable_result(EngineUnavailable(msg["error"]["message"])))
                return
            if "error" in msg:
                self._finish(rid, error=msg["error"])
                return
            result = msg.get("result") or {}
            try:
                wants = self.compat.wants_notes(engine_name, arguments, result)
            except Exception:
                wants = False
            if wants:  # notes may read the artifact through the engine: never on this (the dispatcher's) thread
                self.pool.submit(self._finish_with_notes, rid, engine_name, arguments, result)
            else:
                self._finish(rid, result)

        try:
            req = self.engine.submit("tools/call", forwarded, CLIENT, on_done)
        except RequestTooLarge:
            self._finish(rid, text_result({"status": "error", "produced_by": "pitrelay-claude-host", "error": {
                "code": "REQUEST_TOO_LARGE", "message": "This request is larger than the engine's 1 MiB limit; send "
                                                        "smaller chunks (at most 49152 bytes per upload_chunk)"}}, True))
            return
        except EngineUnavailable as e:
            self._finish(rid, self._unavailable_result(e))
            return
        with self._lock:
            if key in self._calls:
                self._calls[key] = req
            else:
                req.cancelled = True  # cancelled before it was queued (or while a retry waited)

    def _finish_with_notes(self, rid, engine_name: str, arguments: dict, result: dict) -> None:
        try:
            notes = self.compat.notes(engine_name, arguments, result)
        except Exception:  # a note that cannot be made never holds back the engine's answer
            log_exception(self.launch, f"host notes for {engine_name}")
            notes = []
        if notes:
            result = {**result, "content": [*(result.get("content") or []), *notes]}
        self._finish(rid, result)

    @staticmethod
    def _unavailable_result(e: Exception) -> dict:
        return text_result({"status": "error", "produced_by": "pitrelay-claude-host",
                            "error": {"code": "ENGINE_UNAVAILABLE", "message": str(e)}}, True)

    # --- host_status ---

    def _register_status_tool(self) -> None:
        self.register(HostTool({
            "name": "host_status",
            "description": "PitRelay host: engine state (starting, ready, failed or stopped) and its problem, engine build "
                           "and identity, which compatibility fixes are active, the collector's availability, and "
                           "versions. Each Claude Code session runs its own engine. Call it first when engine tools fail "
                           "or before reporting the setup; when no engine tool is listed, it also tries to start the "
                           "engine again.",
            "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "openWorldHint": False},
            "_meta": {"anthropic/alwaysLoad": True},
        }, self._host_status))

    def _host_status(self, arguments: dict, ctx: CallContext) -> dict:
        self.engine.booted.wait(START_TIMEOUT_S)
        e = self.engine
        e.start_unlisted(TOOLS_WAIT_S)
        status = {
            "host": {"name": "pitrelay-claude-host", "version": __version__, "protocol": self.protocol,
                     "dialogs_offered_by_client": self.client_can_elicit(), "self_check": self.self_check,
                     "plugin_folder": str(self.plugin_root), "logs": str(Path(self.launch["state"]) / "host"),
                     "engine_state": str(Path(self.launch["state"]) / "engine")},
            "engine": {"status": e.status, "problem": e.problem, "server_info": e.server_info,
                       "jar_sha256": e.jar_sha256, "tools": len(e.tools or []), "restarts": e.restarts,
                       "access": "workspace" if self.launch.get("workspace") else "standard",
                       "workspace": self.launch.get("workspace"), "workspace_grants": self.launch.get("workspace_grants")},
            "compatibility": self.compat.describe(),
            "collector": {"included": bool(self.launch.get("collector"))},
        }
        for hook in self.status_hooks:
            hook(status)
        return text_result(status)


def log_exception(launch: dict, what: str) -> None:
    import traceback
    try:
        path = Path(launch["state"]) / "host" / "host-errors.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and path.stat().st_size > 1024 * 1024:
            os.replace(path, path.with_suffix(".1.log"))
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {what}\n{traceback.format_exc()}\n")
    except OSError:
        pass


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _transfer_busy(msg: dict) -> bool:
    env = envelope_of(msg.get("result") or {}) if "result" in msg else {}
    res = env.get("result") if isinstance(env.get("result"), dict) else {}
    return env.get("status") == "blocked" and res.get("code") == "TRANSFER_BUSY"


def pid_alive(pid: int) -> bool:
    if pid == os.getpid():
        return True
    if os.name == "nt":  # pragma: no cover - Windows only, UNVERIFIED
        import ctypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        handle = k32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        code = ctypes.c_ulong()
        k32.GetExitCodeProcess(handle, ctypes.byref(code))
        k32.CloseHandle(handle)
        return code.value == 259  # STILL_ACTIVE
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def process_start_time(pid: int) -> int | None:
    """When a process started, to tell it from a later process with the same pid. Linux: field 22 of /proc/<pid>/stat
    (clock ticks after boot); Windows: the creation time from GetProcessTimes; macOS: `ps -o lstart=` in seconds.
    None when it cannot be read. (Windows and macOS: UNVERIFIED.)"""
    if os.name == "nt":  # pragma: no cover - Windows only, UNVERIFIED
        return _windows_start_time(pid)
    try:
        with open(f"/proc/{int(pid)}/stat", "rb") as f:
            fields = f.read().rsplit(b")", 1)[1].split()  # after the command name, which may hold spaces and ')'
        return int(fields[19])  # the list starts at field 3
    except (OSError, ValueError, IndexError):
        pass
    if sys.platform == "darwin":  # pragma: no cover - macOS only, UNVERIFIED
        return _ps_start_time(pid)
    return None


def _ps_start_time(pid: int) -> int | None:
    """A process's start time from `ps -o lstart=`, in seconds since the epoch. ps prints wall-clock time: TZ=UTC0
    makes it print UTC, and calendar.timegm reads it as UTC, so hosts started with different TZ settings (or after the
    system zone changed) compute the same value for one process. (BSD and procps ps print the same format.)"""
    import subprocess
    try:
        done = subprocess.run(["/bin/ps", "-o", "lstart=", "-p", str(int(pid))], capture_output=True, timeout=5,
                              env={"LC_ALL": "C", "TZ": "UTC0", "PATH": "/usr/bin:/bin"}, stdin=subprocess.DEVNULL)
        return _lstart_seconds(done.stdout.decode("ascii", "replace"))
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def _lstart_seconds(text: str) -> int:
    """ps's lstart in the C locale and UTC ('Fri Oct 23 19:34:44 2026') as seconds since the epoch; ValueError if not."""
    return calendar.timegm(time.strptime(text.strip(), "%a %b %d %H:%M:%S %Y"))


def _windows_start_time(pid: int) -> int | None:  # pragma: no cover - Windows only, UNVERIFIED
    import ctypes
    from ctypes import wintypes
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.OpenProcess.restype = wintypes.HANDLE
    handle = k32.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return None
    try:
        times = [wintypes.FILETIME() for _ in range(4)]
        if not k32.GetProcessTimes(wintypes.HANDLE(handle), *[ctypes.byref(t) for t in times]):
            return None
        return (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime
    finally:
        k32.CloseHandle(wintypes.HANDLE(handle))


def prune_logs(folder: Path) -> None:
    """Old per-process engine logs (best effort; another session may be writing its own)."""
    try:
        for f in folder.glob("engine-stderr-*.log"):
            try:
                if time.time() - f.stat().st_mtime > LOG_KEEP_S:
                    f.unlink()
            except OSError:
                pass
    except OSError:
        pass


class TransferJournal:
    """Upload transfers this process opened and the engine still holds open. Claude Code ends the host without
    warning, and an unfinished transfer keeps a partial file and one of the engine's four transfer places; the next
    host aborts the transfers of processes that are gone (with the engine's own artifact.upload_abort).

    Each host process has its own file, open-transfers-<pid>-<random>.json, with its pid and (on Linux) its start time,
    so a later process that gets the same pid never takes it for its own. Files of earlier host versions,
    open-transfers-<pid>.json, are still read."""

    def __init__(self, folder: Path, engine_state: Path | None = None):
        self.pid = os.getpid()
        self.started = process_start_time(self.pid)
        self.path = Path(folder) / f"open-transfers-{self.pid}-{uuid.uuid4().hex[:12]}.json"
        self.engine_state = Path(engine_state) if engine_state is not None else Path(folder).parent / "engine"
        self.open: set[str] = set()
        self._lock = threading.Lock()

    def _write(self) -> None:
        try:
            if self.open:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                _replace_json(self.path, {"pid": self.pid, "started": self.started, "transfers": sorted(self.open)})
            elif self.path.exists():
                self.path.unlink()
        except OSError:
            pass

    def observe(self, params: dict, reply: dict) -> None:
        """Called for every engine reply (relayed and the host's own)."""
        name = params.get("name") if isinstance(params, dict) else None
        if name not in ("pitrelay_artifact_upload_begin", "pitrelay_artifact_upload_finish", "pitrelay_artifact_upload_abort"):
            return
        env = envelope_of(reply.get("result") or {}) if "result" in reply else {}
        with self._lock:
            if name == "pitrelay_artifact_upload_begin":
                res = env.get("result") if isinstance(env.get("result"), dict) else {}
                if env.get("status") == "ok" and isinstance(res.get("id"), str):
                    self.open.add(res["id"])
                else:
                    return
            else:
                args = params.get("arguments") if isinstance(params.get("arguments"), dict) else {}
                tid = args.get("transfer_id")
                if not isinstance(tid, str) or tid not in self.open or not self.settled(name, env, tid):
                    return
                self.open.discard(tid)
            self._write()

    def settled(self, name: str, env: dict, tid: str) -> bool:
        """Whether the engine's answer to upload_finish or upload_abort leaves nothing open for the transfer.

        The v11 engine (checked with its jar): finish answers ok once the artifact is published; abort answers ok with
        state "aborted" (also when repeated), and blocked TRANSFER_FINISHED for a published transfer. An unknown id
        answers error TRANSFER_ID when malformed, and error IO_FAILURE (it cannot read the transfer's record) when
        well-formed; IO_FAILURE can also be a real file error, so it counts only when the engine state holds no record
        of the transfer. Every other answer leaves the transfer open in the engine: blocked TRANSFER_INCOMPLETE (finish
        too early), error TRANSFER_INTEGRITY (wrong hash), blocked TRANSFER_BUSY (another process holds it), JSON-RPC
        errors and no answer."""
        status = env.get("status")
        code = env["result"].get("code") if isinstance(env.get("result"), dict) else None
        if status == "ok":
            return True
        if name == "pitrelay_artifact_upload_abort" and status == "blocked" and code == "TRANSFER_FINISHED":
            return True
        if status == "error" and code == "TRANSFER_ID":
            return True
        return status == "error" and code == "IO_FAILURE" and not self._engine_has_record(tid)

    def _engine_has_record(self, tid: str) -> bool:
        """Whether the engine state holds the transfer's record (engine/ws-*/transfers/<id>.json); when unsure, yes."""
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,199}", tid):
            return True
        try:
            return any((ws / "transfers" / f"{tid}.json").exists() for ws in self.engine_state.glob("ws-*"))
        except OSError:
            return True

    def abort_orphans(self, engine: "EngineHost") -> int:
        """Abort the transfers of host processes that are gone; returns how many were aborted. Each journal file is
        handled on its own, so a damaged one never stops the others."""
        aborted: list[str] = []
        for f in sorted(self.path.parent.glob("open-transfers-*.json")):
            if f == self.path:
                continue
            try:
                self._abort_journal(f, engine, aborted)
            except EngineUnavailable:
                break  # the engine is gone: the next host tries again
            except Exception:
                launch = getattr(engine, "launch", None)
                if isinstance(launch, dict):
                    log_exception(launch, f"aborting the transfers in {f.name}")
        return len(aborted)

    def _abort_journal(self, f: Path, engine: "EngineHost", aborted: list[str]) -> None:
        try:
            text = f.read_text(encoding="utf-8")
        except FileNotFoundError:
            return  # another host just handled it
        entry = _journal_entry(text)
        if entry is None:  # not a journal a host wrote: removed once it is as old as the kept logs
            if time.time() - f.stat().st_mtime > LOG_KEEP_S:
                f.unlink()
            return
        pid, started, transfers = entry
        if not self._orphaned(f.name, pid, started):
            return
        left: list[str] = []
        try:
            for i, tid in enumerate(transfers):
                try:
                    env = engine.call_tool("pitrelay_artifact_upload_abort", {"transfer_id": tid}, timeout=30)
                    done = self.settled("pitrelay_artifact_upload_abort", env, tid)
                except Exception:
                    left += transfers[i:]
                    raise
                (aborted if done else left).append(tid)
        finally:
            # The file keeps the transfers whose abort did not answer that they are closed (e.g. TRANSFER_BUSY).
            if not left:
                f.unlink(missing_ok=True)
            elif left != transfers:
                _replace_json(f, {"pid": pid, "started": started, "transfers": left})

    def _orphaned(self, name: str, pid: int, started: int | None) -> bool:
        if not pid_alive(pid):
            return True
        if re.fullmatch(r"open-transfers-\d+\.json", name):  # an earlier host version's file, never this process's
            return pid == self.pid
        if started is None:
            # Written where the start time could not be read: a file under this process's own pid that is not this
            # process's file was left by an earlier process (one host per process).
            return pid == self.pid
        now = process_start_time(pid)
        return now is not None and now != started  # the pid now belongs to a later process


def _journal_entry(text: str) -> tuple[int, int | None, list[str]] | None:
    """(pid, start time, transfer ids) of a journal file, or None when it is not one."""
    try:
        data = json.loads(text)
    except (ValueError, RecursionError):
        return None
    if not isinstance(data, dict):
        return None
    pid, started, transfers = data.get("pid"), data.get("started"), data.get("transfers")
    if type(pid) is not int or not 0 < pid < 2 ** 31 or not isinstance(transfers, list):
        return None
    if started is not None and type(started) is not int:
        return None
    return pid, started, [t for t in transfers if isinstance(t, str)]


def _replace_json(path: Path, data: dict) -> None:
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex[:8]}.tmp")
    try:
        tmp.write_text(json.dumps(data), encoding="utf-8")
        os.replace(tmp, path)
    except OSError:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
