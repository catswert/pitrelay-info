"""Start the host from host/launch.json (written by configure_claude.py, pinned in its receipt)."""

from __future__ import annotations

import json
import os
import signal
import sys
from pathlib import Path

LAUNCH_SCHEMA = "1.0"


class LaunchError(RuntimeError):
    pass


def load_launch(host_dir: Path) -> dict:
    path = Path(host_dir) / "launch.json"
    try:
        launch = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise LaunchError(f"Cannot read {path}: {e}") from None
    if not isinstance(launch, dict) or launch.get("schema_version") != LAUNCH_SCHEMA:
        raise LaunchError(f"{path} is not a launch file of schema {LAUNCH_SCHEMA}")
    for key in ("java", "state", "tool_name_prefix"):
        if not isinstance(launch.get(key), str) or not launch[key]:
            raise LaunchError(f"{path} lacks {key}")
    if launch.get("workspace") is not None and not isinstance(launch["workspace"], str):
        raise LaunchError(f"{path} has a malformed workspace")
    if not isinstance(launch.get("workspace_grants", []), list):
        raise LaunchError(f"{path} has malformed workspace grants")
    return launch


def protocol_streams():
    """Move the protocol to private descriptors before anything else can write to stdout or read stdin.

    Children (a browser opened for the collector page, the engine) and stray prints then see stderr as stdout
    and an empty stdin, so they can never corrupt or steal a protocol line."""
    proto_in = os.fdopen(os.dup(0), "rb")
    proto_out = os.fdopen(os.dup(1), "wb")
    devnull = os.open(os.devnull, os.O_RDONLY)
    os.dup2(devnull, 0)
    os.close(devnull)
    os.dup2(2, 1)
    sys.stdin = open(os.devnull, "r", encoding="utf-8")
    sys.stdout = sys.stderr
    return proto_in, proto_out


def main(host_dir: str) -> int:
    host_dir = Path(host_dir)
    try:
        launch = load_launch(host_dir)
    except LaunchError as e:
        print(f"PitRelay host: {e}", file=sys.stderr)
        return 2
    from .relay import HostServer

    proto_in, proto_out = protocol_streams()

    def stop(signum, frame):
        raise SystemExit(0)
    # Claude Code ends a stdio server with SIGINT, then SIGTERM after 100 ms and SIGKILL after 500 ms.
    for sig in (getattr(signal, "SIGINT", None), getattr(signal, "SIGTERM", None), getattr(signal, "SIGHUP", None)):
        if sig is not None:
            try:
                signal.signal(sig, stop)
            except (ValueError, OSError):
                pass
    plugin_root = Path(launch["plugin_root"]) if isinstance(launch.get("plugin_root"), str) else host_dir.parent
    server = HostServer(launch, plugin_root, proto_in, proto_out)
    if launch.get("collector"):
        from .collector_tools import install
        install(server)
    code = 0
    try:
        code = server.serve()
    except SystemExit:
        server.shutdown()
    finally:
        try:
            proto_out.flush()
        except OSError:
            pass
        # Worker threads may be waiting on dialogs or jobs; nothing they hold needs an orderly exit (the collector
        # store is crash-safe, and the engine finishes its current request once its input is closed, then exits),
        # so do not wait for them.
        os._exit(code)
    return code
