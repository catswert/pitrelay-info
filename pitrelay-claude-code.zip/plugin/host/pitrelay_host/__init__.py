"""PitRelay host for Claude Code: one local MCP server in front of the unmodified PitRelay engine.

It relays the engine's own tools unchanged, adds PitRelay Collector tools, and applies a small, labelled
compatibility layer for problems observed in the frozen v11 engine (see docs/HOST.md).
"""

__version__ = "2.0.0"
