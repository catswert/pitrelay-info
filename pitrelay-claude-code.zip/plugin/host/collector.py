"""The bundled PitRelay Collector's command line, for the person's own terminal:

    <python> -I -B -X utf8 <plugin>/host/collector.py <command> [...]

Same commands as the standalone `pitrelay-collector` (status, open-ui, run, export, verify, ...), defaulting to
this installation's collector store. `run` keeps collecting while Claude Code is closed; launch at login, turned
on from the collector page, starts exactly this command.
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from pitrelay_collector import autostart  # noqa: E402
from pitrelay_collector.cli import main  # noqa: E402
from pitrelay_host.main import LaunchError, load_launch  # noqa: E402

if __name__ == "__main__":
    try:
        launch = load_launch(HERE)
    except LaunchError as e:
        print(f"PitRelay collector: {e}", file=sys.stderr)
        sys.exit(2)
    if not launch.get("collector"):
        print("This installation was prepared without the collector.", file=sys.stderr)
        sys.exit(2)
    autostart.BUNDLED = {"script": os.path.abspath(__file__), "ident": "claude", "store": launch["collector_store"]}
    sys.exit(main())
