#!/bin/sh
# PitRelay for Claude Code installer for macOS and Linux. Same as: python3 install.py [options]
here=$(cd "$(dirname "$0")" && pwd)
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3.10 or later is needed, and python3 was not found." >&2
  exit 1
fi
exec python3 "$here/install.py" "$@"
