"""PitRelay for Claude Code: install straight from the downloaded ZIP.

    python3 pitrelay-claude-code.zip [install | verify | uninstall] [options]      (Windows: py -3 ...)

Python runs this file when it is given the ZIP itself. It unpacks the ZIP into the installer's own folder
(downloads/<version>/ inside it; the same ZIP is unpacked once) and runs install.py from there, with the same
arguments. Started from an unpacked copy, it runs the install.py next to it.

Standard library only. Written so that an older Python (3.6 and later) can still start it: from 3.7 it hands over
to a newer Python by itself, and 3.6 says what to install.
"""
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))


def intact(folder):
    """Every file SHA256SUMS.txt lists is there, unchanged (an earlier unpacked copy is reused only then)."""
    import hashlib

    try:
        with open(os.path.join(folder, "SHA256SUMS.txt"), encoding="utf-8") as f:
            lines = [line.rstrip("\n").split("  ", 1) for line in f if line.strip()]
        for digest, name in lines:
            h = hashlib.sha256()
            with open(os.path.join(folder, *name.split("/")), "rb") as g:
                for block in iter(lambda: g.read(1 << 20), b""):
                    h.update(block)
            if h.hexdigest() != digest:
                return False
        return bool(lines)
    except (OSError, ValueError):
        return False


def unpack(archive, argv):
    import hashlib
    import json
    import shutil

    import install  # from the ZIP itself (Python puts the archive first on sys.path)

    folder = None
    for i, a in enumerate(argv):
        if a == "--folder" and i + 1 < len(argv):
            folder = argv[i + 1]
        elif a.startswith("--folder="):
            folder = a.split("=", 1)[1]
    base = os.path.abspath(os.path.expanduser(folder)) if folder else str(install.default_base())
    h = hashlib.sha256()
    with open(archive, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    with zipfile.ZipFile(archive) as z:
        bundle = json.loads(z.read("BUNDLE.json").decode("utf-8"))["bundle"]
        target = os.path.join(base, "downloads", f"{bundle}-{h.hexdigest()[:12]}")
        if os.path.isfile(os.path.join(target, ".unpacked")) and intact(target):
            return target
        names = z.namelist()
        for n in names:
            parts = n.replace("\\", "/").split("/")
            if n.startswith(("/", "\\")) or ".." in parts or ":" in parts[0]:
                raise SystemExit(f"Refusing to unpack {archive}: unsafe name {n!r}")
        print(f"Unpacking this download into {target}", flush=True)
        tmp = target + ".partial"
        if os.path.exists(tmp):
            shutil.rmtree(tmp)
        os.makedirs(tmp)
        for n in names:
            if n.endswith("/"):
                continue
            dest = os.path.join(tmp, *n.split("/"))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(n) as src, open(dest, "wb") as out:
                shutil.copyfileobj(src, out)
        with open(os.path.join(tmp, ".unpacked"), "w", encoding="utf-8") as f:
            f.write(archive + "\n")
    if os.path.exists(target):
        shutil.rmtree(target)
    os.replace(tmp, target)
    return target


def main():
    import subprocess

    if sys.version_info < (3, 7):
        print("Python %d.%d is too old for this installer. Install Python 3.12 from https://www.python.org/downloads/ "
              "and run this again with it." % sys.version_info[:2], flush=True)
        return 1
    import install  # from the ZIP, or from beside this file

    argv = sys.argv[1:]
    if os.path.isfile(HERE) and zipfile.is_zipfile(HERE):
        install.ensure_python([HERE, *argv])
        folder = unpack(HERE, argv)
    else:
        folder = HERE
    # Ctrl-C reaches install.py too; wait for it to finish cleaning up rather than returning to the prompt early.
    code, _, _ = install.wait_patiently(
        subprocess.Popen([sys.executable, os.path.join(folder, "install.py"), *argv]), quiet=True)
    return code


if __name__ == "__main__":
    sys.exit(main())
