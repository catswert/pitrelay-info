"""Install PitRelay for Claude Code from this download.

    python3 pitrelay-claude-code.zip              install, or upgrade an earlier installation
    python3 pitrelay-claude-code.zip verify       check the installed copy
    python3 pitrelay-claude-code.zip uninstall    remove it from Claude Code (logs and PitRelay state are kept)
    python3 pitrelay-claude-code.zip doctor       show the Python, Java and Claude Code the installer finds
    python3 pitrelay-claude-code.zip --help       all options
(Windows: py instead of python3. In an unpacked copy, python3 install.py ... is the same.)

The installer is a thin wrapper around plugin/configure_claude.py, which does the real work and all the checks
(INSTALL.md describes them). It adds: checking this download's SHA256SUMS.txt, finding Java and Python, showing the
PitRelay license, choosing new folders, remembering the options of earlier installations, and running the
`claude plugin` commands after you agree.

Standard library only. Nothing from the PitRelay package is executed. Started by an older Python (macOS's own
python3 is 3.9), it looks for a newer one and runs itself with it, so this file avoids syntax that an older
Python cannot read.
"""
from __future__ import annotations

import argparse
import datetime
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import sysconfig
import threading
from pathlib import Path

BUNDLE = "pitrelay-claude-code-20261024-engine-fixes-1"
PACKAGE_DIR = "pitrelay-0.1.0-dev-20261024-engine-fixes-1"
# The fixed engine's package (ENGINE-FIXES-1), as built and verified by PitRelay's scripts/package_local.py.
MANIFEST_SHA256 = "e62f01a685dbd1783a1af9211bc49303fdf3fa093ed202e2faf89df2788b5723"
ENGINE_SHA256 = "a10fb14d720d46789dbfc4c5fc66ef1048ba329238d35ee7df3900e66a6b16f7"
LICENSE_SHA256 = "04bccdf9562964c3f6b9bd030f84a5d504a7c69910355400bfbfd4e3ec3878a4"
DISCLOSURE = "accepted-v1"
MARKETPLACE = "pitrelay-local"
PLUGIN = "pitrelay@pitrelay-local"
STATE_MARKER = "pitrelay-state.json"  # configure_claude.py's marker in a state folder it prepared
OS_METADATA = (".DS_Store", "Thumbs.db", "desktop.ini")  # files a file manager adds by itself

HERE = Path(__file__).resolve().parent
PLUGIN_SRC = HERE / "plugin"
PACKAGE = HERE / PACKAGE_DIR
LICENSE = PACKAGE / "docs" / "release" / "PITRELAY_LICENSE.md"


class Stop(Exception):
    pass


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def say(text: str = "") -> None:
    print(text, flush=True)


def ask(question: str, assume_yes: bool) -> bool:
    if assume_yes:
        say(f"{question} yes (--yes)")
        return True
    if not sys.stdin.isatty():
        say(f"{question} no: there is no terminal to answer in (pass --yes to answer yes).")
        return False
    return input(f"{question} [y/N] ").strip().lower() in ("y", "yes")


def absolute(p: str | Path) -> Path:
    """An absolute path, with ~ expanded and .. removed (configure_claude.py refuses relative ones)."""
    return Path(os.path.abspath(os.path.expanduser(str(p))))


def same_path(a: str | Path | None, b: str | Path | None) -> bool:
    if not a or not b:
        return False
    if os.path.exists(a) and os.path.exists(b):
        try:
            return os.path.samefile(a, b)
        except OSError:
            pass
    return os.path.normcase(str(absolute(a))) == os.path.normcase(str(absolute(b)))


def safe_which(name: str) -> str | None:
    """shutil.which, except that on Windows the current folder is never searched: Windows looks there first, so a
    java.exe that happens to sit in Downloads would otherwise win over the real one."""
    if os.name != "nt":
        return shutil.which(name)
    exts = [""] if os.path.splitext(name)[1] else \
        [e for e in os.environ.get("PATHEXT", ".COM;.EXE;.BAT;.CMD").split(os.pathsep) if e]
    for folder in os.environ.get("PATH", "").split(os.pathsep):
        folder = folder.strip().strip('"')
        if not folder or not os.path.isabs(folder):
            continue
        for ext in exts:
            candidate = os.path.join(folder, name + ext)
            if os.path.isfile(candidate):
                return candidate
    return None


def program(given: str, what: str) -> str:
    """A program named on the command line: a path (absolute, or with a folder in it), or a name on PATH."""
    expanded = os.path.expanduser(given)
    if os.path.isabs(expanded) or os.sep in given or (os.altsep and os.altsep in given):
        if absolute(given).is_file():
            return str(absolute(given))
        raise Stop(f"{what} {given}: no such file.")
    found = safe_which(given)
    if found:
        return str(absolute(found))
    raise Stop(f"{what} {given}: no such program.")


def wait_patiently(proc: subprocess.Popen, capture: bool = False, quiet: bool = False) -> tuple:
    """Wait for a child to finish even when Ctrl-C is pressed: the child gets the same Ctrl-C and cleans up
    (configure_claude.py removes what it created), and killing it would leave half-built folders behind. Output is
    read by a thread, so an interrupted wait loses none of it."""
    chunks = []
    reader = None
    if capture:
        reader = threading.Thread(target=lambda: chunks.append(proc.stdout.read()), daemon=True)
        reader.start()
    interrupted = False
    while True:
        try:
            proc.wait()
            if reader:
                reader.join()
            return proc.returncode, ("".join(chunks) if capture else None), interrupted
        except KeyboardInterrupt:
            if not interrupted and not quiet:
                say("\nInterrupted: waiting for setup to clean up after itself...")
            interrupted = True


def run_child(cmd: list, capture: bool = False, **kw) -> tuple:
    proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE if capture else None,
                            text=True, encoding="utf-8", errors="replace", **kw)
    return wait_patiently(proc, capture)


def default_base() -> Path:
    if os.name == "nt":
        local = os.environ.get("LOCALAPPDATA")
        return (Path(local) if local else Path.home() / "AppData" / "Local") / "PitRelayClaude"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "PitRelay for Claude Code"
    xdg = os.environ.get("XDG_DATA_HOME")
    return (Path(xdg) if xdg else Path.home() / ".local" / "share") / "pitrelay-claude"


def records_path(base: Path) -> Path:
    return base / "installs.json"


RECORD_KEYS = ("installed_at", "output", "state", "receipt_sha256")


def load_records(base: Path) -> list:
    path = records_path(base)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except (OSError, ValueError) as e:
        raise Stop(f"Cannot read {path}: {e}. Move it aside and run again.")
    if not isinstance(data, list) or not all(
            isinstance(r, dict) and all(isinstance(r.get(k), str) for k in RECORD_KEYS) for r in data):
        raise Stop(f"{path} is not this installer's record of installations. Move it aside and run again.")
    return data


def save_records(base: Path, records: list) -> None:
    tmp = records_path(base).with_suffix(".tmp")
    tmp.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, records_path(base))


WIN_PLAIN = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\\/:._-")


def shell_lines(argv: list) -> list:
    """argv as lines to paste into a terminal. On Windows a line that starts with a quoted path is an error in
    PowerShell and a leading & is one in Command Prompt, so a line needing quotes is given once for each."""
    if os.name != "nt":
        import shlex
        return [" ".join(shlex.quote(str(a)) for a in argv)]
    argv = [str(a) for a in argv]
    if all(a and set(a) <= WIN_PLAIN for a in argv):
        return [" ".join(argv)]
    ps = " ".join(a if a and set(a) <= WIN_PLAIN else "'" + a.replace("'", "''") + "'" for a in argv)
    cmd = " ".join(a if a and set(a) <= WIN_PLAIN else f'"{a}"' for a in argv)
    return [f"(PowerShell)      & {ps}", f"(Command Prompt)  {cmd}"]


def installer_copy(base: Path) -> Path:
    """The installer copy that later commands use. Run from the ZIP, that is its unpacked copy in an installer
    folder; run from a folder the person unzipped (Safari, Extract All), the verified files are copied into this
    installer folder first, so that tidying Downloads never breaks check and uninstall."""
    if unpacked():
        return HERE
    sums = HERE / "SHA256SUMS.txt"
    target = base / "downloads" / f"{BUNDLE}-{sha256(sums)[:12]}"
    try:
        if (target / ".unpacked").is_file():
            return target
        tmp = target.with_name(target.name + ".partial")
        if tmp.exists():
            shutil.rmtree(tmp)
        names = [line.split("  ", 1)[1] for line in sums.read_text(encoding="utf-8").splitlines() if "  " in line]
        for name in names + ["SHA256SUMS.txt"]:
            dest = tmp / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(HERE / name, dest)
        (tmp / ".unpacked").write_text(f"copied from {HERE}\n", encoding="utf-8")
        if target.exists():
            shutil.rmtree(target)
        os.replace(tmp, target)
        return target
    except OSError as e:
        say(f"(could not keep a copy of the installer in {target}: {e}; keep {HERE} for the commands below)")
        return HERE


def later_commands(copy: Path, *args: str) -> list:
    return shell_lines([sys.executable, str(copy / "install.py"), *args])


# ---------------------------------------------------------------- Python

MIN_PYTHON = (3, 10)
PYTHON_MINORS = (14, 13, 12, 11, 10)
# json.dumps writes ASCII, so the answer decodes the same whatever either Python's encoding is.
PROBE_PY = ("import json,sys,sysconfig;print(json.dumps([sys.version_info[0],sys.version_info[1],"
            "bool(sysconfig.get_config_var('Py_GIL_DISABLED')) or sys.implementation.name!='cpython',"
            "sys.executable]))")
HANDOVER = "PITRELAY_INSTALLER_HANDOVER"  # set for the Python this installer hands over to, so it never loops


def python_problem(version, unsupported_build, executable) -> str | None:
    """Why this Python cannot run the plugin (configure_claude.py refuses the same ones), or None."""
    if tuple(version[:2]) < MIN_PYTHON:
        return f"Python {version[0]}.{version[1]} is too old (3.10 or later is needed)"
    if unsupported_build:
        return "this Python is not a standard CPython build (free-threaded, or another implementation)"
    if os.name == "nt" and "windowsapps" in str(executable).lower():
        return "this is the Microsoft Store Python, whose path changes with every update"
    return None


def registered_windows_pythons() -> list:
    """python.exe of the CPythons registered per PEP 514 (python.org installers, the install manager)."""
    out = []
    try:
        import winreg
    except ImportError:
        return out
    roots = [(winreg.HKEY_CURRENT_USER, 0), (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_64KEY),
             (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_32KEY)]
    for hive, view in roots:
        try:
            company = winreg.OpenKey(hive, r"Software\Python\PythonCore", 0, winreg.KEY_READ | view)
        except OSError:
            continue
        i = 0
        while True:
            try:
                tag = winreg.EnumKey(company, i)
            except OSError:
                break
            i += 1
            try:
                ip = winreg.OpenKey(company, tag + r"\InstallPath")
                try:
                    exe = winreg.QueryValueEx(ip, "ExecutablePath")[0]
                except OSError:
                    exe = str(Path(winreg.QueryValueEx(ip, "")[0]) / "python.exe")
                out.append(exe)
            except OSError:
                continue
    return out


def python_candidates() -> list:
    """Commands that may start a suitable CPython, newest first."""
    out = []
    if os.name == "nt":
        py = safe_which("py")
        if py:
            out += [[py, f"-3.{m}"] for m in PYTHON_MINORS] + [[py]]
        local = os.environ.get("LOCALAPPDATA")
        if local:
            # The Python install manager (python.org's installer for 3.14 and later), then the classic installer.
            out += [[p] for p in sorted(glob.glob(str(Path(local) / "Python" / "pythoncore-3.*-64" / "python.exe")),
                                        reverse=True)]
            out += [[str(Path(local) / "Programs" / "Python" / f"Python3{m}" / "python.exe")] for m in PYTHON_MINORS]
        out += [[p] for p in registered_windows_pythons()]
        for pf in filter(None, (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"))):
            out += [[str(Path(pf) / f"Python3{m}" / "python.exe")] for m in PYTHON_MINORS]
        return out
    for m in PYTHON_MINORS:
        w = safe_which(f"python3.{m}")
        if w:
            out.append([w])
    if sys.platform == "darwin":
        for m in PYTHON_MINORS:
            out += [[f"/Library/Frameworks/Python.framework/Versions/3.{m}/bin/python3.{m}"],
                    [f"/opt/homebrew/bin/python3.{m}"], [f"/usr/local/bin/python3.{m}"]]
        out += [["/opt/homebrew/bin/python3"], ["/usr/local/bin/python3"]]
        out += [[p] for p in sorted(glob.glob(str(Path.home() / ".pyenv" / "versions" / "3.1*" / "bin" / "python3")),
                                    reverse=True)]
    w = safe_which("python3")
    # macOS's /usr/bin/python3 is Apple's 3.9, and without the Command Line Tools it opens an install dialog.
    if w and not (sys.platform == "darwin" and os.path.realpath(w).startswith("/usr/bin/")):
        out.append([w])
    return out


def probe_python(cmd: list) -> tuple | None:
    if len(cmd) == 1 and not Path(cmd[0]).is_file():
        return None
    env = {k: v for k, v in os.environ.items() if k not in ("PYTHONHOME", "PYTHONPATH", "__PYVENV_LAUNCHER__")}
    # The Windows install manager's py would otherwise offer to download a missing version.
    env.update(PYTHON_MANAGER_AUTOMATIC_INSTALL="false", PYTHON_MANAGER_CONFIRM="false")
    try:
        r = subprocess.run([*cmd, "-I", "-c", PROBE_PY], capture_output=True, timeout=60,
                           stdin=subprocess.DEVNULL, env=env)
        if r.returncode != 0:
            return None
        major, minor, unsupported, exe = json.loads(r.stdout.decode("ascii", "replace").strip().splitlines()[-1])
        return (int(major), int(minor)), bool(unsupported), str(exe)
    except (OSError, subprocess.SubprocessError, ValueError, TypeError, IndexError):
        return None


def python_help() -> str:
    if os.name == "nt":
        return ("Install Python from https://www.python.org/downloads/ (or run: winget install -e --id "
                "Python.Python.3.13 --scope user). Then open a new terminal and run this again with: py <this file>")
    if sys.platform == "darwin":
        return ("Install Python 3.12 from https://www.python.org/downloads/macos/ (or: brew install python@3.12), "
                "then run this again with: python3.12 <this file>")
    return ("Install Python 3.10 or later with your package manager (Ubuntu/Debian: sudo apt install python3 "
            "python3-venv; Fedora: sudo dnf install python3), then run this again.")


def ensure_python(argv: list) -> None:
    """Continue with this Python if it can run the plugin; otherwise run argv with a newer one, or stop."""
    problem = python_problem(sys.version_info, this_build_unsupported(), sys.executable)
    if not problem:
        return
    if os.environ.get(HANDOVER):
        print(f"Stopped: {problem}, also in the Python this installer handed over to.\n{python_help()}", flush=True)
        sys.exit(1)
    me = os.path.realpath(sys.executable)
    for cmd in python_candidates():
        found = probe_python(cmd)
        if not found or os.path.realpath(found[2]) == me or python_problem(*found):
            continue
        print(f"{problem}; continuing with Python {found[0][0]}.{found[0][1]} ({found[2]}).", flush=True)
        try:
            child = subprocess.Popen([found[2], *argv], env={**os.environ, HANDOVER: "1"})
        except OSError as e:
            print(f"Stopped: cannot start {found[2]}: {e}", flush=True)
            sys.exit(1)
        code, _, _ = wait_patiently(child, quiet=True)
        sys.exit(code)
    print(f"Stopped: {problem}, and no suitable Python was found on this computer.\n{python_help()}", flush=True)
    sys.exit(1)


def this_build_unsupported() -> bool:
    return bool(sysconfig.get_config_var("Py_GIL_DISABLED")) or sys.implementation.name != "cpython"


def check_python() -> None:
    problem = python_problem(sys.version_info, this_build_unsupported(), sys.executable)
    if problem:
        raise Stop(f"{problem} ({sys.executable}). {python_help()}")


# ---------------------------------------------------------------- the download

def unpacked() -> bool:
    return (HERE / ".unpacked").is_file()


def remove_os_metadata() -> list:
    """Finder, Explorer and copies to FAT drives add these by themselves (for example after the license folder
    was opened); configure_claude.py would refuse the package because of them, so they are removed first."""
    listed = set()
    sums = HERE / "SHA256SUMS.txt"
    if sums.is_file():
        listed = {line.split("  ", 1)[1] for line in sums.read_text(encoding="utf-8").splitlines() if "  " in line}
    removed = []
    for root in (PACKAGE, PLUGIN_SRC):
        for p in root.rglob("*"):
            if p.is_file() and (p.name in OS_METADATA or p.name.startswith("._")) \
                    and p.relative_to(HERE).as_posix() not in listed:
                p.unlink()
                removed.append(p.relative_to(HERE).as_posix())
    return removed


def check_download() -> None:
    """Every file of this download against SHA256SUMS.txt, and nothing extra in the PitRelay package."""
    again = (f"delete the folder {HERE} and run the ZIP again" if unpacked()
             else "unzip the download again into a new folder")
    sums = HERE / "SHA256SUMS.txt"
    if not sums.is_file():
        raise Stop(f"SHA256SUMS.txt is missing: {again}.")
    for name in remove_os_metadata():
        say(f"(removed {name}, a file the file manager added)")
    listed = {}
    for line in sums.read_text(encoding="utf-8").splitlines():
        if line.strip():
            digest, name = line.split("  ", 1)
            listed[name] = digest
    bad = [name for name, digest in sorted(listed.items())
           if not (HERE / name).is_file() or sha256(HERE / name) != digest]
    if bad:
        raise Stop(f"These files are missing or changed ({again}):\n  " + "\n  ".join(bad[:20]))
    extra = sorted(p.relative_to(HERE).as_posix() for p in PACKAGE.rglob("*")
                   if p.is_file() and p.relative_to(HERE).as_posix() not in listed)
    if extra:
        raise Stop(f"Unexpected files in the PitRelay package folder ({again}):\n  " + "\n  ".join(extra[:20]))
    if sha256(PACKAGE / "package-manifest.json") != MANIFEST_SHA256:
        raise Stop("package-manifest.json is not the published ENGINE-FIXES-1 manifest.")
    say(f"Download checked: {len(listed)} files match SHA256SUMS.txt.")


# ---------------------------------------------------------------- Java

MIN_JAVA = 17
JAVA_EXE = "java.exe" if os.name == "nt" else "java"


def java_major(exe: str) -> int | None:
    """The Java's major version from its java.specification.version ("1.8" is 8), or None if it does not run."""
    env = {k: v for k, v in os.environ.items() if k not in ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS")}
    try:
        r = subprocess.run([exe, "-XshowSettings:properties", "-version"], capture_output=True, text=True,
                           timeout=60, stdin=subprocess.DEVNULL, env=env, errors="replace")
    except (OSError, subprocess.SubprocessError):
        return None
    m = re.search(r"^\s*java\.specification\.version = (\d+)(?:\.(\d+))?\s*$", r.stderr + r.stdout, re.M)
    if r.returncode != 0 or not m:
        return None
    return int(m[2]) if m[1] == "1" and m[2] else int(m[1])


def _year_desc(paths: list) -> list:
    """WPILib folders are named for the season; newest first."""
    return sorted(paths, key=lambda p: [int(x) for x in re.findall(r"\d+", p)], reverse=True)


def java_candidates() -> list:
    """(where, path) of Javas on this computer, the person's own choice (JAVA_HOME, PATH) first."""
    out = []
    if os.environ.get("JAVA_HOME"):
        out.append(("JAVA_HOME", str(Path(os.environ["JAVA_HOME"]) / "bin" / JAVA_EXE)))
    on_path = safe_which("java")
    # macOS's /usr/bin/java is only a stub that may offer to install a JDK; java_home answers without it.
    if on_path and not (sys.platform == "darwin" and os.path.realpath(on_path) == "/usr/bin/java"):
        out.append(("PATH", on_path))
    home = Path.home()
    if sys.platform == "darwin":
        try:
            r = subprocess.run(["/usr/libexec/java_home", "-v", f"{MIN_JAVA}+"], capture_output=True, text=True,
                               timeout=30, stdin=subprocess.DEVNULL)
            if r.returncode == 0 and r.stdout.strip():
                out.append(("java_home", str(Path(r.stdout.strip()) / "bin" / "java")))
        except (OSError, subprocess.SubprocessError):
            pass
    if os.name == "nt":
        public = os.environ.get("PUBLIC") or r"C:\Users\Public"
        out += [("WPILib", p) for p in _year_desc(glob.glob(str(Path(public) / "wpilib" / "*" / "jdk" / "bin" / JAVA_EXE)))]
        for pf in filter(None, (os.environ.get("ProgramFiles"), os.environ.get("ProgramW6432"))):
            for vendor in ("Eclipse Adoptium", "Java", "Microsoft", "Zulu", "Amazon Corretto", "BellSoft",
                           "Eclipse Foundation", "OpenJDK", "Semeru"):
                out += [("installed", p) for p in sorted(glob.glob(str(Path(pf) / vendor / "*" / "bin" / JAVA_EXE)), reverse=True)]
    else:
        # WPILib up to 2026: ~/wpilib/<year>; from 2027: ~/.wpilib/<year> (macOS), ~/.local/share/wpilib/<year> (Linux).
        roots = [home / "wpilib", home / ".wpilib",
                 Path(os.environ.get("XDG_DATA_HOME") or home / ".local" / "share") / "wpilib"]
        found = []
        for root in roots:
            found += glob.glob(str(root / "*" / "jdk" / "bin" / "java"))
            found += glob.glob(str(root / "*" / "jdk" / "Contents" / "Home" / "bin" / "java"))
        out += [("WPILib", p) for p in _year_desc(found)]
        if sys.platform == "darwin":
            for root in ("/Library/Java/JavaVirtualMachines", str(home / "Library" / "Java" / "JavaVirtualMachines")):
                out += [("installed", p) for p in sorted(glob.glob(f"{root}/*/Contents/Home/bin/java"), reverse=True)]
            for brew in ("/opt/homebrew/opt", "/usr/local/opt"):
                out += [("Homebrew", p) for p in sorted(glob.glob(f"{brew}/openjdk*/bin/java"), reverse=True)]
        else:
            out += [("installed", p) for p in sorted(glob.glob("/usr/lib/jvm/*/bin/java"), reverse=True)]
            out += [("Homebrew", p) for p in sorted(glob.glob("/home/linuxbrew/.linuxbrew/opt/openjdk*/bin/java"), reverse=True)]
        out += [("SDKMAN", p) for p in sorted(glob.glob(str(home / ".sdkman" / "candidates" / "java" / "*" / "bin" / "java")), reverse=True)]
    seen, unique = set(), []
    for where, p in out:
        key = os.path.normcase(os.path.realpath(p))
        if key not in seen and Path(p).is_file():
            seen.add(key)
            unique.append((where, p))
    return unique


def java_help() -> str:
    if os.name == "nt":
        return ("Install Java 21, for example: winget install -e --id EclipseAdoptium.Temurin.21.JRE "
                "(or the installer from https://adoptium.net), then run this again.")
    if sys.platform == "darwin":
        return ("Install Java 21, for example the macOS .pkg from https://adoptium.net "
                "(or: brew install --cask temurin@21), then run this again.")
    return ("Install Java 17 or later, for example: sudo apt install openjdk-21-jre-headless (Ubuntu 22.04 or later, "
            "Debian 13), sudo apt install openjdk-17-jre-headless (Debian 12) or sudo dnf install "
            "java-21-openjdk-headless (Fedora), then run this again.")


def find_java(given: str | None, previous: str | None = None) -> str:
    if given:
        exe = program(given, "--java")
        major = java_major(exe)
        if major is None or major < MIN_JAVA:
            raise Stop(f"--java {given} is not a working Java {MIN_JAVA} or later "
                       f"({'it did not run' if major is None else f'it is Java {major}'}).")
        return exe
    candidates = java_candidates()
    if previous and Path(previous).is_file():
        candidates.insert(0, ("the earlier installation", previous))
    too_old = []
    for where, exe in candidates:
        major = java_major(exe)
        if major is not None and major >= MIN_JAVA:
            say(f"Java {major} found ({where}): {exe}")
            return str(absolute(exe))
        if major is not None:
            too_old.append(f"Java {major} at {exe}")
    old = f" Only older ones were found: {', '.join(too_old)}." if too_old else ""
    raise Stop(f"Java {MIN_JAVA} or later was not found.{old} {java_help()} Or pass --java <path to java>.")


# ---------------------------------------------------------------- license

def accept_license(given: str | None) -> str:
    actual = sha256(LICENSE)
    if actual != LICENSE_SHA256:
        raise Stop("The PitRelay license file is not the expected one.")
    if given:
        if given.lower() != actual:
            raise Stop(f"--accept-license does not match the license's SHA-256 ({actual}).")
        say("PitRelay license accepted with --accept-license.")
        return actual
    if not sys.stdin.isatty():
        raise Stop(f"There is no terminal to answer in. Read {LICENSE}, then run again with --accept-license {actual} "
                   "(in Git Bash on Windows, use PowerShell or Command Prompt instead).")
    say("=" * 78)
    say(LICENSE.read_text(encoding="utf-8").rstrip())
    say("=" * 78)
    if input('Type "accept" to accept the PitRelay license: ').strip().lower() != "accept":
        raise Stop("License not accepted; nothing was installed.")
    return actual


def accept_disclosure() -> None:
    """Workspace Access lets PitRelay read a folder: PitRelay's own disclosure, from the verified package, first."""
    code, out, _ = run_child([sys.executable, "-B", str(PLUGIN_SRC / "configure_claude.py"), "show-disclosure",
                              "--package", str(PACKAGE), "--manifest-sha256", MANIFEST_SHA256],
                             capture=True, cwd=str(PLUGIN_SRC))
    if code != 0:
        say(out or "")
        raise Stop("Cannot show PitRelay's Workspace Access disclosure.")
    say("=" * 78)
    say(out.rstrip())
    say("=" * 78)
    if not sys.stdin.isatty():
        raise Stop("Workspace Access needs its disclosure accepted at a terminal; run the installer interactively.")
    if input('Type "accept" to accept the Workspace Access disclosure: ').strip().lower() != "accept":
        raise Stop("Disclosure not accepted; nothing was installed.")


# ---------------------------------------------------------------- Claude Code

CMD_UNSAFE = set('"%!^&|<>()\r\n')  # characters Python cannot pass safely through a .cmd file to cmd.exe


def claude_version(exe: str) -> str | None:
    """'2.1.310 (Claude Code)' if exe is Claude Code's command line, else None."""
    try:
        r = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=60, stdin=subprocess.DEVNULL,
                           encoding="utf-8", errors="replace")
    except (OSError, subprocess.SubprocessError):
        return None
    out = (r.stdout or "").strip()
    return out if r.returncode == 0 and "Claude Code" in out else None


def claude_candidates() -> list:
    out = []
    if os.name == "nt" and os.environ.get("USERPROFILE"):
        out.append(str(Path(os.environ["USERPROFILE"]) / ".local" / "bin" / "claude.exe"))  # the native installer
    w = safe_which("claude")
    if w:
        out.append(w)
    if os.name == "nt" and os.environ.get("APPDATA"):  # npm's real binary, rather than its claude.cmd wrapper
        out.append(str(Path(os.environ["APPDATA"]) / "npm" / "node_modules" / "@anthropic-ai" / "claude-code" / "bin"
                       / "claude.exe"))
    # A .cmd or .bat wrapper only as a last resort; an older Claude desktop app's WindowsApps alias opens the app.
    out = [c for c in out if not (os.name == "nt" and "windowsapps" in c.lower())]
    return sorted(out, key=lambda c: c.lower().endswith((".cmd", ".bat")))


def find_claude(given: str | None) -> str | None:
    if given:
        exe = program(given, "--claude")
        if not claude_version(exe):
            raise Stop(f"--claude {given} is not Claude Code's command line (claude --version does not say so).")
        return exe
    for c in claude_candidates():
        if Path(c).is_file() and claude_version(c):
            return c
    return None


def claude_run(claude: str, *args: str, capture: bool = False) -> tuple:
    """(exit code, captured stdout or None)."""
    if claude.lower().endswith((".cmd", ".bat")) and any(CMD_UNSAFE & set(a) for a in args):
        raise Stop(f"{claude} is a .cmd wrapper, through which this path cannot be passed safely. Run the claude "
                   "command yourself, or install Claude Code with its native installer.")
    if not capture:
        say("$ claude " + " ".join(f'"{a}"' if " " in a else a for a in args))
    code, out, _ = run_child([claude, *args], capture=capture)
    return code, out


def claude_json(claude: str, *args: str):
    code, out = claude_run(claude, *args, "--json", capture=True)
    if code != 0:
        return None
    try:
        return json.loads(out or "null")
    except ValueError:
        return None


def registered_marketplace(claude: str | None) -> str | None:
    """The folder Claude Code has registered as pitrelay-local (an earlier installation), if any."""
    if not claude:
        return None
    data = claude_json(claude, "plugin", "marketplace", "list")
    items = data if isinstance(data, list) else (data or {}).get("marketplaces", []) if isinstance(data, dict) else []
    for m in items:
        if isinstance(m, dict) and m.get("name") == MARKETPLACE:
            return m.get("path") or m.get("installLocation") or ""
    return None


def plugin_installed(claude: str) -> bool | None:
    data = claude_json(claude, "plugin", "list")
    if not isinstance(data, list):
        return None
    return any(isinstance(p, dict) and p.get("id") == PLUGIN for p in data)


def claude_config_dir() -> Path:
    given = os.environ.get("CLAUDE_CONFIG_DIR")
    return absolute(given) if given else Path.home() / ".claude"


def read_settings() -> tuple:
    """(path, data) of Claude Code's user settings; stops on a file this installer cannot safely change."""
    path = claude_config_dir() / "settings.json"
    if not path.exists():
        return path, {}
    try:
        text = path.read_text(encoding="utf-8-sig")  # Claude Code accepts a leading BOM (Windows editors add one)
        data = json.loads(text) if text.strip() else {}
    except (OSError, ValueError) as e:
        raise Stop(f"{path} cannot be read as JSON ({e}), so it was not changed.")
    for key in ("extraKnownMarketplaces", "enabledPlugins"):
        if not isinstance(data, dict) or not isinstance(data.get(key, {}), dict):
            raise Stop(f"{path} has an unexpected layout, so it was not changed.")
    return path, data


def write_settings(path: Path, data: dict) -> None:
    """Replace the settings file's contents, keeping a link a link (dotfile managers) and the file's permissions
    (it may hold secrets), with a dated copy of the previous file beside it."""
    real = Path(os.path.realpath(path))
    try:
        real.parent.mkdir(parents=True, exist_ok=True)
        tmp = real.with_name(real.name + ".pitrelay-tmp")
        tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        if real.exists():
            backup = path.with_name(f"settings.json.before-pitrelay-{datetime.datetime.now():%Y%m%d-%H%M%S}")
            shutil.copy2(real, backup)
            shutil.copymode(real, tmp)
            say(f"(a copy of the previous settings: {backup})")
        os.replace(tmp, real)
    except OSError as e:
        raise Stop(f"Cannot write {path}: {e}")


def settings_entries() -> bool | None:
    """Whether PitRelay is declared in Claude Code's settings; None when the file cannot be read."""
    try:
        _, data = read_settings()
    except Stop:
        return None
    return MARKETPLACE in data.get("extraKnownMarketplaces", {}) or PLUGIN in data.get("enabledPlugins", {})


def settings_marketplace() -> str | None:
    """The folder Claude Code's settings say to load pitrelay-local from, if any."""
    try:
        _, data = read_settings()
    except Stop:
        return None
    source = data.get("extraKnownMarketplaces", {}).get(MARKETPLACE)
    path = source.get("source", {}).get("path") if isinstance(source, dict) and isinstance(source.get("source"), dict) else None
    return path if isinstance(path, str) else None


def add_to_settings(output: Path, assume_yes: bool) -> bool:
    """Without the claude command (for example only the desktop app): declare the plugin in Claude Code's user
    settings, exactly as `claude plugin marketplace add` and `install` record it; Claude Code loads a folder
    marketplace from there when a session starts."""
    path, data = read_settings()
    say(f"Instead, PitRelay can be added to Claude Code's settings file, {path}.")
    say("Claude Code, the desktop app included, loads it when a new session starts.")
    if not ask("Add it there?", assume_yes):
        return False
    data.setdefault("extraKnownMarketplaces", {})[MARKETPLACE] = {"source": {"source": "directory", "path": str(output)}}
    data.setdefault("enabledPlugins", {})[PLUGIN] = True
    write_settings(path, data)
    say(f"Added to {path}.")
    return True


def remove_from_settings(assume_yes: bool) -> bool:
    path, data = read_settings()
    if not ask(f"Remove PitRelay from Claude Code's settings file ({path})?", assume_yes):
        return False
    data.get("extraKnownMarketplaces", {}).pop(MARKETPLACE, None)
    data.get("enabledPlugins", {}).pop(PLUGIN, None)
    write_settings(path, data)
    return True


def print_manual(output: Path) -> None:
    say("To add PitRelay to Claude Code yourself, run these in a terminal:")
    say(f'  claude plugin marketplace add "{output}"')
    say(f"  claude plugin install {PLUGIN}")
    say("or type these into a Claude Code session in a terminal, one at a time:")
    # No quotes here: /plugin keeps the rest of the line as one path, and a quote would make it an invalid source.
    say(f"  /plugin marketplace add {output}")
    say(f"  /plugin install {PLUGIN}")


def claude_help() -> str:
    if os.name == "nt":
        return "PowerShell: irm https://claude.ai/install.ps1 | iex   (or: winget install Anthropic.ClaudeCode)"
    return "curl -fsSL https://claude.ai/install.sh | bash" + ("   (or: brew install --cask claude-code)"
                                                               if sys.platform == "darwin" else "")


def install_into_claude(claude: str | None, output: Path, assume_yes: bool, skip: bool) -> str | None:
    """How PitRelay was added to Claude Code ("cli" or "settings"), or None."""
    if skip:
        print_manual(output)
        return None
    if not claude:
        say("Claude Code's `claude` command was not found (the desktop app does not install it).")
        try:
            if add_to_settings(output, assume_yes):
                return "settings"
        except Stop as e:
            say(str(e))
        say("To use the command line instead, install it with: " + claude_help())
        print_manual(output)
        return None
    if claude.lower().endswith((".cmd", ".bat")) and CMD_UNSAFE & set(str(output)):
        say(f"Claude Code's command is the wrapper {claude}, and the plugin folder's path has characters that "
            "cannot be passed through it safely.")
        print_manual(output)
        return None
    code, out = claude_run(claude, "plugin", "validate", str(output / "pitrelay"), capture=True)
    if code != 0:
        say(out or "")
        raise Stop("Claude Code does not accept the prepared plugin (above), so your Claude Code settings were not "
                   "changed. Update Claude Code (claude update) and run this again.")
    previous = registered_marketplace(claude)
    say()
    say("Adding PitRelay changes your Claude Code settings:")
    if previous is not None:
        say(f"  claude plugin marketplace remove {MARKETPLACE}   (replaces the installation from {previous or 'elsewhere'})")
    say(f'  claude plugin marketplace add "{output}"')
    say(f"  claude plugin install {PLUGIN}")
    if not ask("Run these now?", assume_yes):
        say("Not added to Claude Code.")
        print_manual(output)
        return None
    if previous is not None:
        code, _ = claude_run(claude, "plugin", "marketplace", "remove", MARKETPLACE)
        if code != 0:
            raise Stop("Removing the earlier installation from Claude Code failed (above); it is still installed. "
                       "Nothing else was changed.")
    for args in (("plugin", "marketplace", "add", str(output)), ("plugin", "install", PLUGIN)):
        code, _ = claude_run(claude, *args)
        if code != 0:
            msg = "A `claude plugin` command failed (above). The prepared plugin is kept."
            if previous:
                msg += (f" The earlier installation was removed from Claude Code; to put it back, run:\n"
                        f'  claude plugin marketplace remove {MARKETPLACE}\n  claude plugin marketplace add "{previous}"\n'
                        f"  claude plugin install {PLUGIN}")
            raise Stop(msg + f"\nTo add the new one instead, run:\n  claude plugin marketplace add \"{output}\"\n"
                       f"  claude plugin install {PLUGIN}")
    return "cli"


# ---------------------------------------------------------------- commands

def claude_loads(claude: str | None) -> str | None:
    """The folder Claude Code loads pitrelay-local from: as registered with the claude command, else as declared
    in its settings file (an installation made without the claude command)."""
    return registered_marketplace(claude) or settings_marketplace()


def choose_base(a, claude: str | None) -> Path:
    """--folder; else the installer folder of the installation Claude Code loads; else the default."""
    if a.folder:
        return absolute(a.folder)
    loaded = claude_loads(claude)
    if loaded:
        parent = absolute(loaded).parent
        if records_path(parent).is_file():
            if not same_path(parent, default_base()):
                say(f"Using the installer folder of your earlier installation: {parent}")
            return parent
    return default_base()


def current_record(records: list, claude: str | None, receipt: str | None = None) -> dict | None:
    """The installation meant: the one with this receipt; else the one Claude Code loads; else the newest added."""
    if receipt:
        for r in reversed(records):
            if r["receipt_sha256"] == receipt.lower():
                return r
        raise Stop("No recorded installation has that receipt_sha256. Check the value, or pass --folder if you "
                   "installed into another folder.")
    loaded = claude_loads(claude)
    if loaded:
        for r in reversed(records):
            if same_path(r["output"], loaded):
                return r
    added = [r for r in records if r.get("added_to_claude")]
    return (added or records)[-1] if records else None


def check_state(a, state: Path, records: list) -> bool:
    """Whether to reuse an existing state folder; stops on one that cannot be reused."""
    if not state.exists():
        if a.reuse_state:
            raise Stop(f"--reuse-state: {state} does not exist.")
        return False
    if any(same_path(r.get("state"), state) for r in records) or a.reuse_state:
        if not (state / STATE_MARKER).is_file():
            raise Stop(f"{state} is not a PitRelay state folder (it has no {STATE_MARKER}).")
        say(f"Keeping the PitRelay state of your earlier installation (cases, artifacts): {state}")
        say("Close every Claude Code session that uses PitRelay before continuing.")
        if not ask("Continue?", a.yes):
            raise Stop("Nothing was changed.")
        return True
    if not (state / STATE_MARKER).is_file():
        raise Stop(f"{state} already exists, but holds no PitRelay state: probably an earlier attempt that was cut "
                   "off. Delete that folder and run this again, or pass --state <new folder>.")
    raise Stop(f"{state} is a PitRelay state folder that this installer did not make. Pass --reuse-state to keep "
               "using it, or --state <new folder>.")


def autostart(rec: dict, action: str) -> tuple:
    script = Path(rec["output"]) / "pitrelay" / "host" / "collector.py"
    py = rec.get("python")
    if not (py and rec.get("collector_store") and script.is_file() and Path(py).is_file()):
        return None, None
    return run_child([py, "-I", "-B", "-X", "utf8", str(script), "autostart", action], capture=True)[:2]


def login_item(records: list) -> tuple:
    """(enabled, the record that can still answer) for the background collector's login item, asked through the
    newest installation whose collector can still run; (None, None) if none can."""
    for r in reversed(records):
        code, out = autostart(r, "status")
        if code is None:
            continue
        try:
            return (bool(json.loads(out).get("enabled")) if code == 0 else None), r
        except (TypeError, ValueError, AttributeError):
            return None, r
    return None, None


def version_named_java(java: str) -> bool:
    """A Java in a folder named for its full version (Temurin's jre-21.0.5.11-hotspot) moves on every update."""
    return any(re.search(r"\d+\.\d+\.\d+", part) for part in Path(java).parent.parent.parts[-2:])


def cmd_install(a) -> int:
    check_python()
    check_download()
    claude = find_claude(a.claude)
    base = choose_base(a, claude)
    records = load_records(base)
    loaded = claude_loads(claude)
    if loaded and not any(same_path(r["output"], loaded) for r in records):
        say(f"Note: Claude Code now loads PitRelay from {loaded}, which this installer's folder {base} has no record "
            "of. It will be replaced, and its PitRelay state is not reused (to keep it: --state <that state folder> "
            "--reuse-state, or --folder <that installer folder>).")
    prev = current_record(records, claude) or {}
    prev_opts = prev.get("options") or {}

    workspace = absolute(a.workspace) if a.workspace else None
    grants = a.grants
    if workspace is None and not a.standard_access and prev_opts.get("workspace"):
        workspace, grants = absolute(prev_opts["workspace"]), a.grants or prev_opts.get("grants")
        say(f"Keeping Workspace Access to {workspace} ({grants}) from your earlier installation "
            "(pass --standard-access to drop it).")
    grants = grants or "project_read,propose"
    without_collector = a.without_collector or (not a.with_collector and bool(prev_opts.get("without_collector")))
    python = program(a.python, "--python") if a.python else (
        prev_opts.get("python") if prev_opts.get("python") and Path(prev_opts["python"]).is_file() else None)
    java = find_java(a.java, None if a.java else prev.get("java"))
    state = absolute(a.state) if a.state else (absolute(prev["state"]) if prev.get("state") else base / "state")
    reuse = check_state(a, state, records)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    if a.output:
        output = absolute(a.output)
        if output.exists():
            raise Stop(f"{output} already exists; the plugin folder must be new.")
    else:
        output, n = base / f"marketplace-{stamp}", 1
        while output.exists():
            n += 1
            output = base / f"marketplace-{stamp}-{n}"
    if without_collector and (a.wheelhouse or a.collector_store):
        raise Stop("--wheelhouse and --collector-store are for the collector, which this installation leaves out "
                   "(--without-collector, or an earlier installation without it: pass --with-collector).")
    for given, what in ((a.wheelhouse, "--wheelhouse"), (a.workspace, "--workspace")):
        if given and not absolute(given).is_dir():
            raise Stop(f"{what} {given}: no such folder.")
    license_sha = accept_license(a.accept_license)
    base.mkdir(parents=True, exist_ok=True)

    cmd = [sys.executable, "-B", str(PLUGIN_SRC / "configure_claude.py"),
           "--package", str(PACKAGE), "--manifest-sha256", MANIFEST_SHA256, "--accept-license", license_sha,
           "--java", java, "--state", str(state), "--output", str(output)]
    if python:
        cmd += ["--python", python]
    if reuse:
        cmd.append("--reuse-state")
    if without_collector:
        cmd.append("--without-collector")
    if a.wheelhouse:
        cmd += ["--wheelhouse", str(absolute(a.wheelhouse))]
    if a.collector_store:
        cmd += ["--collector-store", str(absolute(a.collector_store))]
    if workspace is not None:
        if a.workspace or prev_opts.get("workspace_disclosure") != DISCLOSURE:
            accept_disclosure()
        cmd += ["--workspace", str(workspace), "--workspace-disclosure", DISCLOSURE, "--grants", grants]
    say()
    say("Preparing the plugin: checking the package, Java and Python"
        + ("" if without_collector else ", and installing the collector's two Python packages") + ". About a minute...")
    code, out, interrupted = run_child(cmd, capture=True, cwd=str(PLUGIN_SRC))
    if interrupted:
        raise Stop("Interrupted. Setup removed what it had created; nothing was installed.")
    try:
        result = json.loads(out)
    except ValueError:
        say(out or "")
        raise Stop("Preparation failed (above).")
    if code != 0 or result.get("result") != "PASS":
        raise Stop("Preparation failed: " + str(result.get("error") or result.get("problems") or result))
    for w in result.get("warnings") or []:
        say(f"Warning: {w}")
    if result.get("engine_sha256") != ENGINE_SHA256:
        raise Stop("The prepared engine is not the ENGINE-FIXES-1 engine.")
    if result.get("java") and version_named_java(result["java"]):
        say(f"Warning: this Java's folder is named for its exact version ({result['java']}), so a Java update "
            "replaces it and PitRelay stops starting. After updating Java, run this installer again.")

    copy = installer_copy(base)
    record = {"installed_at": stamp, "bundle": BUNDLE, "output": result["marketplace_root"],
              "state": result["state"], "collector_store": result.get("collector_store"),
              "python": result.get("python"), "java": result.get("java"),
              "plugin_version": result.get("plugin_version"), "receipt_sha256": result["receipt_sha256"],
              "installer": str(copy / "install.py"), "added_to_claude": False,
              "options": {"workspace": str(workspace) if workspace is not None else None,
                          "grants": grants if workspace is not None else None,
                          "workspace_disclosure": DISCLOSURE if workspace is not None else None,
                          "without_collector": without_collector, "python": python}}
    records.append(record)
    save_records(base, records)
    say()
    say(f"Prepared: {record['output']}")
    say(f"  plugin version {record['plugin_version']}, Java {result.get('runtime_major')} ({result.get('java')})")
    say(f"  PitRelay state: {record['state']}")
    if record["collector_store"]:
        say(f"  collected logs: {record['collector_store']}")
    say(f"  receipt_sha256: {record['receipt_sha256']}")
    say("  Copy that receipt_sha256 into your own notes: verify --receipt-sha256 <it> detects later changes.")
    say("  Do not move or delete the prepared folder while PitRelay is installed: Claude Code loads it from there.")

    how = install_into_claude(claude, Path(record["output"]), a.yes, a.no_claude)
    added = how is not None
    if added:
        record["added_to_claude"] = True
        record["added_by"] = how
        save_records(base, records)
    say()
    if added:
        say("Done. Start a NEW Claude Code session and run /pitrelay:start"
            + ("." if without_collector else ", then /pitrelay:collect."))
    else:
        say("Prepared, but not added to Claude Code yet (see the commands above).")
    folder = ["--folder", str(base)] if a.folder else []
    say("Later, to check or uninstall it (paste one line into a terminal):")
    for line in later_commands(copy, "verify", "--receipt-sha256", record["receipt_sha256"], *folder):
        say(f"  check      {line}")
    for line in later_commands(copy, "uninstall", *folder):
        say(f"  uninstall  {line}")
    old = [r for r in records[:-1] if Path(r["output"]).exists() and not same_path(r["output"], record["output"])]
    if old and added:
        enabled, via = login_item(records[:-1])
        if enabled or any("starts at login" in w for w in result.get("warnings") or []):
            say("Background collection still starts an earlier installation's collector at login. Keep the earlier "
                "folders until you turn it on again in this installation (ask Claude: \"turn on background "
                "collection\") or turn it off with:")
            if via:
                for line in shell_lines([via["python"], "-I", "-B", "-X", "utf8",
                                         str(Path(via["output"]) / "pitrelay" / "host" / "collector.py"),
                                         "autostart", "disable"]):
                    say(f"  {line}")
            say("Then you can delete:")
        elif enabled is None and any(r.get("collector_store") for r in old):
            say("Whether background collection still starts an earlier installation at login could not be checked. "
                "If you turned it on, turn it on again in this installation before deleting:")
        else:
            say("Earlier prepared folders you can delete now:")
        for r in old:
            say(f"  {r['output']}")
    if result.get("older_python_environments"):
        say("Earlier Python environments in the state folder: " + ", ".join(result["older_python_environments"]))
    if result.get("older_python_environments_note"):
        say(f"  {result['older_python_environments_note']}")
    return 0


def remove_metadata_in(folder: Path) -> list:
    """Exact-name file-manager files (Finder's .DS_Store, Explorer's Thumbs.db and desktop.ini): nothing loads them,
    and verify would otherwise report a changed installation."""
    removed = []
    for p in folder.rglob("*"):
        if p.is_file() and p.name in OS_METADATA:
            p.unlink()
            removed.append(str(p))
    return removed


def cmd_verify(a) -> int:
    check_python()
    claude = find_claude(a.claude)
    base = choose_base(a, claude)
    rec = current_record(load_records(base), claude, a.receipt_sha256)
    if not rec:
        raise Stop(f"No installation recorded in {records_path(base)}. Pass --folder if you used another folder.")
    if Path(rec["output"]).is_dir():
        for p in remove_metadata_in(Path(rec["output"])):
            say(f"(removed {p}, a file the file manager added)")
    cmd = [sys.executable, "-B", str(PLUGIN_SRC / "configure_claude.py"), "verify", "--output", rec["output"],
           "--manifest-sha256", MANIFEST_SHA256]
    if a.receipt_sha256:
        cmd += ["--receipt-sha256", a.receipt_sha256]
    code, out, _ = run_child(cmd, capture=True, cwd=str(PLUGIN_SRC))
    try:
        result = json.loads(out)
    except ValueError:
        say(out or "")
        return 1
    ok = result.get("result") == "PASS" and code == 0
    files = f" ({result['files_verified']} files)" if result.get("files_verified") is not None else ""
    say(f"verify {rec['output']}: {result.get('result')}{files}")
    for p in result.get("problems") or []:
        say(f"  problem: {p}")
    if not a.receipt_sha256:
        receipt = Path(rec["output"]) / "prepared-installation.json"
        same = receipt.is_file() and sha256(receipt) == rec["receipt_sha256"]
        say(f"  receipt {'unchanged' if same else 'CHANGED'} since installation (compared with {records_path(base)})")
        ok = ok and same
        say("  This finds accidental changes. To detect deliberate ones, and to check the Java and Python it starts, "
            "pass --receipt-sha256 with the value from your notes.")
    if result.get("note"):
        say(f"  {result['note']}")
    return 0 if ok else 1


def cmd_uninstall(a) -> int:
    check_python()
    claude = find_claude(a.claude)
    base = choose_base(a, claude)
    records = load_records(base)
    rec = current_record(records, claude)
    if not rec:
        raise Stop(f"No installation recorded in {records_path(base)}. Pass --folder if you used another folder.")
    failed = False
    enabled, via = login_item(records)
    if enabled:
        say("Background collection starts at login.")
        if ask("Turn off launch at login now?", a.yes):
            code, out = autostart(via, "disable")
            say((out or "").strip() or f"autostart disable exited with {code}")
            failed |= code != 0
        else:
            failed = True
        say("A background collector that is running now keeps running until you log out, or until you stop it on "
            "its page.")
    elif enabled is None and any(r.get("collector_store") for r in records):
        say("Could not check whether background collection starts at login: no installation's collector can run "
            "any more. If you turned it on, remove its login item by hand.")
        failed = True
    declared = settings_entries()
    if declared is None:
        say(f"{claude_config_dir() / 'settings.json'} cannot be read, so PitRelay's entries in it (if any) were not "
            "removed.")
        failed = True
    if not claude:
        if declared:
            failed |= not remove_from_settings(a.yes)
        elif declared is False and rec.get("added_by") != "settings":
            say("`claude` was not found. Remove PitRelay from Claude Code with:\n"
                f"  claude plugin uninstall {PLUGIN}\n  claude plugin marketplace remove {MARKETPLACE}\n"
                f"or in a Claude Code session: /plugin uninstall {PLUGIN}, then /plugin marketplace remove {MARKETPLACE}")
            failed = True
        elif declared is False:
            say("PitRelay is not in Claude Code's settings.")
    else:
        steps = []
        if plugin_installed(claude) is not False:
            steps.append(("plugin", "uninstall", PLUGIN))
        if registered_marketplace(claude) is not None:
            steps.append(("plugin", "marketplace", "remove", MARKETPLACE))
        if not steps:
            say("PitRelay is not installed in Claude Code.")
        elif ask("Remove PitRelay from Claude Code (" + ", then ".join(" ".join(s[1:]) for s in steps) + ")?", a.yes):
            for s in steps:
                code, _ = claude_run(claude, *s)
                failed |= code != 0
        else:
            failed = True
        if not failed and settings_entries():
            failed |= not remove_from_settings(a.yes)
    config = claude_config_dir()
    say()
    say("Left on disk; delete them yourself when you no longer need them:")
    say(f"  Claude Code's cached copy of the plugin (contains the engine): {config / 'plugins' / 'cache' / MARKETPLACE}")
    for r in records:
        if Path(r["output"]).exists():
            say(f"  prepared plugin: {r['output']}")
    leftovers = set()
    for root in (base, default_base()):
        leftovers.update(glob.glob(str(root / "downloads" / "*")) + glob.glob(str(root / ".marketplace-*")))
    for d in sorted(leftovers):
        say(f"  unpacked download or leftover (contains the engine): {d}")
    say(f"  PitRelay state (cases, artifacts, reports): {rec['state']}")
    if rec.get("collector_store"):
        say(f"  collected logs (shared with the standalone collector): {rec['collector_store']}")
    if failed:
        say()
        say("PitRelay was NOT completely removed (see above).")
        return 1
    return 0


def cmd_doctor(a) -> int:
    """What the installer sees on this computer, to copy into a question or a bug report."""
    import platform
    say(f"System: {platform.platform()} ({platform.machine()})")
    problem = python_problem(sys.version_info, this_build_unsupported(), sys.executable)
    say(f"Python: {sys.version.split()[0]} at {sys.executable}" + (f" - {problem}" if problem else " - suitable"))
    for cmd in python_candidates():
        found = probe_python(cmd)
        if found:
            note = python_problem(*found)
            say(f"  also Python {found[0][0]}.{found[0][1]}: {found[2]}" + (f" - {note}" if note else ""))
    javas = java_candidates()
    for where, exe in javas:
        major = java_major(exe)
        say(f"Java ({where}): {exe} - " + ("does not run" if major is None else f"Java {major}"
                                            + ("" if major >= MIN_JAVA else " (too old)")))
    if not javas:
        say("Java: none found")
    try:
        claude = find_claude(a.claude)
    except Stop as e:
        claude = None
        say(f"claude: {e}")
    if claude:
        say(f"claude: {claude} - {claude_version(claude)}")
        say(f"  marketplace {MARKETPLACE}: {registered_marketplace(claude) or 'not registered'}")
        say(f"  plugin {PLUGIN}: {'installed' if plugin_installed(claude) else 'not installed'}")
    else:
        say("claude: not found")
    settings = claude_config_dir() / "settings.json"
    try:
        read_settings()
        say(f"Claude Code settings: {settings} - PitRelay "
            + ("declared there" if settings_entries() else "not declared there"))
    except Stop as e:
        say(f"Claude Code settings: {e}")
    base = choose_base(a, claude)
    try:
        records = load_records(base)
    except Stop as e:
        records = []
        say(str(e))
    say(f"Installer folder: {base} - {len(records)} installation(s) recorded")
    r = current_record(records, claude) if records else None
    if r:
        say(f"  in use: {r['installed_at']} {r.get('bundle')} -> {r['output']}"
            f" ({'added to Claude Code' if r.get('added_to_claude') else 'not added to Claude Code'})")
    return 0


def main(argv=None) -> int:
    try:
        sys.stdout.reconfigure(errors="replace")
    except (AttributeError, ValueError):
        pass
    p = argparse.ArgumentParser(prog="install.py", description="Install PitRelay for Claude Code from this download.")
    p.add_argument("command", nargs="?", default="install", choices=["install", "verify", "uninstall", "doctor"],
                   help="install (the default), verify, uninstall, or doctor (show what the installer finds)")
    p.add_argument("--version", action="version", version=f"{BUNDLE} (engine {ENGINE_SHA256[:12]})")
    p.add_argument("--yes", action="store_true", help="answer yes to the installer's questions (not the license)")
    p.add_argument("--folder", help=f"the installer's folder (default {default_base()})")
    p.add_argument("--claude", help="the claude command (default: from PATH)")
    g = p.add_argument_group("install")
    g.add_argument("--java", help="Java 17+ (default: JAVA_HOME, java on PATH, then WPILib's and other installed JDKs)")
    g.add_argument("--python", help="Python 3.10+ for the plugin (default: the one running this installer)")
    g.add_argument("--accept-license", metavar="SHA256", help="accept the PitRelay license without the prompt")
    g.add_argument("--state", help="PitRelay state folder (default <folder>/state, or the earlier installation's)")
    g.add_argument("--output", help="new folder for the prepared plugin (default <folder>/marketplace-<time>)")
    g.add_argument("--reuse-state", action="store_true", help="keep using an existing --state folder")
    g.add_argument("--collector-store", help="folder for collected logs (default: the standalone collector's)")
    c = g.add_mutually_exclusive_group()
    c.add_argument("--without-collector", action="store_true", help="engine only, no collector")
    c.add_argument("--with-collector", action="store_true", help="include the collector again after --without-collector")
    g.add_argument("--wheelhouse", help="install the collector's Python packages from this folder of wheels")
    w = g.add_mutually_exclusive_group()
    w.add_argument("--workspace", help="Workspace Access: a folder PitRelay may read (its disclosure is shown first)")
    w.add_argument("--standard-access", action="store_true", help="drop the Workspace Access of an earlier installation")
    g.add_argument("--grants", help="Workspace grants (default project_read,propose)")
    g.add_argument("--no-claude", action="store_true", help="prepare only; print the commands that add it to Claude Code")
    v = p.add_argument_group("verify")
    v.add_argument("--receipt-sha256", help="the receipt_sha256 from your notes")
    a = p.parse_args(argv)
    say(f"PitRelay for Claude Code installer, {BUNDLE}")
    try:
        code = {"install": cmd_install, "verify": cmd_verify, "uninstall": cmd_uninstall,
                "doctor": cmd_doctor}[a.command](a)
    except Stop as e:
        say()
        say(f"Stopped: {e}")
        code = 1
    except KeyboardInterrupt:
        say("\nInterrupted.")
        code = 130
    return code


if __name__ == "__main__":
    ensure_python([os.path.abspath(__file__), *sys.argv[1:]])
    sys.exit(main())
