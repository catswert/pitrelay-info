@echo off
rem PitRelay for Claude Code installer for Windows: double-click it in the unzipped folder.
rem Same as: py install.py [options]
if not exist "%~dp0install.py" (
  echo Unzip pitrelay-claude-code.zip first: right-click it, choose Extract All, then run install.cmd in that folder.
  echo Or, without unzipping: py pitrelay-claude-code.zip
  pause
  exit /b 1
)
where py >nul 2>nul
if %errorlevel%==0 (
  py "%~dp0install.py" %*
) else (
  python "%~dp0install.py" %*
)
set PITRELAY_EXIT=%errorlevel%
pause
exit /b %PITRELAY_EXIT%
